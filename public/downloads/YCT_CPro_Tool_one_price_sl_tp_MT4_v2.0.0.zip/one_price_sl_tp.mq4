//+------------------------------------------------------------------+
//|                                         CPro Tool one_price_sl_tp MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

input double ZEN = 0;
//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
      int total = OrdersTotal();
  for(int b=total-1;b>=0;b--)
  {
     if(OrderSelect(b, SELECT_BY_POS)==false) break;
     if(OrderCloseTime()!=0 || OrderSymbol()!=Symbol()) continue;
     if(OrderType()==OP_BUY)
       if(ZEN>0 && ZEN>Ask)
         if(OrderTakeProfit()>=0)
                 {
                 if(!OrderModify(OrderTicket(),OrderOpenPrice(),OrderStopLoss(),ZEN,0,clrNONE))
                        Print("Take Profit Updated TO New Level ",OrderTicket());
                    }
         if(ZEN>0 && ZEN<Bid)
         if(OrderStopLoss()>=0)
                 {
                 if(!OrderModify(OrderTicket(),OrderOpenPrice(),ZEN,OrderTakeProfit(),0,clrNONE))
                        Print("Stop Loss Updated TO New Level ",OrderTicket());
                    }
      if(OrderType()==OP_SELL)
       if(ZEN>0 && ZEN<Bid)
         if(OrderTakeProfit()>=0)
                 {
                 if(!OrderModify(OrderTicket(),OrderOpenPrice(),OrderStopLoss(),ZEN,0,clrNONE))
                        Print("Take Profit Updated TO New Level ",OrderTicket());
                    }
         if(ZEN>0 && ZEN>Ask)
         if(OrderStopLoss()>=0)
                 {
                 if(!OrderModify(OrderTicket(),OrderOpenPrice(),ZEN,OrderTakeProfit(),0,clrNONE))
                        Print("Stop Loss Updated TO New Level ",OrderTicket());
                    }
//---
  }
//+------------------------------------------------------------------+
  }
//+------------------------------------------------------------------+