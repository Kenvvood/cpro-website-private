//+------------------------------------------------------------------+
//|                                         CPro Indicator Grid MT5                          |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#define PREFIX "ger_grid_"
input int InpP1 = 30;//点数
input color InpColor = clrCyan;//颜色
input ENUM_LINE_STYLE InpStyle = STYLE_DOT; // Style
input int InpMaxBars = 10000;//均线x K线数
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    ObjectsDeleteAll(0, PREFIX);
    int bars = MathMin(Bars(NULL, 0), InpMaxBars);
    int imax = iHighest(NULL, 0, MODE_HIGH, bars);
    int imin = iLowest(NULL, 0, MODE_LOW, bars);
    double max = iHigh(NULL, 0, imax);
    double min = iLow(NULL, 0, imin);
    int s = (int) MathFloor(min / _Point);
    int e = (int) MathCeil(max / _Point);
    s -= s % InpP1;
    e -= e % InpP1;
    e += InpP1;
    for (int i = s; i <= e; i += InpP1) {
        double v = NormalizeDouble(i * _Point, _Digits);
        datetime t1 = iTime(NULL, 0, 0);
        datetime t2 = iTime(NULL, 0, 1);
        string name = PREFIX + DoubleToString(v, _Digits);
        ObjectCreate(0, name, OBJ_TREND, 0, t1, v, t2, v);
        ObjectSetInteger(0, name, OBJPROP_RAY_LEFT, true);
        ObjectSetInteger(0, name, OBJPROP_RAY_RIGHT, true);
        ObjectSetInteger(0, name, OBJPROP_COLOR, InpColor);
        ObjectSetInteger(0, name, OBJPROP_STYLE, InpStyle);
        ObjectSetInteger(0, name, OBJPROP_WIDTH, 1);
        ObjectSetInteger(0, name, OBJPROP_BACK, true);
        ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
    }
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
    ObjectsDeleteAll(0, PREFIX);
   CPro_Deinit();  // CPro营销模块清理
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    return(rates_total);
}
//+------------------------------------------------------------------+