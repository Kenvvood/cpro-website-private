//+------------------------------------------------------------------+
//|                                         CPro Tool auto_tp_multipled_by_sl MT4            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
//Works for Single symbol
//
extern string  SL_MUL = "<<< Multiplier value to set TP based on SL>>>";
extern double SL_Multiplier=4;//Profit Percentage
//
// Declare a function to set the profit target for open positions
void setProfitTarget()
  {
// Loop through all open positions
   for(int i = 0; i < OrdersTotal(); i++)
     {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
        {
         if(OrderType() == OP_BUY)
           {
            double takeProfitDistance=(OrderOpenPrice()-OrderStopLoss())*SL_Multiplier;
            // Set take profit to required distance
            bool result = OrderModify(OrderTicket(), OrderOpenPrice(), OrderStopLoss(), OrderOpenPrice()+takeProfitDistance, 0, Green);
            if(result)
              {
               Print("Profit target set for buy order ", OrderTicket());
              }
            else
              {
               //  Print("Failed to set profit target for buy order ", OrderTicket());
              }
           }
         //If sell
         if(OrderType() == OP_SELL)
           {
            double takeProfitDistance1=(OrderStopLoss()-OrderOpenPrice())*SL_Multiplier;
            // Set take profit to required distance
            bool result1 = OrderModify(OrderTicket(), OrderOpenPrice(), OrderStopLoss(), OrderOpenPrice()-takeProfitDistance1, 0, Green);
            if(result1)
              {
               Print("Profit target set for sell order ", OrderTicket());
              }
            else
              {
               // Print("Failed to set profit target for sell order ", OrderTicket());
              }
           }
        }
     }
  }
// Declare an event handler for the OnTick event
void OnTick()
  {
   setProfitTarget();
  }
//+------------------------------------------------------------------+