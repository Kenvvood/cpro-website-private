
//+------------------------------------------------------------------+
//|                 YCT Tool SP_Bao_Resistance_v1_mq5                  |
//|                         城诺科技                            |
//|                         WeChat: Lookee333                        |
//+------------------------------------------------------------------+


//+------------------------------------------------------------------+
//|                           Brand Panel                             |
//+------------------------------------------------------------------+
#include <mq5\Marketing.mqh>

// 品牌面板将在 OnInit() 中通过 InitMarketing() 初始化
// 品牌面板将在 OnDeinit() 中通过 DeinitMarketing() 清理

//+------------------------------------------------------------------+
//|                                          SP_Bao_Resistance_v1.mq5|
//|                       Copyright 2024, Singularity Partners Sarl. |
//|                               https://www.SingularityPartners.ch |
//+------------------------------------------------------------------+
   #property copyright "Copyright 2024, Singularity Partners Sarl."
   #property link      "https://www.SingularityPartners.ch"
   #property version   "1.0" 

//+------------------------------------------------------------------+
//|                  Input Variables                                 |
//+------------------------------------------------------------------+

   input group "Copyright 2024, www.SingularityPartners.ch "
   input double IL = 0.1; // IL Initial Lot
   input double SL = 0.05; // SL Stop Loss as Percent of Balance
   //input double TP = 0.03; // TP Take Profit as Percent of Balance
   input double TPP = 1000; // TPP Take Profit in Points
   input double SLP = 2600; // SLP Stop Loss in Points

   input group "Signal Inputs"
   input uint Period = 67; // Period iMA
   input uint Shift = 6; // Shift iMA


   input ENUM_MA_METHOD METHOD = MODE_LWMA;
   input ENUM_APPLIED_PRICE APPLIED_PRICE = PRICE_WEIGHTED;
   input uint CBA =9; // CBA CopyBufferAmount
   input uint EMAFirst = 2 ;  
   input uint EMASecond = 4 ;  


   input group "EXTRA Inputs"
   input int MAX_POSITION = 1; // Max Positions allowed to be openened
   input uint LIFE_SPAM_PROFITABLE = 12000; // Time limit for a proffitable position
   input uint LIFE_SPAM_NON_PROFITABLE = 10000; // Time limit for a NON proffitable position
   input uint BAR_NUM = 20; // Number of bar to calculate (MIN 2 Not Checked)

   //Include Files
   #include<Trade/Trade.mqh>
   CTrade trade; //Trade Class

   // Include the HashMap library
   #include <Generic/HashMap.mqh>
   // A HashMap to store the time when a position started to be profitable
   CHashMap<ulong, datetime> profitStartTime;
   // A HashMap to store the time when a position started to be unprofitable
   CHashMap<ulong, datetime> lossStartTime;

   // Variables Definitions
   bool signal;
   bool CS; // Close Shorts
   bool CL; // Close Longs
   int LT; // Counter of Long Trades
   int ST; // Counter of Short Trades
   int T; // Counter of Total Trades
   int L; // Code Line
   double EMAArray[];

   // Current prices
   double ask;
   double bid;

   // Account information
   double balance;
   double equity;
   double profit;

  // Dashboard info
  input group "Dashboard"
  input int maxLines = 14;


  // Resistance and Support
  int distanceToCurrentBar = 1;
  
  double max1;
  int maxIndex1;
  double max2;
  int maxIndex2;

  int startTime;
  int currentTime;

  double startValue;
  double currentResistance;

  datetime futureTime; 
  double futureResistance;

  double slope;

  double support;

  datetime lastBarTime;


//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
   int OnInit() {
      return(INIT_SUCCEEDED);
   }

//+------------------------------------------------------------------+
//|                  Expert Tester Function                          |
//+------------------------------------------------------------------+
// This function is to calculate CUSTOM CRITERIA for OPTIMIZATION. 
   
   // The modified code calculates the relative drawdown (RDD) and ... (UR) for optimization purposes in a trading expert advisor. 
   // It uses the TesterStatistics function to retrieve relevant statistics from the backtesting results. 
   // The UR is calculated as the ratio of the sum of profit and initial deposit 
   // to a denominator based on the initial deposit, RDD, and a constant factor. 
   // The UR and RDD are then concatenated into a string and converted back to a double for return.
   double OnTester() {  
         // Calculate REALTIVE DRAWDOWN
         double RDD = TesterStatistics(STAT_EQUITY_DDREL_PERCENT); 

         // Calculate NUMERATOS as the SUM of PROFIT and INITIAL DEPOSIT
         double numerator = TesterStatistics(STAT_PROFIT) + TesterStatistics(STAT_INITIAL_DEPOSIT);

         // Calculate denominator based on initial deposit, RDD and a constant factor
         int month = 60;
         double denominator = TesterStatistics(STAT_INITIAL_DEPOSIT) * month/12 * RDD * 0.01; 

         // Calculate UR as the ratio of Numerator and Denominator
         double UR = numerator / denominator;

         // Convert UR and RDD to strings and concatenate them
         string concatenatedString = DoubleToString(UR, 0) + "." + DoubleToString(RDD, 0); 

         // Convert the concatenated string back to double and return
         return StringToDouble(concatenatedString);
   }
 
//+------------------------------------------------------------------+
//|                  Expert Tick Function                            |
//+------------------------------------------------------------------+
// Special event handler that is called every time a new quote is received for the symbol the Expert Advisor (EA).
// It's triggered EVERY TIME THE PRICE CHANGES (a new "tick" is received).
   void OnTick() {

      UpdateInformation();

      // Count current trades
      CountTrades();


      CalculateSignal();

      // Check current position and stop loss
      CheckPosition();
      CheckStopLoss();

      // Attempt to open long and short positions
      OpenLongs();
      OpenShorts();

      // Attempt to close long and short positions
      CloseLongs();
      CloseShorts();

      CalculateResistance();

      // Calculate and draw the support line
      CalculateSupport();

      DrawVerticalLineLimiter();
      // Print dashboard information
      PrintDashboard();
   }

//+------------------------------------------------------------------+
//|                  Longs Shorts Counter                            | 
//+------------------------------------------------------------------+
// Function to count operations
   void CountTrades() {
      // Initializes the long (LT), short (ST), and total (T) counters to 0
      LT=0; ST=0; T=0;

      // Go through all open positions
      for(int i = 0; i < PositionsTotal(); i++)
      {
         // Get the ticket for the position
         ulong ticket = PositionGetTicket(i);
         // Select the position by its ticket
         PositionSelectByTicket(ticket);

         // If the position is long (buy)
         if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
         {
               // Increment the long operations counter
               LT ++;
         }
         // If the position is short (sell)
         else if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_SELL)
         {
               // Increment the short operations counter
               ST ++;
         }
         // Updates the total trade counter by adding the long and short trades
         T=(LT+ST);   
      }
   }

//+------------------------------------------------------------------+
//|                  Sensing                                         |
//+------------------------------------------------------------------+
   void CalculateSignal() {
      // The iMA() function is used to calculate the exponential moving average (EMA) of the closing price (PRICE_CLOSE)
      // for a specific number of periods (Period) and a shift (Shift) in the current symbol and time period.
      // The EMA calculation method is specified by the METHOD variable.
      int EMA = iMA(_Symbol, _Period, Period, Shift, METHOD, PRICE_CLOSE);

      // ArraySetAsSeries() is used to set EMAArray as a series, which means that new data is added to the beginning of the array.
      // This is useful when working with time series data, since the most recent data is usually the most relevant.
      ArraySetAsSeries(EMAArray, true);

      // CopyBuffer() is used to copy the values ​​from the EMA to the EMAArray array. The parameters are:
      // - EMA: the identifier of the technical indicator, which in this case is the EMA.
      // - 0: the index of the indicator buffer (0 because the EMA only has one buffer).
      // - 0: The index of the first element to copy.
      // - CBA: the number of elements to copy.
      // - EMAArray: the array to which the data will be copied.
      CopyBuffer(EMA, 0, 0, CBA, EMAArray);

      // The function then checks if the first EMA is greater than the second EMA.
      if(EMAArray[EMAFirst] > EMAArray[EMASecond]) {
         // If so, set the signal variable to 0, indicating a buy signal.
         signal = 0;
         
         L = __LINE__;
         //Print("Señal de compra generada en la línea: ", L);
      }

      // The function then checks if the first EMA is less than the second EMA.
      if(EMAArray[EMAFirst] < EMAArray[EMASecond]) {
         // If so, set the signal variable to 1, indicating a sell signal.
         signal = 1;
         
         L = __LINE__;
         //Print("Señal de venta generada en la línea: ", L);
      }
   }

//+------------------------------------------------------------------+
//|                  Control                                         |
//+------------------------------------------------------------------+
   // Function to verify and activate the stop loss
   void CheckStopLoss() {
      // Calculates the stop loss limit as the balance minus a percentage of the balance (SL)
      double stopLossLimit = balance * (1 - SL);

      // If stop loss has not been activated for long positions (CL == 0), there is at least one long position (LT >= 1)
      // and the equity is less than the stop loss limit, then activate the stop loss for long positions
      if(!CL && LT >= 1 && equity < stopLossLimit) {
         CL = 1; // Activate stop loss for long positions
         L = __LINE__; // Save the current line of code
         // Print a message indicating that the stop loss has been activated for long positions
         Print("------- Stop loss activado para posiciones largas. L: ", L); 
      }

      // If the stop loss for short positions has not been activated (CS == 0), there is at least one short position (ST >= 1)
      // and the equity is less than the stop loss limit, then activate the stop loss for short positions
      if(!CS && ST >= 1 && equity < stopLossLimit) {
         CS = 1; // Activate stop loss for short positions
         L = __LINE__; // Save the current line of code
         
         // Print a message indicating that the stop loss has been activated for short positions
         Print("------- Stop loss activado para posiciones cortas. L: ", L);
      }
   }
//+------------------------------------------------------------------+
//|                  ACTUATION                                       |
//+------------------------------------------------------------------+

   //+------------------------------------------------------------------+
   //|                  Check Position Profit                           | 
   //+------------------------------------------------------------------+
   // Function to check and store position depending of the profit and time
   void CheckPosition() {
      // Check if any open position has been profitable for a certain amount of time
      for(int i = 0; i < PositionsTotal(); i++)
      {
         ulong ticket = PositionGetTicket(i);
         PositionSelectByTicket(ticket);

         double positionProfit = PositionGetDouble(POSITION_PROFIT);
         if(positionProfit > 0) // if the position is profitable
         {
               if(!profitStartTime.ContainsKey(ticket)) // if this is the first time this position is profitable
               {
                  // Store the current time as the start time of the profit
                  profitStartTime.Add(ticket, TimeCurrent());
               }
               else // if this position has been profitable before
               {
                  // Check if the position has been profitable for more than X time
                  datetime positionStartTime;
                  profitStartTime.TryGetValue(ticket, positionStartTime);
                  if(TimeCurrent() - positionStartTime > LIFE_SPAM_PROFITABLE) // Replace variable input with the desired amount of time
                  {
                     // If so, close the position
                     trade.PositionClose(ticket);
                     // And remove the ticket from the HashMap
                     profitStartTime.Remove(ticket);
                  }
               }
               // If the position was previously unprofitable, remove it from the HashMap
               if(lossStartTime.ContainsKey(ticket))
               {
                  lossStartTime.Remove(ticket);
               }
         }
         else // if the position is not profitable
         {
               if(!lossStartTime.ContainsKey(ticket)) // if this is the first time this position is unprofitable
               {
                  // Store the current time as the start time of the loss
                  lossStartTime.Add(ticket, TimeCurrent());
               }
               else // if this position has been unprofitable before
               {
                  // Check if the position has been unprofitable for more than X time
                  datetime positionStartTime;
                  lossStartTime.TryGetValue(ticket, positionStartTime);
                  if(TimeCurrent() - positionStartTime > LIFE_SPAM_NON_PROFITABLE) // Replace variable input with the desired amount of time
                  {
                     // If so, close the position
                     trade.PositionClose(ticket);
                     // And remove the ticket from the HashMap
                     lossStartTime.Remove(ticket);
                  }
               }
         }
      }
   }
   //+------------------------------------------------------------------+
   //|                  Resistance Functions                            | 
   //+------------------------------------------------------------------+
   
    void CalculateResistance(){

        datetime currentBarTime = iTime(_Symbol, _Period, 0);

        if (currentBarTime != lastBarTime) {

            lastBarTime = currentBarTime;
            
            CalculateSlope();
            CalculateCurrentResistance();

            // Draw the resistance line
            DrawResistanceTrendLine();
        }
    }
   
    void CalculateSlope() {
        // Define an array to store the high prices
        double highPrices[];
        // Set the array as a series
        ArraySetAsSeries(highPrices, true);
        // Copy the high prices of the last 20 bars to the array
        CopyHigh(_Symbol, _Period, distanceToCurrentBar, 20, highPrices);

        // Start from the last index
        maxIndex1 = 19;
        max1 = highPrices[maxIndex1];

        // Find a slope that isn't broken by any other index
        for (int i = maxIndex1 - 1; i >= 0; i--) {
            double potentialSlope = (highPrices[i] - max1) / ( maxIndex1 - i);
            bool slopeBroken = false;

            for (int j = i - 1; j >= 0; j--) {
                if (highPrices[j] > max1 + potentialSlope * (maxIndex1 - j)) {
                    slopeBroken = true;
                    break;
                }
            }

            if (!slopeBroken) {
                maxIndex2 = i;
                max2 = highPrices[i];
                slope = potentialSlope;
                break;
            }
        }
    }


    void CalculateCurrentResistance(){

        int startIndex = maxIndex1 > maxIndex2 ? maxIndex1 : maxIndex2;
        startValue = maxIndex1 > maxIndex2 ? max1 : max2;

        startTime = int(iTime(_Symbol, _Period, startIndex + distanceToCurrentBar));

        currentTime = int(iTime(_Symbol, _Period, 0));

        double barsToCurrent = startIndex + distanceToCurrentBar;
        double slopeIncreasedBy = slope * barsToCurrent;
        currentResistance = startValue + slopeIncreasedBy;

        int futureBars = 5;
        futureTime = currentTime + futureBars * PeriodSeconds(); 
        futureResistance = currentResistance + slope * futureBars;

    }

    // Function to draw a horizontal line at the resistance level
    void DrawResistanceTrendLine() {
        // Create the trendline
        string trendlineName = "ResistanceTrendline";
        ObjectDelete(0, trendlineName);

        if (!ObjectCreate(0, trendlineName, OBJ_TREND, 0, startTime, startValue, futureTime, futureResistance)) {
            Print("Failed to create trendline. Error code: ", GetLastError());
            return;
        }

        // Set the properties of the trendline
        ObjectSetInteger(0, trendlineName, OBJPROP_COLOR, clrYellow);  // Set the color to red
        ObjectSetInteger(0, trendlineName, OBJPROP_WIDTH, 2);  // Set the width to 2
        ObjectSetInteger(0, trendlineName, OBJPROP_STYLE, STYLE_SOLID);  // Set the style to solid
    }

   //+------------------------------------------------------------------+
   //|                  Support Functions                               | 
   //+------------------------------------------------------------------+
    // Function to calculate and draw the support line
    void CalculateSupport(){
      // Define an array to store the low prices
      double lowPrices[];
      // Set the array as a series
      ArraySetAsSeries(lowPrices, true);
      // Copy the low prices of the last 20 bars to the array
      CopyLow(_Symbol, _Period, 0, 20, lowPrices);

      // Find the minimum in the array
      int minIndex = ArrayMinimum(lowPrices, 0, 20);
      support = lowPrices[minIndex];

      // Draw the support line
      DrawSupportHorizontalLine();
    }

    // Function to draw a horizontal line at the support level
   void DrawSupportHorizontalLine() {
      // Delete the old support line if it exists
      ObjectDelete(_Symbol, "SupportHorizontalLine");

      // Get the time of the current bar
      datetime currentBarTime = iTime(_Symbol, _Period, 0);

      // Create a horizontal line at the support level
      ObjectCreate(0, "SupportHorizontalLine", OBJ_HLINE, 0, currentBarTime, support);

      // Set the properties of the support line
      ObjectSetInteger(0, "SupportHorizontalLine", OBJPROP_COLOR, clrMagenta);
      ObjectSetInteger(0, "SupportHorizontalLine", OBJPROP_WIDTH, 2);
   }

   //+------------------------------------------------------------------+
   //|                  Vertical Visual Line                            | 
   //+------------------------------------------------------------------+
    // Function to draw a visual vertical line to limit the bar
   void DrawVerticalLineLimiter(){

      string lineName = "VerticalLineAtBar20";
      ObjectDelete(0, lineName); 
      datetime timeForBar20 = iTime(_Symbol, _Period, 20 + distanceToCurrentBar);
      ObjectCreate(0, lineName, OBJ_VLINE, 0, timeForBar20, 0);
      ObjectSetInteger(0, lineName, OBJPROP_COLOR, C'0,255,136');
      ObjectSetInteger(0, lineName, OBJPROP_WIDTH, 5);
   }
//+------------------------------------------------------------------+
//|                  OPENING LONGS                                   |
//+------------------------------------------------------------------+
// Function to open long positions
   void OpenLongs() {
      // If the signal is 0 (indicating a buy signal) and there are no other open positions
      if(signal == 0 && PositionsTotal() < MAX_POSITION) {
         // Calculate the stop loss and take profit
         double stopLoss = ask - SLP * _Point;
         double takeProfit = ask + TPP * _Point;
         // Open a long position
         trade.Buy(IL, NULL, ask, stopLoss, takeProfit, NULL);
         L = __LINE__; // Save the current line of code
         
         // Print a message indicating that a long position has been opened
         Print("\n Se ha abierto una posición larga \n");
      }
   }

//+------------------------------------------------------------------+
//|                  OPENING SHORTS                                  |
//+------------------------------------------------------------------+
// Function to open short positions
   void OpenShorts() {
      // If the signal is 1 (indicating a sell signal) and there are no other open positions
      if(signal == 1 && PositionsTotal() < MAX_POSITION) {
         // Calculate the stop loss and take profit
         double stopLoss = bid + SLP * _Point;
         double takeProfit = bid - TPP * _Point;
         // Open a short position
         trade.Sell(IL, NULL, bid, stopLoss, takeProfit, NULL);
         L = __LINE__; // Save the current line of code
         
         // Print a message indicating that a short position has been opened
         Print("\n Se ha abierto una posición corta \n");
      }
   }


//+------------------------------------------------------------------+
//|                  CLOSING LONGS                                   |
//+------------------------------------------------------------------+
// Function to close long positions
   void CloseLongs() {
      // If the stop loss has been activated for long positions (CL == 1)
      if(CL==1)
      {
         // Go through all open positions
         for(int i=PositionsTotal()-1;i>=0; i--)
         {
               // Get the ticket for the position
               ulong ticket=PositionGetTicket(i);
               PositionSelectByTicket(ticket);
               // If the position is long
               if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
               {   
                  // Close the position
                  trade.PositionClose(ticket); 
               }
         }
         // Disable stop loss for long positions
         CL=0;
         L=__LINE__; // Save the current line of code
         
         // Prints a message indicating that the closing of long positions has been confirmed
         Print("CL=1 CONFIRMED. L:",__LINE__);
      }
   }


//+------------------------------------------------------------------+
//|                  CLOSING SHORTS                                  |
//+------------------------------------------------------------------+
// Function to close short positions
   void CloseShorts() {
      // If the stop loss has been activated for short positions (CS == 1)
      if(CS==1)
      {
         // Go through all open positions
         for(int i=PositionsTotal()-1; i>=0; i--)
         {
               // Get the ticket for the position
               ulong ticket2=PositionGetTicket(i);
               PositionSelectByTicket(ticket2);
               // If the position is short
               if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_SELL) 
               {   
                  // Close the position
                  trade.PositionClose(ticket2);
               }
         }
         // Disable stop loss for short positions
         CS=0;
         L=__LINE__; 
         Print("CS=1 CONFIRMED. L:",__LINE__); 
      }
   }




//+------------------------------------------------------------------+
//|                  DASHBOARD                                       |
//+------------------------------------------------------------------+
// Custom Dashboard
   void PrintDashboard() {

      // Split the commentText into lines
      string commentText = GetComment();

      string lines[];
      StringSplit(commentText, '\n', lines);

      SetBackgroundLabel(ArraySize(lines));
      SetTextLabel(lines);

   }

   string GetComment(){

      return "\n" +
      "© Singularity Partners 2024" + "\n" +
      "CODE LINE:  " + L + "\n" +
      "\n" +
      "------- ACCOUNT ----------------\n" +
      "Balance:   " + StringFormat("%9.0f", balance) + "\n" +
      "Equity:       " + StringFormat("%9.0f", equity) + "\n" +
      "Profit:         " + StringFormat("%9.0f", profit) + "\n" +
      "----------------------------------------\n"
      "\n" +
      "------- USEFULL -----------------\n" +
      "LT: " + LT + " ST: " + ST + " T:" + PositionsTotal() + "\n" +
      "CL: " + CL + " CS: " + CS + "\n" +
      "----------------------------------------\n"
      "\n" +
      "------- SIGNAL -------------------\n" +
      "Signal:    " + signal + "\n" +
      "EMAFirst:" + NormalizeDouble(EMAArray[EMAFirst],_Digits) + "\n" + 
      "EMASecond:" + NormalizeDouble(EMAArray[EMASecond],_Digits) + "\n" +
      "--------------------------------------\n"
      "\n" +
      "------- TICKET ------------------\n" +
      AllTicketToString() +
      "-------------------------------------\n"
      "\n" +
      "\n" +
      "\n" +
      "------- Resistance ---------------\n" +
      "Index 1: " + maxIndex1 + " Max 1: " + max1 + "\n" +
      "Index 2: " + maxIndex2 + " Max 2: " + max2 + "\n" + 
      "Slope: " + slope + "\n" +
      "Index Start: " + ((maxIndex1 > maxIndex2 ? maxIndex1 : maxIndex2) + distanceToCurrentBar) + "\n" +
      "Start Time: " + startTime + "\n" +
      "Start Value: " + startValue + "\n" +
      "CurrentTime = " + currentTime + "\n" +
      "CurrentResistance = " + currentResistance + "\n" +
      "-------------------------------------\n"
      ;

   }

   string AllTicketToString() {

      if (PositionsTotal() == 0) return "\nNO OPEN POSITIONS\n\n";

      string result = "";

      for(int i = 0; i < PositionsTotal(); i++){
         ulong ticket = PositionGetTicket(i);
         PositionSelectByTicket(ticket);
         
         // Get the profit of the position
         double ticketProfit = PositionGetDouble(POSITION_PROFIT);
         
         // Calculate the time the position has been open in seconds
         ulong openTimeInSeconds = TimeCurrent() - PositionGetInteger(POSITION_TIME);
         
         // Calculate the remaining time before the position is closed
         // ulong remainingTime = 12000 - openTimeInSeconds;
                        
         result += StringFormat("Ticket: %5d\nProfit: %6s\nOpen Time : %8d(s)\n", 
                        ticket, ticketProfit < 0 ? "- " + DoubleToString(MathAbs(ticketProfit) , 2) : "+ " + DoubleToString(ticketProfit , 2) , 
                        openTimeInSeconds);                      
                              
      }
      return result;
   }

   void SetBackgroundLabel(int lenght){
      // Create a single rectangle for all lines
      string allLinesRectObjName = "RectangleAllLines";

      int row = lenght / maxLines;

      // Create the rectangle
      if (ObjectCreate(0, allLinesRectObjName, OBJ_RECTANGLE_LABEL, 0, 0, 0)) {
      // Set the rectangle's coordinates
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_CORNER, CORNER_LEFT_UPPER);
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_XDISTANCE, 10);
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_YDISTANCE, 20);  // Start from the top

         // Set the rectangle's size
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_XSIZE, 200 + 200 * row);  // Adjust the width as needed
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_YSIZE, 20 * maxLines);  // Height is line height times number of lines

         // Set the rectangle's color
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_COLOR, clrBlack);  // Change clrBlack to your desired color

         // Set the rectangle's background color
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_BGCOLOR, clrBlack);  // Change clrBlack to your desired color

         // Set the rectangle's z-order to be below the labels
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_ZORDER, 0);
      } else {
         Print("Failed to create rectangle. Error code: ", GetLastError());
      }
   }

   void SetTextLabel(string &lines[]){
      // Create a label for each line
      for (int i = 0; i < ArraySize(lines); i++) {
        string lineObjName = "DashBoardLabel" + IntegerToString(i);

        // Calculate the column and row for this label
        int column = i / maxLines;
        int row = i % maxLines;

        // Create the label
        if (ObjectCreate(0, lineObjName, OBJ_LABEL, 0, 0, 0)) {
            // Set the label's coordinates
            ObjectSetInteger(0, lineObjName, OBJPROP_CORNER, CORNER_LEFT_UPPER);
            ObjectSetInteger(0, lineObjName, OBJPROP_XDISTANCE, 10 + column * 200);  // Adjust the X distance for each column
            ObjectSetInteger(0, lineObjName, OBJPROP_YDISTANCE, 20 + row * 20);  // Adjust the Y distance for each row

            // Set the label's text
            ObjectSetString(0, lineObjName, OBJPROP_TEXT, "      " + lines[i]);

            // Set the label's color
            color labelColor = C'0,255,191';
            if (StringFind(lines[i], "-------") == 0) {
              labelColor = C'255,165,0';
            }
            ObjectSetInteger(0, lineObjName, OBJPROP_COLOR, labelColor);  

            // Set the label's font size
            ObjectSetInteger(0, lineObjName, OBJPROP_FONTSIZE, 7); 

            // Set the label's z-order to be above the black square (ZORDER == 0)
            ObjectSetInteger(0, lineObjName, OBJPROP_ZORDER, 1);
        } else {
            Print("Failed to create label. Error code: ", GetLastError());
        }
      }
   }
//+------------------------------------------------------------------+
//|                  EXTRA FUNCTION                                  |
//+------------------------------------------------------------------+
// Minors functions
   void UpdateInformation()
      {
         // Get current prices
         ask = GetAsk();
         bid = GetBid();

         // Get account information
         balance = GetBalance();
         equity = GetEquity();
         profit = GetProfit();
      }
   double GetAsk() 
      {
         return NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_ASK),_Digits);
      }

   double GetBid() 
      {
         return NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);
      }

   double GetBalance() 
      {
         return NormalizeDouble(AccountInfoDouble(ACCOUNT_BALANCE),0);
      }

   double GetEquity() 
      {
         return NormalizeDouble(AccountInfoDouble(ACCOUNT_EQUITY),0);
      }

   double GetProfit() {
      return NormalizeDouble(AccountInfoDouble(ACCOUNT_PROFIT),0);
   }
