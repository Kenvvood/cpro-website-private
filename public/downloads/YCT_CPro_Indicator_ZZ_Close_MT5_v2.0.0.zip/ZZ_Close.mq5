//+------------------------------------------------------------------+
//|                                         CPro Indicator ZZ_Close MT5                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input uint ExtDepth=12;
int min_rates_total;
double LowestBuffer[];
double HighestBuffer[];
double ColorBuffer[];
double ZZLBuffer[];
double ZZHBuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   min_rates_total=int(ExtDepth);
   SetIndexBuffer(0,LowestBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,HighestBuffer,INDICATOR_DATA);
   SetIndexBuffer(2,ColorBuffer,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(3,ZZLBuffer,INDICATOR_DATA);
   SetIndexBuffer(4,ZZHBuffer,INDICATOR_DATA);
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,0.0);
   ArraySetAsSeries(LowestBuffer,true);
   ArraySetAsSeries(HighestBuffer,true);
   ArraySetAsSeries(ColorBuffer,true);
   ArraySetAsSeries(ZZLBuffer,true);
   ArraySetAsSeries(ZZHBuffer,true);
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,min_rates_total);
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);
   string shortname;
   StringConcatenate(shortname,"ZZ_Close(ExtDepth=",ExtDepth,")");
   IndicatorSetString(INDICATOR_SHORTNAME,shortname);
//---
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
//---
   if(rates_total<min_rates_total) return(0);
   int limit,climit,bar,curlowpos,curhighpos,pos;
   static int lasthighpos,lastlowpos;
   double curlow,curhigh,min,max;
   static double lasthigh,lastlow;
   if(prev_calculated>rates_total || prev_calculated<=0)
     {
      limit=rates_total-min_rates_total; 
      climit=limit; 
      lasthighpos=limit;
      lastlowpos=limit;
      lastlow=close[limit];
      lasthigh=close[limit];
     }
   else
     {
      limit=rates_total-prev_calculated; 
      climit=limit+min_rates_total; 
      int lim=rates_total-prev_calculated;
      limit=lim+MathMax(lasthighpos,lastlowpos);
      lasthighpos+=lim;
      lastlowpos+=lim;
     }
   ArraySetAsSeries(high,true);
   ArraySetAsSeries(low,true);
   ArraySetAsSeries(close,true);
   for(bar=limit; bar>=0 && !IsStopped(); bar--)
     {
      //--- low
      LowestBuffer[bar]=NULL;
      ZZLBuffer[bar]=NULL;
      curlowpos=ArrayMinimum(close,bar,ExtDepth);
      curlow=close[curlowpos];
      if(lasthighpos>curlowpos)
        {
         ZZLBuffer[curlowpos]=curlow;
         min=999999999;
         pos=lasthighpos;
         for(int rrr=lasthighpos; rrr>=curlowpos; rrr--)
           {
            if(!ZZLBuffer[rrr]) continue;
            if(ZZLBuffer[rrr]<min)
              {
               min=ZZLBuffer[rrr];
               pos=rrr;
              }
            LowestBuffer[rrr]=NULL;
           }
         LowestBuffer[pos]=min;
        }
      lastlowpos=curlowpos;
      lastlow=curlow;
      //--- high
      HighestBuffer[bar]=NULL;
      ZZHBuffer[bar]=NULL;
      curhighpos=ArrayMaximum(close,bar,ExtDepth);
      curhigh=close[curhighpos];
      if(curhigh<=lasthigh) lasthigh=curhigh;
      else
        {
         if(lastlowpos>curhighpos)
           {
            ZZHBuffer[curhighpos]=curhigh;
            max=-999999999;
            pos=lastlowpos;
            for(int rrr=lastlowpos; rrr>=curhighpos; rrr--)
              {
               if(!ZZHBuffer[rrr]) continue;
               if(ZZHBuffer[rrr]>max)
                 {
                  max=ZZHBuffer[rrr];
                  pos=rrr;
                 }
               HighestBuffer[rrr]=NULL;
              }
            HighestBuffer[pos]=max;
           }
         lasthighpos       =  curhighpos;
         lasthigh          =  curhigh;
        }
     }
   for(bar=climit; bar>=0 && !IsStopped(); bar--)
     {
      max=HighestBuffer[bar];
      min=LowestBuffer[bar];
      if(!max && !min) ColorBuffer[bar]=ColorBuffer[bar+1];
      if(max && min)
        {
         if(ColorBuffer[bar+1]==0) ColorBuffer[bar]=1;
         else                      ColorBuffer[bar]=0;
        }
      if( max && !min) ColorBuffer[bar]=1;
      if(!max &&  min) ColorBuffer[bar]=0;
     }
//--- return value of prev_calculated for next call
   return(rates_total);
}
//+------------------------------------------------------------------+