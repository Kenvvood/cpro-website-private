//+------------------------------------------------------------------+
//|                                         CPro Indicator IndBarIndex MT5                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


// setting this input to true will freeze all indicators drawing on
// all charts of the same symbol, until you remove the indicator
input bool SimulateCalculation = false;
double Buffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
void OnInit()
{
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0, Buffer, INDICATOR_DATA);
   IndicatorSetInteger(INDICATOR_DIGITS, 0);
   if(SimulateCalculation)
   {
      EventSetTimer(1);
   }
}
//+------------------------------------------------------------------+
//| Timer handler                                                    |
//+------------------------------------------------------------------+
void OnTimer()
{
   Comment("Calculation started at ", TimeLocal());
   // the endless loop emulates lengthy calculations
   while(!IsStopped())
   {
   }
   Comment("");
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const int begin,
                const double &price[])
{
   if(prev_calculated <= 0)
   {
      ArrayInitialize(Buffer, EMPTY_VALUE);
   }
   const int N = MathMin(rates_total, TerminalInfoInteger(TERMINAL_MAXBARS));
   for(int i = MathMax(prev_calculated - 1, 0); i < N && !IsStopped(); i++)
   {
      Buffer[i] = i;
   }
   return rates_total;
}
//+------------------------------------------------------------------+