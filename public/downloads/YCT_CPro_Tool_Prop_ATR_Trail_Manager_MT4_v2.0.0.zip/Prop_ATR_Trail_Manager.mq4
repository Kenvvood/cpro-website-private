//+------------------------------------------------------------------+
//|                                         CPro Tool Prop_ATR_Trail_Manager MT4             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//--- Inputs
input int    InpATRPeriod     = 14;//ATR 周期
input double InpATRMultiplier = 2.0;//ATR指标 乘数
input bool   InpUseBreakeven  = true;//使用 auto-保本
input int    InpBEActivation  = 20;//点值s in 利润 to activate be
input int    InpBELockProfit  = 2;//点值s to lock in 利润 (covers fees)
input int    InpMagicNumber   = 0;//魔术号码 (0 = manual trades)
double pt;
double pip_mult;
//+------------------------------------------------------------------+
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   pt = Point;
   pip_mult = (Digits == 3 || Digits == 5) ? 10.0 : 1.0;
   Print("Institutional ATR Manager Initialized.");
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
void OnTick()
  {
   double atr_value = iATR(Symbol(), 0, InpATRPeriod, 1);
   double trail_distance = atr_value * InpATRMultiplier;
   double be_activation_pts = InpBEActivation * pip_mult * pt;
   double be_lock_pts       = InpBELockProfit * pip_mult * pt;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
        {
         if(OrderSymbol() == Symbol() && (InpMagicNumber == 0 || OrderMagicNumber() == InpMagicNumber))
           {
            double open_price = OrderOpenPrice();
            double current_sl = OrderStopLoss();
            int    type       = OrderType();
            //--- BUY ORDERS
            if(type == OP_BUY)
              {
               double bid = Bid;
               // 1. Breakeven Logic
               if(InpUseBreakeven && bid >= open_price + be_activation_pts)
                 {
                  double new_be_sl = open_price + be_lock_pts;
                  if(current_sl < new_be_sl && new_be_sl < bid)
                    {
                     bool res = OrderModify(OrderTicket(), open_price, new_be_sl, OrderTakeProfit(), 0, clrGreen);
                     if(res) current_sl = new_be_sl; // Update for trailing check
                    }
                 }
               // 2. ATR Trailing Logic
               double new_trail_sl = bid - trail_distance;
               if(new_trail_sl > current_sl && new_trail_sl < bid)
                 {
                  // Only modify if difference is meaningful to prevent broker spam
                  if(current_sl == 0 || new_trail_sl - current_sl > (2 * pip_mult * pt))
                    {
                     OrderModify(OrderTicket(), open_price, new_trail_sl, OrderTakeProfit(), 0, clrBlue);
                    }
                 }
              }
            //--- SELL ORDERS
            else if(type == OP_SELL)
              {
               double ask = Ask;
               // 1. Breakeven Logic
               if(InpUseBreakeven && ask <= open_price - be_activation_pts)
                 {
                  double new_be_sl2 = open_price - be_lock_pts;
                  if(current_sl > new_be_sl2 || current_sl == 0)
                    {
                     if(new_be_sl2 > ask)
                       {
                        bool res2 = OrderModify(OrderTicket(), open_price, new_be_sl2, OrderTakeProfit(), 0, clrGreen);
                        if(res2) current_sl = new_be_sl2;
                       }
                    }
                 }
               // 2. ATR Trailing Logic
               double new_trail_sl2 = ask + trail_distance;
               if(current_sl == 0 || (new_trail_sl2 < current_sl && new_trail_sl2 > ask))
                 {
                  if(current_sl == 0 || current_sl - new_trail_sl2 > (2 * pip_mult * pt))
                    {
                     OrderModify(OrderTicket(), open_price, new_trail_sl2, OrderTakeProfit(), 0, clrRed);
                    }
                 }
              }
           }
        }
     }
  }
//+------------------------------------------------------------------+
