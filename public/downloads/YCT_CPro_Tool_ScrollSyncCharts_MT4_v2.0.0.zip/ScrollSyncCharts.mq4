//+------------------------------------------------------------------+
//|                                         CPro Tool ScrollSyncCharts MT4                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


input ENUM_TIMEFRAMES OtherTimeframe=1440;
input int UpdateFrequency=50;
//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+
void OnStart()
  {
   datetime some_time;
   long chartId=0;
   chartId=ChartOpen(Symbol(),OtherTimeframe);
   if(!(chartId>0))
     {
      Print(GetLastError());
     }
   ChartSetInteger(chartId,CHART_AUTOSCROLL,false);
   ChartSetInteger(chartId,CHART_SHIFT,false);
   ChartSetInteger(chartId,CHART_MODE,0,CHART_CANDLES);
   int shift=0;
   int lastShift=0;
   int bar=0;
   int lastBar=0;
   ChartNavigate(chartId,CHART_END,0);
   while(!IsStopped())
     {
      bar=(int)ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR,0);
      if(!(lastBar==bar))
        {
         some_time=iTime(NULL,0,bar);
         shift=iBarShift(NULL,OtherTimeframe,some_time)*-1;
         if(shift<1 && (lastShift != shift))
           {
            if(MathAbs(lastShift-shift)==1) 
              {
               ChartNavigate(chartId,CHART_CURRENT_POS,(lastShift-shift)*-1);
              }
            else
              {
               ChartNavigate(chartId,CHART_END,shift);
              }
           }
         lastBar=bar;
         lastShift=shift;
        }
      Sleep(UpdateFrequency);
     }
   ChartClose(chartId);
  }
//+------------------------------------------------------------------+