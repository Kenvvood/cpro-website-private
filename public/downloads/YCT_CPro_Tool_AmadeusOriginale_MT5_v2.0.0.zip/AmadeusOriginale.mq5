//+------------------------------------------------------------------+
//|                                         CPro Tool AmadeusOriginale MT5                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <trade/trade.mqh>

CTrade trade;
//-------------------------------------------OVEROPTIMIZED VERSION AFTER 1. TESTING -------------
input double TrigPDif = 0.00005;
input double DesiredProfitPerc = 20;
input int ExpiryTime = 120;
input double Lots = 1.0;
input double TPFactor = 1;
input double RuleMinimumTPSLValue = 0.0001;
input double PufferDistance = 0.0001;
input double WhiteYellowProtRange = 0.00001;
input bool SWhiteProtection = true;
//AUSSTEHEND input double TPSLFactor = 1.0;
input string Opentime = "07:30:00";
input string CloseTime = "23:00";
double bid0 = 0; 
double accountbalancebeginning;
double accountprofit;
double Lostrades = 0;
double Wintrades = 0;
double AllWinRatio = 0;
int OnInit(){
   CPro_Init();  // CPro营销模块初始化
   accountbalancebeginning = AccountInfoDouble(ACCOUNT_BALANCE);
   //OrderinAction = false;
   return(INIT_SUCCEEDED);
  }
void OnTick(){
   //DETERMINING TIMEFRAME
   datetime opentimenow = StringToTime(Opentime);
   datetime closetimenow = StringToTime(CloseTime);
   datetime currenttime = TimeCurrent();
   if(currenttime > opentimenow && currenttime < closetimenow){      
      /*//GET PINK AMA VALUES
      double PinkAMAPriceArray[];
      int PinkAMADefinition = iAMA (_Symbol,_Period,1,1,20,0,PRICE_CLOSE);
      ArraySetAsSeries(PinkAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(PinkAMADefinition,0,0,10,PinkAMAPriceArray);
      double PinkAMACurrentValue = NormalizeDouble(PinkAMAPriceArray[0],6);*/
      //GET YELLWOW AMA VALUES
      double YellAMAPriceArray[];
      int YellAMADefinition = iAMA (_Symbol,_Period,2,5,1,0,PRICE_CLOSE);
      ArraySetAsSeries(YellAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(YellAMADefinition,0,0,10,YellAMAPriceArray);
      double YellAMACurrentValue = NormalizeDouble(YellAMAPriceArray[0],6);
      //GET WHITE AMA VALUES
      double WhiteAMAPriceArray[];
      int WhiteAMADefinition = iAMA (_Symbol,_Period,2,5,1,1,PRICE_CLOSE);
      ArraySetAsSeries(WhiteAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(WhiteAMADefinition,0,0,10,WhiteAMAPriceArray);
      double WhiteAMACurrentValue = NormalizeDouble(WhiteAMAPriceArray[0],6);
      //GET SWHITE AMA VALUES
      double SWhiteAMAPriceArray[];
      int SWhiteAMADefinition = iAMA (_Symbol,_Period,2,5,1,2,PRICE_CLOSE);
      ArraySetAsSeries(SWhiteAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(SWhiteAMADefinition,0,0,10,SWhiteAMAPriceArray);
      double SWhiteAMACurrentValue = NormalizeDouble(SWhiteAMAPriceArray[0],6);
      //GET RED AMA VALUES
      double RedAMAPriceArray[];
      int RedAMADefinition = iAMA (_Symbol,_Period,5,2,30,0,PRICE_CLOSE);
      ArraySetAsSeries(RedAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(RedAMADefinition,0,0,10,RedAMAPriceArray);
      double RedAMACurrentValue = NormalizeDouble(RedAMAPriceArray[0],6);
      //GET ORANGE AMA VALUES
      double OrangeAMAPriceArray[];
      int OrangeAMADefinition = iAMA (_Symbol,_Period,5,2,30,1,PRICE_CLOSE);
      ArraySetAsSeries(OrangeAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(OrangeAMADefinition,0,0,10,OrangeAMAPriceArray);
      double OrangeAMACurrentValue = NormalizeDouble(OrangeAMAPriceArray[0],6);
      //SET THE ORDER
      bid0 = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);
      double PufferPrice = RedAMACurrentValue + PufferDistance;
      double InvalidStopProhibitorline = RuleMinimumTPSLValue + PufferDistance + RedAMACurrentValue;
      double iLow1 = iLow(_Symbol,PERIOD_CURRENT,1);
      double iLow2 = iLow(_Symbol,PERIOD_CURRENT,2);
      /*//DYNAMIC CALCULATION OF LOT SIZE
      double accountbalance = AccountInfoDouble(ACCOUNT_BALANCE);
      double lotsizegeneral = (accountbalance * DesiredProfitPerc/100) / 146;
      lotsizegeneral = NormalizeDouble(lotsizegeneral,1);*/
      if(SWhiteProtection == false){SWhiteAMACurrentValue = 5;}
      if( iLow1 > OrangeAMACurrentValue + PufferDistance && iLow2 > OrangeAMACurrentValue + PufferDistance){
         if(WhiteAMACurrentValue - WhiteYellowProtRange > YellAMACurrentValue &&
            YellAMACurrentValue > bid0 &&
            YellAMACurrentValue > PufferPrice &&
            SWhiteAMACurrentValue > WhiteAMACurrentValue &&
            bid0 > InvalidStopProhibitorline && 
            PositionsTotal() == 0 && 
            OrdersTotal() == 0){
            double TrigP = bid0 - TrigPDif;
            double TP = TrigP - ((TrigP - RedAMACurrentValue) * TPFactor);
            double SL = TrigP + (TrigP - RedAMACurrentValue);
            datetime OrderExpTime = TimeCurrent() + ExpiryTime;
            trade.SellStop(Lots,TrigP,_Symbol,SL,TP,ORDER_TIME_SPECIFIED,OrderExpTime);
            Print(//"\nPinkAMA-Value ",PinkAMACurrentValue,
                 "\nYellAMA-Value ",YellAMACurrentValue,
                 "\nWhiteAMA-Value ",WhiteAMACurrentValue,
                 "\nRedAMA-Value ",RedAMACurrentValue,
                 "\nOrangeAMA-Value ",OrangeAMACurrentValue,
                 "\niLow 1: ",iLow1,
                 "\niLow2",iLow2,
                 "\nBid ",bid0);
         }
      }
      // DISPLAY OF VALUES ON CHART
      double accountequity = AccountInfoDouble(ACCOUNT_EQUITY);
      accountprofit = accountequity - accountbalancebeginning;
      accountprofit = NormalizeDouble(accountprofit,2);  
      Comment("\nServertime: ", TimeCurrent(),
              "\nCurrenttime: ",TimeCurrent(),
              "\nProfit: ",accountprofit,
              "\nEquity: ",accountequity,
              //"\nPinkAMA-Value ",PinkAMACurrentValue,
              "\nYellAMA-Value ",YellAMACurrentValue,
              "\nWhiteAMA-Value ",WhiteAMACurrentValue,
              "\nRedAMA-Value ",RedAMACurrentValue,
              "\nOrangeAMA-Value ",OrangeAMACurrentValue,
              "\niLow 1: ",iLow1,
              "\niLow2",iLow2,
              "\nBid ",bid0);
   }//END TIMEFRAME
  }//END ONTICK
void OnDeinit(const int reason)
{
   Lostrades = TesterStatistics(STAT_LOSS_TRADES);
   Wintrades = TesterStatistics(STAT_PROFIT_TRADES);
   if(Lostrades + Wintrades > 0){
      AllWinRatio = Wintrades / (Wintrades + Lostrades);
   }else{AllWinRatio = 0;}
   Print("Verlorene Trades:  ",Lostrades,
         "Gewonnenen Trades: ",Wintrades,
         "Gewinnrate:________",AllWinRatio);
   CPro_Deinit();  // CPro营销模块清理
}
double OnTester()
{
   return(AllWinRatio);
}