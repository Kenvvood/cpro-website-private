//+------------------------------------------------------------------+
//|                                         CPro Tool KnitPkgExpertDemo MT5                  |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include "../knitpkg/flat/KnitPkgExpertDemo_flat.mqh"
#include <Trade/PositionInfo.mqh>
#include <Trade/Trade.mqh>

//------------------------------------------------------------------
// Flat mode include — resolves dependencies and enables
// MetaEditor IntelliSense. Run `kp install` to generate.
//------------------------------------------------------------------
// Standard Library includes. No conflict with KnitPkg at all.
input int sma1period = 10;//做空 term sma 周期
input int sma2period = 25;//mid term sma 周期
input int sma3period = 200;//做空 term sma 周期
input bool filterEnabled = false;   // Entry filter on/off
// Global variables
douglasrechia::BarWatcher *barWatcher;
douglasrechia::BarMqlRates *myBar;
//---
int sma1handle = INVALID_HANDLE;
int sma2handle = INVALID_HANDLE;
int sma3handle = INVALID_HANDLE;
//---
CPositionInfo positionInfo;
CTrade trade;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   CPro_Init();  // CPro营销模块初始化
   barWatcher = new douglasrechia::BarWatcher();
   myBar = new douglasrechia::BarMqlRates();
//--- Validate that sma1.period < sma2.period < sma3.period
   if(!(sma1period < sma2period && sma2period < sma3period))
     {
      Print("Invalid moving average periods");
      return(INIT_FAILED);
     }
//--- Handlers for SMA indicators calculated at three different periods
   sma1handle = iCustom(_Symbol, _Period, "sma/bin/KnitPkgSMA", sma1period);
   sma2handle = iCustom(_Symbol, _Period, "sma/bin/KnitPkgSMA", sma2period);
   sma3handle = iCustom(_Symbol, _Period, "sma/bin/KnitPkgSMA", sma3period);
   if(sma1handle == INVALID_HANDLE || sma2handle == INVALID_HANDLE || sma3handle == INVALID_HANDLE)
     {
      Print("Could not initialize KnitPkgSMA indicator");
      return(INIT_FAILED);
     }
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//--- Releasing indicator resources
   if(sma1handle != INVALID_HANDLE)
      IndicatorRelease(sma1handle);
   if(sma2handle != INVALID_HANDLE)
      IndicatorRelease(sma2handle);
   if(sma3handle != INVALID_HANDLE)
      IndicatorRelease(sma3handle);
//---
   delete barWatcher;
   delete myBar;
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
   barWatcher.Update();
   if(barWatcher.IsFirstTick())
     {
      Print("Hello world! This is KnitPkg's debut EA. I'm mostly here for show, but hey, looking good is half the battle! ;-)");
     }
   else
      if(barWatcher.IsNewBar())
        {
         OnNewBar();
        }
  }
//+------------------------------------------------------------------+
//| OnNewBar — called when a new bar is formed                       |
//+------------------------------------------------------------------+
void OnNewBar()
  {
//--- Get latest 5 bars data
   myBar.Refresh(5);
//--- Get the 5 most recent values of SMA into the TimeSeries.
//--- Do it for the three SMAs.
   douglasrechia::TimeSeriesArray<double>* sma1 =
      douglasrechia::NewTimeSeriesFromIndicator(sma1handle, 0, 0, 5);
   douglasrechia::TimeSeriesArray<double>* sma2 =
      douglasrechia::NewTimeSeriesFromIndicator(sma2handle, 0, 0, 5);
   douglasrechia::TimeSeriesArray<double>* sma3 =
      douglasrechia::NewTimeSeriesFromIndicator(sma3handle, 0, 0, 5);
   if(sma1 != NULL && sma2 != NULL && sma3 != NULL)
     {
      if(!positionInfo.Select(_Symbol))
        {
         //--- No position. Check filter conditions.
         if(!filterEnabled || (myBar.Close(1) > sma1.ValueAtShift(1) &&
                               sma1.ValueAtShift(1) > sma2.ValueAtShift(1) &&
                               sma2.ValueAtShift(1) > sma3.ValueAtShift(1)))
           {
            //--- Open position if Short term sma1 crosses up Mid term sma2
            if(douglasrechia::CrossUp(sma1, sma2, 1))
              {
               Print(StringFormat("[%s] Let's do it", TimeToString(myBar.Time(0))));
               trade.Buy(1);
              }
           }
        }
      else
        {
         //--- Position is found. Close it if Short term sma1 crosses down Mid term sma2.
         if(douglasrechia::CrossUp(sma2, sma1, 1))
           {
            Print(StringFormat("[%s] Time to go", TimeToString(myBar.Time(0))));
            trade.PositionClose(_Symbol);
           }
        }
     }
   else
     {
      Print("ERROR: could not get TimeSeries from indicators buffers.");
     }
   if(sma1 != NULL)
      delete sma1;
   if(sma2 != NULL)
      delete sma2;
   if(sma3 != NULL)
      delete sma3;
  }
//+------------------------------------------------------------------+