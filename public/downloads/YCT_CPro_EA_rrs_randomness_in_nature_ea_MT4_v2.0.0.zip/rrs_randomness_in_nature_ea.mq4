//+------------------------------------------------------------------+
//|                                         CPro EA rrs_randomness_in_nature_ea MT4          |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| EA Inputs                                                        |
//+------------------------------------------------------------------+
extern string __EA_Strategy__ = "***Trading Strategy***";
enum TradingStrategy_enum {OneSide, DoubleSide};
extern TradingStrategy_enum Trading_Strategy = DoubleSide;
extern string __LotSettings__ = "***Lot Settings***";
extern double minLot_Size = 0.01;
extern double maxLot_Size = 0.50;
extern string __OrderSettings__ = "***Order Settings***";
extern int TakeProfit = 100;
extern int StopLoss = 200;
extern string __TrailingSettings__ = "***Trailing Settings***";
extern int Trailing_Start = 50;
extern int Trailing_Gap = 50;
extern string __RestricationSettings__ = "***Restrication Settings***";
extern int maxSpread = 100;
extern int Slippage = 3;
extern string __Risk_Management__ = "***Risk Management***";
enum RiskInMoneyMode_enum {FixedMoney, BalancePercentage};
extern RiskInMoneyMode_enum Risk_In_Money_Type = BalancePercentage;
extern double Money_In_Risk = 5.0;
extern string __ExpertAdvisor__ = "***EA Settings***";
extern string Trade_Comment = "RRS";
extern int Magic = 1000;
extern string EA_Notes = "Note For Your Reference";
//Timezone
int localHours = (TimeLocal() - TimeGMT()) / 3600;
int localMinutes = ((TimeLocal() - TimeGMT()) % 3600) / 60;
int brokerHours = (TimeCurrent() - TimeGMT()) / 3600;
int brokerMinutes = ((TimeCurrent() - TimeGMT()) % 3600) / 60;
//+------------------------------------------------------------------+
//| RRS Defined                                                      |
//+------------------------------------------------------------------+
//int
int gBuyMagic, gSellMagic;
int OrderCount_BuyMagicOPBUY, OrderCount_SellMagicOPSELL;
int BuySellRandomMath = -1;
int Buy_StopLevel, Sell_StopLevel;
//String
string stylecommenttrade;
string BuyStopTradeComment, SellStopTradeComment;
string cTradingStyle;
string buy_random_symbol, sell_random_symbol;
string buyOpenTrade_Symbol, sellOpenTrade_Symbol;
//Double
double gSymbolEA_FloatingPL, gBuyFloatingPL, gSellFloatingPL;
double gTargeted_Revenue, gRisk_Money;
double OrderSend_StopLoss, OrderSend_TakeProfit;
double Buy_Lot_Size, Sell_Lot_Size;
//+------------------------------------------------------------------+
//| OnInit                                                           |
//+------------------------------------------------------------------+
int OnInit()
  {
//Magic Numbers and Trade-Order Comments
   if(Trading_Strategy == OneSide)
     {
      stylecommenttrade = "OneSide";
      gBuyMagic    = Magic + 1;
      gSellMagic   = Magic + 11;
     }
   if(Trading_Strategy == DoubleSide)
     {
      stylecommenttrade = "DoubleSide";
      gBuyMagic    = Magic + 2;
      gSellMagic   = Magic + 22;
     }
//Trade Comments
   BuyStopTradeComment = Trade_Comment + "+" + stylecommenttrade + "+RRS";
   SellStopTradeComment = Trade_Comment + "+" + stylecommenttrade + "+RRS";
//Comment status
   cTradingStyle = (Trading_Strategy == OneSide) ? "One Side" : "Double Side";
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| On Deinit                                                        |
//+------------------------------------------------------------------+
int deinit()
  {
   ObjectsDeleteAll(0,"#",-1,-1);
   return (0);
  }
//+------------------------------------------------------------------+
//| OnTick                                                           |
//+------------------------------------------------------------------+
void OnTick()
  {
//Pre-defined OnTick Value
   MathSrand(GetTickCount());
   BuySellRandomMath = MathRand() % 6;
   OrderCount_BuyMagicOPBUY = trade_count_ordertype(OP_BUY, gBuyMagic);
   OrderCount_SellMagicOPSELL = trade_count_ordertype(OP_SELL, gSellMagic);
   buy_random_symbol = randomsymbol();
   sell_random_symbol = randomsymbol();
   buyOpenTrade_Symbol = GetSymbolOpenTrade(gBuyMagic, OP_BUY);
   sellOpenTrade_Symbol = GetSymbolOpenTrade(gSellMagic, OP_SELL);
   Buy_Lot_Size = RandomLotSize();
   Sell_Lot_Size = RandomLotSize();
   Buy_StopLevel = MarketInfo(buy_random_symbol, MODE_STOPLEVEL) + 2;
   Sell_StopLevel = MarketInfo(sell_random_symbol, MODE_STOPLEVEL) + 2;
//Trailing TP
   if(Trailing_Gap > 0 && Trailing_Start > 0)
     {
      if(OrderCount_BuyMagicOPBUY >= 1)
         TrailingStopLoss(gBuyMagic);
      if(OrderCount_SellMagicOPSELL >= 1)
         TrailingStopLoss(gSellMagic);
     }
//Order Placement
   if(Trading_Strategy == DoubleSide)
      DoubleSide_OrderSend();
   else
      OneSide_OrderSend();
//Financial Value
   gBuyFloatingPL = CalculateTradeFloating(gBuyMagic);
   gSellFloatingPL = CalculateTradeFloating(gSellMagic);
   gSymbolEA_FloatingPL = gBuyFloatingPL + gSellFloatingPL;
//Risk In Money
   if(Risk_In_Money_Type == BalancePercentage)
      gRisk_Money =(-1.0 * AccountBalance() * (Money_In_Risk * 0.01));
   else
      gRisk_Money = (-1.0 * Money_In_Risk);
   if(gSymbolEA_FloatingPL <= gRisk_Money)
     {
      CloseOpenAndPendingTrades(gBuyMagic);
      CloseOpenAndPendingTrades(gSellMagic);
      Print("Risk Management => Successfully Closed");
     }
   ChartComment(); //Chart Comment to show details
// --------- OnTick End ------------ //
  }
//+------------------------------------------------------------------+
//| Doube Side Buy And Sell Order                                    |
//+------------------------------------------------------------------+
void DoubleSide_OrderSend()
  {
   if(OrderCount_BuyMagicOPBUY == 0 && CheckVolumeValue(Buy_Lot_Size, buy_random_symbol) == true && CheckMoneyForTrade(buy_random_symbol, Buy_Lot_Size, OP_BUY) == true && MarketInfo(buy_random_symbol, MODE_SPREAD) < maxSpread)
     {
      ResetLastError();
      if(!OrderSend(buy_random_symbol, OP_BUY, Buy_Lot_Size, MarketInfo(buy_random_symbol, MODE_ASK), Slippage, OrderSend_StopLoss = (StopLoss > 0) ? MarketInfo(buy_random_symbol, MODE_ASK) - MathMax(StopLoss, Buy_StopLevel) * Point : 0, OrderSend_TakeProfit = (TakeProfit > 0) ? MarketInfo(buy_random_symbol, MODE_ASK) + MathMax(TakeProfit, Buy_StopLevel) * Point : 0, BuyStopTradeComment, gBuyMagic, 0, clrNONE))
         Print("Buy Order => Error Code : " + GetLastError());
     }
   if(OrderCount_SellMagicOPSELL == 0 && CheckVolumeValue(Sell_Lot_Size, sell_random_symbol) == true && CheckMoneyForTrade(sell_random_symbol, Sell_Lot_Size, OP_SELL) == true && MarketInfo(sell_random_symbol, MODE_SPREAD) < maxSpread)
     {
      ResetLastError();
      if(!OrderSend(sell_random_symbol, OP_SELL, Sell_Lot_Size, MarketInfo(sell_random_symbol, MODE_BID), Slippage, OrderSend_StopLoss = (StopLoss > 0) ? MarketInfo(sell_random_symbol, MODE_BID) + MathMax(StopLoss, Sell_StopLevel) * Point : 0, OrderSend_TakeProfit = (TakeProfit > 0) ? MarketInfo(sell_random_symbol, MODE_BID) - MathMax(TakeProfit, Sell_StopLevel) * Point : 0, SellStopTradeComment, gSellMagic, 0, clrNONE))
         Print("Sell Order => Error Code : " + GetLastError());
     }
  }
//+------------------------------------------------------------------+
//|    One Side Order Send                                           |
//+------------------------------------------------------------------+
void OneSide_OrderSend()
  {
   if(OrderCount_BuyMagicOPBUY == 0 && OrderCount_SellMagicOPSELL == 0 && CheckVolumeValue(Buy_Lot_Size, buy_random_symbol) == true && (BuySellRandomMath == 1 || BuySellRandomMath == 4) && CheckMoneyForTrade(buy_random_symbol, Buy_Lot_Size, OP_BUY) == true && MarketInfo(buy_random_symbol, MODE_SPREAD) < maxSpread)
     {
      ResetLastError();
      if(!OrderSend(buy_random_symbol, OP_BUY, Buy_Lot_Size, MarketInfo(buy_random_symbol, MODE_ASK), Slippage, OrderSend_StopLoss = (StopLoss > 0) ? MarketInfo(buy_random_symbol, MODE_ASK) - MathMax(StopLoss, Buy_StopLevel) * Point : 0, OrderSend_TakeProfit = (TakeProfit > 0) ? MarketInfo(buy_random_symbol, MODE_ASK) + MathMax(TakeProfit, Buy_StopLevel) * Point : 0, BuyStopTradeComment, gBuyMagic, 0, clrNONE))
         Print("Buy Order => Error Code : " + GetLastError());
     }
   if(OrderCount_SellMagicOPSELL == 0 && OrderCount_BuyMagicOPBUY == 0 && CheckVolumeValue(Sell_Lot_Size, sell_random_symbol) == true && (BuySellRandomMath == 0 || BuySellRandomMath == 3) && CheckMoneyForTrade(sell_random_symbol, Sell_Lot_Size, OP_SELL) == true && MarketInfo(sell_random_symbol, MODE_SPREAD) < maxSpread)
     {
      ResetLastError();
      if(!OrderSend(sell_random_symbol, OP_SELL, Sell_Lot_Size, MarketInfo(sell_random_symbol, MODE_BID), Slippage, OrderSend_StopLoss = (StopLoss > 0) ? MarketInfo(sell_random_symbol, MODE_BID) + MathMax(StopLoss, Sell_StopLevel) * Point : 0, OrderSend_TakeProfit = (TakeProfit > 0) ? MarketInfo(sell_random_symbol, MODE_BID) - MathMax(TakeProfit, Sell_StopLevel) * Point : 0, SellStopTradeComment, gSellMagic, 0, clrNONE))
         Print("Sell Order => Error Code : " + GetLastError());
     }
  }
// Calculate Trade profits and Loss
double CalculateTradeFloating(int CalculateTradeFloating_Magic)
  {
   double CalculateTradeFloating_Value = 0;
   for(int CalculateTradeFloating_i = 0; CalculateTradeFloating_i < OrdersTotal(); CalculateTradeFloating_i++)
     {
      OrderSelect(CalculateTradeFloating_i, SELECT_BY_POS, MODE_TRADES);
      if(OrderType() != OP_BUY && OrderType() != OP_SELL)
         continue;
      if(CalculateTradeFloating_Magic == OrderMagicNumber())
         CalculateTradeFloating_Value += OrderProfit() + OrderSwap() + OrderCommission();
     }
   return CalculateTradeFloating_Value;
  }
// Trade closing based on Magic number
void CloseOpenAndPendingTrades(int trade_close_magic)
  {
   for(int pos_0 = OrdersTotal() - 1; pos_0 >= 0; pos_0--)
     {
      OrderSelect(pos_0, SELECT_BY_POS, MODE_TRADES);
      if(OrderMagicNumber() != trade_close_magic)
         continue;
      if(OrderType() != OP_BUY && OrderType() != OP_SELL)
        {
         ResetLastError();
         if(!OrderDelete(OrderTicket()))
            Print(__FUNCTION__ " => Pending Order failed to close, error code:", GetLastError());
        }
      else
        {
         ResetLastError();
         if(OrderType() == OP_BUY)
           {
            if(!OrderClose(OrderTicket(), OrderLots(), MarketInfo(buyOpenTrade_Symbol, MODE_BID), Slippage, clrNONE))
               Print(__FUNCTION__ " => Buy Order failed to close, error code:", GetLastError());
           }
         if(OrderType() == OP_SELL)
           {
            if(!OrderClose(OrderTicket(), OrderLots(), MarketInfo(sellOpenTrade_Symbol, MODE_ASK), Slippage, clrNONE))
               Print(__FUNCTION__ " => Sell Order failed to close, error code:", GetLastError());
           }
        }
     }
  }
// Trade Counting based on Order Type and Magic Number
int trade_count_ordertype(int trade_count_ordertype_value, int trade_count_ordertype_magic)
  {
   int count_4 = 0;
   for(int pos_8 = 0; pos_8 < OrdersTotal(); pos_8++)
     {
      OrderSelect(pos_8, SELECT_BY_POS, MODE_TRADES);
      if(OrderMagicNumber() != trade_count_ordertype_magic)
         continue;
      if(trade_count_ordertype_value == OrderType())
         count_4++;
     }
   return count_4;
  }
// Chart Comment Status
void ChartComment()
  {
   string c_Risk_Type, c_risk_t;
   if(Risk_In_Money_Type == BalancePercentage)
     {
      c_risk_t = "Balance Percentage";
      c_Risk_Type = "(Percentage : " + Money_In_Risk + ") => (Money In Risk : " + -1 * gRisk_Money + ")";
     }
   else
     {
      c_risk_t = "Fixed Money";
      c_Risk_Type = "(Money In Risk : " + -1 * gRisk_Money + ")";
     }
   Comment("                                               ---------------------------------------------"
           "\n                                             :: ===>RRS Randomness in Nature EA<==="
           "\n                                             ------------------------------------------------" +
           "\n                                             :: Trading Strategy             : " + cTradingStyle +
           "\n                                             :: Lot Size                         : (Min Lot : " + minLot_Size + ") |:| (Max Lot : " + maxLot_Size + ")" +
           "\n                                             :: Take Profit                      : " + TakeProfit +
           "\n                                             :: Stop Loss                      : " + StopLoss +
           "\n                                             :: Trailing                          : (Start : " + Trailing_Start + ") |:| (Gap : " + Trailing_Gap + ")" +
           "\n                                             :: Risk Management          : (Risk Type : " + c_risk_t + ") |:| "  + c_Risk_Type  +
           "\n                                             ------------------------------------------------" +
           "\n                                             :: Magic Number               : " + Magic + " => (Buy Magic : " + gBuyMagic + ") |:| (Sell Magic : " + gSellMagic + ")" +
           "\n                                             :: Timezone                      : (Local PC : " + localHours + ":" + localMinutes + ")" + " |:| (Broker Timezone : " + brokerHours + ":" + brokerMinutes + ")" +
           "\n                                             :: Order Comment             : " + Trade_Comment +
           "\n                                             :: Notes                           : " + EA_Notes +
           "\n                                             ------------------------------------------------" +
           "\n                                             :: Email                           : rajeeevrrs@gmail.com " +
           "\n                                             :: Telegram                     : @rajeevrrs " +
           "\n                                             :: Skype                         : rajeev-rrs " +
           "\n                                             ------------------------------------------------");
  }
//+--------------------------------------------------------------------+
// Trailing SL                                                         +
//+--------------------------------------------------------------------+
void TrailingStopLoss(int TrailingStopLoss_magic)
  {
// Loop through all open orders
   double TrailingStopLoss_entryPrice;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
        {
         TrailingStopLoss_entryPrice = OrderOpenPrice();
         // Check if the order is a buy order with magic number 1
         if(OrderMagicNumber() == TrailingStopLoss_magic && OrderType() == OP_BUY)
           {
            if(MarketInfo(buyOpenTrade_Symbol, MODE_BID) - (TrailingStopLoss_entryPrice + Trailing_Start * Point) > Point * Trailing_Gap)
              {
               if(OrderStopLoss() < MarketInfo(buyOpenTrade_Symbol, MODE_BID) - Point * Trailing_Gap || OrderStopLoss() == 0)
                 {
                  ResetLastError();
                  RefreshRates();
                  if(!OrderModify(OrderTicket(), OrderOpenPrice(), MarketInfo(buyOpenTrade_Symbol, MODE_BID) - Point * Trailing_Gap, OrderTakeProfit(), 0, clrNONE))
                     Print(__FUNCTION__ + " => Buy Order Error Code : " + GetLastError());
                 }
              }
           }
         // Check if the order is a sell order with magic number 2
         if(OrderMagicNumber() == TrailingStopLoss_magic && OrderType() == OP_SELL)
           {
            if((TrailingStopLoss_entryPrice - Trailing_Start * Point) - MarketInfo(sellOpenTrade_Symbol, MODE_ASK) > Point * Trailing_Gap)
              {
               if(OrderStopLoss() > MarketInfo(sellOpenTrade_Symbol, MODE_ASK) + Point * Trailing_Gap || OrderStopLoss() == 0)
                 {
                  ResetLastError();
                  RefreshRates();
                  if(!OrderModify(OrderTicket(), OrderOpenPrice(), MarketInfo(sellOpenTrade_Symbol, MODE_ASK) + Point * Trailing_Gap, OrderTakeProfit(), 0, clrNONE))
                     Print(__FUNCTION__ + " => Sell Order Error Code : " + GetLastError());
                 }
              }
           }
        }
     }
  }
//+------------------------------------------------------------------+
//|    Check Balance and Margin                                      |
//+------------------------------------------------------------------+
bool CheckMoneyForTrade(string symb, double lots,int type)
  {
   double free_margin=AccountFreeMarginCheck(symb,type, lots);
//-- if there is not enough money
   if(free_margin<0)
     {
      Print("Not enough money to trade");
      return(false);
     }
//--- checking successful
   return(true);
  }
//+------------------------------------------------------------------+
//|  Random Symbol                                                   |
//+------------------------------------------------------------------+
string randomsymbol()
  {
   string randomsymbol_pairs[] = {"USD", "GBP", "AUD", "CAD", "JPY", "XAU", "XAG",
                                  "EUR", "CHF", "SDG", "HKD", "NZD"
                                 };
   int totalSymbols = SymbolsTotal(true);  // Include all Market Watch symbols
   string validSymbols[];
   for(int i = 0; i < totalSymbols; i++)
     {
      string symbolName = SymbolName(i, true);
      // Check for valid currency pair combinations
      for(int j = 0; j < ArraySize(randomsymbol_pairs); j++)
        {
         for(int k = 0; k < ArraySize(randomsymbol_pairs); k++)
           {
            if(j != k)  // Prevent matching same symbols (e.g., USDUSD)
              {
               if(StringFind(symbolName, randomsymbol_pairs[j]) != -1 &&
                  StringFind(symbolName, randomsymbol_pairs[k]) != -1)
                 {
                  ArrayResize(validSymbols, ArraySize(validSymbols) + 1);
                  validSymbols[ArraySize(validSymbols) - 1] = symbolName;
                 }
              }
           }
        }
     }
// Return a random symbol from the valid list
   if(ArraySize(validSymbols) > 0)
     {
      int randomIndex = MathRand() % ArraySize(validSymbols);
      return validSymbols[randomIndex];
     }
   return ""; // Return empty if no valid symbol found
  }
//+------------------------------------------------------------------+
//|   Get Symbol by Magic                                            |
//+------------------------------------------------------------------+
string GetSymbolOpenTrade(int magicNumber, int OrderTypee)
  {
   for(int i = 0; i < OrdersTotal(); i++)
     {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) // Select order by position
        {
         if(OrderMagicNumber() == magicNumber && OrderType() == OrderTypee)
            return OrderSymbol(); // Return the symbol name
        }
     }
   return ""; // Return empty string if no match is found
  }
//+------------------------------------------------------------------+
//|        Random Lot size                                           |
//+------------------------------------------------------------------+
double RandomLotSize()
  {
// Generate a random value within the specified range
   double LotrandomValue = minLot_Size + (maxLot_Size - minLot_Size) * MathRand() / 32767.0;
// Normalize to 2 decimal places
   return NormalizeDouble(LotrandomValue, 2);
  }
//+------------------------------------------------------------------+
//| Check the correctness of the order volume                        |
//+------------------------------------------------------------------+
bool CheckVolumeValue(double volume, string randomsymbol_checkvolume)
  {
//--- minimal allowed volume for trade operations
   double min_volume=SymbolInfoDouble(randomsymbol_checkvolume,SYMBOL_VOLUME_MIN);
   if(volume<min_volume)
     {
      PrintFormat("Volume is less than the minimal allowed SYMBOL_VOLUME_MIN=%.2f",min_volume);
      return(false);
     }
//--- maximal allowed volume of trade operations
   double max_volume=SymbolInfoDouble(randomsymbol_checkvolume,SYMBOL_VOLUME_MAX);
   if(volume>max_volume)
     {
      PrintFormat("Volume is greater than the maximal allowed SYMBOL_VOLUME_MAX=%.2f",max_volume);
      return(false);
     }
//--- get minimal step of volume changing
   double volume_step=SymbolInfoDouble(randomsymbol_checkvolume,SYMBOL_VOLUME_STEP);
   int ratio=(int)MathRound(volume/volume_step);
   if(MathAbs(ratio*volume_step-volume)>0.0000001)
     {
      PrintFormat("Volume is not a multiple of the minimal step SYMBOL_VOLUME_STEP=%.2f, the closest correct volume is %.2f",
            volume_step,ratio*volume_step);
      return(false);
     }
   return(true);
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+