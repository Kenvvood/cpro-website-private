//+------------------------------------------------------------------+
//|                                         CPro Tool buttonclosebuysell MT4                 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//--- input parameters
input int Magic = 0; // Magic number, -1 for all, 0 for manual
input string FilterComment = ""; // Filter by order comment string
input int Slippage = 3; // Maximum allowed slippage
//
double profitB = 0.0, profitS = 0.0;
int OnInit()
{
    ObjectCreate(0, "CloseBuy", OBJ_BUTTON, 0, 0, 0);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_XDISTANCE, 331);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_YDISTANCE, 0);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_XSIZE, 105);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_YSIZE, 16);
    ObjectSetString(0, "CloseBuy", OBJPROP_FONT, "Arial");
    ObjectSetInteger(0, "CloseBuy", OBJPROP_FONTSIZE, 8);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_COLOR, White);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_BGCOLOR, clrDarkSlateBlue);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_BORDER_COLOR, Yellow);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_BORDER_TYPE, BORDER_FLAT);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_BACK, false);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_HIDDEN, true);
    ObjectSetInteger(0, "CloseBuy", OBJPROP_STATE, false);
    ObjectCreate(0,"CloseSell", OBJ_BUTTON, 0, 0, 0);
    ObjectSetInteger(0,"CloseSell", OBJPROP_XDISTANCE, 225);
    ObjectSetInteger(0,"CloseSell", OBJPROP_YDISTANCE, 0);
    ObjectSetInteger(0,"CloseSell", OBJPROP_XSIZE, 105);
    ObjectSetInteger(0,"CloseSell", OBJPROP_YSIZE, 16);
    ObjectSetString(0, "CloseSell", OBJPROP_FONT, "Arial");
    ObjectSetInteger(0, "CloseSell", OBJPROP_FONTSIZE, 8);
    ObjectSetInteger(0, "CloseSell", OBJPROP_COLOR, White);
    ObjectSetInteger(0, "CloseSell", OBJPROP_BGCOLOR, clrDarkMagenta);
    ObjectSetInteger(0, "CloseSell", OBJPROP_BORDER_COLOR, Yellow);
    ObjectSetInteger(0, "CloseSell", OBJPROP_BORDER_TYPE, BORDER_FLAT);
    ObjectSetInteger(0, "CloseSell", OBJPROP_BACK, false);
    ObjectSetInteger(0, "CloseSell", OBJPROP_HIDDEN, true);
    ObjectSetInteger(0, "CloseSell", OBJPROP_STATE, false);
    calc_profits();
    ObjectSetString(0, "CloseBuy", OBJPROP_TEXT,
                    "Close Buys " + DoubleToStr(profitB, 2));
    ObjectSetString(0, "CloseSell", OBJPROP_TEXT,
                    "Close Sells " + DoubleToStr(profitS, 2));
    return(INIT_SUCCEEDED);
}
void OnDeinit(const int reason)
{
    ObjectDelete(0,"CloseBuy");
    ObjectDelete(0,"CloseSell");
}
void calc_profits()
{
    profitB = 0.0; profitS = 0.0;
    for (int cnt = 0; cnt < OrdersTotal(); cnt++) {
        if (!OrderSelect(cnt, SELECT_BY_POS))
            continue;  
        if ((Magic >= 0 && OrderMagicNumber() != Magic) || OrderSymbol() != Symbol())
            continue;
        if (StringLen(FilterComment) > 0 && StringCompare(FilterComment, OrderComment(), true) != 0)
            continue;
        if (OrderCloseTime() == 0) {
            if (OrderType() == OP_BUY)
                profitB += OrderProfit() + OrderSwap() + OrderCommission();
            else if (OrderType() == OP_SELL)
                profitS += OrderProfit() + OrderSwap() + OrderCommission();
        }
    }
}
void OnTick()
{
    calc_profits();
    ObjectSetString(0, "CloseBuy", OBJPROP_TEXT,
                    "Close Buys " + DoubleToStr(profitB, 2));
    ObjectSetString(0, "CloseSell", OBJPROP_TEXT,
                    "Close Sells " + DoubleToStr(profitS, 2));
}
void OnChartEvent(const int id, const long &lparam,
                  const double &dparam, const string &sparam)
{
    if (sparam == "CloseBuy") {
        CloseOpenPositions(OP_BUY);
        ObjectSetInteger(0, "CloseBuy", OBJPROP_STATE, false);    
    }
    if (sparam == "CloseSell") {
        CloseOpenPositions(OP_SELL);
        ObjectSetInteger(0, "CloseBuy", OBJPROP_STATE, false);    
    }
}
void CloseOpenPositions(int op)
{
    for (int cnt = OrdersTotal() - 1; cnt >= 0; cnt--) { 
        if (!OrderSelect(cnt, SELECT_BY_POS))
            continue;  
        if ((Magic >= 0 && OrderMagicNumber() != Magic) || OrderSymbol() != Symbol())
            continue;
        if (StringLen(FilterComment) > 0 && StringCompare(FilterComment, OrderComment(), true) != 0)
            continue;
        if (OrderCloseTime() == 0 && OrderType() == op) {
            if (!OrderClose(OrderTicket(), OrderLots(), OrderClosePrice(),
                            Slippage, CLR_NONE))
                Alert("Close attempt for order #", OrderTicket(),
                      " returned error code ", GetLastError());
        }
    }
}