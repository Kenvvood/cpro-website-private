//+------------------------------------------------------------------+
//|                                         CPro Tool MovingAverageMiracle MT5               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include  <trade/trade.mqh>

CTrade trade;
input int MovingAvPeriodSlow = 200;
input int MovingAvShiftSlow = 0;
input int MovingAvPeriodFast = 20;
input int MovingAvShiftFast = 0;
input double TPBuy = 0.0001;
input double SLBuy = 0.0001;
input double TPSell = 0.0001;
input double SLSell = 0.0001;
input double Lotsize = 1.0;
double accountbalancebeginning;
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
      accountbalancebeginning = AccountInfoDouble(ACCOUNT_BALANCE);
      return(INIT_SUCCEEDED);
  }
void OnTick()
  {
      static datetime timestamp;
      datetime time = iTime(_Symbol,PERIOD_CURRENT,0); 
      if(timestamp != time)
      {
         timestamp = time;
         static int handleSlowMa = iMA(_Symbol,PERIOD_CURRENT,MovingAvPeriodSlow, MovingAvShiftSlow,MODE_SMA,PRICE_CLOSE);
         double slowMaArray[];
         CopyBuffer(handleSlowMa,0,1,2,slowMaArray);
         ArraySetAsSeries(slowMaArray,true);
         static int handleFastMa = iMA(_Symbol,PERIOD_CURRENT,MovingAvPeriodFast, MovingAvShiftFast,MODE_SMA,PRICE_CLOSE);
         double FastMaArray[];
         CopyBuffer(handleFastMa,0,1,2,FastMaArray);
         ArraySetAsSeries(FastMaArray,true);
         if(FastMaArray[0] > slowMaArray[0] && FastMaArray[1] < slowMaArray[1])
         {
            double ask = SymbolInfoDouble(_Symbol,SYMBOL_ASK);
            double tpbuyx = ask + TPBuy;
            double slbuyx = ask - SLBuy;
            trade.Buy(Lotsize,_Symbol,ask,slbuyx,tpbuyx,"BUYTRADE");
         }
         if(FastMaArray[0] < slowMaArray[0] && FastMaArray[1] > slowMaArray[1])
         {
            double ask = SymbolInfoDouble(_Symbol,SYMBOL_ASK);
            double tpsellx = ask + TPSell;
            double slsellx = ask - SLSell;
            trade.Sell(Lotsize,_Symbol,ask,slsellx,tpsellx,"SELLTRADE");         
         }
      }
      //STATISTICS
      double accountbalance = AccountInfoDouble(ACCOUNT_BALANCE);
      double accountprofit = AccountInfoDouble(ACCOUNT_PROFIT);
      double accountequity = AccountInfoDouble(ACCOUNT_EQUITY);
      accountprofit = accountequity - accountbalancebeginning;
      accountprofit = NormalizeDouble(accountprofit,2);
      // DISPLAY OF VALUES ON CHART   
      Comment("\nServertime: ", TimeCurrent(),
              "\nCurrenttime: ",TimeCurrent(),
              "\nProfit: ",accountprofit,
              "\nEquity: ",accountequity);
  }//END ON TICK