//+------------------------------------------------------------------+
//|                                         CPro Tool movestoploss MT4                       |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
input bool AutoTrail= true;
input int Distance2Trail=300;
double When2Trail;
int OnInit()
  {
//---
  HideTestIndicators(true);
   if( !IsTradeAllowed()){
      Alert("Enable AutoTrading Please"); 
     return(0);
     }
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
   ObjectDelete("WAMEK1");
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
  ATRMaxMin();
 MoveStoploss();
 DrawLABEL(0,"WAMEK1",StringConcatenate("Distance2MoveStopLoss: "+DoubleToStr(When2Trail/Point(),0))+"pips", 12*50,40,DodgerBlue);
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|   Move stoploss with price action                                |
//+------------------------------------------------------------------+
void MoveStoploss()
  {  
   int OrdMod;
   if(AutoTrail==true) When2Trail =NormalizeDouble( 0.85*AtrMax,Digits);
   else When2Trail=NormalizeDouble( Distance2Trail*Point(),Digits);
   for(int p=OrdersTotal()-1; p >=0; p--)
      if(OrderSelect(p,SELECT_BY_POS,MODE_TRADES))
        {
         if(OrderSymbol()==Symbol() )
           {
            if(OrderType()==OP_BUY)
               if(Bid> OrderOpenPrice() && OrderStopLoss()<Bid-When2Trail)
                  OrdMod= OrderModify(OrderTicket(),OrderOpenPrice(),Bid-When2Trail,OrderTakeProfit(),0,clrNONE);
            if(OrderType()==OP_SELL)
               if(Ask < OrderOpenPrice() && (OrderStopLoss()>Ask+When2Trail || OrderStopLoss()==0))
                  OrdMod= OrderModify(OrderTicket(),OrderOpenPrice(),Ask+When2Trail,OrderTakeProfit(),0,clrNONE);
           }
        }
  }
//--- ATR--------
double AtrMin,AtrMax;
void ATRMaxMin(){
 AtrMin =876532009;
 AtrMax =-876532009;
  for (int i=30; i>0; i--) {
 double Atr = iATR(Symbol(),Period(),7,i);
 AtrMax = MathMax(AtrMax,Atr);
 AtrMin = MathMin(AtrMin,Atr);
     }
}
//---Draw Object on the chart
void DrawLABEL(long Id, string ObjName, string Info, float X, float Y, color clr)
  {
   if(ObjectFind(Id,ObjName)==-1)
     {
      ObjectCreate(Id,ObjName, OBJ_LABEL, 0, 0, 0);
      ObjectSet(ObjName, OBJPROP_CORNER, 0);
      ObjectSet(ObjName, OBJPROP_XDISTANCE, X);
      ObjectSet(ObjName, OBJPROP_YDISTANCE, Y);
      ObjectSetInteger(Id,ObjName,OBJPROP_FONTSIZE,10); 
      ChartRedraw(Id);
     }
   ObjectSetText(ObjName,Info,12,"Arial",clr);
  }