
//+------------------------------------------------------------------+
//|                 YCT Tool Migliorino_mq5                            |
//|                         城诺科技                            |
//|                         WeChat: Lookee333                        |
//+------------------------------------------------------------------+


//+------------------------------------------------------------------+
//|                           Brand Panel                             |
//+------------------------------------------------------------------+
#include <mq5\Marketing.mqh>

// 品牌面板将在 OnInit() 中通过 InitMarketing() 初始化
// 品牌面板将在 OnDeinit() 中通过 DeinitMarketing() 清理

﻿//+-----------------------------------------------------------------------+
//|                                                     MIGLIORINO TS.mq5 |
//| Copyright © 2021, Davide Dallari, Simone Rubessi & Massimo Torricelli |
//+-----------------------------------------------------------------------+

#property copyright "Copyright © 2021, Davide Dallari, Simone Rubessi & Massimo Torricelli"
#define VERSION "1.52"
#property version VERSION
#define desc_agg "Entering with M1, (C1, C2, C3) + last closed HeikinAshi M15; TP with last closed HeikinAshi HikinAshi H1 switched"

#include <Trade\Trade.mqh>
CTrade trade;

//+------------------------------------------------------------------+
//|   DAVIDE - Handles                                               |
//+------------------------------------------------------------------+
int MIGL1definition;

int CI0definition;
int CI1definition;
int CI2definition;
int CI3definition;

int FF1definition;
int FF2definition;
int FF3definition;

int HA1definition;
int HA2definition;

//+------------------------------------------------------------------+
//|   DAVIDE - Inizializzazione cicli di trade                       |
//+------------------------------------------------------------------+
#property script_show_inputs
enum cycles                                        //Tipi di ciclo
  {
   day = 0,                                        //1 giorno - 24 h
   tracy_minus_2 = 1,                              //2 giorni - 48 h
   tracy_minus_1 = 2,                              //4 giorni - 96 h
   tracy = 3,                                      //8 giorni - 192 h
   tracy_plus_1 = 4,                               //16 giorni - 384 h
   month = 5,                                      //32 giorni - 768 h

   day_5days = 6,                                  // 1 day   - 18 h (5 days)
   tracy_minus_2_5days = 7,                        // 2 days  - 36 h (5 days)
   tracy_minus_1_5days = 8,                        // 4 days  - 72 h (5 days)
   tracy_5days = 9,                                // 8 days  - 144 h (5 days)
   tracy_plus_1_5days = 10,                        // 16 days - 288 h (5 days)
   month_5days = 11,                               // 32 days - 576 h (5 days)
  };
input cycles CycleToTrade = tracy;                 //Ciclo da tradare

//+------------------------------------------------------------------+
//|   DAVIDE - Inizializzazione variabili di trade                   |
//+------------------------------------------------------------------+
int OrigPeriodToTrade;                             //Periodo da tradare (h)
int PeriodToTrade;                                 //Periodo da tradare (considerando il timeframe scelto)

ENUM_TIMEFRAMES PeriodHA1 = PERIOD_H1;             //Inizializza il timeframe HeikinAshi 1
ENUM_TIMEFRAMES PeriodHA2 = PERIOD_H1;             //Inizializza il timeframe HeikinAshi 2

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int PeriodCI0;                                     //Periodo di riferimento Indicatore ciclico0 (considerando il timeframe scelto)
int PeriodCI1;                                     //Periodo di riferimento Indicatore ciclico1 (considerando il timeframe scelto)
int PeriodCI2;                                     //Periodo di riferimento Indicatore ciclico2 (considerando il timeframe scelto)
int PeriodCI3;                                     //Periodo di riferimento Indicatore ciclico3 (considerando il timeframe scelto)

input double OrigLotsToBuy = 0.10;                 //Lotti da comprare ad ogni ingresso standard
double LotsToBuy;                                  //Lotti effettivi da comprare a seconda dell'ingresso
//input int TP_Pips = 10;                            //Pips per target take-profit
//input int SL_Pips = 10;                            //Pips per target stop-loss
int CI_thread_DN = 1;                              //Soglia dimezzamento lotti
int CI_thread_UP = 6;                              //Soglia raddoppio lotti
const int Commission = 0;                          //Commissione per ogni deal da 1 lotto

input string xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;

//+------------------------------------------------------------------+
//|   DAVIDE - Inizializzazione condizioni di ingresso               |
//+------------------------------------------------------------------+
input string CONDIZIONI_DI_INGRESSO_MIGLIORINO;
bool MIGL_filter = true;
input bool signal_slow_cross = true;               //- il segnale oltrepassa la banda lenta
input bool signal_all_cross = false;               //- il segnale oltrepassa tutte 3 le bande
input bool bands_all_cross = false;                //- ogni banda oltrepassa quella immediatamente più lenta
input bool cross_back = false;                     //- il segnale/le bande rientrano (NB: da usare in abbinamento)

input string xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;

input string CONDIZIONI_DI_HEIKINASHI;
bool HA_filter = true;
input bool HA1_concord = true;                     //- si attende la concordanza con HA1 di 1 ciclo superiore
input bool HA2_concord = true;                     //- si esce con la discordanza di HA2 di 3 cicli superiori

input string xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;

input string CONDIZIONI_DI_INGRESSO_INDICATORE_CICLICO;
bool CI_filter = true;
input bool CI0_concord = true;                     //- si verifica la concordanza del CI del ciclo stesso
input bool CI1_concord = true;                     //- si verifica la concordanza del CI di 1 ciclo superiore
input bool CI2_concord = true;                     //- si verifica la concordanza del CI di 2 cicli superiore
input bool CI3_concord = true;                     //- si verifica la concordanza del CI di 3 cicli superiore

input string xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;
/*
//+------------------------------------------------------------------+
//|   DAVIDE - Inizializzazione trigger di ingresso e uscita         |
//+------------------------------------------------------------------+
enum enter_trigger                                 //elenco dei trigger di ingresso nel mercato
  {
   None_in = 0,                                    //false
   PriceAction_in = 1,                             //PriceAction
  };
input enter_trigger Trigger_in = None_in;          //TRIGGER DI INGRESSO

enum exit_trigger                                  //elenco dei trigger di uscita nel mercato
  {
   Migliorino_out = 0,                             //Migliorino - Rientro nelle bande medie
  };
input exit_trigger Trigger_out = Migliorino_out;   //TRIGGER DI USCITA

input string xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;
*/
//+------------------------------------------------------------------+
//|   DAVIDE - Inizializzazione variabili indicatori                 |
//+------------------------------------------------------------------+
bool signalXdownSlow = false;                      //Migliorino - variabile che indica se il segnale ha oltrepassato la banda lenta inferiore
bool signalXupSlow = false;                        //Migliorino - variabile che indica se il segnale ha oltrepassato la banda lenta superiore
bool signalXdown = false;                          //Migliorino - variabile che indica se il segnale ha oltrepassato le 3 bande inferiori
bool signalXup = false;                            //Migliorino - variabile che indica se il segnale ha oltrepassato le 3 bande superiori
bool bandsXdown = false;                           //Migliorino - variabile che indica se ciascuna banda ha oltrepassato al ribasso la propria banda più lenta
bool bandsXup = false;                             //Migliorino - variabile che indica se ciascuna banda ha oltrepassato al rialzo la propria banda più lenta
bool backXdown = false;                            //Migliorino - variabile che indica se il segnale è rientrato al ribasso all'interno della banda oltrepassata al rialzo
bool backXup = false;                              //Migliorino - variabile che indica se il segnale è rientrato al rialzo all'interno della banda oltrepassata al ribasso

int cross_candle = 0;                              //Numero di candela a ritroso in cui è avvenuto l'ultimo tocco delle bande di Migliorino
int cross_candle_new = 0;                          //Numero di nuova candela a ritroso in cui è avvenuto l'ultimo tocco delle bande di Migliorino
int enter_candle = 0;                              //Numero di candela a ritroso in cui è avvenuto l'ultimo ingresso nel mercato
int exit_candle = 0;                               //Numero di candela a ritroso in cui è avvenuta l'ultima uscita dal mercato

bool HA1positive = false;                          //HA - variabile che indica se la candela HeikinAshi 1 è positiva
bool HA1negative = false;                          //HA - variabile che indica se la candela HeikinAshi 1 è negativa
bool HA2positive = false;                          //HA - variabile che indica se la candela HeikinAshi 2 è positiva
bool HA2negative = false;                          //HA - variabile che indica se la candela HeikinAshi 2 è negativa

bool CI0positive = false;                          //CI - variabile che indica se l'indicatore ciclico 0 è positivo
bool CI0negative = false;                          //CI - variabile che indica se l'indicatore ciclico 0 è negativo
bool CI1positive = false;                          //CI - variabile che indica se l'indicatore ciclico 1 è positivo
bool CI1negative = false;                          //CI - variabile che indica se l'indicatore ciclico 1 è negativo
bool CI2positive = false;                          //CI - variabile che indica se l'indicatore ciclico 2 è positivo
bool CI2negative = false;                          //CI - variabile che indica se l'indicatore ciclico 2 è negativo
bool CI3positive = false;                          //CI - variabile che indica se l'indicatore ciclico 3 è positivo
bool CI3negative = false;                          //CI - variabile che indica se l'indicatore ciclico 3 è negativo

input int Migl_check_fraction = 16;                //Migliorino - Frazione di periodo in cui verificare il tocco 1/x
input double bands_tolerance = 10;                 //Migliorino - Tolleranza % tra bande opposte
input double signal_tolerance = 10;                //Migliorino - Tolleranza % tra segnale e banda
input double SL_tolerance = 5;                     //Migliorino - Tolleranza % tra stop-loss e banda lenta
//input int max_trend = 1;                           //PriceAction - N° massimo di candele di colore opposto al trend

input int      ATcalc = 10000;                     //AutoTuning - Frequenza di calcolo
input double   ATmultiplier = 1.5;                 //AutoTuning - Moltiplicatore del periodo da considerare
input int      AToutMAX = 1;                       //AutoTuning - N° massimo di picchi superati dal segnale
input double   Increment = 0.05;                   //AutoTuning - Step incremento ampiezza bande
input double   Decrement = 0;                      //AutoTuning - Decremento finale ampiezza bande

input string xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx;

//+------------------------------------------------------------------+
//|   DAVIDE - Inizializzazione variabili interne                    |
//+------------------------------------------------------------------+
double coefficient = 1;                            //Coefficiente di adeguamento al timeframe scelto
double ratio_HA1 = 1;                              //Rapporto tra timeframe HikinAshi 1 e timeframe di base
double ratio_HA2 = 1;                              //Rapporto tra timeframe HikinAshi 2 e timeframe di base

int Dim = 0;                                       //Dimensione dei vettori degli indicatori

double Ask = 0;                                    //Prezzo di acquisto
double Bid = 0;                                    //Prezzo di vendita

string order_in = "";                              //Ordine di ingresso
string order_out = "";                             //Ordine di uscita
string position = "";                              //Posizione in cui si è entrati

datetime time_in = 0;                              //Data e ora di ingresso nel mercato
datetime time_out = 0;                             //Data e ora di uscita dal mercato
datetime time_in_array[];                          //Array delle date degli ingressi di una tradata
datetime time_out_array[];                         //Array delle date delle uscite di una tradata
double price_in = 0;                               //Prezzi di ingresso nel mercato (esclusi gli stop-loss)
double price_out = 0;                              //Prezzi di uscita dal mercato
double price_in_array[];                           //Array dei prezzi degli ingressi di una tradata
double price_out_array[];                          //Array dei prezzi delle uscite di una tradata
double TP_price = 0;                               //Take-profit price
double SL_price = 0;                               //Stop-loss price

int SL_count = 0;                                  //Contatore di stop-loss nella tradata
double SL_loss = 0;                                //Accumulatore di stop-loss nella tradata
double profit_out = 0;                             //Profitto o perdita della tradata

double Balance_max = 0;                            //Bilancio massimo raggiunto durante il backtest
double DD_until_stop = 0.001;                      //Drawdown (di equity) massimo nella singola tradata fino a stop-loss
double DD_trade = 0.001;                           //Drawdown (di equity) massimo nella singola tradata (somma di tutti i tratti)
double Max_DD_trade = 0.001;                       //Drawdown massimo tra i drawdown di trade
double DD_backtest = 0.001;                        //Drawdown massimo di backtest

int bars = 0;                                      //Contatore di candele
bool new_bar = false;                              //Variabile che indica se siamo appena passati a una nuova candela
bool new_touch = false;                            //Variabile che si attiva quando è avvenuto un nuovo tocco

int period_to_write = 0;                           //Numero di candele da utilizzare nella scrittura dei file .csv
int file_count = 1001;                             //Progressivo per la creazione dei file
string InpFileName = IntegerToString(file_count);  //Nome file
string InpDirectoryName = "DataTest";              //Nome directory

//+------------------------------------------------------------------+
//|   MASSIMO - Inizializzazione variabili Telegram e file .csv      |
//+------------------------------------------------------------------+
#include <Comment.mqh>
#include <Telegram.mqh>

//--- Variabili Telegram
long chat_ID = -1001429715820;         //Questo serve SOLO se si vuole mandare un messaggio dalla funzione OnInit() dove non si sa quale chat parla
bool msg_sent = 0;                     //Verifica che non sia già stato mandato un messaggio relativo all'oltrepassamento della BdM

//--- Variabili per menù tastiera
#define LOCK_TEXT       "Lock"
#define UNLOCK_TEXT     "Unlock"
#define LOCK_CODE       "\xF512"
#define UNLOCK_CODE     "\xF513"

const ENUM_TIMEFRAMES _periods[]= {PERIOD_M1,PERIOD_M5,PERIOD_M15,PERIOD_M30,PERIOD_H1,PERIOD_H4,PERIOD_D1,PERIOD_W1,PERIOD_MN1};

input bool Use_FileCSV = true;
input bool Use_Telegram = true;

//+------------------------------------------------------------------+
//|   MASSIMO - CMyBot                                               |
//+------------------------------------------------------------------+
class CMyBot: public CCustomBot
  {
private:
   ENUM_LANGUAGES    m_lang;
   string            m_symbol;
   ENUM_TIMEFRAMES   m_period;
   string            m_template;
   CArrayString      m_templates;
   bool              m_lock_state;

public:
   //+------------------------------------------------------------------+
   void              CMyBot::CMyBot(void)
     {
      m_lock_state=true;
     }
   //+------------------------------------------------------------------+
   void              Language(const ENUM_LANGUAGES _lang) {m_lang=_lang;}

   //+------------------------------------------------------------------+
   int               Templates(const string _list)
     {
      m_templates.Clear();
      //--- parsing
      string text=StringTrim(_list);
      if(text=="")
         return(0);

      //---
      while(::StringReplace(text,"  "," ")>0);
      ::StringReplace(text,";"," ");
      ::StringReplace(text,","," ");

      //---
      string array[];
      int amount=StringSplit(text,' ',array);
      amount=fmin(amount,5);

      for(int i=0; i<amount; i++)
        {
         array[i]=StringTrim(array[i]);
         if(array[i]!="")
            m_templates.Add(array[i]);
        }

      return(amount);
     }

   //+------------------------------------------------------------------+
   int               SendScreenShot(const long _chat_id,
                                    const string _symbol,
                                    const ENUM_TIMEFRAMES _period,
                                    const string _template=NULL)
     {
      int result=0;
      if(Use_Telegram)
        {
         long chart_id=ChartOpen(_symbol,_period);
         if(chart_id==0)
            return(ERR_CHART_NOT_FOUND);

         ChartSetInteger(ChartID(),CHART_BRING_TO_TOP,true);

         //--- updates chart
         //int wait=60;
         int wait=5;
         while(--wait>0)
           {
            if(SeriesInfoInteger(_symbol,_period,SERIES_SYNCHRONIZED))
               break;
            Sleep(500);
           }

         if(_template!=NULL)
            if(!ChartApplyTemplate(chart_id,_template))
               PrintError(_LastError,InpLanguage);

         ChartRedraw(chart_id);
         Sleep(500);

         ChartSetInteger(chart_id,CHART_SHOW_GRID,false);

         ChartSetInteger(chart_id,CHART_SHOW_PERIOD_SEP,false);

         string filename=StringFormat("%s%d.gif",_symbol,_period);

         if(FileIsExist(filename))
            FileDelete(filename);
         ChartRedraw(chart_id);

         Sleep(100);

         if(ChartScreenShot(chart_id,filename,800,600,ALIGN_RIGHT))
           {
            Sleep(100);

            bot.SendChatAction(_chat_id,ACTION_UPLOAD_PHOTO);

            //--- waitng 30 sec for save screenshot
            wait=60;
            while(!FileIsExist(filename) && --wait>0)
               Sleep(500);

            //---
            if(FileIsExist(filename))
              {
               string screen_id;
               //result=bot.SendPhoto(_chat_id,filename,screen_id,_symbol+"_"+StringSubstr(EnumToString(_period),7));
               result=bot.SendPhoto(screen_id,_chat_id,filename,_symbol+"_"+StringSubstr(EnumToString(_period),7));
              }
            else
              {
               string mask=m_lang==LANGUAGE_EN?"Screenshot file '%s' not created.":"Файл скриншота '%s' не создан.";
               PrintFormat(mask,filename);
              }

           }

         ChartClose(chart_id);
        }
      return(result);
     }

   //+------------------------------------------------------------------+
   void              ProcessMessages(void)
     {

#define EMOJI_TOP    "\xF51D"
#define EMOJI_BACK   "\xF519"
#define KEYB_MAIN    (m_lang==LANGUAGE_EN)?"[[\"Account Info\",\"Altro...\"],[\"Charts\"],[\"Ordini\"]]":"[[\"Информация\"],[\"Котировки\"],[\"Графики\"]]"
#define KEYB_SYMBOLS "[[\""+EMOJI_TOP+"\",\"GBPUSD\",\"EURUSD\"],[\"AUDUSD\",\"USDJPY\",\"EURJPY\"],[\"USDCAD\",\"USDCHF\",\"EURCHF\"]]"
#define KEYB_PERIODS "[[\""+EMOJI_TOP+"\",\"M1\",\"M5\",\"M15\"],[\""+EMOJI_BACK+"\",\"M30\",\"H1\",\"H4\"],[\" \",\"D1\",\"W1\",\"MN1\"]]"
#define KEYB_TS "[[\""+EMOJI_TOP+"\",\""+EMOJI_BACK+"\"],[\"SELL\",\"BUY\"],[\"Chiudi tutte le posizioni\"],[\"\xF512 Lock\"]]"
#define KEYB_ALTRO "[[\""+EMOJI_TOP+"\",\""+EMOJI_BACK+"\"],[\"Kill TS\"]]"

      for(int i=0; i<m_chats.Total(); i++)
        {
         CCustomChat *chat=m_chats.GetNodeAtIndex(i);

         if(!chat.m_new_one.done)
           {
            chat.m_new_one.done=true;
            string text=chat.m_new_one.message_text;

            Print("Messaggio ricevuto: ", text);

            //--- start
            if(text=="/start" || text=="/help" || text=="/commands@testDMtradingbot")
              {
               chat.m_state=0;
               string msg="The bot works with your trading account:\n";
               msg+="/info - get account information\n";
               msg+="/quotes - get quotes\n";
               msg+="/charts - get chart images\n";

               if(m_lang==LANGUAGE_RU)
                 {
                  msg="Бот работает с вашим торговым счетом:\n";
                  msg+="/info - запросить информацию по счету\n";
                  msg+="/quotes - запросить котировки\n";
                  msg+="/charts - запросить график\n";
                 }

               SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_MAIN,false,false));
               continue;
              }

            //---
            if(text==EMOJI_TOP)
              {
               chat.m_state=0;
               string msg=(m_lang==LANGUAGE_EN)?"Choose a menu item":"Выберите пункт меню";
               SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_MAIN,false,false));
               continue;
              }

            //---
            if(text==EMOJI_BACK)
              {
               if(chat.m_state==31)
                 {
                  chat.m_state=3;
                  string msg=(m_lang==LANGUAGE_EN)?"Enter a symbol name like 'EURUSD'":"Введите название инструмента, например 'EURUSD'";
                  SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_SYMBOLS,false,false));
                 }
               else
                  if(chat.m_state==32)
                    {
                     chat.m_state=31;
                     string msg=(m_lang==LANGUAGE_EN)?"Select a timeframe like 'H1'":"Введите период графика, например 'H1'";
                     SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_PERIODS,false,false));
                    }
                  else
                    {
                     chat.m_state=0;
                     string msg=(m_lang==LANGUAGE_EN)?"Choose a menu item":"Выберите пункт меню";
                     SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_MAIN,false,false));
                    }
               continue;
              }

            //---
            if(text=="/info" || text=="Account Info" || text=="Информация")
              {
               chat.m_state=1;
               string currency=AccountInfoString(ACCOUNT_CURRENCY);
               string msg=StringFormat("%d: %s\n",AccountInfoInteger(ACCOUNT_LOGIN),AccountInfoString(ACCOUNT_SERVER));
               msg+=StringFormat("%s: %.2f %s\n",(m_lang==LANGUAGE_EN)?"Balance":"Баланс",AccountInfoDouble(ACCOUNT_BALANCE),currency);
               msg+=StringFormat("%s: %.2f %s\n",(m_lang==LANGUAGE_EN)?"Profit":"Прибыль",AccountInfoDouble(ACCOUNT_PROFIT),currency);
               SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_MAIN,false,false));
              }

            //---
            if(text=="/quotes" || text=="Quotes" || text=="Котировки")
              {
               chat.m_state=2;
               string msg=(m_lang==LANGUAGE_EN)?"Enter a symbol name like 'EURUSD'":"Введите название инструмента, например 'EURUSD'";
               SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_SYMBOLS,false,false));
               continue;
              }

            //---
            if(text=="/charts" || text=="Charts" || text=="Графики")
              {
               //chat.m_state=31;
               //string msg=(m_lang==LANGUAGE_EN)?"Enter a symbol name like 'EURUSD'":"Введите название инструмента, например 'EURUSD'";
               //SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_SYMBOLS,false,false));
               
                 
               //--- template
               chat.m_state=32;
               string str="[[\""+EMOJI_BACK+"\",\""+EMOJI_TOP+"\"]";
               str+=",[\"None\"]";
               for(int k=0; k<m_templates.Total(); k++)
                  str+=",[\""+m_templates.At(k)+"\"]";
               str+="]";

               SendMessage(chat.m_id,(m_lang==LANGUAGE_EN)?"Select a template":"Выберите шаблон",ReplyKeyboardMarkup(str,false,false));
                                
               
               continue;
              }

            //---
            if(text=="/ordini" || text=="Ordini" || text=="Графики")
              {
               chat.m_state=4;
               string msg=(m_lang==LANGUAGE_EN)?"Gestione Trading System":"Введите название инструмента, например 'EURUSD'";
               SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_TS,false,false));
              }

            //---
            if(text=="/altro" || text=="Altro..." || text=="Графики")
              {
               chat.m_state=5;
               string msg=(m_lang==LANGUAGE_EN)?"Scegli un'opzione":"Введите название инструмента, например 'EURUSD'";
               SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_ALTRO,false,false));
              }

            //--- Quotes
            if(chat.m_state==2)
              {
               string mask=(m_lang==LANGUAGE_EN)?"Invalid symbol name '%s'":"Инструмент '%s' не найден";
               string msg=StringFormat(mask,text);
               StringToUpper(text);
               string symbol=text;
               if(SymbolSelect(symbol,true))
                 {
                  double open[1]= {0};

                  m_symbol=symbol;
                  //--- upload history
                  for(int k=0; k<3; k++)
                    {
#ifdef __MQL4__
                     double array[][6];
                     ArrayCopyRates(array,symbol,PERIOD_D1);
#endif

                     Sleep(2000);
                     CopyOpen(symbol,PERIOD_D1,0,1,open);
                     if(open[0]>0.0)
                        break;
                    }

                  int digits=(int)SymbolInfoInteger(symbol,SYMBOL_DIGITS);
                  double bid=SymbolInfoDouble(symbol,SYMBOL_BID);

                  CopyOpen(symbol,PERIOD_D1,0,1,open);
                  if(open[0]>0.0)
                    {
                     double percent=100*(bid-open[0])/open[0];
                     //--- sign
                     string sign=ShortToString(0x25B2);
                     if(percent<0.0)
                        sign=ShortToString(0x25BC);

                     msg=StringFormat("%s: %s %s (%s%%)",symbol,DoubleToString(bid,digits),sign,DoubleToString(percent,2));
                    }
                  else
                    {
                     msg=(m_lang==LANGUAGE_EN)?"No history for ":"Нет истории для "+symbol;
                    }
                 }

               SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_SYMBOLS,false,false));
               continue;
              }

            //--- Charts
            if(chat.m_state==3)
              {

               StringToUpper(text);
               string symbol=text;
               if(SymbolSelect(symbol,true))
                 {
                  m_symbol=symbol;

                  chat.m_state=32;
                  string msg=(m_lang==LANGUAGE_EN)?"Select a timeframe like 'H1'":"Введите период графика, например 'H1'";
                  SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_PERIODS,false,false));
                 }
               else
                 {
                  string mask=(m_lang==LANGUAGE_EN)?"Invalid symbol name '%s'":"Инструмент '%s' не найден";
                  string msg=StringFormat(mask,text);
                  SendMessage(chat.m_id,msg,ReplyKeyboardMarkup(KEYB_SYMBOLS,false,false));
                 }
               continue;
              }

            //Charts->Periods
            if(chat.m_state==31)
              {
               bool found=false;
               int total=ArraySize(_periods);
               for(int k=0; k<total; k++)
                 {
                  string str_tf=StringSubstr(EnumToString(_periods[k]),7);
                  if(StringCompare(str_tf,text,false)==0)
                    {
                     m_period=_periods[k];
                     found=true;
                     break;
                    }
                 }

               if(found)
                 {
                  //--- template
                  chat.m_state=32;
                  string str="[[\""+EMOJI_BACK+"\",\""+EMOJI_TOP+"\"]";
                  str+=",[\"None\"]";
                  for(int k=0; k<m_templates.Total(); k++)
                     str+=",[\""+m_templates.At(k)+"\"]";
                  str+="]";

                  SendMessage(chat.m_id,(m_lang==LANGUAGE_EN)?"Select a template":"Выберите шаблон",ReplyKeyboardMarkup(str,false,false));
                 }
               else
                 {
                  SendMessage(chat.m_id,(m_lang==LANGUAGE_EN)?"Invalid timeframe":"Неправильно задан период графика",ReplyKeyboardMarkup(KEYB_PERIODS,false,false));
                 }
               continue;
              }
            //---
            if(chat.m_state==32)
              {
               m_template=text;
               if(m_template=="None")
                  m_template="standard";
               int result=SendScreenShot(chat.m_id,m_symbol,m_period,m_template);
               if(result!=0)
                  Print(GetErrorDescription(result,InpLanguage));
              }

            //--- Ordini
            if(chat.m_state==4)
              {
               Ask = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_ASK),_Digits);
               Bid = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);

               //--- Inserisci Ordine
               if(text=="SELL")
                 {
                  trade.Sell(LotsToBuy,NULL,Bid,NULL,NULL,NULL);
                  Print("Inviato ordine di SELL");
                  int result=SendScreenShot(chat.m_id,m_symbol,m_period,"3_Migliorino_bands_8DD_7days");
                  if(result!=0)
                     Print(GetErrorDescription(result,InpLanguage));
                 }

               if(text=="BUY")
                 {
                  trade.Buy(LotsToBuy,NULL,Ask,NULL,NULL,NULL);
                  Print("Inviato ordine di BUY");
                  int result=SendScreenShot(chat.m_id,m_symbol,m_period,"3_Migliorino_bands_8DD_7days");
                  if(result!=0)
                     Print(GetErrorDescription(result,InpLanguage));
                 }

               if(text=="Chiudi tutte le posizioni")
                 {
                  //CloseAllPositions();     //DA RIVEDERE
                  Print("Chiuse tutte le posizioni");
                  int result=SendScreenShot(chat.m_id,m_symbol,m_period,"3_Migliorino_bands_8DD_7days");
                  if(result!=0)
                     Print(GetErrorDescription(result,InpLanguage));
                  SendMessage(chat.m_id,"Chiuse tutte le posizioni");
                 }

               //--- Unmute
               if(text==LOCK_CODE+" "+LOCK_TEXT)
                 {
                  m_lock_state=false;
                  string kyb = "[[\""+EMOJI_TOP+"\",\""+EMOJI_BACK+"\"],[\"SELL\",\"BUY\"],[\"Chiudi tutte le posizioni\"],[\"\xF513 Unlock\"]]";
                  bot.SendMessage(chat.m_id,UNLOCK_TEXT,bot.ReplyKeyboardMarkup(kyb,false,false));
                 }

               //--- Mute
               if(text==UNLOCK_CODE+" "+UNLOCK_TEXT)
                 {
                  m_lock_state=true;
                  string kyb = "[[\""+EMOJI_TOP+"\",\""+EMOJI_BACK+"\"],[\"SELL\",\"BUY\"],[\"Chiudi tutte le posizioni\"],[\"\xF512 Lock\"]]";
                  bot.SendMessage(chat.m_id,LOCK_TEXT,bot.ReplyKeyboardMarkup(kyb,false,false));
                 }
               continue;
              }

            //--- Altro...
            if(chat.m_state==5)
              {

               //--- Inserisci Ordine
               if(text=="Kill TS")
                 {
                  string msg = "Inviato ordine di stoppare il TS";
                  Print(msg);
                  int result = bot.SendMessage(chat.m_id,msg);
                  if(result!=0)
                     Print(GetErrorDescription(result,InpLanguage));

                  ExpertRemove();
                 }
               continue;
              }
           }
        }
     }
  };

//+------------------------------------------------------------------+
#define EXPERT_NAME     "Telegram Bot"
#define EXPERT_VERSION  "1.00"
#property version       EXPERT_VERSION
#define CAPTION_COLOR   clrWhite
#define LOSS_COLOR      clrOrangeRed

//+------------------------------------------------------------------+
//|   MASSIMO - Input parameters                                     |
//+------------------------------------------------------------------+
ENUM_LANGUAGES          InpLanguage=LANGUAGE_EN;//Language
ENUM_UPDATE_MODE        InpUpdateMode=UPDATE_NORMAL;//Update Mode
//input string            InpChannelName="davidetradingchannel";                      //Channel Name
//input string            InpToken="926822042:AAGrLjhhe1HYPpyAfsn9PrlsFlnjwKV07PI";   //Token Davide
input string            InpToken="871454864:AAGKLdMR0SI_lqSeYkAiHlBnkUqhLfAXYKs";   //Token
string                  InpUserNameFilter="";                                       //Whitelist Usernames
string                  InpTemplates="Migliorino;3_Migliorino_bands_8DD_7days;Cyclic_Indicator_H4_7days;Cyclic_Indicator_D1_7days;DNA_192";  //Templates

//---
CComment       comm;
CMyBot         bot;
ENUM_RUN_MODE  run_mode;
datetime       time_check;
int            web_error;
int            init_error;
string         photo_id=NULL;

//+------------------------------------------------------------------+
//|   DAVIDE - OnInit                                                |
//+------------------------------------------------------------------+
int OnInit()
  {
   int OrigPeriodCI0=0;       //Indicatore Ciclico - periodo di riferimento (h)
   int OrigPeriodCI1=0;       //Indicatore Ciclico - periodo di riferimento (h)
   int OrigPeriodCI2=0;       //Indicatore Ciclico - periodo di riferimento (h)
   int OrigPeriodCI3=0;       //Indicatore Ciclico - periodo di riferimento (h)

   switch(CycleToTrade)       //setto il periodo da tradare (h)
     {
      case day:               //1 giorno - 24h
         OrigPeriodToTrade = 24;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*4;
         OrigPeriodCI3 = OrigPeriodToTrade*8;
         break;
      case tracy_minus_2:     //2 giorni - 48h
         OrigPeriodToTrade = 48;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*4;
         OrigPeriodCI3 = OrigPeriodToTrade*8;
         break;
      case tracy_minus_1:     //4 giorni - 96h
         OrigPeriodToTrade = 96;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*4;
         OrigPeriodCI3 = OrigPeriodToTrade*8;
         break;
      case tracy:             //8 giorni - 192h
         OrigPeriodToTrade = 192;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*4;
         OrigPeriodCI3 = OrigPeriodToTrade*12;              //NB: trimestrale
         break;
      case tracy_plus_1:      //16 giorni - 384h
         OrigPeriodToTrade = 384;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*6;               //NB: trimestrale
         OrigPeriodCI3 = OrigPeriodToTrade*24;              //NB: annuale
         break;
      case month:             //32 giorni - 768h
         OrigPeriodToTrade = 768;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*3;               //NB: trimestrale
         OrigPeriodCI2 = OrigPeriodToTrade*12;              //NB: annuale
         OrigPeriodCI3 = OrigPeriodToTrade*24;              //NB: biennale
         break;
         

      case day_5days:            //1 giorno - 18h
         OrigPeriodToTrade = 18;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*4;
         OrigPeriodCI3 = OrigPeriodToTrade*8;
         break;
      case tracy_minus_2_5days:  //2 giorni - 36h
         OrigPeriodToTrade = 36;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*4;
         OrigPeriodCI3 = OrigPeriodToTrade*8;
         break;
      case tracy_minus_1_5days:  //4 giorni - 72h
         OrigPeriodToTrade = 72;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*4;
         OrigPeriodCI3 = OrigPeriodToTrade*8;
         break;
      case tracy_5days:          //8 giorni - 144h
         OrigPeriodToTrade = 144;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*4;
         OrigPeriodCI3 = OrigPeriodToTrade*12;              //NB: trimestrale
         break;
      case tracy_plus_1_5days:   //16 giorni - 288h
         OrigPeriodToTrade = 288;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*2;
         OrigPeriodCI2 = OrigPeriodToTrade*6;               //NB: trimestrale
         OrigPeriodCI3 = OrigPeriodToTrade*24;              //NB: annuale
         break;
      case month_5days:          //32 giorni - 576h
         OrigPeriodToTrade = 576;
         OrigPeriodCI0 = OrigPeriodToTrade;
         OrigPeriodCI1 = OrigPeriodToTrade*3;               //NB: trimestrale
         OrigPeriodCI2 = OrigPeriodToTrade*12;              //NB: annuale
         OrigPeriodCI3 = OrigPeriodToTrade*24;              //NB: biennale
         break;
     }

   switch(_Period)
     {
      //case 1:        //M1
      //   coefficient = 0.01666666666666666666666666666666666666666666666666666666;
      //   PeriodHA1 = PERIOD_M3;
      //   ratio_HA1 = 3;
      //   PeriodHA2 = PERIOD_M15;
      //   ratio_HA2 = 15;
      //   break;
      case 3:        //M3
         coefficient = 0.05;
         PeriodHA1 = PERIOD_M6;
         ratio_HA1 = 2;
         PeriodHA2 = PERIOD_M30;
         ratio_HA2 = 10;
         break;
      //case 5:        //M5
      //   coefficient = 0.08333333333333333333333333333333333333333333333333333333;
      //   PeriodHA1 = PERIOD_M15;
      //   ratio_HA1 = 3;
      //   PeriodHA2 = PERIOD_H1;
      //   ratio_HA2 = 12;
      //   break;
      case 6:        //M6
         coefficient = 0.1;
         PeriodHA1 = PERIOD_M12;
         ratio_HA1 = 2;
         PeriodHA2 = PERIOD_H1;
         ratio_HA2 = 10;
         break;
      case 15:       //M15
         coefficient = 0.25;
         PeriodHA1 = PERIOD_M30;
         ratio_HA1 = 2;
         PeriodHA2 = PERIOD_H4;
         ratio_HA2 = 16;
         break;
      case 30:       //M30
         coefficient = 0.5;
         PeriodHA1 = PERIOD_H1;
         ratio_HA1 = 2;
         PeriodHA2 = PERIOD_H12;
         ratio_HA2 = 24;
         break;
      case 16385:    //H1
         coefficient = 1;
         PeriodHA1 = PERIOD_H4;
         ratio_HA1 = 4;
         PeriodHA2 = PERIOD_D1;
         ratio_HA2 = 24;
         break;
      case 16388:    //H4
         coefficient = 4;
         PeriodHA1 = PERIOD_D1;
         ratio_HA1 = 6;
         PeriodHA2 = PERIOD_W1;
         ratio_HA2 = 42;
         break;
      case 16408:    //D1
         coefficient = 24;
         PeriodHA1 = PERIOD_W1;
         ratio_HA1 = 7;
         PeriodHA2 = PERIOD_MN1;
         ratio_HA2 = 30;
         break;
     }

   Print(_Symbol);
   Print(EnumToString(_Period));
   Print(EnumToString(PeriodHA1));
   Print(EnumToString(PeriodHA2));

   PeriodToTrade = int(OrigPeriodToTrade/coefficient);      //Setta il periodo da tradare con timeframe scelto

   Dim = PeriodToTrade;                                     //Setta la lunghezza del vettore degli array pari al periodo da tradare con timeframe scelto

   cross_candle = 0;                                        //Azzera il contatore della candela di attraversamento
   enter_candle = 0;                                        //Azzera il contatore della candela di ingresso
   exit_candle = 0;                                         //Azzera il contatore della candela di uscita

   PeriodCI0 = int(OrigPeriodCI0/coefficient);              //Setta il periodo di riferimento dell'Indicatore ciclico0 con timeframe scelto
   PeriodCI1 = int(OrigPeriodCI1/coefficient);              //Setta il periodo di riferimento dell'Indicatore ciclico1 con timeframe scelto
   PeriodCI2 = int(OrigPeriodCI2/coefficient);              //Setta il periodo di riferimento dell'Indicatore ciclico2 con timeframe scelto
   PeriodCI3 = int(OrigPeriodCI3/coefficient);              //Setta il periodo di riferimento dell'Indicatore ciclico3 con timeframe scelto

   period_to_write = int(4*PeriodToTrade);                  //Setta il numero di candele da utilizzare nella scrittura dei file .csv già considerando il timeframe scelto

   ArrayResize(time_in_array, period_to_write+1);
   ArrayResize(time_out_array, period_to_write+1);
   ArrayResize(price_in_array, period_to_write+1);
   ArrayResize(price_out_array, period_to_write+1);

//--- now make an attempt resulting in error
   MIGL1definition=iCustom(_Symbol,_Period,"Three_Editable_Migliorino_Bands",CycleToTrade,true,ATcalc,ATmultiplier,AToutMAX,Increment,Decrement,PRICE_CLOSE);

   if(MIGL_filter==true)
     {
      if(!ChartIndicatorAdd(0,0,MIGL1definition))
         PrintFormat("Failed to add Migliorino indicator on %d chart window. Error code  %d",0,GetLastError());
      else
         Print("Created indicator Migliorino");
     }

   HA1definition=iCustom(_Symbol,PeriodHA1,"Examples\\Heiken_Ashi");

   if(HA_filter==true && HA1_concord==true)
     {
      if(!ChartIndicatorAdd(0,0,HA1definition))
         PrintFormat("Failed to add HA1 indicator on %d chart window. Error code  %d",0,GetLastError());
      else
         Print("Created indicator HeikinAshi");
     }

   HA2definition=iCustom(_Symbol,PeriodHA2,"Examples\\Heiken_Ashi");

   if(HA_filter==true && HA2_concord==true)
     {
      if(!ChartIndicatorAdd(0,0,HA2definition))
         PrintFormat("Failed to add HA2 indicator on %d chart window. Error code  %d",0,GetLastError());
      else
         Print("Created indicator HeikinAshi");
     }

//FF1definition=iCustom(_Symbol,_Period,"Fourier_Transform",PeriodCI0,PRICE_CLOSE);
//ChartIndicatorAdd(0,0,FF0definition);

   CI0definition=iCustom(_Symbol,_Period,"Cyclic_Indicator",PeriodCI0,true,clrWhite,clrGray,PRICE_CLOSE);

   if(CI_filter==true && CI0_concord==true)
     {
      if(!ChartIndicatorAdd(0,1,CI0definition))
         PrintFormat("Failed to add CI0 indicator on %d chart window. Error code  %d",0,GetLastError());
      else
         Print("Created indicator CI0");
     }

//FF1definition=iCustom(_Symbol,_Period,"Fourier_Transform",PeriodCI1,PRICE_CLOSE);
//ChartIndicatorAdd(0,0,FF1definition);

   CI1definition=iCustom(_Symbol,_Period,"Cyclic_Indicator",PeriodCI1,true,clrWhite,clrGray,PRICE_CLOSE);

   if(CI_filter==true && CI1_concord==true)
     {
      if(!ChartIndicatorAdd(0,2,CI1definition))
         PrintFormat("Failed to add CI1 indicator on %d chart window. Error code  %d",0,GetLastError());
      else
         Print("Created indicator CI1");
     }

//FF2definition=iCustom(_Symbol,_Period,"Fourier_Transform",PeriodCI2,PRICE_CLOSE);
//ChartIndicatorAdd(0,0,FF2definition);

   CI2definition=iCustom(_Symbol,_Period,"Cyclic_Indicator",PeriodCI2,true,clrWhite,clrGray,PRICE_CLOSE);

   if(CI_filter==true && CI2_concord==true)
     {
      if(!ChartIndicatorAdd(0,3,CI2definition))
         PrintFormat("Failed to add CI2 indicator on %d chart window. Error code  %d",0,GetLastError());
      else
         Print("Created indicator CI2");
     }

//FF3definition=iCustom(_Symbol,_Period,"Fourier_Transform",PeriodCI3,PRICE_CLOSE);
//ChartIndicatorAdd(0,0,FF3definition);

   CI3definition=iCustom(_Symbol,_Period,"Cyclic_Indicator",PeriodCI3,true,clrWhite,clrGray,PRICE_CLOSE);

   if(CI_filter==true && CI3_concord==true)
     {
      if(!ChartIndicatorAdd(0,4,CI3definition))
         PrintFormat("Failed to add CI3 indicator on %d chart window. Error code  %d",0,GetLastError());
      else
         Print("Created indicator CI3");
     }

   OnInitTelegram();

//--- done
   return(INIT_SUCCEEDED);
  }

//+------------------------------------------------------------------+
//|   DAVIDE - OnDeinit                                              |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   int n=ChartIndicatorsTotal(0,0);

   if(reason==REASON_CLOSE ||
      reason==REASON_PROGRAM ||
      reason==REASON_PARAMETERS ||
      reason==REASON_REMOVE ||
      reason==REASON_RECOMPILE ||
      reason==REASON_ACCOUNT ||
      reason==REASON_INITFAILED)
     {
      time_check=0;
      comm.Destroy();
     }

//delete all indicators displayed
   int subwindows= int(ChartGetInteger(0,CHART_WINDOWS_TOTAL));
   for(int i=subwindows; i>=0; i--)
     {
      int indicators=ChartIndicatorsTotal(0,i);
      for(int j=indicators-1; j>=0; j--)
        {
         ChartIndicatorDelete(0,i,ChartIndicatorName(0,i,j));
         Print("Deleted indicator: "+ChartIndicatorName(0,i,j));
        }
     }

   EventKillTimer();
   ChartRedraw();

   if(Use_Telegram)
      bot.SendMessage(chat_ID,StringFormat("TS '" +__FILE__+"'                   > STOP <     \n(%s)",GetUninitReasonText(UninitializeReason())));
  }

//+------------------------------------------------------------------+
//|   DAVIDE - OnChartEvent                                          |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam)
  {
   comm.OnChartEvent(id,lparam,dparam,sparam);
  }

//+------------------------------------------------------------------+
//|   DAVIDE - OnTimer                                               |
//+------------------------------------------------------------------+
void OnTimer()
  {
   OnTimerTelegram();
  }

//+------------------------------------------------------------------+
//|   DAVIDE - OnTick                                                |
//+------------------------------------------------------------------+
void OnTick()
  {

   NewBar();

   Ask = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_ASK),_Digits);
   Bid = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);

   MqlRates PriceInfo[];
   int PriceData = CopyRates(_Symbol,_Period,0,Dim+1,PriceInfo);

//+------------------------------------------------------------------+
//|   INDICATORS ARRAYS                                              |
//+------------------------------------------------------------------+
   double upperMIGL1array[];
   double lowerMIGL1array[];
   CopyBuffer(MIGL1definition,0,0,Dim+1,upperMIGL1array);
   CopyBuffer(MIGL1definition,1,0,Dim+1,lowerMIGL1array);
   double upperMIGL2array[];
   double lowerMIGL2array[];
   CopyBuffer(MIGL1definition,2,0,Dim+1,upperMIGL2array);
   CopyBuffer(MIGL1definition,3,0,Dim+1,lowerMIGL2array);
   double upperMIGL3array[];
   double lowerMIGL3array[];
   CopyBuffer(MIGL1definition,4,0,Dim+1,upperMIGL3array);
   CopyBuffer(MIGL1definition,5,0,Dim+1,lowerMIGL3array);

   double HA1open[];
   double HA1high[];
   double HA1low[];
   double HA1close[];
   CopyBuffer(HA1definition,0,0,Dim+1,HA1open);
   CopyBuffer(HA1definition,1,0,Dim+1,HA1high);
   CopyBuffer(HA1definition,2,0,Dim+1,HA1low);
   CopyBuffer(HA1definition,3,0,Dim+1,HA1close);
   double HA2open[];
   double HA2high[];
   double HA2low[];
   double HA2close[];
   CopyBuffer(HA2definition,0,0,Dim+1,HA2open);
   CopyBuffer(HA2definition,1,0,Dim+1,HA2high);
   CopyBuffer(HA2definition,2,0,Dim+1,HA2low);
   CopyBuffer(HA2definition,3,0,Dim+1,HA2close);

   double predictCI0array[];
   double phasedCI0array[];
   CopyBuffer(CI0definition,0,0,Dim+1,predictCI0array);
   CopyBuffer(CI0definition,1,0,Dim+1,phasedCI0array);
   double predictCI1array[];
   double phasedCI1array[];
   CopyBuffer(CI1definition,0,0,Dim+1,predictCI1array);
   CopyBuffer(CI1definition,1,0,Dim+1,phasedCI1array);
   double predictCI2array[];
   double phasedCI2array[];
   CopyBuffer(CI2definition,0,0,Dim+1,predictCI2array);
   CopyBuffer(CI2definition,1,0,Dim+1,phasedCI2array);
   double predictCI3array[];
   double phasedCI3array[];
   CopyBuffer(CI3definition,0,0,Dim+1,predictCI3array);
   CopyBuffer(CI3definition,1,0,Dim+1,phasedCI3array);

//+------------------------------------------------------------------+
//|   CONDITIONS TO ENTER                                            |
//+------------------------------------------------------------------+
   if(new_bar==true && (upperMIGL1array[Dim]-lowerMIGL1array[Dim])*100 > 0.1)
     {
      enter_candle--;
      exit_candle--;
     }

//Migliorino cross conditions ----------------------

   if(signal_slow_cross == true || signal_all_cross == true || bands_all_cross == true)
      //se è attiva almeno una condizione su Migliorino
     {
      cross_candle_new = Dim;    //"azzera" il contatore della nuova candela di attraversamento
      new_touch = false;         //azzera la variabile che indica che è avvenuto un nuovo tocco

      for(int i=Dim; i>(Dim - int(PeriodToTrade/Migl_check_fraction)); i--)
        {
         if(PriceInfo[i].low < lowerMIGL1array[i])
            //se il prezzo è stato inferiore alla banda lenta inferiore di Migliorino nel periodo considerato
           {
            signalXdownSlow = true;
            new_touch = true;
           }
         if(PriceInfo[i].high > upperMIGL1array[i])
            //se il prezzo è stato superiore alla banda lenta superiore di Migliorino nel periodo considerato
           {
            signalXupSlow = true;
            new_touch = true;
           }
         if(signal_slow_cross == true && new_touch == true && (signalXdownSlow == true || signalXupSlow == true))
            //se questa è una condizione attiva, se il tocco avvenuto è nuovo, e se appunto c'è stato un attraversamento, allora devo memorizzare in quale candela è avvenuto
           {cross_candle_new = i;}

         if(PriceInfo[i].low < lowerMIGL1array[i] && PriceInfo[i].low < lowerMIGL2array[i] && PriceInfo[i].low < lowerMIGL3array[i])
            //se il prezzo è inferiore a tutte 3 le bande inferiori di Migliorino nell'ultima candela
           {
            signalXdown = true;
            new_touch = true;
           }
         if(PriceInfo[i].high > upperMIGL1array[i] && PriceInfo[i].high > upperMIGL2array[i] && PriceInfo[i].high > upperMIGL3array[i])
            //se il prezzo è superiore a tutte 3 le bande superiori di Migliorino nell'ultima candela
           {
            signalXup = true;
            new_touch = true;
           }
         if(signal_all_cross == true && new_touch == true && (signalXdown == true || signalXup == true))
            //se questa è una condizione attiva, se il tocco avvenuto è nuovo, e se appunto c'è stato un attraversamento, allora devo memorizzare in quale candela è avvenuto
           {cross_candle_new = i;}

         if(lowerMIGL3array[i] < lowerMIGL2array[i] && lowerMIGL2array[i] < lowerMIGL1array[i])
            //se la banda veloce è inferiore alla banda media e contemporaneamente la banda media è inferiore alla banda lenta nell'ultima candela
           {
            bandsXdown = true;
            new_touch = true;
           }
         if(upperMIGL3array[i] > upperMIGL2array[i] && upperMIGL2array[i] > upperMIGL1array[i])
            //se la banda veloce è superiore alla banda media e contemporaneamente la banda media è superiore alla banda lenta nell'ultima candela
           {
            bandsXup = true;
            new_touch = true;
           }
         if(bands_all_cross == true && new_touch == true && (bandsXdown == true || bandsXup == true))
            //se questa è una condizione attiva, se il tocco avvenuto è nuovo, e se appunto c'è stato un attraversamento, allora  devo memorizzare in quale candela è avvenuto
           {cross_candle_new = i;}

         if(cross_candle_new!=Dim)
            //se si è verificata una delle condizioni precedenti nel periodo considerato allora esci dal ciclo (mantenendo memorizzato in quale candela si è attivata la condizione)
            break;
        }

      if(cross_candle_new!=Dim && cross_candle_new > cross_candle && PositionsTotal() == 0 && (upperMIGL1array[Dim]-lowerMIGL1array[Dim])*100 > 0.1)
         //se c'è stato un tocco più recente di quello memorizzato, allora aggiorna la variabile cross_candle
         cross_candle = cross_candle_new;
      else
         if(cross_candle!=0 && new_bar==true && (upperMIGL1array[Dim]-lowerMIGL1array[Dim])*100 > 0.1)
            //se la variabile cross_candle non ha avuto bisogno di essere aggiornata, allora mantieni semplicemente il conteggio delle candele
            cross_candle--;
     }

//Migliorino cross back conditions -----------------

   for(int i=Dim; i>=cross_candle; i--)
     {
      if((signal_slow_cross == true && signalXdownSlow == true && (PriceInfo[i].close > lowerMIGL1array[i])) ||
         (signal_all_cross == true && signalXdown == true && (PriceInfo[i].close > lowerMIGL1array[i])) ||
         (bands_all_cross == true && bandsXdown == true && (lowerMIGL3array[i] > lowerMIGL2array[i] && lowerMIGL2array[i] > lowerMIGL1array[i])))
         //se una volta che il prezzo ha oltrepassato la banda lenta inferiore esso è rientrato oltrepassando la banda lenta (e se questa era una condizione attiva) o
         //se una volta che il prezzo ha oltrepassato le 3 bande inferiori, esso è rientrato oltrepassando la banda lenta (e se questa era una condizione attiva) o
         //se una volta che le bande si sono incrociate al ribasso, ognuna di esse è rientrata incrociando di nuovo la sua superiore (e se questa era una condizione attiva)
        {backXup = true;}

      if((signal_slow_cross == true && signalXupSlow == true && (PriceInfo[i].close < upperMIGL1array[i])) ||
         (signal_all_cross == true && signalXup == true && (PriceInfo[i].close < upperMIGL1array[i])) ||
         (bands_all_cross == true && bandsXup == true && (upperMIGL3array[i] < upperMIGL2array[i] && upperMIGL2array[i] < upperMIGL1array[i])))
         //se una volta che il prezzo ha oltrepassato la banda lenta superiore esso è rientrato oltrepassando la banda lenta (e se questa era una condizione attiva) o
         //se una volta che il prezzo ha oltrepassato le 3 bande superiori, esso è rientrato oltrepassando la banda lenta (e se questa era una condizione attiva) o
         //se una volta che le bande si sono incrociate al rialzo, ognuna di esse è rientrata incrociando di nuovo la sua superiore (e se questa era una condizione attiva)
        {backXdown = true;}
     }

//HeikinAshi indicator conditions -----------------------

   if(HA1close[Dim-1] > HA1open[Dim-1])
      //se l'ultima candela HeikinAshi 1 chiusa è positiva
     {HA1positive = true;}
   else
     {HA1positive = false;}

   if(HA1close[Dim-1] < HA1open[Dim-1])
      //se l'ultima candela HeikinAshi 1 chiusa è negativa
     {HA1negative = true;}
   else
     {HA1negative = false;}

   if(HA2close[Dim-1] > HA2open[Dim-1])
      //se l'ultima candela HeikinAshi 2 chiusa è positiva
     {HA2positive = true;}
   else
     {HA2positive = false;}

   if(HA2close[Dim-1] < HA2open[Dim-1])
      //se l'ultima candela HeikinAshi 2 chiusa è negativa
     {HA2negative = true;}
   else
     {HA2negative = false;}

//Cyclic Indicator conditions ---------------------------

   if(predictCI0array[Dim] > 0)
      //se CI0 è positivo
     {CI0positive = true;}
   else
     {CI0positive = false;}

   if(predictCI0array[Dim] < 0)
      //se CI0 è negativo
     {CI0negative = true;}
   else
     {CI0negative = false;}

   if(predictCI1array[Dim] > 0)
      //se CI1 è positivo
     {CI1positive = true;}
   else
     {CI1positive = false;}

   if(predictCI1array[Dim] < 0)
      //se CI1 è negativo
     {CI1negative = true;}
   else
     {CI1negative = false;}

   if(predictCI2array[Dim] > 0)
      //se CI2 è positivo
     {CI2positive = true;}
   else
     {CI2positive = false;}

   if(predictCI2array[Dim] < 0)
      //se CI2 è negativo
     {CI2negative = true;}
   else
     {CI2negative = false;}

   if(predictCI3array[Dim] > 0)
      //se CI3 è positivo
     {CI3positive = true;}
   else
     {CI3positive = false;}

   if(predictCI3array[Dim] < 0)
      //se CI3 è negativo
     {CI3negative = true;}
   else
     {CI3negative = false;}

//Special invalidation 1) of previous Migliorino conditions ---------------------------

   bool cancCond = false;      //variabile che assume il valore true quando vengono invalidate le condizioni su Migliorino

   if((signalXdownSlow == true || signalXdown == true || bandsXdown == true || backXup == true) && CI_filter == true &&
      ((CI1_concord == true && CI1positive == false) || (CI2_concord == true && CI2positive == false) || (CI3_concord == true && CI3positive == false)))
      //se, nonostante le condizioni di ingresso di Migliorino siano favorevoli, gli indicatori ciclici 1, 2 e 3 attivati non sono concordi alla tendenza long
     {
      //allora bisogna evitare di entrare
      cancCond = true;
      //e bisogna azzerare tutte la variabili del filtro
      signalXdownSlow = false;
      signalXdown = false;
      bandsXdown = false;
      backXup = false;
     }

   if((signalXupSlow == true || signalXup == true || bandsXup == true || backXdown == true) && CI_filter == true &&
      ((CI1_concord == true && CI1negative == false) || (CI2_concord == true && CI2negative == false) || (CI3_concord == true && CI3negative == false)))
      //se, nonostante le condizioni di ingresso di Migliorino siano favorevoli, gli indicatori ciclici 1, 2 e 3 attivati non sono concordi alla tendenza short
     {
      //allora bisogna evitare di entrare
      cancCond = true;
      //e bisogna azzerare tutte la variabili del filtro
      signalXupSlow = false;
      signalXup = false;
      bandsXup = false;
      backXdown = false;
     }

//Special invalidation 2) of previous Migliorino conditions ---------------------------

   if(PositionsTotal()>0 || OrdersTotal()>0 || (Dim-cross_candle > Dim-exit_candle) || order_out!="" || (MIGL_filter == true &&
         ((upperMIGL2array[Dim]-lowerMIGL1array[Dim]) < (bands_tolerance/100)*(upperMIGL1array[Dim]-lowerMIGL1array[Dim]) ||
          (upperMIGL1array[Dim]-lowerMIGL2array[Dim]) < (bands_tolerance/100)*(upperMIGL1array[Dim]-lowerMIGL1array[Dim]) ||
          ((signalXdownSlow == true || signalXdown == true || bandsXdown == true || backXup == true) && ((upperMIGL2array[Dim]-PriceInfo[Dim].close) < (signal_tolerance/100)*(upperMIGL2array[Dim]-lowerMIGL2array[Dim]))) ||
          ((signalXupSlow == true || signalXup == true || bandsXup == true || backXdown == true) && ((PriceInfo[Dim].close - lowerMIGL2array[Dim]) < (signal_tolerance/100)*(upperMIGL2array[Dim]-lowerMIGL2array[Dim]))) ||
          (PriceInfo[Dim].low < lowerMIGL1array[Dim] && PriceInfo[Dim].high > upperMIGL1array[Dim]))))
      //se, nonostante le condizioni di ingresso di Migliorino siano favorevoli, ci sono già ordini o posizioni aperte o chiuse da troppo poco
      //o se la banda media superiore è troppo vicina alla banda lenta inferiore,
      //o se la banda media inferiore è troppo vicina alla banda lenta superiore,
      //o se (volendo entrare in long) il prezzo è troppo vicino alla banda media superiore,
      //o se (volendo entrare in short) il prezzo è troppo vicino alla banda media inferiore,
      //o se, per un eccessivo sbalzo del prezzo, nell'ultima candela il segnale attraversa entrambe le bande lente
     {
      //allora bisogna evitare di entrare
      cancCond = true;
      //e bisogna azzerare tutte la variabili del filtro
      signalXdownSlow = false;
      signalXupSlow = false;
      signalXdown = false;
      signalXup = false;
      bandsXdown = false;
      bandsXup = false;
      backXup = false;
      backXdown = false;
     }

//Notify telegram user ---------------------------

   if(MIGL_filter == true && cross_back == true)
     {
      //avvisa l'utente che il sistema sta per entrare in long in quanto il segnale ha oltrepassato al ribasso 1 o le 3 bande, oppure vi è stato un incrocio al ribasso tra le bande
      if((signalXdownSlow == true || signalXdown == true || bandsXdown == true) && new_touch == true && new_bar == true && SL_count == 0 && (upperMIGL1array[Dim]-lowerMIGL1array[Dim])*100 > 0.1)
        {
         string msg="Possibile ingresso long imminente";
         Print(msg);
         int res=bot.SendMessage(chat_ID,msg);
         int result=bot.SendScreenShot(chat_ID,_Symbol,_Period,"3_Migliorino_bands_8DD_7days");
         if(result!=0)
            Print(GetErrorDescription(result,InpLanguage));
        }

      //avvisa l'utente che il sistema sta per entrare in short in quanto il segnale ha oltrepassato al rialzo 1 o le 3 bande, oppure vi è stato un incrocio al rialzo tra le bande
      if((signalXupSlow == true || signalXup == true || bandsXup == true) && new_touch == true && new_bar == true && SL_count == 0 && (upperMIGL1array[Dim]-lowerMIGL1array[Dim])*100 > 0.1)
        {
         string msg="Possibile ingresso short imminente";
         Print(msg);
         int res=bot.SendMessage(chat_ID,msg);
         int result=bot.SendScreenShot(chat_ID,_Symbol,_Period,"3_Migliorino_bands_8DD_7days");
         if(result!=0)
            Print(GetErrorDescription(result,InpLanguage));
        }
     }

//+------------------------------------------------------------------+
//|   REQUIREMENTS TO ENTER                                          |
//+------------------------------------------------------------------+
   bool req_in_long = true;      //variabile che rimane true finché non viene invalidata da qualche condizione di ingresso (se true posso entrare in una posizione long)
   bool req_in_short = true;     //variabile che rimane true finché non viene invalidata da qualche condizione di ingresso (se true posso entrare in una posizione short)

//Migliorino invalidating the enter conditions ----------------------
   if(MIGL_filter == true)
     {
      if((cross_back == false &&                                        //se non mi aspetto che il segnale debba rientrare ma
          ((signal_slow_cross == true && signalXdownSlow == false) ||   //mi aspetto che il segnale debba oltrepassare la banda lenta al ribasso ma non lo ha fatto, oppure
           (signal_all_cross == true && signalXdown == false) ||        //mi aspetto che il segnale debba oltrepassare tutte le bande al ribasso ma non lo ha fatto, oppure
           (bands_all_cross == true && bandsXdown == false))) ||        //mi aspetto che ciascuna banda oltrepassi la propria banda più lenta al ribasso ma non lo ha fatto,
         (cross_back == true && backXup == false))                      //se invece mi aspetto che il segnale debba rientrare al rialzo ma non lo ha fatto
        {req_in_long = false;}
      if((cross_back == false &&                                        //se non mi aspetto che il segnale debba rientrare ma
          ((signal_slow_cross == true && signalXupSlow == false) ||     //mi aspetto che il segnale debba oltrepassare la banda lenta al rialzo ma non lo ha fatto, oppure
           (signal_all_cross == true && signalXup == false) ||          //mi aspetto che il segnale debba oltrepassare tutte le bande al rialzo ma non lo ha fatto, oppure
           (bands_all_cross == true && bandsXup == false))) ||          //mi aspetto che ciascuna banda oltrepassi la propria banda più lenta al rialzo ma non lo ha fatto,
         (cross_back == true && backXdown == false))                    //se invece mi aspetto che il segnale debba rientrare al ribasso ma non lo ha fatto
        {req_in_short = false;}
     }

//HeikinAshi 1 Indicator invalidating the enter conditions ------------
   if(HA_filter == true)
     {
      if(HA1_concord == true && HA1positive == false)                   //se mi aspetto che HeikinAshi 1 debba essere concorde ma non lo è poichè non è positivo
        {req_in_long = false;}
      if(HA1_concord == true && HA1negative == false)                   //se mi aspetto che HeikinAshi 1 debba essere concorde ma non lo è poichè non è negativo
        {req_in_short = false;}
     }

   /*
   //Priceaction trigger to enter -----------------------------------------
      if(Trigger_in == PriceAction_in)
        {
         int count_long=0;          //contatore di candele long consecutive
         int count_short=0;         //contatore di candele short consecutive

         //conta quante candele sono consecutivamente in long a partire dalla penultima
         for(int i=Dim-2; i>=0; i--)
           {
            if(PriceInfo[i].close > PriceInfo[i].open)
              {count_long++;}
            else
               break;
           }

         //conta quante candele sono consecutivamente in short a partire dalla penultima
         for(int i=Dim-2; i>=0; i--)
           {
            if(PriceInfo[i].close < PriceInfo[i].open)
              {count_short++;}
            else
               break;
           }

         //se a partire dalla penultima candela e andando a ritroso ci sono un numero di candele rosse maggiori uguali a 1 e minori uguali a max_trend
         //se l'ultima candela è verde
         //se l'ombra inf dell'ultima candela è minore dell'ombra inf della penultima, ma l'ombra sup dell'ultima candela non è maggiore dell'ombra sup della penultima
         if((count_short >= 1 && count_short <= max_trend) &&
            (PriceInfo[Dim-1].close > PriceInfo[Dim-1].open) &&
            (PriceInfo[Dim-1].low < PriceInfo[Dim-2].low && PriceInfo[Dim-1].high < PriceInfo[Dim-2].high))
           {req_in_short = false;}
         //se a partire dalla penultima candela e andando a ritroso ci sono un numero di candele verdi maggiori uguali a 1 e minori uguali a max_trend
         //se l'ultima candela è rossa
         //se l'ombra sup dell'ultima candela è maggiore dell'ombra sup della penultima, ma l'ombra inf dell'ultima candela non è minore dell'ombra inf della penultima
         else
            if((count_long >= 1 && count_long <= max_trend) &&
               (PriceInfo[Dim-1].close < PriceInfo[Dim-1].open) &&
               (PriceInfo[Dim-1].high > PriceInfo[Dim-2].high && PriceInfo[Dim-1].low > PriceInfo[Dim-2].low))
              {req_in_long = false;}
            //in tutti gli altri casi azzera le variabili filtro
            else
              {
               req_in_short = false;
               req_in_long = false;
              }
        }
   */
//+------------------------------------------------------------------+
//|   OPENING ORDERS                                                 |
//+------------------------------------------------------------------+
   order_in = "";

   if(req_in_long == true && PositionsTotal()<1 && OrdersTotal()<1)
      //se vengono rispettate tutte le condizioni di ingresso e se non ci sono altre posizioni o ordini aperti
     {
      //allora compra
      order_in = "buyOrder";

      //e azzera le variabili relative alle condizioni di ingresso
      signalXdownSlow = false;
      signalXdown = false;
      bandsXdown = false;
      backXup = false;

      if(predictCI2array[Dim] * predictCI3array[Dim] < CI_thread_DN)
         LotsToBuy = 1; //0.5
      else
         if(predictCI2array[Dim] * predictCI3array[Dim] >= CI_thread_UP)
            LotsToBuy = 1; //2
         else
            LotsToBuy = 1;
     }

   if(req_in_short == true && PositionsTotal()<1 && OrdersTotal()<1)
      //se vengono rispettate tutte le condizioni di ingresso e se non ci sono altre posizioni o ordini aperti
     {
      //allora vendi
      order_in = "sellOrder";

      //e azzera le variabili relative alle condizioni di ingresso
      signalXupSlow = false;
      signalXup = false;
      bandsXup = false;
      backXdown = false;

      if(predictCI2array[Dim] * predictCI3array[Dim] < CI_thread_DN)
         LotsToBuy = 1; //0.5
      else
         if(predictCI2array[Dim] * predictCI3array[Dim] >= CI_thread_UP)
            LotsToBuy = 1; //2
         else
            LotsToBuy = 1;
     }

//+------------------------------------------------------------------+
//|   OPENING POSITIONS                                              |
//+------------------------------------------------------------------+
   if(order_in == "buyOrder")
      //se c'è un ordine di comprare
     {
      TP_price = upperMIGL2array[Dim];
      SL_price = NULL;
      //TP_price = Ask+double(TP_Pips)/10000;
      //SL_price = Ask-double(SL_Pips)/10000;

      trade.Buy(LotsToBuy,NULL,Ask,SL_price,TP_price,NULL);

      if(order_in == "buyOrder" && PositionsTotal()==0)
         //se c'è stato un ordine ma non è andato a buon fine
         Print("Richiesta di ordine fallita. Errore: ",GetLastError());
      else
        {
         position = "longPosition";                      //setto la posizione in long
         enter_candle = Dim;                             //setto il contatore della candela di ingresso
         Print(position+" opened");

         if(SL_count==0)
           {
            time_in = TimeCurrent();                     //aggiorno la data di ingresso nel mercato
            price_in = Ask;                              //aggiorno il prezzo di ingresso nel mercato
            DD_trade = 0.001;                            //azzero la variabile del drawdown del singolo trade
            WriteOnFile();                               //scrivo il file .csv
           }

         //salvo i dati di ingresso negli array (con orario approssimato)
         time_in_array[SL_count+1] = ApproximateTime(TimeCurrent());
         price_in_array[SL_count+1] = Ask;

         int result=bot.SendScreenShot(chat_ID,_Symbol,_Period,"3_Migliorino_bands_8DD_7days");
         if(result!=0)
            Print(GetErrorDescription(result,InpLanguage));
         //invia messaggio Telegram di ingresso long nel mercato
         string msg=StringFormat("MIGLIORINO Signal \xF4E3\nSymbol: %s\nTimeframe: %s\nType: Buy\nPrice: %s\nTime: %s",
                                 _Symbol,
                                 StringSubstr(EnumToString(_Period),7),
                                 DoubleToString(SymbolInfoDouble(_Symbol,SYMBOL_ASK),_Digits),
                                 TimeToString(iTime(_Symbol,_Period,0)));
         if(Use_Telegram)
           {
            int res=bot.SendMessage(chat_ID,msg);
            if(res!=0)
               Print("Error: ",GetErrorDescription(res));
           }
        }
     }

   if(order_in == "sellOrder")
      //se c'è un ordine di vendere
     {
      TP_price = lowerMIGL2array[Dim];
      SL_price = NULL;
      //TP_price = Bid-double(TP_Pips)/10000;
      //SL_price = Bid+double(SL_Pips)/10000;

      trade.Sell(LotsToBuy,NULL,Bid,SL_price,TP_price,NULL);

      if(order_in == "sellOrder" && PositionsTotal()==0)
         //se c'è stato un ordine ma non è andato a buon fine
         Print("Richiesta di ordine fallita. Errore: ",GetLastError());
      else
        {
         position = "shortPosition";                     //setto la posizione in short
         enter_candle = Dim;                             //setto il contatore della candela di ingresso
         Print(position+" opened");

         if(SL_count==0)
           {
            time_in = TimeCurrent();                     //aggiorno la data di ingresso nel mercato
            price_in = Bid;                              //aggiorno il prezzo di ingresso nel mercato
            DD_trade = 0.001;                            //azzero la variabile del drawdown del singolo trade
            WriteOnFile();                               //scrivo il file .csv
           }

         //salvo i dati di ingresso negli array (con orario approssimato)
         time_in_array[SL_count+1] = ApproximateTime(TimeCurrent());
         price_in_array[SL_count+1] = Bid;

         int result=bot.SendScreenShot(chat_ID,_Symbol,_Period,"3_Migliorino_bands_8DD_7days");
         if(result!=0)
            Print(GetErrorDescription(result,InpLanguage));
         //invia messaggio Telegram di ingresso short nel mercato
         string msg=StringFormat("MIGLIORINO Signal \xF4E3\nSymbol: %s\nTimeframe: %s\nType: Sell\nPrice: %s\nTime: %s",
                                 _Symbol,
                                 StringSubstr(EnumToString(_Period),7),
                                 DoubleToString(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits),
                                 TimeToString(iTime(_Symbol,_Period,0)));
         if(Use_Telegram)
           {
            int res=bot.SendMessage(chat_ID,msg);
            if(res!=0)
               Print("Error: ",GetErrorDescription(res));
           }
        }
     }

//+------------------------------------------------------------------+
//|   UPDATING SL & TP VALUES                                        |
//+------------------------------------------------------------------+
   if(position == "longPosition")// && new_bar==true)
      //se siamo in una posizione long
     {
      //aggiorna ad ogni tick i prezzi di take-profit (raggiungimento della banda media opposta) e stop-loss (rientro all'interno della banda lenta)
      UpdatePrices(upperMIGL1array[Dim],lowerMIGL1array[Dim],upperMIGL2array[Dim],lowerMIGL2array[Dim],upperMIGL3array[Dim],lowerMIGL3array[Dim],TP_price,SL_price,PriceInfo[Dim-1].close);
      //aggiorno la variabile del tipo di uscita in previsione di quando si verificherà
      order_out = "sellCloseOrder";
     }

   if(position == "shortPosition")// && new_bar==true)
      //se siamo in una posizione short
     {
      //aggiorna ad ogni tick i prezzi di take-profit (raggiungimento della banda media opposta) e stop-loss (rientro all'interno della banda lenta)
      UpdatePrices(upperMIGL1array[Dim],lowerMIGL1array[Dim],upperMIGL2array[Dim],lowerMIGL2array[Dim],upperMIGL3array[Dim],lowerMIGL3array[Dim],TP_price,SL_price,PriceInfo[Dim-1].close);
      //aggiorno la variabile del tipo di uscita in previsione di quando si verificherà
      order_out = "buyCloseOrder";
     }

//+------------------------------------------------------------------+
//|   DRAWDOWNS                                                      |
//+------------------------------------------------------------------+
   int Balance = int(AccountInfoDouble(ACCOUNT_BALANCE));
   int Equity = int(AccountInfoDouble(ACCOUNT_EQUITY));
   int Free_margin = int(AccountInfoDouble(ACCOUNT_MARGIN_FREE));
   int Margin_level = int(AccountInfoDouble(ACCOUNT_MARGIN_LEVEL));
   int Margin = int(AccountInfoDouble(ACCOUNT_MARGIN));

   if(Balance >= Balance_max)
      //drawdown di backtest (bilancio massimo - equity minima successiva)
     {Balance_max = Balance;}
   if(Balance_max-Equity > DD_backtest)
     {DD_backtest = Balance_max-Equity;}

   if(position == "longPosition" || position == "shortPosition")
      //drawdown di trade (bilancio di ingresso nel trade - equity minima nel trade). Qui calcoliamo solo il singolo tratto da ingresso a stop-loss: in uscita si sommano tutti i tratti.
     {
      if(Balance-Equity > DD_until_stop)
        {DD_until_stop = Balance-Equity;}
     }
   else
      DD_until_stop = 0.001;

   if(Balance-Equity > Max_DD_trade)
      //drawdown di trade massimo (il più grande tra i drawdown di trade)
     {Max_DD_trade = Balance-Equity;}

//+------------------------------------------------------------------+
//|   OUTPUTS ON CHARTS                                              |
//+------------------------------------------------------------------+

//+------------------------ BACKGROUND 1 ----------------------------+

   ObjectCreate(0,"Background",OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,"Background",OBJPROP_XSIZE,260);
   ObjectSetInteger(0,"Background",OBJPROP_YSIZE,2000);
   ObjectSetInteger(0,"Background",OBJPROP_YDISTANCE,12);
   ObjectSetInteger(0,"Background",OBJPROP_BGCOLOR,clrBlack);
   ObjectSetInteger(0,"Background",OBJPROP_BORDER_TYPE,BORDER_FLAT);

   ObjectCreate(0,"Balance",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"Balance",OBJPROP_TEXT,"BALANCE:         "+(string)(int)(Balance));
   ObjectSetInteger(0,"Balance",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"Balance",OBJPROP_YDISTANCE,20);
   ObjectSetInteger(0,"Balance",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"Balance",OBJPROP_COLOR,clrOrange);
   ObjectCreate(0,"Equity",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"Equity",OBJPROP_TEXT,"EQUITY:             "+(string)(int)(Equity));
   ObjectSetInteger(0,"Equity",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"Equity",OBJPROP_YDISTANCE,35);
   ObjectSetInteger(0,"Equity",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"Equity",OBJPROP_COLOR,clrOrange);
   ObjectCreate(0,"Free_margin",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"Free_margin",OBJPROP_TEXT,"FREE MARGIN:   "+(string)(int)(Free_margin));
   ObjectSetInteger(0,"Free_margin",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"Free_margin",OBJPROP_YDISTANCE,50);
   ObjectSetInteger(0,"Free_margin",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"Free_margin",OBJPROP_COLOR,clrOrange);
   ObjectCreate(0,"Margin_level",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"Margin_level",OBJPROP_TEXT,"MARGIN LEV.:    "+(string)(int)(Margin_level));
   ObjectSetInteger(0,"Margin_level",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"Margin_level",OBJPROP_YDISTANCE,65);
   ObjectSetInteger(0,"Margin_level",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"Margin_level",OBJPROP_COLOR,clrOrange);
   ObjectCreate(0,"Margin",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"Margin",OBJPROP_TEXT,"MARGIN:             "+(string)(int)(Margin));
   ObjectSetInteger(0,"Margin",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"Margin",OBJPROP_YDISTANCE,80);
   ObjectSetInteger(0,"Margin",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"Margin",OBJPROP_COLOR,clrOrange);

   ObjectCreate(0,"signalXdownS",OBJ_LABEL,0,0,0);
   signalXdownSlow==true ? ObjectSetString(0,"signalXdownS",OBJPROP_TEXT,"signalXdownS:  "+(string)(signalXdownSlow)) : ObjectSetString(0,"signalXdownS",OBJPROP_TEXT,"signalXdownS:  ");
   ObjectSetInteger(0,"signalXdownS",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"signalXdownS",OBJPROP_YDISTANCE,110);
   ObjectSetInteger(0,"signalXdownS",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"signalXdownS",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"signalXdown",OBJ_LABEL,0,0,0);
   signalXdown==true ? ObjectSetString(0,"signalXdown",OBJPROP_TEXT,"signalXdown:    "+(string)(signalXdown)) : ObjectSetString(0,"signalXdown",OBJPROP_TEXT,"signalXdown:  ");
   ObjectSetInteger(0,"signalXdown",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"signalXdown",OBJPROP_YDISTANCE,125);
   ObjectSetInteger(0,"signalXdown",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"signalXdown",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"bandsXdown",OBJ_LABEL,0,0,0);
   bandsXdown==true ? ObjectSetString(0,"bandsXdown",OBJPROP_TEXT,"bandsXdown:    "+(string)(bandsXdown)) : ObjectSetString(0,"bandsXdown",OBJPROP_TEXT,"bandsXdown:  ");
   ObjectSetInteger(0,"bandsXdown",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"bandsXdown",OBJPROP_YDISTANCE,140);
   ObjectSetInteger(0,"bandsXdown",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"bandsXdown",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"backXup",OBJ_LABEL,0,0,0);
   backXup==true ? ObjectSetString(0,"backXup",OBJPROP_TEXT,"backXup:           "+(string)(backXup)) : ObjectSetString(0,"backXup",OBJPROP_TEXT,"backXup:  ");
   ObjectSetInteger(0,"backXup",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"backXup",OBJPROP_YDISTANCE,155);
   ObjectSetInteger(0,"backXup",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"backXup",OBJPROP_COLOR,clrWhite);

   ObjectCreate(0,"signalXupS",OBJ_LABEL,0,0,0);
   signalXupSlow==true ? ObjectSetString(0,"signalXupS",OBJPROP_TEXT,"signalXupS:        "+(string)(signalXupSlow)) : ObjectSetString(0,"signalXupS",OBJPROP_TEXT,"signalXupS:  ");
   ObjectSetInteger(0,"signalXupS",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"signalXupS",OBJPROP_YDISTANCE,175);
   ObjectSetInteger(0,"signalXupS",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"signalXupS",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"signalXup",OBJ_LABEL,0,0,0);
   signalXup==true ? ObjectSetString(0,"signalXup",OBJPROP_TEXT,"signalXup:          "+(string)(signalXup)) : ObjectSetString(0,"signalXup",OBJPROP_TEXT,"signalXup:  ");
   ObjectSetInteger(0,"signalXup",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"signalXup",OBJPROP_YDISTANCE,190);
   ObjectSetInteger(0,"signalXup",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"signalXup",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"bandsXup",OBJ_LABEL,0,0,0);
   bandsXup==true ? ObjectSetString(0,"bandsXup",OBJPROP_TEXT,"bandsXup:         "+(string)(bandsXup)) : ObjectSetString(0,"bandsXup",OBJPROP_TEXT,"bandsXup:  ");
   ObjectSetInteger(0,"bandsXup",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"bandsXup",OBJPROP_YDISTANCE,205);
   ObjectSetInteger(0,"bandsXup",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"bandsXup",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"backXdown",OBJ_LABEL,0,0,0);
   backXdown==true ? ObjectSetString(0,"backXdown",OBJPROP_TEXT,"backXdown:      "+(string)(backXdown)) : ObjectSetString(0,"backXdown",OBJPROP_TEXT,"backXdown:  ");
   ObjectSetInteger(0,"backXdown",OBJPROP_XDISTANCE,3);
   ObjectSetInteger(0,"backXdown",OBJPROP_YDISTANCE,220);
   ObjectSetInteger(0,"backXdown",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"backXdown",OBJPROP_COLOR,clrWhite);

//+------------------------ second column ---------------------------+

   ObjectCreate(0,"CycleToTrade",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"CycleToTrade",OBJPROP_TEXT,"Cycle:         "+EnumToString(CycleToTrade));
   ObjectSetInteger(0,"CycleToTrade",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"CycleToTrade",OBJPROP_YDISTANCE,20);
   ObjectSetInteger(0,"CycleToTrade",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CycleToTrade",OBJPROP_COLOR,clrOrange);
   ObjectCreate(0,"TimeFrame",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"TimeFrame",OBJPROP_TEXT,"Timeframe: "+EnumToString(_Period));
   ObjectSetInteger(0,"TimeFrame",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"TimeFrame",OBJPROP_YDISTANCE,35);
   ObjectSetInteger(0,"TimeFrame",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"TimeFrame",OBJPROP_COLOR,clrOrange);
   ObjectCreate(0,"TimeFrameHA1",OBJ_LABEL,0,0,0);
   HA1_concord==true ? ObjectSetString(0,"TimeFrameHA1",OBJPROP_TEXT,"HA_in:        "+EnumToString(PeriodHA1)) : ObjectSetString(0,"TimeFrameHA1",OBJPROP_TEXT," ");
   ObjectSetInteger(0,"TimeFrameHA1",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"TimeFrameHA1",OBJPROP_YDISTANCE,50);
   ObjectSetInteger(0,"TimeFrameHA1",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"TimeFrameHA1",OBJPROP_COLOR,clrOrange);
   ObjectCreate(0,"TimeFrameHA2",OBJ_LABEL,0,0,0);
   HA2_concord==true ? ObjectSetString(0,"TimeFrameHA2",OBJPROP_TEXT,"HA_out:      "+EnumToString(PeriodHA2)) : ObjectSetString(0,"TimeFrameHA2",OBJPROP_TEXT," ");
   ObjectSetInteger(0,"TimeFrameHA2",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"TimeFrameHA2",OBJPROP_YDISTANCE,65);
   ObjectSetInteger(0,"TimeFrameHA2",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"TimeFrameHA2",OBJPROP_COLOR,clrOrange);

   ObjectCreate(0,"TIME_DATE",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"TIME_DATE",OBJPROP_TEXT,TimeToString(TimeCurrent(),TIME_DATE));
   ObjectSetInteger(0,"TIME_DATE",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"TIME_DATE",OBJPROP_YDISTANCE,95);
   ObjectSetInteger(0,"TIME_DATE",OBJPROP_FONTSIZE,12);
   ObjectSetInteger(0,"TIME_DATE",OBJPROP_COLOR,clrLightGray);
   ObjectCreate(0,"TIME_MINUTES",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"TIME_MINUTES",OBJPROP_TEXT,TimeToString(TimeCurrent(),TIME_MINUTES));
   ObjectSetInteger(0,"TIME_MINUTES",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"TIME_MINUTES",OBJPROP_YDISTANCE,115);
   ObjectSetInteger(0,"TIME_MINUTES",OBJPROP_FONTSIZE,12);
   ObjectSetInteger(0,"TIME_MINUTES",OBJPROP_COLOR,clrLightGray);

   ObjectCreate(0,"Pos_tot",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"Pos_tot",OBJPROP_TEXT,"Pos_tot:     "+IntegerToString(PositionsTotal()));
   ObjectSetInteger(0,"Pos_tot",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"Pos_tot",OBJPROP_YDISTANCE,145);
   ObjectSetInteger(0,"Pos_tot",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"Pos_tot",OBJPROP_COLOR,clrYellow);
   ObjectCreate(0,"Pos_type",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"Pos_type",OBJPROP_TEXT,"Pos_type:  ");
   ObjectSetInteger(0,"Pos_type",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"Pos_type",OBJPROP_YDISTANCE,160);
   ObjectSetInteger(0,"Pos_type",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"Pos_type",OBJPROP_COLOR,clrYellow);
   ObjectCreate(0,"Long-Short",OBJ_LABEL,0,0,0);
   position=="longPosition" ? ObjectSetString(0,"Long-Short",OBJPROP_TEXT,"LONG") : position=="shortPosition" ? ObjectSetString(0,"Long-Short",OBJPROP_TEXT,"SHORT") : ObjectSetString(0,"Long-Short",OBJPROP_TEXT," ");
   ObjectSetInteger(0,"Long-Short",OBJPROP_XDISTANCE,185);
   ObjectSetInteger(0,"Long-Short",OBJPROP_YDISTANCE,160);
   ObjectSetInteger(0,"Long-Short",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"Long-Short",OBJPROP_COLOR,clrRed);

   ObjectCreate(0,"SL_count",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"SL_count",OBJPROP_TEXT,"SL_count:  "+(string)(SL_count));
   ObjectSetInteger(0,"SL_count",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"SL_count",OBJPROP_YDISTANCE,185);
   ObjectSetInteger(0,"SL_count",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"SL_count",OBJPROP_COLOR,clrYellow);

   ObjectCreate(0,"req_in_long",OBJ_LABEL,0,0,0);
   req_in_long==true ? ObjectSetString(0,"req_in_long",OBJPROP_TEXT,"req_in_long:    "+(string)(req_in_long)) : ObjectSetString(0,"req_in_long",OBJPROP_TEXT,"req_in_long:  ");
   ObjectSetInteger(0,"req_in_long",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"req_in_long",OBJPROP_YDISTANCE,210);
   ObjectSetInteger(0,"req_in_long",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"req_in_long",OBJPROP_COLOR,clrYellow);
   ObjectCreate(0,"req_in_short",OBJ_LABEL,0,0,0);
   req_in_short==true ? ObjectSetString(0,"req_in_short",OBJPROP_TEXT,"req_in_short:    "+(string)(req_in_short)) : ObjectSetString(0,"req_in_short",OBJPROP_TEXT,"req_in_short:  ");
   ObjectSetInteger(0,"req_in_short",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"req_in_short",OBJPROP_YDISTANCE,225);
   ObjectSetInteger(0,"req_in_short",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"req_in_short",OBJPROP_COLOR,clrYellow);

   ObjectCreate(0,"cancCond",OBJ_LABEL,0,0,0);
   cancCond==true ? ObjectSetString(0,"cancCond",OBJPROP_TEXT,"cancCond:  "+(string)(cancCond)) : ObjectSetString(0,"cancCond",OBJPROP_TEXT,"cancCond:  ");
   ObjectSetInteger(0,"cancCond",OBJPROP_XDISTANCE,130);
   ObjectSetInteger(0,"cancCond",OBJPROP_YDISTANCE,250);
   ObjectSetInteger(0,"cancCond",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"cancCond",OBJPROP_COLOR,clrWhite);

//+------------------------ BACKGROUND 2 ----------------------------+

   ObjectCreate(0,"Background2",OBJ_RECTANGLE_LABEL,0,0,0);
   ObjectSetInteger(0,"Background2",OBJPROP_XSIZE,260);
   ObjectSetInteger(0,"Background2",OBJPROP_YSIZE,2000);
   ObjectSetInteger(0,"Background2",OBJPROP_XDISTANCE,1410);
   ObjectSetInteger(0,"Background2",OBJPROP_YDISTANCE,0);
   ObjectSetInteger(0,"Background2",OBJPROP_BGCOLOR,clrBlack);
   ObjectSetInteger(0,"Background2",OBJPROP_BORDER_TYPE,BORDER_FLAT);

   ObjectCreate(0,"ParamMigl1",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"ParamMigl1",OBJPROP_TEXT,"Migliorino:  "+(string)(PeriodToTrade/2)+ " - "+DoubleToString((upperMIGL1array[Dim]-lowerMIGL1array[Dim])*100,2));
   ObjectSetInteger(0,"ParamMigl1",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"ParamMigl1",OBJPROP_YDISTANCE,20);
   ObjectSetInteger(0,"ParamMigl1",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"ParamMigl1",OBJPROP_COLOR,clrOrange);

   ObjectCreate(0,"upperMIGL1",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"upperMIGL1",OBJPROP_TEXT,"upperMIGL1:  "+DoubleToString(upperMIGL1array[Dim],_Digits));
   ObjectSetInteger(0,"upperMIGL1",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"upperMIGL1",OBJPROP_YDISTANCE,50);
   ObjectSetInteger(0,"upperMIGL1",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"upperMIGL1",OBJPROP_COLOR,clrYellow);
   ObjectCreate(0,"upperMIGL2",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"upperMIGL2",OBJPROP_TEXT,"upperMIGL2:  "+DoubleToString(upperMIGL2array[Dim],_Digits));
   ObjectSetInteger(0,"upperMIGL2",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"upperMIGL2",OBJPROP_YDISTANCE,65);
   ObjectSetInteger(0,"upperMIGL2",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"upperMIGL2",OBJPROP_COLOR,clrYellow);
   ObjectCreate(0,"upperMIGL3",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"upperMIGL3",OBJPROP_TEXT,"upperMIGL3:  "+DoubleToString(upperMIGL3array[Dim],_Digits));
   ObjectSetInteger(0,"upperMIGL3",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"upperMIGL3",OBJPROP_YDISTANCE,80);
   ObjectSetInteger(0,"upperMIGL3",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"upperMIGL3",OBJPROP_COLOR,clrYellow);
   ObjectCreate(0,"PriceClose",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"PriceClose",OBJPROP_TEXT,"PriceClose:    "+DoubleToString(PriceInfo[Dim].close,_Digits));
   ObjectSetInteger(0,"PriceClose",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"PriceClose",OBJPROP_YDISTANCE,95);
   ObjectSetInteger(0,"PriceClose",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"PriceClose",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"lowerMIGL3",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"lowerMIGL3",OBJPROP_TEXT,"lowerMIGL3:  "+DoubleToString(lowerMIGL3array[Dim],_Digits));
   ObjectSetInteger(0,"lowerMIGL3",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"lowerMIGL3",OBJPROP_YDISTANCE,110);
   ObjectSetInteger(0,"lowerMIGL3",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"lowerMIGL3",OBJPROP_COLOR,clrYellow);
   ObjectCreate(0,"lowerMIGL2",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"lowerMIGL2",OBJPROP_TEXT,"lowerMIGL2:  "+DoubleToString(lowerMIGL2array[Dim],_Digits));
   ObjectSetInteger(0,"lowerMIGL2",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"lowerMIGL2",OBJPROP_YDISTANCE,125);
   ObjectSetInteger(0,"lowerMIGL2",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"lowerMIGL2",OBJPROP_COLOR,clrYellow);
   ObjectCreate(0,"lowerMIGL1",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"lowerMIGL1",OBJPROP_TEXT,"lowerMIGL1:  "+DoubleToString(lowerMIGL1array[Dim],_Digits));
   ObjectSetInteger(0,"lowerMIGL1",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"lowerMIGL1",OBJPROP_YDISTANCE,140);
   ObjectSetInteger(0,"lowerMIGL1",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"lowerMIGL1",OBJPROP_COLOR,clrYellow);

   ObjectCreate(0,"cross_candle",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"cross_candle",OBJPROP_TEXT,"cross_candle:  "+(string)(int)(Dim-cross_candle));
   ObjectSetInteger(0,"cross_candle",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"cross_candle",OBJPROP_YDISTANCE,170);
   ObjectSetInteger(0,"cross_candle",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"cross_candle",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"enter_candle",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"enter_candle",OBJPROP_TEXT,"enter_candle:   "+(string)(int)(Dim-enter_candle));
   ObjectSetInteger(0,"enter_candle",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"enter_candle",OBJPROP_YDISTANCE,185);
   ObjectSetInteger(0,"enter_candle",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"enter_candle",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"exit_candle",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"exit_candle",OBJPROP_TEXT,"exit_candle:      "+(string)(int)(Dim-exit_candle));
   ObjectSetInteger(0,"exit_candle",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"exit_candle",OBJPROP_YDISTANCE,200);
   ObjectSetInteger(0,"exit_candle",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"exit_candle",OBJPROP_COLOR,clrWhite);

   ObjectCreate(0,"ratio_HA2/ratio_HA1",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"ratio_HA2/ratio_HA1",OBJPROP_TEXT,"HA2 / HA1:        "+(string)(int)(ratio_HA2/ratio_HA1));
   ObjectSetInteger(0,"ratio_HA2/ratio_HA1",OBJPROP_XDISTANCE,1420);
   ObjectSetInteger(0,"ratio_HA2/ratio_HA1",OBJPROP_YDISTANCE,230);
   ObjectSetInteger(0,"ratio_HA2/ratio_HA1",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"ratio_HA2/ratio_HA1",OBJPROP_COLOR,clrWhite);

//+------------------------ second column ---------------------------+

   ObjectCreate(0,"TP-SL",OBJ_LABEL,0,0,0);
   ObjectSetString(0,"TP-SL",OBJPROP_TEXT,""+DoubleToString(TP_price,_Digits)+"   "+DoubleToString(SL_price,_Digits));
   ObjectSetInteger(0,"TP-SL",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"TP-SL",OBJPROP_YDISTANCE,20);
   ObjectSetInteger(0,"TP-SL",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"TP-SL",OBJPROP_COLOR,clrOrange);

   ObjectCreate(0,"CI0_long",OBJ_LABEL,0,0,0);
   CI0_concord==true ? ObjectSetString(0,"CI0_long",OBJPROP_TEXT,"CI0_long:   "+(string)(CI0positive)) : ObjectSetString(0,"CI0_long",OBJPROP_TEXT,"CI0_long:  ");
   ObjectSetInteger(0,"CI0_long",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"CI0_long",OBJPROP_YDISTANCE,50);
   ObjectSetInteger(0,"CI0_long",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CI0_long",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"CI1_long",OBJ_LABEL,0,0,0);
   CI1_concord==true ? ObjectSetString(0,"CI1_long",OBJPROP_TEXT,"CI1_long:   "+(string)(CI1positive)) : ObjectSetString(0,"CI1_long",OBJPROP_TEXT,"CI1_long:  ");
   ObjectSetInteger(0,"CI1_long",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"CI1_long",OBJPROP_YDISTANCE,65);
   ObjectSetInteger(0,"CI1_long",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CI1_long",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"CI2_long",OBJ_LABEL,0,0,0);
   CI2_concord==true ? ObjectSetString(0,"CI2_long",OBJPROP_TEXT,"CI2_long:   "+(string)(CI2positive)) : ObjectSetString(0,"CI2_long",OBJPROP_TEXT,"CI2_long:  ");
   ObjectSetInteger(0,"CI2_long",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"CI2_long",OBJPROP_YDISTANCE,80);
   ObjectSetInteger(0,"CI2_long",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CI2_long",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"CI3_long",OBJ_LABEL,0,0,0);
   CI3_concord==true ? ObjectSetString(0,"CI3_long",OBJPROP_TEXT,"CI3_long:   "+(string)(CI3positive)) : ObjectSetString(0,"CI3_long",OBJPROP_TEXT,"CI3_long:  ");
   ObjectSetInteger(0,"CI3_long",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"CI3_long",OBJPROP_YDISTANCE,95);
   ObjectSetInteger(0,"CI3_long",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CI3_long",OBJPROP_COLOR,clrWhite);

   ObjectCreate(0,"CI0_short",OBJ_LABEL,0,0,0);
   CI0_concord==true ? ObjectSetString(0,"CI0_short",OBJPROP_TEXT,"CI0_short:  "+(string)(CI0negative)) : ObjectSetString(0,"CI0_short",OBJPROP_TEXT,"CI0_short:  ");
   ObjectSetInteger(0,"CI0_short",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"CI0_short",OBJPROP_YDISTANCE,125);
   ObjectSetInteger(0,"CI0_short",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CI0_short",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"CI1_short",OBJ_LABEL,0,0,0);
   CI1_concord==true ? ObjectSetString(0,"CI1_short",OBJPROP_TEXT,"CI1_short:  "+(string)(CI1negative)) : ObjectSetString(0,"CI1_short",OBJPROP_TEXT,"CI1_short:  ");
   ObjectSetInteger(0,"CI1_short",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"CI1_short",OBJPROP_YDISTANCE,140);
   ObjectSetInteger(0,"CI1_short",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CI1_short",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"CI2_short",OBJ_LABEL,0,0,0);
   CI2_concord==true ? ObjectSetString(0,"CI2_short",OBJPROP_TEXT,"CI2_short:  "+(string)(CI2negative)) : ObjectSetString(0,"CI2_short",OBJPROP_TEXT,"CI2_short:  ");
   ObjectSetInteger(0,"CI2_short",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"CI2_short",OBJPROP_YDISTANCE,155);
   ObjectSetInteger(0,"CI2_short",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CI2_short",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"CI3_short",OBJ_LABEL,0,0,0);
   CI3_concord==true ? ObjectSetString(0,"CI3_short",OBJPROP_TEXT,"CI3_short:  "+(string)(CI3negative)) : ObjectSetString(0,"CI3_short",OBJPROP_TEXT,"CI3_short:  ");
   ObjectSetInteger(0,"CI3_short",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"CI3_short",OBJPROP_YDISTANCE,170);
   ObjectSetInteger(0,"CI3_short",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"CI3_short",OBJPROP_COLOR,clrWhite);

   ObjectCreate(0,"HA1_long",OBJ_LABEL,0,0,0);
   HA1_concord==true ? ObjectSetString(0,"HA1_long",OBJPROP_TEXT,"HA1_in_long:     "+(string)(HA1positive)) : ObjectSetString(0,"HA1_long",OBJPROP_TEXT," ");
   ObjectSetInteger(0,"HA1_long",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"HA1_long",OBJPROP_YDISTANCE,200);
   ObjectSetInteger(0,"HA1_long",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"HA1_long",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"HA1_short",OBJ_LABEL,0,0,0);
   HA1_concord==true ? ObjectSetString(0,"HA1_short",OBJPROP_TEXT,"HA1_in_short:   "+(string)(HA1negative)) : ObjectSetString(0,"HA1_short",OBJPROP_TEXT," ");
   ObjectSetInteger(0,"HA1_short",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"HA1_short",OBJPROP_YDISTANCE,215);
   ObjectSetInteger(0,"HA1_short",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"HA1_short",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"HA2_long",OBJ_LABEL,0,0,0);
   HA2_concord==true ? ObjectSetString(0,"HA2_long",OBJPROP_TEXT,"HA2_out_long:   "+(string)(HA2positive)) : ObjectSetString(0,"HA2_long",OBJPROP_TEXT," ");
   ObjectSetInteger(0,"HA2_long",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"HA2_long",OBJPROP_YDISTANCE,230);
   ObjectSetInteger(0,"HA2_long",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"HA2_long",OBJPROP_COLOR,clrWhite);
   ObjectCreate(0,"HA2_short",OBJ_LABEL,0,0,0);
   HA2_concord==true ? ObjectSetString(0,"HA2_short",OBJPROP_TEXT,"HA2_out_short: "+(string)(HA2negative)) : ObjectSetString(0,"HA2_short",OBJPROP_TEXT," ");
   ObjectSetInteger(0,"HA2_short",OBJPROP_XDISTANCE,1545);
   ObjectSetInteger(0,"HA2_short",OBJPROP_YDISTANCE,245);
   ObjectSetInteger(0,"HA2_short",OBJPROP_FONTSIZE,8);
   ObjectSetInteger(0,"HA2_short",OBJPROP_COLOR,clrWhite);
  }

/*
//+------------------------------------------------------------------+
//|   CloseAllPositions                                              |
//+------------------------------------------------------------------+
//chiude tutte le posizioni aperte
void CloseAllPositions()
  {
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      int ticket = int(PositionGetTicket(i));
      trade.PositionClose(ticket);
      bot.SendMessage(chat_ID,"Chiusura di tutte le posizioni attive");
     }
  }
*/
//+------------------------------------------------------------------+
//|   UpdatePrices                                                   |
//+------------------------------------------------------------------+
//aggiorna i prezzi di stop-loss e di take-profit
void UpdatePrices(double upperMIGL1, double lowerMIGL1, double upperMIGL2, double lowerMIGL2, double upperMIGL3, double lowerMIGL3, double TPprice, double SLprice, double PriceClose)
  {
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      int ticket = int(PositionGetTicket(i));
      if(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_BUY)
        {
         if(HA_filter == true && HA2_concord == true)
            //se si utilizzano le candele HekinAshi e se è attivata caondizione di uscita con HeikinAshi 2
           {
            if(HA2positive == false && int(Dim-enter_candle) > int(ratio_HA2/ratio_HA1))
               //se HeikinAshi 2 non è positivo e sono passate più di "ratio_HA2/ratio_HA1" candele dall'ingresso nel mercato, allora si chiude il trade in TP
              {
               TPprice = PriceClose;
               SLprice = Bid-0.1000;
              }
            else
               if(HA2positive == false && int(Dim-enter_candle) == int(ratio_HA2/ratio_HA1))
                  //se HeikinAshi 2 non è positivo e sono passate esattamente "ratio_HA2/ratio_HA1" candele dall'ingresso nel mercato, allora si chiude il trade in SL
                 {
                  TPprice = Ask+0.1000;
                  SLprice = PriceClose;
                 }
               else
                 {
                  TPprice = Ask+0.1000;
                  SLprice = Bid-0.1000;
                 }
           }
         else
            //se invece le candele HekinAshi 2 non sono attivate
           {
            //allora si va in stop-loss se il segnale rientra all'interno della banda lenta
              {SLprice = lowerMIGL1-Ask+Bid-(SL_tolerance/100)*(upperMIGL1-lowerMIGL1);}

            if(Dim-cross_candle < int(PeriodToTrade*2/4))
               //se ci troviamo prima della metà del ciclo, il target price è upperMIGL2
              {TPprice = upperMIGL2;}
            else
               //a partire dalla metà del ciclo, il target price inizia gradualmente a scendere in modo che dopo 1/4 di periodo sia pari a upperMIGL3, e poi continua
              {TPprice = upperMIGL2 - (upperMIGL2-upperMIGL3)*(1-(cross_candle-int(PeriodToTrade*3/4))/(double(int(PeriodToTrade*1/4))));}
           }
        }

      if(PositionGetInteger(POSITION_TYPE)==POSITION_TYPE_SELL)
        {
         if(HA_filter == true && HA2_concord == true)
            //se si utilizzano le candele HekinAshi e se è attivata caondizione di uscita con HeikinAshi 2
           {
            if(HA2negative == false && int(Dim-enter_candle) > int(ratio_HA2/ratio_HA1))
               //se HeikinAshi 2 non è negativo e sono passate più di "ratio_HA2/ratio_HA1" candele dall'ingresso nel mercato, allora si chiude il trade in TP
              {
               TPprice = PriceClose;
               SL_price = Ask+0.1000;
              }
            else
               if(HA2negative == false && int(Dim-enter_candle) == int(ratio_HA2/ratio_HA1))
                  //se HeikinAshi 2 non è negativo e sono passate esattamente "ratio_HA2/ratio_HA1" candele dall'ingresso nel mercato, allora si chiude il trade in SL
                 {
                  TPprice = Bid-0.1000;
                  SLprice = PriceClose;
                 }
               else
                 {
                  TPprice = Bid-0.1000;
                  SLprice = Ask+0.1000;
                 }
           }
         else
            //se invece le candele HekinAshi 2 non sono attivate
           {
            //allora si va in stop-loss se il segnale rientra all'interno della banda lenta
              {SLprice = upperMIGL1+Ask-Bid+(SL_tolerance/100)*(upperMIGL1-lowerMIGL1);}

            if(Dim-cross_candle < int(PeriodToTrade*2/4))
               //se ci troviamo prima della metà del ciclo, il target price è lowerMIGL2
              {TPprice = lowerMIGL2;}
            else
               //a partire dalla metà del ciclo, il target price inizia gradualmente a salire in modo che dopo 1/4 di periodo sia pari a lowerMIGL3, e poi continua
              {TPprice = lowerMIGL2 + (lowerMIGL3-lowerMIGL2)*(1-(cross_candle-int(PeriodToTrade*3/4))/(double(int(PeriodToTrade*1/4))));}
           }
        }

      if((NormalizeDouble(SLprice,_Digits) != PositionGetDouble(POSITION_SL) || (NormalizeDouble(TPprice,_Digits) != PositionGetDouble(POSITION_TP))))
        {trade.PositionModify(ticket,SLprice,TPprice);}
     }
  }

//+------------------------------------------------------------------+
//|   OnTradeTransaction                                             |
//+------------------------------------------------------------------+
//verifica se si è usciti da una posizione e agisce di conseguenza
void OnTradeTransaction(const MqlTradeTransaction& trans,
                        const MqlTradeRequest& request,
                        const MqlTradeResult& results)
  {
   if(HistoryDealSelect(trans.deal) == true)
     {
      ENUM_DEAL_REASON deal_reason = (ENUM_DEAL_REASON)
                                     HistoryDealGetInteger(trans.deal,DEAL_REASON);

      //se si è usciti da una posizione a causa di uno stop-loss o di un take-profit
      if(deal_reason == DEAL_REASON_SL || deal_reason == DEAL_REASON_TP)
        {
         Print("Position closed!");
         //scala la commissione
         TesterWithdrawal(Commission);
         DD_trade = DD_trade + DD_until_stop;

         //calcola il prezzo di uscita
         if(order_out == "sellCloseOrder")
            price_out = Bid;
         if(order_out == "buyCloseOrder")
            price_out = Ask;

         //calcola l'orario di uscita
         time_out = TimeCurrent();

         //calcola il profitto della tradata appena fatta
         HistorySelect(TimeCurrent()-60, TimeCurrent());    //da 1 minuto fa ad ora
         int All_Deals = HistoryDealsTotal();
         ulong temp_Ticket = HistoryDealGetTicket(All_Deals-1);
         profit_out = HistoryDealGetDouble(temp_Ticket, DEAL_PROFIT);

         //se inoltre si è usciti da una posizione a causa di uno stop-loss
         if(deal_reason == DEAL_REASON_SL)
           {
            //manda un messaggio su Telegram
            int result=bot.SendScreenShot(chat_ID,_Symbol,_Period,"3_Migliorino_bands_8DD_7days");
            if(result!=0)
               Print(GetErrorDescription(result,InpLanguage));

            //aggiorna le variabili
            SL_count++;
            SL_loss = SL_loss + profit_out;
            profit_out = 0;
           }

         //se invece si è usciti da una posizione a causa di un'uscita regolare
         if(deal_reason == DEAL_REASON_TP)
           {
            //manda un messaggio su Telegram
            int result=bot.SendScreenShot(chat_ID,_Symbol,_Period,"3_Migliorino_bands_8DD_7days");
            if(result!=0)
               Print(GetErrorDescription(result,InpLanguage));
           }

         //salva i dati di uscita negli array
         time_out_array[SL_count+1] = time_out;
         price_out_array[SL_count+1] = price_out;

         //scrivi il file .csv
         WriteOnFile();

         //azzera le variabili e svuota gli array
         position = "";
         order_out = "";
         SL_count = 0;
         SL_loss = 0;
         ArrayInitialize(time_in_array,0);
         ArrayInitialize(time_out_array,0);
         ArrayInitialize(price_in_array,0);
         ArrayInitialize(price_out_array,0);

         exit_candle = Dim;    //setta il contatore della candela di uscita
        }
     }
  }

//+------------------------------------------------------------------+
//|   NewBar                                                         |
//+------------------------------------------------------------------+
//verifica se siamo in una nuova candela: viene chiamata ad ogni tick e se il tick fa parte di una nuova candela allora new_bar = true, altrimenti new_bar = false
void NewBar()
  {
   static datetime new_time = 0;
   new_bar = false;
   if(new_time != iTime(_Symbol,_Period,0))
     {
      new_time = iTime(_Symbol,_Period,0);
      new_bar = true;
      bars++;
     }
  }

//+------------------------------------------------------------------+
//|   ApproximateTime                                                |
//+------------------------------------------------------------------+
//approssima una data al timeframe in vigore
datetime ApproximateTime(datetime aTime)
  {
   MqlDateTime stm;
   TimeToStruct(aTime,stm);

   switch(_Period)
     {
      case 15:       //M15
        {
         stm.sec=0;
         (stm.min>=0 && stm.min<15) ? stm.min=0 : stm.min=stm.min;
         (stm.min>=15 && stm.min<30) ? stm.min=15 : stm.min=stm.min;
         (stm.min>=30 && stm.min<45) ? stm.min=30 : stm.min=stm.min;
         (stm.min>=45 && stm.min<60) ? stm.min=45 : stm.min=stm.min;
        }
      break;
      case 30:       //M30
        {
         stm.sec=0;
         (stm.min>=0 && stm.min<30) ? stm.min=0 : stm.min=stm.min;
         (stm.min>=30 && stm.min<60) ? stm.min=30 : stm.min=stm.min;
        }
      break;
      case 16385:    //H1
        {stm.sec=0; stm.min=0;}
      break;
      case 16388:    //H4
        {
         stm.sec=0;
         stm.min=0;
         (stm.hour>=0 && stm.hour<4) ? stm.hour=0 : stm.hour=stm.hour;
         (stm.hour>=4 && stm.hour<8) ? stm.hour=4 : stm.hour=stm.hour;
         (stm.hour>=8 && stm.hour<12) ? stm.hour=8 : stm.hour=stm.hour;
         (stm.hour>=12 && stm.hour<16) ? stm.hour=12 : stm.hour=stm.hour;
         (stm.hour>=16 && stm.hour<20) ? stm.hour=16 : stm.hour=stm.hour;
         (stm.hour>=20 && stm.hour<24) ? stm.hour=20 : stm.hour=stm.hour;
        }
      break;
      case 16408:    //D1
        {stm.sec=0; stm.min=0; stm.hour=0;}
      break;
     }

   return(StructToTime(stm));
  }

//+------------------------------------------------------------------+
//|   OnTester                                                       |
//+------------------------------------------------------------------+
//calcola il profitto finale al netto delle commissioni e la linearità
double OnTester()
  {
   double  profit = TesterStatistics(STAT_PROFIT);
   double  withdrawal = TesterStatistics(STAT_WITHDRAWAL);
   double  profit_factor = TesterStatistics(STAT_PROFIT_FACTOR);
   double  net_profit = profit-withdrawal;
   double  linearity = 1000 * (net_profit * profit_factor) / (DD_backtest * bars);

   return(NormalizeDouble(linearity,2));
  }

//+------------------------------------------------------------------+
//|   WriteOnFile                                                    |
//+------------------------------------------------------------------+
//scrive un file .csv con i dati della tradata
void WriteOnFile()
  {
   if(Use_FileCSV == true)
     {
      datetime time_buff[];         // array tempi segnale
      datetime time_write[];        // array tempi segnale da scrivere nel file

      double upperMIGL1_buff[];     // array valori banda alta
      double upperMIGL1_write[];    // array valori banda alta da scrivere nel file
      double lowerMIGL1_buff[];     // array valori banda bassa
      double lowerMIGL1_write[];    // array valori banda bassa da scrivere nel file
      double upperMIGL2_buff[];     // array valori banda alta
      double upperMIGL2_write[];    // array valori banda alta da scrivere nel file
      double lowerMIGL2_buff[];     // array valori banda bassa
      double lowerMIGL2_write[];    // array valori banda bassa da scrivere nel file
      double upperMIGL3_buff[];     // array valori banda alta
      double upperMIGL3_write[];    // array valori banda alta da scrivere nel file
      double lowerMIGL3_buff[];     // array valori banda bassa
      double lowerMIGL3_write[];    // array valori banda bassa da scrivere nel file

      double HA1_open_buff[];       // array valori HA Open
      double HA1_open_write[];      // array valori HA Open da scrivere nel file
      double HA1_high_buff[];       // array valori HA High
      double HA1_high_write[];      // array valori HA High da scrivere nel file
      double HA1_low_buff[];        // array valori HA Low
      double HA1_low_write[];       // array valori HA Low da scrivere nel file
      double HA1_close_buff[];      // array valori HA Close
      double HA1_close_write[];     // array valori HA Close da scrivere nel file
      double HA2_open_buff[];       // array valori HA Open
      double HA2_open_write[];      // array valori HA Open da scrivere nel file
      double HA2_high_buff[];       // array valori HA High
      double HA2_high_write[];      // array valori HA High da scrivere nel file
      double HA2_low_buff[];        // array valori HA Low
      double HA2_low_write[];       // array valori HA Low da scrivere nel file
      double HA2_close_buff[];      // array valori HA Close
      double HA2_close_write[];     // array valori HA Close da scrivere nel file

      double CI0_predict_buff[];    // array valori CI predetto
      double CI0_predict_write[];   // array valori CI predetto da scrivere nel file
      double CI0_phased_buff[];     // array valori CI in fase
      double CI0_phased_write[];    // array valori CI in fase da scrivere nel file
      double CI1_predict_buff[];    // array valori CI predetto
      double CI1_predict_write[];   // array valori CI predetto da scrivere nel file
      double CI1_phased_buff[];     // array valori CI in fase
      double CI1_phased_write[];    // array valori CI in fase da scrivere nel file
      double CI2_predict_buff[];    // array valori CI predetto
      double CI2_predict_write[];   // array valori CI predetto da scrivere nel file
      double CI2_phased_buff[];     // array valori CI in fase
      double CI2_phased_write[];    // array valori CI in fase da scrivere nel file
      double CI3_predict_buff[];    // array valori CI predetto
      double CI3_predict_write[];   // array valori CI predetto da scrivere nel file
      double CI3_phased_buff[];     // array valori CI in fase
      double CI3_phased_write[];    // array valori CI in fase da scrivere nel file

      double IN_market_buff[];      // array valori ingressi nel mercato
      double IN_market_write[];     // array valori ingressi nel mercato da scrivere nel file
      double OUT_market_buff[];     // array valori uscite dal mercato
      double OUT_market_write[];    // array valori uscite dal mercato da scrivere nel file

      datetime date_start = iTime(NULL, _Period, period_to_write);
      datetime date_finish = TimeCurrent();

      //--- copia la data appropriata nel buffer
      ResetLastError();
      if(CopyTime(_Symbol,_Period,date_start,date_finish,time_buff)==-1)
        {
         PrintFormat("Fallimento nel copiare i valori temporali dell'indicatore. Codice Errore = %d",GetLastError());
         return;
        }

      //--- copia i valori dell'indicatore Migliorino nei buffer
      ResetLastError();
      if(CopyBuffer(MIGL1definition,0,date_start,date_finish,upperMIGL1_buff)==-1 ||
         CopyBuffer(MIGL1definition,1,date_start,date_finish,lowerMIGL1_buff)==-1 ||
         CopyBuffer(MIGL1definition,2,date_start,date_finish,upperMIGL2_buff)==-1 ||
         CopyBuffer(MIGL1definition,3,date_start,date_finish,lowerMIGL2_buff)==-1 ||
         CopyBuffer(MIGL1definition,4,date_start,date_finish,upperMIGL3_buff)==-1 ||
         CopyBuffer(MIGL1definition,5,date_start,date_finish,lowerMIGL3_buff)==-1)
        {
         PrintFormat("Fallimento nel copiare i valori dell'indicatore Migliorino. Codice Errore = %d",GetLastError());
         return;
        }

      //--- copia i valori dell'indicatore HeikinAshi nei buffer
      ResetLastError();
      if(CopyBuffer(HA1definition,0,date_start-86400,date_finish,HA1_open_buff)==-1 ||
         CopyBuffer(HA1definition,1,date_start-86400,date_finish,HA1_high_buff)==-1 ||
         CopyBuffer(HA1definition,2,date_start-86400,date_finish,HA1_low_buff)==-1 ||
         CopyBuffer(HA1definition,3,date_start-86400,date_finish,HA1_close_buff)==-1 ||
         CopyBuffer(HA2definition,0,date_start-86400,date_finish,HA2_open_buff)==-1 ||
         CopyBuffer(HA2definition,1,date_start-86400,date_finish,HA2_high_buff)==-1 ||
         CopyBuffer(HA2definition,2,date_start-86400,date_finish,HA2_low_buff)==-1 ||
         CopyBuffer(HA2definition,3,date_start-86400,date_finish,HA2_close_buff)==-1)
        {
         PrintFormat("Fallimento nel copiare i valori dell'indicatore HeikinAshi. Codice Errore = %d",GetLastError());
         return;
        }

      //--- copia i valori dell'Indicatore Ciclico nei buffer
      ResetLastError();
      if(CopyBuffer(CI0definition,0,date_start,date_finish,CI0_predict_buff)==-1 ||
         CopyBuffer(CI0definition,1,date_start,date_finish,CI0_phased_buff)==-1  ||
         CopyBuffer(CI1definition,0,date_start,date_finish,CI1_predict_buff)==-1 ||
         CopyBuffer(CI1definition,1,date_start,date_finish,CI1_phased_buff)==-1  ||
         CopyBuffer(CI2definition,0,date_start,date_finish,CI2_predict_buff)==-1 ||
         CopyBuffer(CI2definition,1,date_start,date_finish,CI2_phased_buff)==-1  ||
         CopyBuffer(CI3definition,0,date_start,date_finish,CI3_predict_buff)==-1 ||
         CopyBuffer(CI3definition,1,date_start,date_finish,CI3_phased_buff)==-1)
        {
         PrintFormat("Fallimento nel copiare i valori dell'Indicatore Ciclico. Codice Errore = %d",GetLastError());
         return;
        }

      //--- scrive i prezzi di ingressi e uscite nelle corrispondenti righe
      CopyClose(_Symbol,_Period,date_start,date_finish,IN_market_buff);
      CopyClose(_Symbol,_Period,date_start,date_finish,OUT_market_buff);

      ArrayInitialize(IN_market_buff,0);
      ArrayInitialize(OUT_market_buff,0);

      for(int i=1; i<period_to_write+1; i++)
        {
         for(int j=1; j<=SL_count+1; j++)
           {
            if(time_buff[i] == time_in_array[j])
               IN_market_buff[i-1] = price_in_array[j];
            if(time_buff[i] == time_out_array[j])
               OUT_market_buff[i-1] = price_out_array[j];
           }
        }
      for(int j=1; j<=SL_count+1; j++)
        {
         if(TimeCurrent() == time_out_array[j])
            OUT_market_buff[period_to_write] = price_out_array[j];
        }

      //--- analizza i dati e salva i segnali indicatore negli array
      ArrayResize(time_write, period_to_write);

      ArrayResize(upperMIGL1_write, period_to_write);
      ArrayResize(lowerMIGL1_write, period_to_write);
      ArrayResize(upperMIGL2_write, period_to_write);
      ArrayResize(lowerMIGL2_write, period_to_write);
      ArrayResize(upperMIGL3_write, period_to_write);
      ArrayResize(lowerMIGL3_write, period_to_write);

      ArrayResize(HA1_open_write, period_to_write);
      ArrayResize(HA1_high_write, period_to_write);
      ArrayResize(HA1_low_write,  period_to_write);
      ArrayResize(HA1_close_write, period_to_write);
      ArrayResize(HA2_open_write, period_to_write);
      ArrayResize(HA2_high_write, period_to_write);
      ArrayResize(HA2_low_write,  period_to_write);
      ArrayResize(HA2_close_write, period_to_write);

      ArrayResize(CI0_predict_write,period_to_write);
      ArrayResize(CI0_phased_write, period_to_write);
      ArrayResize(CI1_predict_write,period_to_write);
      ArrayResize(CI1_phased_write, period_to_write);
      ArrayResize(CI2_predict_write,period_to_write);
      ArrayResize(CI2_phased_write, period_to_write);
      ArrayResize(CI3_predict_write,period_to_write);
      ArrayResize(CI3_phased_write, period_to_write);

      ArrayResize(IN_market_write,  period_to_write);
      ArrayResize(OUT_market_write, period_to_write);

      int jj=0;
      for(int i=1; i<period_to_write+1; i++)
        {
         time_write[jj] = time_buff[i];

         upperMIGL1_write[jj] = upperMIGL1_buff[i];
         lowerMIGL1_write[jj] = lowerMIGL1_buff[i];
         upperMIGL2_write[jj] = upperMIGL2_buff[i];
         lowerMIGL2_write[jj] = lowerMIGL2_buff[i];
         upperMIGL3_write[jj] = upperMIGL3_buff[i];
         lowerMIGL3_write[jj] = lowerMIGL3_buff[i];

         CI0_predict_write[jj] = CI0_predict_buff[i];
         CI0_phased_write[jj]  = CI0_phased_buff[i];
         CI1_predict_write[jj] = CI1_predict_buff[i];
         CI1_phased_write[jj]  = CI1_phased_buff[i];
         CI2_predict_write[jj] = CI2_predict_buff[i];
         CI2_phased_write[jj]  = CI2_phased_buff[i];
         CI3_predict_write[jj] = CI3_predict_buff[i];
         CI3_phased_write[jj]  = CI3_phased_buff[i];

         IN_market_write[jj]  = IN_market_buff[i];
         OUT_market_write[jj] = OUT_market_buff[i];

         jj++;
        }

      jj=0;
      for(int i=1; i<period_to_write/ratio_HA1+1; i++)        //conto "period_to_write/ratio_HA1" candele
        {
         for(int kk=1; kk<ratio_HA1+1 ; kk++)
           {
            HA1_open_write[jj] = HA1_open_buff[i];
            HA1_high_write[jj] = HA1_high_buff[i];
            HA1_low_write[jj]  = HA1_low_buff[i];
            HA1_close_write[jj] = HA1_close_buff[i];

            jj++;
           }
        }

      jj=0;
      for(int i=1; i<period_to_write/ratio_HA2+1; i++)        //conto "period_to_write/ratio_HA2" candele
        {
         for(int kk=1; kk<ratio_HA2+1 ; kk++)
           {
            HA2_open_write[jj] = HA2_open_buff[i];
            HA2_high_write[jj] = HA2_high_buff[i];
            HA2_low_write[jj]  = HA2_low_buff[i];
            HA2_close_write[jj] = HA2_close_buff[i];

            jj++;
           }
        }

      //--- apre il file per la scrittura dei valori indicatore (se il file è assente, verrà creato automaticamente)
      ResetLastError();
      int file_handle=FileOpen(InpDirectoryName+"//"+InpFileName+".csv",FILE_READ|FILE_WRITE|FILE_CSV);

      if(file_handle!=INVALID_HANDLE)
        {
         PrintFormat("il file %s è disponibile per la scrittura",InpFileName);
         PrintFormat("Percorso file: %s\\Files\\",TerminalInfoString(TERMINAL_DATA_PATH));

         if(order_in == "sellOrder" || order_in == "buyOrder")
            //--- popolamento del file nel caso si tratti di un ingresso
           {
            FileWrite(file_handle,
                      "Order type",
                      "Time IN",
                      "Price IN",
                      "Timeframe",
                      "Timeframe HA",
                      "Cross candle");
            FileWrite(file_handle,
                      order_in,
                      time_in,
                      price_in,
                      _Period,
                      PeriodHA1,
                      Dim-cross_candle);
            FileWrite(file_handle,"");
            FileWrite(file_handle,
                      "Time",
                      "Open",
                      "High",
                      "Low",
                      "Close",
                      "Slow Upper band",
                      "Slow Lower band",
                      "Middle Upper band",
                      "Middle Lower band",
                      "Fast Upper band",
                      "Fast Lower band",
                      "CI0 Predict",
                      "CI0 Phased",
                      "CI1 Predict",
                      "CI1 Phased",
                      "CI2 Predict",
                      "CI2 Phased",
                      "CI3 Predict",
                      "CI3 Phased",
                      "HA1 Open",
                      "HA1 High",
                      "HA1 Low",
                      "HA1 Close",
                      "HA2 Open",
                      "HA2 High",
                      "HA2 Low",
                      "HA2 Close");
            for(int i=1; i<period_to_write; i++)
              {
               FileWrite(file_handle,
                         time_write[i],
                         iOpen(_Symbol,_Period,period_to_write-1-i),
                         iHigh(_Symbol,_Period,period_to_write-1-i),
                         iLow(_Symbol,_Period,period_to_write-1-i),
                         iClose(_Symbol,_Period,period_to_write-1-i),
                         DoubleToString(upperMIGL1_write[i-1],_Digits),
                         DoubleToString(lowerMIGL1_write[i-1],_Digits),
                         DoubleToString(upperMIGL2_write[i-1],_Digits),
                         DoubleToString(lowerMIGL2_write[i-1],_Digits),
                         DoubleToString(upperMIGL3_write[i-1],_Digits),
                         DoubleToString(lowerMIGL3_write[i-1],_Digits),
                         DoubleToString(CI0_predict_write[i-1],_Digits),
                         DoubleToString(CI0_phased_write[i-1],_Digits),
                         DoubleToString(CI1_predict_write[i-1],_Digits),
                         DoubleToString(CI1_phased_write[i-1],_Digits),
                         DoubleToString(CI2_predict_write[i-1],_Digits),
                         DoubleToString(CI2_phased_write[i-1],_Digits),
                         DoubleToString(CI3_predict_write[i-1],_Digits),
                         DoubleToString(CI3_phased_write[i-1],_Digits),
                         DoubleToString(HA1_open_write[i-1],_Digits),
                         DoubleToString(HA1_high_write[i-1],_Digits),
                         DoubleToString(HA1_low_write[i-1],_Digits),
                         DoubleToString(HA1_close_write[i-1],_Digits),
                         DoubleToString(HA2_open_write[i-1],_Digits),
                         DoubleToString(HA2_high_write[i-1],_Digits),
                         DoubleToString(HA2_low_write[i-1],_Digits),
                         DoubleToString(HA2_close_write[i-1],_Digits));
              }
            FileWrite(file_handle,
                      TimeCurrent(),
                      iOpen(_Symbol,_Period,0),
                      iHigh(_Symbol,_Period,0),
                      iLow(_Symbol,_Period,0),
                      iClose(_Symbol,_Period,0),
                      DoubleToString(upperMIGL1_write[period_to_write-1],_Digits),
                      DoubleToString(lowerMIGL1_write[period_to_write-1],_Digits),
                      DoubleToString(upperMIGL2_write[period_to_write-1],_Digits),
                      DoubleToString(lowerMIGL2_write[period_to_write-1],_Digits),
                      DoubleToString(upperMIGL3_write[period_to_write-1],_Digits),
                      DoubleToString(lowerMIGL3_write[period_to_write-1],_Digits),
                      DoubleToString(CI0_predict_write[period_to_write-1],_Digits),
                      DoubleToString(CI0_phased_write[period_to_write-1],_Digits),
                      DoubleToString(CI1_predict_write[period_to_write-1],_Digits),
                      DoubleToString(CI1_phased_write[period_to_write-1],_Digits),
                      DoubleToString(CI2_predict_write[period_to_write-1],_Digits),
                      DoubleToString(CI2_phased_write[period_to_write-1],_Digits),
                      DoubleToString(CI3_predict_write[period_to_write-1],_Digits),
                      DoubleToString(CI3_phased_write[period_to_write-1],_Digits),
                      DoubleToString(HA1_open_write[period_to_write-1],_Digits),
                      DoubleToString(HA1_high_write[period_to_write-1],_Digits),
                      DoubleToString(HA1_low_write[period_to_write-1],_Digits),
                      DoubleToString(HA1_close_write[period_to_write-1],_Digits),
                      DoubleToString(HA2_open_write[period_to_write-1],_Digits),
                      DoubleToString(HA2_high_write[period_to_write-1],_Digits),
                      DoubleToString(HA2_low_write[period_to_write-1],_Digits),
                      DoubleToString(HA2_close_write[period_to_write-1],_Digits));
           }

         if(order_out == "sellCloseOrder" || order_out == "buyCloseOrder")
            //--- popolamento del file nel caso si tratti di un'uscita
           {
            FileWrite(file_handle,
                      "Order type",
                      "Time IN",
                      "Price IN",
                      "Time OUT",
                      "Price OUT",
                      "SL count",
                      "Drawdown",
                      "SL loss",
                      "TP gain",
                      "Lots",
                      "Timeframe",
                      "Timeframe HA1",
                      "Timeframe HA2");
            FileWrite(file_handle,
                      order_out,
                      time_in,
                      price_in,
                      time_out,
                      price_out,
                      SL_count,
                      DoubleToString(-DD_trade,2),
                      DoubleToString(SL_loss,2),
                      DoubleToString(profit_out,2),
                      LotsToBuy,
                      _Period,
                      PeriodHA1,
                      PeriodHA2);
            FileWrite(file_handle,"");
            FileWrite(file_handle,
                      "Time",
                      "Open",
                      "High",
                      "Low",
                      "Close",
                      "Slow Upper band",
                      "Slow Lower band",
                      "Middle Upper band",
                      "Middle Lower band",
                      "Fast Upper band",
                      "Fast Lower band",
                      "CI0 Predict",
                      "CI0 Phased",
                      "CI1 Predict",
                      "CI1 Phased",
                      "CI2 Predict",
                      "CI2 Phased",
                      "CI3 Predict",
                      "CI3 Phased",
                      "IN_market",
                      "OUT_market",
                      "HA1 Open",
                      "HA1 High",
                      "HA1 Low",
                      "HA1 Close",
                      "HA2 Open",
                      "HA2 High",
                      "HA2 Low",
                      "HA2 Close");
            for(int i=1; i<period_to_write; i++)
              {
               FileWrite(file_handle,
                         time_write[i],
                         iOpen(_Symbol,_Period,period_to_write-1-i),
                         iHigh(_Symbol,_Period,period_to_write-1-i),
                         iLow(_Symbol,_Period,period_to_write-1-i),
                         iClose(_Symbol,_Period,period_to_write-1-i),
                         DoubleToString(upperMIGL1_write[i-1],_Digits),
                         DoubleToString(lowerMIGL1_write[i-1],_Digits),
                         DoubleToString(upperMIGL2_write[i-1],_Digits),
                         DoubleToString(lowerMIGL2_write[i-1],_Digits),
                         DoubleToString(upperMIGL3_write[i-1],_Digits),
                         DoubleToString(lowerMIGL3_write[i-1],_Digits),
                         DoubleToString(CI0_predict_write[i-1],_Digits),
                         DoubleToString(CI0_phased_write[i-1],_Digits),
                         DoubleToString(CI1_predict_write[i-1],_Digits),
                         DoubleToString(CI1_phased_write[i-1],_Digits),
                         DoubleToString(CI2_predict_write[i-1],_Digits),
                         DoubleToString(CI2_phased_write[i-1],_Digits),
                         DoubleToString(CI3_predict_write[i-1],_Digits),
                         DoubleToString(CI3_phased_write[i-1],_Digits),
                         IN_market_write[i-1],
                         OUT_market_write[i-1],
                         DoubleToString(HA1_open_write[i-1],_Digits),
                         DoubleToString(HA1_high_write[i-1],_Digits),
                         DoubleToString(HA1_low_write[i-1],_Digits),
                         DoubleToString(HA1_close_write[i-1],_Digits),
                         DoubleToString(HA2_open_write[i-1],_Digits),
                         DoubleToString(HA2_high_write[i-1],_Digits),
                         DoubleToString(HA2_low_write[i-1],_Digits),
                         DoubleToString(HA2_close_write[i-1],_Digits));
              }
            FileWrite(file_handle,
                      TimeCurrent(),
                      iOpen(_Symbol,_Period,0),
                      iHigh(_Symbol,_Period,0),
                      iLow(_Symbol,_Period,0),
                      iClose(_Symbol,_Period,0),
                      DoubleToString(upperMIGL1_write[period_to_write-1],_Digits),
                      DoubleToString(lowerMIGL1_write[period_to_write-1],_Digits),
                      DoubleToString(upperMIGL2_write[period_to_write-1],_Digits),
                      DoubleToString(lowerMIGL2_write[period_to_write-1],_Digits),
                      DoubleToString(upperMIGL3_write[period_to_write-1],_Digits),
                      DoubleToString(lowerMIGL3_write[period_to_write-1],_Digits),
                      DoubleToString(CI0_predict_write[period_to_write-1],_Digits),
                      DoubleToString(CI0_phased_write[period_to_write-1],_Digits),
                      DoubleToString(CI1_predict_write[period_to_write-1],_Digits),
                      DoubleToString(CI1_phased_write[period_to_write-1],_Digits),
                      DoubleToString(CI2_predict_write[period_to_write-1],_Digits),
                      DoubleToString(CI2_phased_write[period_to_write-1],_Digits),
                      DoubleToString(CI3_predict_write[period_to_write-1],_Digits),
                      DoubleToString(CI3_phased_write[period_to_write-1],_Digits),
                      IN_market_write[period_to_write-1],
                      OUT_market_write[period_to_write-1],
                      DoubleToString(HA1_open_write[period_to_write-1],_Digits),
                      DoubleToString(HA1_high_write[period_to_write-1],_Digits),
                      DoubleToString(HA1_low_write[period_to_write-1],_Digits),
                      DoubleToString(HA1_close_write[period_to_write-1],_Digits),
                      DoubleToString(HA2_open_write[period_to_write-1],_Digits),
                      DoubleToString(HA2_high_write[period_to_write-1],_Digits),
                      DoubleToString(HA2_low_write[period_to_write-1],_Digits),
                      DoubleToString(HA2_close_write[period_to_write-1],_Digits));
           }
         //--- chiusura del file
         FileClose(file_handle);
         PrintFormat("I dati sono stati scritti, il file %s è chiuso",InpFileName);
         file_count++;
         InpFileName = IntegerToString(file_count);
        }
      else
         PrintFormat("Fallimento nell'aprire il file %s, Codice errore = %d",InpFileName,GetLastError());
     }
  }

//+------------------------------------------------------------------+
//|   GetCustomInfo                                                  |
//+------------------------------------------------------------------+
void GetCustomInfo(CustomInfo &info,
                   const int _error_code,
                   const ENUM_LANGUAGES _lang)
  {
   switch(_error_code)
     {
#ifdef __MQL5__
      case ERR_FUNCTION_NOT_ALLOWED:
         info.text1 = (_lang==LANGUAGE_EN)?"The URL does not allowed for WebRequest":"Этого URL нет в списке для WebRequest.";
         info.text2 = TELEGRAM_BASE_URL;
         break;
#endif
#ifdef __MQL4__
      case ERR_FUNCTION_NOT_CONFIRMED:
         info.text1 = (_lang==LANGUAGE_EN)?"The URL does not allowed for WebRequest":"Этого URL нет в списке для WebRequest.";
         info.text2 = TELEGRAM_BASE_URL;
         break;
#endif

      case ERR_TOKEN_ISEMPTY:
         info.text1 = (_lang==LANGUAGE_EN)?"The 'Token' parameter is empty.":"Параметр 'Token' пуст.";
         info.text2 = (_lang==LANGUAGE_EN)?"Please fill this parameter.":"Пожалуйста задайте значение для этого параметра.";
         break;
     }
  }

//+------------------------------------------------------------------+
//|   GetUninitReasonText                                            |
//+------------------------------------------------------------------+
string GetUninitReasonText(int reasonCode)
  {
   string text="";
//---
   switch(reasonCode)
     {
      case REASON_ACCOUNT:
         text="L'account è cambiato";
         break;
      case REASON_CHARTCHANGE:
         text="La coppia di valute o il timeframe sono cambiati";
         break;
      case REASON_CHARTCLOSE:
         text="Il grafico è stato chiuso";
         break;
      case REASON_PARAMETERS:
         text="I parametri di input sono cambiati";
         break;
      case REASON_RECOMPILE:
         text="Il programma "+__FILE__+" è stato ricompilato";
         break;
      case REASON_REMOVE:
         text="Il programma "+__FILE__+" è stato rimosso dal grafico";
         break;
      case REASON_TEMPLATE:
         text="Il nuovo template è stato applicato al grafico";
         break;
      default:
         text="Altra motivazione";
     }
//---
   return text;
  }

//+------------------------------------------------------------------+
//|   OnInitTelegram                                                 |
//+------------------------------------------------------------------+
void OnInitTelegram()
  {
   run_mode=GetRunMode();

   if(run_mode!=RUN_LIVE)
     {
      Print("Telegram functions will not work since you are running the backtest mode");
     }

   int y=40;
   if(ChartGetInteger(0,CHART_SHOW_ONE_CLICK))
      y=120;
   comm.Create("myPanel",20,y);
   comm.SetColor(clrDimGray,clrBlack,220);
//--- set language
   bot.Language(InpLanguage);

//--- set token
   init_error=bot.Token(InpToken);

//--- set filter
   bot.UserNameFilter(InpUserNameFilter);

//--- set templates
   bot.Templates(InpTemplates);

//--- set timer
   int timer_ms=3000;
   switch(InpUpdateMode)
     {
      case UPDATE_FAST:
         timer_ms=1000;
         break;
      case UPDATE_NORMAL:
         timer_ms=2000;
         break;
      case UPDATE_SLOW:
         timer_ms=3000;
         break;
      default:
         timer_ms=3000;
         break;
     };
   EventSetMillisecondTimer(timer_ms);
   OnTimer();

//--- Communications
   if(Use_Telegram)
     {
      bot.SendMessage(chat_ID,StringFormat("TS '" +__FILE__+"'                   > START <     \nSymbol: %s  Period: %s \nPrice: %s  Time: %s",
                                           _Symbol,
                                           StringSubstr(EnumToString(_Period),7),
                                           DoubleToString(SymbolInfoDouble(_Symbol,(SYMBOL_ASK+SYMBOL_BID)/2),_Digits),
                                           TimeToString(iTime(_Symbol,_Period,0))));
      //bot.SendMessage(chat_ID,StringFormat("Versione: %s Ultimo aggiornamento: %s:",VERSION,desc_agg));
      int result=bot.SendScreenShot(chat_ID,_Symbol,_Period,"3_Migliorino_bands_8DD_7days");
      if(result!=0)
         Print(GetErrorDescription(result,InpLanguage));
     }
  }

//+------------------------------------------------------------------+
//|   OnTimerTelegram()                                             |
//+------------------------------------------------------------------+
void OnTimerTelegram()
  {

//--- show init error
   if(init_error!=0)
     {
      //--- show error on display
      CustomInfo info;
      GetCustomInfo(info,init_error,InpLanguage);

      //---
      comm.Clear();
      comm.SetText(0,StringFormat("%s v.%s",EXPERT_NAME,EXPERT_VERSION),CAPTION_COLOR);
      comm.SetText(1,info.text1, LOSS_COLOR);
      if(info.text2!="")
         comm.SetText(2,info.text2,LOSS_COLOR);
      comm.Show();

      return;
     }

//--- show web error
   if(run_mode==RUN_LIVE)
     {

      //--- check bot registration
      if(time_check<TimeLocal()-PeriodSeconds(PERIOD_H1))
        {
         time_check=TimeLocal();
         if(TerminalInfoInteger(TERMINAL_CONNECTED))
           {
            //---
            web_error=bot.GetMe();
            if(web_error!=0)
              {
               //---
               if(web_error==ERR_NOT_ACTIVE)
                 {
                  time_check=TimeCurrent()-PeriodSeconds(PERIOD_H1)+300;
                 }
               //---
               else
                 {
                  time_check=TimeCurrent()-PeriodSeconds(PERIOD_H1)+5;
                 }
              }
           }
         else
           {
            web_error=ERR_NOT_CONNECTED;
            time_check=0;
           }
        }

      //--- show error
      if(web_error!=0)
        {
         comm.Clear();
         comm.SetText(0,StringFormat("%s v.%s",EXPERT_NAME,EXPERT_VERSION),CAPTION_COLOR);

         if(
#ifdef __MQL4__ web_error==ERR_FUNCTION_NOT_CONFIRMED #endif
#ifdef __MQL5__ web_error==ERR_FUNCTION_NOT_ALLOWED #endif
         )
           {
            time_check=0;

            CustomInfo info= {0};
            GetCustomInfo(info,web_error,InpLanguage);
            comm.SetText(1,info.text1,LOSS_COLOR);
            comm.SetText(2,info.text2,LOSS_COLOR);
           }
         else
            comm.SetText(1,GetErrorDescription(web_error,InpLanguage),LOSS_COLOR);

         comm.Show();
         return;
        }
     }

//---
   bot.GetUpdates();

//---
   if(run_mode==RUN_LIVE)
     {
      comm.Clear();
      comm.SetText(0,StringFormat("%s v.%s",EXPERT_NAME,EXPERT_VERSION),CAPTION_COLOR);
      comm.SetText(1,StringFormat("%s: %s",(InpLanguage==LANGUAGE_EN)?"Bot Name":"Имя Бота",bot.Name()),CAPTION_COLOR);
      comm.SetText(2,StringFormat("%s: %d",(InpLanguage==LANGUAGE_EN)?"Chats":"Чаты",bot.ChatsTotal()),CAPTION_COLOR);
      comm.Show();
     }

//---
   bot.ProcessMessages();
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
