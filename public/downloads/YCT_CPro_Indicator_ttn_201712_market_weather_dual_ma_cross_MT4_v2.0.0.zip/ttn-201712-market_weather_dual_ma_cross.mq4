//+------------------------------------------------------------------+
//|                                         CPro Indicator ttn_201712_market_weather_dual_ma_cross MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

/* MIT License
Copyright (c) 2017 tickelton@gmail.com
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
input int SlowMAperiod = 60;
input int FastMAperiod = 20;
input int CountPeriods = 480;
double ExtCrossBuffer[];
double ExtSlowMABuffer[];
double ExtFastMABuffer[];
int OnInit(void)
{
   string short_name;
   IndicatorBuffers(3);
   IndicatorDigits(Digits);
   SetIndexStyle(0,DRAW_LINE,STYLE_SOLID, 1);
   SetIndexBuffer(0, ExtCrossBuffer);
   SetIndexBuffer(1, ExtSlowMABuffer);
   SetIndexBuffer(2, ExtFastMABuffer);
   short_name="MWPMC("+
         IntegerToString(SlowMAperiod)+"/"+
         IntegerToString(FastMAperiod)+"-"+
         IntegerToString(CountPeriods)+")";
   IndicatorShortName(short_name);
   SetIndexLabel(0,short_name);
   SetIndexDrawBegin(0,0);
   return(INIT_SUCCEEDED);
}
int getCrossValue(int idx)
{
   static bool once = true;
   int crossCount = 0;
   for(int i=idx; i<idx+CountPeriods; i++) {
      if(ExtSlowMABuffer[i+1] >= ExtFastMABuffer[i+1] &&
          ExtSlowMABuffer[i] < ExtFastMABuffer[i]) {
         crossCount++;
      } else if(ExtSlowMABuffer[i+1] <= ExtFastMABuffer[i+1] &&
          ExtSlowMABuffer[i] > ExtFastMABuffer[i]) {
         crossCount++;   
      }
   }
   return crossCount;
}
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   int i, pos;
   ArraySetAsSeries(ExtCrossBuffer, true);
   ArraySetAsSeries(ExtSlowMABuffer, true);
   ArraySetAsSeries(ExtFastMABuffer, true);
   pos=rates_total - CountPeriods - prev_calculated - 1;
   for(i=pos+CountPeriods; i>=0; i--) {
      ExtSlowMABuffer[i] = iMA(NULL, 0, SlowMAperiod, 0, MODE_SMA, PRICE_CLOSE, i);
   }
   for(i=pos+CountPeriods; i>=0; i--) {
      ExtFastMABuffer[i] = iMA(NULL, 0, FastMAperiod, 0, MODE_SMA, PRICE_CLOSE, i);
   }
   for(i=pos; i>=0; i--) {
      ExtCrossBuffer[i] = getCrossValue(i);
   }
   return(rates_total);
}