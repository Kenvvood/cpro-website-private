//+------------------------------------------------------------------+
//|                                         CPro Indicator VROC MT5                          |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- indicator settings
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
//--- input parametrs
input int                 InpPeriodVROC=25;//周期
input ENUM_APPLIED_VOLUME InpVolumeType=VOLUME_TICK;//交易量s
//--- indicator buffer
double ExtVROCBuffer[];
int    ExtPeriodVROC;
//+------------------------------------------------------------------+
//| VROC initialization function                                     |
//+------------------------------------------------------------------+
void OnInit()
  {
//--- check for input value
   CPro_Init();  // CPro营销模块初始化
   if(InpPeriodVROC<=1)
     {
      ExtPeriodVROC=25;
      PrintFormat("Incorrect value for input variable InpPeriodVROC=%d. Indicator will use value=%d for calculations.",
                  InpPeriodVROC,ExtPeriodVROC);
     }
   else
      ExtPeriodVROC=InpPeriodVROC;
//--- define index buffer
   SetIndexBuffer(0,ExtVROCBuffer);
//--- set indicator short name
   IndicatorSetString(INDICATOR_SHORTNAME,"VROC("+string(ExtPeriodVROC)+")");
//--- set indicator digits
   IndicatorSetInteger(INDICATOR_DIGITS,2);
//--- set draw begin
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,ExtPeriodVROC-1);
  }
//+------------------------------------------------------------------+
//| Volume Rate of Change                                            |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(rates_total<ExtPeriodVROC)
      return(0);
//--- starting work
   int pos=prev_calculated-1;
   if(pos<ExtPeriodVROC-1)
     {
      pos=ExtPeriodVROC-1;
      for(int i=0; i<pos; i++)
         ExtVROCBuffer[i]=0.0;
     }
//--- main cycle by volume type
   if(InpVolumeType==VOLUME_TICK)
      CalculateVROC(pos,rates_total,tick_volume);
   else
      CalculateVROC(pos,rates_total,volume);
//--- OnCalculate done. Return new prev_calculated.
   return(rates_total);
  }
//+------------------------------------------------------------------+
//| Calculate VROC by volume argument                                |
//+------------------------------------------------------------------+
void CalculateVROC(const int pos,const int rates_total,const long& volume[])
  {
   for(int i=pos; i<rates_total && !IsStopped(); i++)
     {
      double prev_volume=(double)(volume[i-(ExtPeriodVROC-1)]);
      double curr_volume=(double)volume[i];
      //--- calculate VROC
      if(prev_volume!=0.0)
         ExtVROCBuffer[i]=100.0*(curr_volume-prev_volume)/prev_volume;
      else
         ExtVROCBuffer[i]=ExtVROCBuffer[i-1];
     }
  }
//+------------------------------------------------------------------+