//+------------------------------------------------------------------+
//|                                         CPro Tool 10pips MT4                             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int       TakeProfit_Buy = 10;
extern int       StopLoss_Buy = 50;
extern int       TrailingStop_Buy = 50;
extern int       TakeProfit_Sell = 10;
extern int       StopLoss_Sell = 50;
extern int       TrailingStop_Sell = 50;
extern double     Lots = 0.1;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
  if (Volume[0] > 1) return(0);
//  
int total, cnt;
  total=OrdersTotal();
  //  
  if(AccountFreeMargin()<(1000*Lots))
     {
       Print("We have no money. Free Margin = ", AccountFreeMargin());   
       return(0);  
     }
  if(total<1)
    {  
     //  
       OrderSend(Symbol(),OP_BUY,Lots,Ask,3,Bid-StopLoss_Buy*Point,Ask+TakeProfit_Buy*Point,"",16384,0,Green);
       Sleep(10000);//10 
       RefreshRates();
       OrderSend(Symbol(),OP_SELL,Lots,Bid,3,Ask+StopLoss_Sell*Point,Bid-TakeProfit_Sell*Point,"",16385,0,Red);
    }
  if(total==1)
    {
       OrderSelect(0, SELECT_BY_POS, MODE_TRADES);
       if(OrderType()==OP_BUY)
         {
           OrderSend(Symbol(),OP_BUY,Lots,Ask,3,Bid-StopLoss_Buy*Point,Ask+TakeProfit_Buy*Point,"",16384,0,Green);
         }
       if(OrderType()==OP_SELL)
         {
           OrderSend(Symbol(),OP_SELL,Lots,Bid,3,Ask+StopLoss_Sell*Point,Bid-TakeProfit_Sell*Point,"",16385,0,Red);
         }
    }   
  for(cnt=total-1;cnt>=0;cnt--)
     {
       OrderSelect(cnt, SELECT_BY_POS, MODE_TRADES);
       if(OrderType()==OP_BUY)
         {
           if(TrailingStop_Buy>0)  
             {                 
               if(Bid-OrderOpenPrice()>Point*TrailingStop_Buy) // Bid -  
                 {
                   if(OrderStopLoss()<Bid-Point*TrailingStop_Buy)
                     {
                       OrderModify(OrderTicket(),OrderOpenPrice(),Bid-Point*TrailingStop_Buy,OrderTakeProfit(),0,Green);
                       return(0);
                     }
                 }
             }
         }
       if(OrderType()==OP_SELL)
         {
           if(TrailingStop_Sell>0)  
             {                 
               if((OrderOpenPrice()-Ask)>(Point*TrailingStop_Sell))  // Ask -  
                 {
                   if((OrderStopLoss()>(Ask+Point*TrailingStop_Sell)) || (OrderStopLoss()==0))
                     {
                       OrderModify(OrderTicket(),OrderOpenPrice(),Ask+Point*TrailingStop_Sell,OrderTakeProfit(),0,Red);
                       return(0);
                     }
                 }
             }
         }
     }
//----
   return(0);
  }
//+------------------------------------------------------------------+