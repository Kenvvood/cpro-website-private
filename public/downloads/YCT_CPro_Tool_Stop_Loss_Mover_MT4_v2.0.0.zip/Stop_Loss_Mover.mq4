//+------------------------------------------------------------------+
//|                                         CPro Tool Stop_Loss_Mover MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
//extern double        TakeProfitPips=35;
//extern double        StopLossPips=100;
extern double  Move_SL_at = 0.9175;
      int         Faktor, Digt, cnt;
   double         TPp, SLp, Total, i;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init(){}
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit(){}
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
double OP = OrderOpenPrice();
double BCP = High[0];
double SCP = Low[0];
Total=OrdersTotal();
  if(Total>0)
  {
     for(i=Total-1; i>=0; i--) 
     {
     if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES))
        {
        if(OrderSymbol() == Symbol()){
            if(OrderStopLoss()==0 )
               {
                  if(OrderType()==OP_BUY && BCP>Move_SL_at)
                     {SLp = OP;
                     OrderModify(OrderTicket(),OrderOpenPrice(),SLp,TPp,0);
                     SendMail("","Stop Loss has just been moved to : "+DoubleToStr(SLp,5)+""  );
                     }
                  if(OrderType()==OP_SELL && SCP<Move_SL_at)                     
                     {SLp = OP;
                     OrderModify(OrderTicket(),OrderOpenPrice(),SLp,TPp,0);
                     SendMail("","Stop Loss has just been moved to : "+DoubleToStr(SLp,5)+""  ); 
                     }
               } else SLp = OrderStopLoss();
            }}} }
Comment(
           "\nStop Loss will move to BE at ", Move_SL_at);
/*
//---------------Modify Order--------------------------
            if (OrderType()==OP_BUY || OrderType()==OP_SELL)   
            OrderModify(OrderTicket(),OrderOpenPrice(),SLp,TPp,0);               
//-----------------------------------------------------
*/         
Print ("Order Type= ",OrderType());
Print ("Open= ",OrderOpenPrice());
Print ("Ticket= ",OrderTicket());         
Print ("Chart= ",OrderSymbol());
Print ("BCP= ",BCP);
Print ("SCP= ",SCP);
  return(0);
  }// Start()
//+------------------------------------------------------------------+