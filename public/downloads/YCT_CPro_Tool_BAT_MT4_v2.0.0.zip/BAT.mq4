//+------------------------------------------------------------------+
//|                                         CPro Tool BAT MT4                                |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- indicator settings
//---- indicator parameters
extern int BackPeriod   = 1000;
extern int ATRPeriod   = 3;
extern double Factor = 3;
extern bool TypicalPrice = false;
//---- indicator buffers
double     ind_buffer1[];
double     ind_buffer2[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int init()
  {
//---- drawing settings  
   SetIndexStyle(0,DRAW_LINE,EMPTY,2);
   SetIndexDrawBegin(0,ATRPeriod);
   SetIndexBuffer(0,ind_buffer1);
   SetIndexStyle(1,DRAW_LINE,EMPTY,2);
   SetIndexDrawBegin(1,ATRPeriod);
   SetIndexBuffer(1,ind_buffer2);
   IndicatorDigits(MarketInfo(Symbol(),MODE_DIGITS)+2);
//---- name for DataWindow and indicator subwindow label
   IndicatorShortName("ATR Trailing Stop("+ATRPeriod+" * "+Factor+")");
   SetIndexLabel(0,"Support");
   SetIndexLabel(1,"Resistance");
//---- initialization done
   return(0);
  }
//+------------------------------------------------------------------+
//| Moving Averages Convergence/Divergence                           |
//+------------------------------------------------------------------+
int start()
  {
   int limit;
   int counted_bars=IndicatorCounted();
   double PrevUp, PrevDn;
   double CurrUp, CurrDn;
   double PriceLvl;
   double LvlUp = 0;
   double LvlDn = 1000;
   int Dir = 1;
   int InitDir;
//---- check for possible errors
   if(counted_bars<0) return(-1);
//---- last counted bar will be recounted
   if(counted_bars>0) counted_bars--;
   limit=Bars-counted_bars;
//---- fill in buffervalues
   InitDir = 0;
   for(int i=BackPeriod; i>=0; i--)
   {
      if (TypicalPrice) PriceLvl = (High[i] + Low[i] + Close[i])/3;
      else PriceLvl = Close[i];  
      if(InitDir == 0) {
         CurrUp=Close[i] - (iATR(NULL,0,ATRPeriod,i) * Factor);
         PrevUp=Close[i-1] - (iATR(NULL,0,ATRPeriod,i-1) * Factor);
         CurrDn=Close[i] + (iATR(NULL,0,ATRPeriod,i) * Factor);
         PrevDn=Close[i-1] + (iATR(NULL,0,ATRPeriod,i-1) * Factor);
         if (CurrUp > PrevUp) Dir = 1;
         LvlUp = CurrUp;
         if (CurrDn < PrevDn) Dir = -1;
         LvlDn = CurrDn;
         InitDir = 1;
      }
      CurrUp=PriceLvl - (iATR(NULL,0,ATRPeriod,i) * Factor);
      CurrDn=PriceLvl + (iATR(NULL,0,ATRPeriod,i) * Factor);
      if (Dir == 1) {
         if (CurrUp > LvlUp) {
            ind_buffer1[i] = CurrUp;
            LvlUp = CurrUp;
         }
         else {
            ind_buffer1[i] = LvlUp;
         }
         ind_buffer2[i] = EMPTY_VALUE;
         if (Low[i] < ind_buffer1[i]) {
            Dir = -1;
            LvlDn = 1000;
         }
      }
      if (Dir == -1) {
         if (CurrDn < LvlDn) {
            ind_buffer2[i] = CurrDn;
            LvlDn = CurrDn;
         }
         else {
            ind_buffer2[i] = LvlDn;
         }
         ind_buffer1[i] = EMPTY_VALUE;
         if (High[i] > ind_buffer2[i]) {
            Dir = 1;
            LvlUp = 0;
         }
      }
   }  
//---- done
   return(0);
  }