//+------------------------------------------------------------------+
//|                                         CPro Indicator Laguerre MT5                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input double Gamma =  0.7;
input int CountBars = 950;
double Laguerre[];
void OnInit()
{
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, Laguerre, INDICATOR_DATA);
    IndicatorSetString(INDICATOR_SHORTNAME, "Laguerre");
    ArraySetAsSeries(Laguerre, true);
}
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &Close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
    int i = rates_total - 1;
    if (i >= CountBars) i = CountBars - 1;
    ArraySetAsSeries(Close, true);
    double L0 = 0, L1 = 0, L2 = 0, L3 = 0, LRSI = 0;
    while (i >= 0)
    {
        double L0A = L0;
        double L1A = L1;
        double L2A = L2;
        double L3A = L3;
        L0 = (1 - Gamma) * Close[i] + Gamma * L0A;
        L1 = -Gamma * L0 + L0A + Gamma * L1A;
        L2 = -Gamma * L1 + L1A + Gamma * L2A;
        L3 = -Gamma * L2 + L2A + Gamma * L3A;
        double CU = 0;
        double CD = 0;
        if (L0 >= L1) CU = L0 - L1;
        else CD = L1 - L0;
        if (L1 >= L2) CU = CU + L1 - L2;
        else CD = CD + L2 - L1;
        if (L2 >= L3) CU = CU + L2 - L3;
        else CD = CD + L3 - L2;
        if (CU + CD != 0) LRSI = CU / (CU + CD);
        Laguerre[i] = LRSI;
        i--;
    }
    return rates_total;
}
//+------------------------------------------------------------------+