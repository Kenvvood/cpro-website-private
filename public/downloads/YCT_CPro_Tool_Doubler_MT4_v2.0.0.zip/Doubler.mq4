//+------------------------------------------------------------------+
//|                                         CPro Tool Doubler MT4                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int    StopLoss       = 100;
extern int    TakeProfit     = 50;
int    magicnumber    = 777;
extern double lots = 0.1;
extern int Ext1 = 1;
extern int Ext2 = 1;
extern bool AutoLotChanging = false;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
int total = OrdersTotal();   
int SLB = Bid-(StopLoss*Point);
int TPB = Ask+(TakeProfit*Point);
int balance=AccountBalance()/500;
double lot=balance*0.1;
//----
              if (total == 0)
              {
              if (AutoLotChanging == true)
   {   
              OrderSend(Symbol(),OP_BUY,lot,Ask,3,SLB,TPB,"Doubler BUY",magicnumber,0,Green);
              OrderSend(Symbol(),OP_SELL,lot,Ask,3,TPB+(Ext1*Point),SLB-(Ext2*Point),"Doubler SELL",magicnumber,0,Green);
   }
   else
              OrderSend(Symbol(),OP_BUY,lots,Ask,3,SLB,TPB,"Doubler BUY",magicnumber,0,Green);
              OrderSend(Symbol(),OP_SELL,lots,Ask,3,TPB+(Ext1*Point),SLB-(Ext2*Point),"Doubler SELL",magicnumber,0,Green);
   }
//----
   return(0);
  }
//+------------------------------------------------------------------+