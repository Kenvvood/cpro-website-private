//+------------------------------------------------------------------+
//|                                         CPro Tool ytg_Speed_MA_ea MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int  PeriodMA     = 13;
extern int  Porog        = 10 ;
extern int  shift        = 1;
extern bool Revers       = false;
extern int  TP           = 500;
extern int  SL           = 490;
//+------------------------------------------------------------------+
int start()
  {
//----
   double MA_bar0 =iMA(NULL,0,PeriodMA,0,0,0,shift);
   double MA_bar1 =iMA(NULL,0,PeriodMA,0,0,0,shift+1);
   double Delta = MA_bar0-MA_bar1;   
   bool buy = false, sell = false;
   if(Delta>Porog*Point){if(Revers)sell = true;else buy = true;}   
   if(Delta<-Porog*Point){if(Revers)buy = true;else sell = true;}
   if(OrdersTotal()<1){
   if(buy)OrderSend(Symbol(),OP_BUY,0.1,Ask,50,Bid-SL*Point,Ask+TP*Point);
   if(sell)OrderSend(Symbol(),OP_SELL,0.1,Bid,50,Ask+SL*Point,Bid-TP*Point);}   
//----
   return(0);
  }
//+------------------------------------------------------------------+