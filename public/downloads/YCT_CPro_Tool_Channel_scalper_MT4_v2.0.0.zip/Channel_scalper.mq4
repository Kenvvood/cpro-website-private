//+------------------------------------------------------------------+
//|                                         CPro Tool Channel_scalper MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

double TrendU[];
double TrendUA[];
double TrendD[];
double TrendDA[];
double Direction[];
double Up[];
double Dn[];
int init()
{
 IndicatorBuffers(7);
 SetIndexBuffer(0, TrendU);
 SetIndexBuffer(1, TrendD);
 SetIndexBuffer(3, Direction);
 SetIndexBuffer(4, Up);
 SetIndexBuffer(5, Dn);
 SetIndexLabel(0,"");
 SetIndexLabel(1,"");
 SetIndexLabel(2,"");
 SetIndexLabel(3,"");
 IndicatorShortName("");
}
int deinit()
{
 return(0);
}
int start()
{
 int counted_bars = IndicatorCounted();
 int limit,i;
 if(counted_bars < 0) return(-1);
 if(counted_bars > 0) counted_bars--;
 limit = Bars-counted_bars;
 for(i = limit; i >= 0; i--)
  {
   double atr    = iATR(NULL,0,11,i);
   double cprice = iMA(NULL,0,1,0,MODE_SMA,PRICE_CLOSE,i);
   double mprice = (High[i]+Low[i])/2; 
   Up[i] = mprice+(1.28*atr);
   Dn[i] = mprice-(1.28*atr);
   Direction[i] = Direction[i+1]; 
   if(cprice > Up[i+1])
    {
     Direction[i] = 1;
    }
   if(cprice < Dn[i+1])
    {
     Direction[i] = -1;
    }
   if(Direction[i] > 0)
    {
     Dn[i] = MathMax(Dn[i],Dn[i+1]);
     TrendU[i] = Dn[i];
     GlobalVariableSet("GSignalBuy",1);
     GlobalVariableSet("GSignalSell",0);
    } 
   if(Direction[i] < 0)
    {
     Up[i] = MathMin(Up[i],Up[i+1]);
     TrendD[i] = Up[i];
     GlobalVariableSet("GSignalBuy",0);
     GlobalVariableSet("GSignalSell",1);
    }
  }
   return(0);
}