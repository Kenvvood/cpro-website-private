//+------------------------------------------------------------------+
//|                                         CPro Indicator I_Heikin_Ashi_Kerzen_V0 MT5       |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//---
input string   KerzenName="HA_Open;HA_High;HA_Low;HA_Close";//名称n der kerzenpunkte
input color    KerzenNeutral=clrGray; // Kerzenfarbe Neutral
input color    KerzenLong=clrBlue;//kerzenfarbe 做多
input color    KerzenShort=clrRed;//kerzenfarbe 做空
//--- indicator buffers
double         HA_Buffer_O[];
double         HA_Buffer_H[];
double         HA_Buffer_L[];
double         HA_Buffer_C[];
double         HA_Buffer_Colors[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,HA_Buffer_O,INDICATOR_DATA);
   SetIndexBuffer(1,HA_Buffer_H,INDICATOR_DATA);
   SetIndexBuffer(2,HA_Buffer_L,INDICATOR_DATA);
   SetIndexBuffer(3,HA_Buffer_C,INDICATOR_DATA);
   SetIndexBuffer(4,HA_Buffer_Colors,INDICATOR_COLOR_INDEX);
//---
   PlotIndexSetInteger(0,PLOT_DRAW_TYPE,DRAW_COLOR_CANDLES);
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,1);
   PlotIndexSetInteger(0,PLOT_COLOR_INDEXES,3);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,0,KerzenNeutral);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,1,KerzenLong);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,2,KerzenShort);
   //PlotIndexSetInteger(0,PLOT_LINE_WIDTH,4);
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,0.0);
   PlotIndexSetString(0,PLOT_LABEL,KerzenName);
//---
   IndicatorSetString(INDICATOR_SHORTNAME,"TF Heikin Ashi Kerzen");
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);
//---
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   CPro_Deinit();  // CPro营销模块清理
//---
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
//---
   int i=prev_calculated-1;
   double   haO,haH,haL,haC;
//---
   if(i==-1)
      {
         i=1;
         HA_Buffer_O[0]=open[0];
         HA_Buffer_H[0]=high[0];
         HA_Buffer_L[0]=low[0];
         HA_Buffer_C[0]=close[0];
         HA_Buffer_Colors[0]=(open[0]==close[0])?0:(open[0]<close[0])?1:2;
      }
//---
   for(i; i<rates_total && !IsStopped(); i++)
      {
         haO=(HA_Buffer_O[i-1]+HA_Buffer_C[i-1])/2;
         haC=(open[i]+high[i]+low[i]+close[i])/4;
         haH=MathMax(high[i],MathMax(haO,haC));
         haL=MathMin(low[i],MathMin(haO,haC));
         HA_Buffer_O[i]=haO;
         HA_Buffer_H[i]=haH;
         HA_Buffer_L[i]=haL;
         HA_Buffer_C[i]=haC;
         HA_Buffer_Colors[i]=(haO==haC)?0:(haO<haC)?1:2;
      }
//--- return value of prev_calculated for next call
   return(rates_total);
}
//+------------------------------------------------------------------+