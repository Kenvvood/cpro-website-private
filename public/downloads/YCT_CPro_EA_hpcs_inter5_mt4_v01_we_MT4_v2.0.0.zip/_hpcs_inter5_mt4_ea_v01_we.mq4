//+------------------------------------------------------------------+
//|                                         CPro EA hpcs_inter5_mt4_v01_we MT4               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
input int ii_stoploss = 10;
input int ii_TakeProfit = 10;
int OnInit()
  {
//---
      int li_ticket,li_factor = 1;
   double ld_stoploss,ld_Takeprofit;
   if(Digits ==5 || Digits == 3)
   { li_factor = 10;}
   ld_Takeprofit = Ask + ii_TakeProfit*Point()*li_factor;
   ld_stoploss = Ask - ii_stoploss*Point()*li_factor;
   if(ld_stoploss > (Bid - MarketInfo(_Symbol,MODE_STOPLEVEL )*Point()))
   {
      ld_stoploss = (Bid - MarketInfo(_Symbol,MODE_STOPLEVEL )*Point());
   } 
      if(Close[5] > Close[1])
      {
         li_ticket = OrderSend(_Symbol,OP_BUY,1,Ask,10,ld_stoploss,ld_Takeprofit,NULL,2233);
         if(li_ticket < 0)
         {
            Print("Order not placed with Error: ",GetLastError());
         }
         if(OrderSelect(li_ticket,SELECT_BY_TICKET,MODE_TRADES))
         {
            OrderPrint();
            Print("Order Open Time is: ",OrderOpenTime());
         }
      }
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//--- 
  }
//+------------------------------------------------------------------+