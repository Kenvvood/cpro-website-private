//+------------------------------------------------------------------+
//|                                         CPro Tool NewsTrader MT4                         |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

int cnt, ticket =0, ticket2=0, total;
extern int lot = 1;
extern int sl = 10;
extern int tp = 10;
extern int bias = 20; //we place our order 20 pips from current price
double orderAsk;
double orderBid;
string OrderCloseDate;
int init()
  {
  Print(MarketInfo(Symbol(), MODE_STOPLEVEL));
   return(0);
  }
int deinit()
  {
   return(0);
  }
int start()
  {
   //we have to know the time and date of news publication
   //I don't want to write what sombody else has written here http://articles.mql4.com/523
   //we can use this indicator to get the date and time of news publications
   //I have put here some example date and 
   int newsDateYear = 2010;
   int newsDateMonth = 3;
   int newsDateDay = 8;
   int newsDateHour = 1;
   int newsDateMinute = 30;
   //we need to open order before news publication
   newsDateMinute -= 10; //10 minutes before publication
   string orderOpenDate = newsDateDay + "-" + newsDateMonth + "-" + newsDateYear 
                                                + " " + newsDateHour + ":" + newsDateMinute + ":00";
   int currentYear = Year();
   int currentMonth = Month();
   int currentDay = Day();
   int currentHour = Hour();
   int currentMinute = Minute();
   //we get current time
   string currentDate = currentDay + "-" + currentMonth + "-" + currentYear 
                                                + " " + currentHour + ":" + currentMinute + ":00";
   if(orderOpenDate == currentDate)
   { 
      //we place 2 orders: buy stop and sell stop
      if(ticket < 1)
      {
         orderAsk = Ask - bias * Point;
         orderBid = Bid - bias * Point;
         ticket=OrderSend(Symbol(),OP_SELLSTOP,lot,orderBid,1,orderAsk+Point*sl,orderBid-tp*Point,"NewsTrader",2,0,Red); 
      }
      if(ticket2 < 1)
      {
         orderAsk = Ask + bias * Point;
         orderBid = Bid + bias * Point;
         ticket2=OrderSend(Symbol(),OP_BUYSTOP,lot,orderAsk,1,orderBid-Point*sl,orderAsk+tp*Point,"NewsTrader",2,0,Green); 
      }         
   }
   return(0);
  }