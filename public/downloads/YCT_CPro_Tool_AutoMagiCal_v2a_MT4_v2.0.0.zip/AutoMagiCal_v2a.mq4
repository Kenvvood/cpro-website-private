//+------------------------------------------------------------------+
//|                                         CPro Tool AutoMagiCal_v2a MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//===Variables=================================================================================
int      Magic,MagiCal[5],Mcar;
double   mNr;
string   StrMagic;
//===Init======================================================================================
int init()
   {
      ObjectCreate("MagicLabel",OBJ_LABEL,0,0,0);
      ObjectSet("MagicLabel",OBJPROP_CORNER,0);
      ObjectSet("MagicLabel",OBJPROP_XDISTANCE,10);
      ObjectSet("MagicLabel",OBJPROP_YDISTANCE,10);
      ObjectSet("MagicLabel",OBJPROP_BACK,true);
      return(0);
   }
//===Deinit====================================================================================
int deinit()
   {
      ObjectDelete("MagicLabel");
      return(0);
   }
//===Start=====================================================================================
int start()
   {
      if(Magic == 0) {AutoMagiCal();}
      return(0);
   }
//===AutoMagiCal===Automatic=Magic=Number=Calculator===========================================
void AutoMagiCal()
   {
      for(Mcar = 1; Mcar < 5; Mcar++) {MagiCal[Mcar] = StringGetChar(Symbol(), Mcar);}    //change char from symbol to number
      StrMagic = MagiCal[1] + "" + MagiCal[2] + "" + MagiCal[3] + "" + MagiCal[4];        //sort number in string
      mNr = StrToDouble(StrMagic);                                                        //make string to double | while double is bigger then integer
      if(mNr > 999999999) {mNr = mNr / 10;}            //maximum of integer = 2147483647 is bigger then 999999999 make / 10
      if(mNr > 9999999999) {mNr = mNr / 100;}
      else
         {
            Magic = NormalizeDouble(mNr, 0);//make double to integer
            ObjectSetText("MagicLabel", "Magic No. =  " + Magic, 9, "Arial", Lime);
         }
      return(0);
   }
//===End=======================================================================================