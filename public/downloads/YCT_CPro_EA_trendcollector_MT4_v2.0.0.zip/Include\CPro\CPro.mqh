//+------------------------------------------------------------------+
//|                                               CPro.mqh           |
//|                         CPro Trading 营销模块主入口                |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+
//
//  PURPOSE:
//    CPro.mqh is the main entry point for all CPro Trading
//    marketing shell components. It provides startup dialogs,
//    statistics panels, and brand watermarks.
//
//  COMPONENTS:
//    - CProConfig.mqh   : Configuration and constants
//    - CProDialog.mqh   : Startup authorization dialog
//    - CProPanel.mqh    : Statistics panel with About tab
//    - CProWatermark.mqh: Circular logo watermark
//
//  USAGE:
//    #include "CPro\CPro.mqh"
//
//    CProDialog dialog;
//    CProPanel panel;
//    CProWatermark watermark;
//
//    dialog.Init();
//    dialog.ShowStartupDialog();
//
//    panel.Init();
//
//    watermark.Init();
//    watermark.DrawWatermark();
//
//+------------------------------------------------------------------+

#ifndef CPRO_MQH
#define CPRO_MQH

// Include all CPro modules
#include "CProConfig.mqh"
#include "CProDialog.mqh"
#include "CProPanel.mqh"
#include "CProWatermark.mqh"

//+------------------------------------------------------------------+
//| Convenience Initialization Macro                                 |
//+------------------------------------------------------------------+
#define CPRO_INIT_ALL(dialog, panel, watermark) \
    dialog.Init(); \
    panel.Init(); \
    watermark.Init();

#define CPRO_SHOW_STARTUP(dialog) \
    dialog.ShowStartupDialog();

#define CPRO_DRAW_WATERMARK(watermark) \
    watermark.DrawWatermark();

#define CPRO_DEINIT_ALL(dialog, panel, watermark) \
    dialog.Deinit(); \
    panel.Deinit(); \
    watermark.Deinit();

#endif // CPRO_MQH
