//+------------------------------------------------------------------+
//|                                         CPro Indicator AndeanOscillator MT5              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input int Length = 50;
input int SignalLength = 9;
double Bull[];
double Bear[];
double Signal[];
double Up1[], Up2[], Dn1[], Dn2[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, Bull, INDICATOR_DATA);
    SetIndexBuffer(1, Bear, INDICATOR_DATA);
    SetIndexBuffer(2, Signal, INDICATOR_DATA);
    SetIndexBuffer(3, Up1, INDICATOR_CALCULATIONS);
    SetIndexBuffer(4, Up2, INDICATOR_CALCULATIONS);
    SetIndexBuffer(5, Dn1, INDICATOR_CALCULATIONS);
    SetIndexBuffer(6, Dn2, INDICATOR_CALCULATIONS);
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    if (rates_total < SignalLength + 1) return(0);
    int start;
    if (prev_calculated == 0) {
        Up1[0] = 0;
        Up2[0] = 0;
        Dn1[0] = 0;
        Dn2[0] = 0;
        Signal[0] = 0;
        start = 1;
    } else {
        start = prev_calculated - 1;
    }
    for (int i = start; i < rates_total && !IsStopped(); i++) {
        double t;
        double alpha = 2.0 / (Length + 1);
        t = MathMax(close[i], open[i]);
        Up1[i] = MathMax(t, Up1[i - 1] - (Up1[i - 1] - close[i]) * alpha);
        if (Up1[i] == 0) Up1[i] = close[i];
        t = MathMax(close[i] * close[i], open[i] * open[i]);
        Up2[i] = MathMax(t, Up2[i - 1] - (Up2[i - 1] - close[i] * close[i]) * alpha);
        if (Up2[i] == 0) Up2[i] = close[i] * close[i];
        t = MathMin(close[i], open[i]);
        Dn1[i] = MathMin(t, Dn1[i - 1] + (close[i] - Dn1[i - 1]) * alpha);
        if (Dn1[i] == 0) Dn1[i] = close[i];
        t = MathMin(close[i] * close[i], open[i] * open[i]);
        Dn2[i] = MathMin(t, Dn2[i - 1] + (close[i] * close[i] - Dn2[i - 1]) * alpha);
        if (Dn2[i] == 0) Dn2[i] = close[i] * close[i];
        Bull[i] = MathSqrt(Dn2[i] - Dn1[i] * Dn1[i]);
        Bear[i] = MathSqrt(Up2[i] - Up1[i] * Up1[i]);
        Signal[i] = MathMax(Bull[i], Bear[i]);
    }
    CalculateEMA(rates_total, prev_calculated, SignalLength, Signal);
    return(rates_total);
}
//+------------------------------------------------------------------+
//|  exponential moving average                                      |
//+------------------------------------------------------------------+
void CalculateEMA(int rates_total, int prev_calculated, int len, double &s[]) {
    int i, start;
    double SmoothFactor = 2.0 / (1.0 + len);
    if (prev_calculated == 0) {
        start = 1;
    } else {
        start = prev_calculated - 1;
    }
    for (i = start; i < rates_total && !IsStopped(); i++) {
        s[i] = s[i] * SmoothFactor + s[i - 1] * (1.0 - SmoothFactor);
    }
}
//+------------------------------------------------------------------+