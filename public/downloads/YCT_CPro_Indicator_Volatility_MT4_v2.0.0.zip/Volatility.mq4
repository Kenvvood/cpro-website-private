//+------------------------------------------------------------------+
//|                                         CPro Indicator Volatility MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot A
//--- plot B
//--- plot C
//--- plot C
//--- input parameters
input int      VolatilityPeriod=5;//volatility 周期
//--- indicator buffers
double         aBuffer[];
double         bBuffer[];
double         cBuffer[];
double         dBuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   IndicatorShortName(StringFormat("Volatility (%i, %i, %i, %i)",(int)MathPow(VolatilityPeriod,1),(int)MathPow(VolatilityPeriod,2),(int)MathPow(VolatilityPeriod,3),(int)MathPow(VolatilityPeriod,4)));
   SetIndexBuffer(0,aBuffer);
   SetIndexBuffer(1,bBuffer);
   SetIndexBuffer(2,cBuffer);
   SetIndexBuffer(3,dBuffer);
   SetIndexLabel(0,StringFormat("Volatility %i",(int)MathPow(VolatilityPeriod,4)));
   SetIndexLabel(1,StringFormat("Volatility %i",(int)MathPow(VolatilityPeriod,3)));
   SetIndexLabel(2,StringFormat("Volatility %i",(int)MathPow(VolatilityPeriod,2)));
   SetIndexLabel(3,StringFormat("Volatility %i",(int)MathPow(VolatilityPeriod,1)));
   ZoomHistograms();
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int i=Bars-IndicatorCounted()-1;
   while(i>0)
     {
      i--;
      aBuffer[i]=iStdDev(Symbol(),Period(),(int)MathPow(VolatilityPeriod,4),0,MODE_SMA,PRICE_MEDIAN,i);
      bBuffer[i]=iStdDev(Symbol(),Period(),(int)MathPow(VolatilityPeriod,3),0,MODE_SMA,PRICE_MEDIAN,i);
      cBuffer[i]=iStdDev(Symbol(),Period(),(int)MathPow(VolatilityPeriod,2),0,MODE_SMA,PRICE_MEDIAN,i);
      dBuffer[i]=iStdDev(Symbol(),Period(),(int)MathPow(VolatilityPeriod,1),0,MODE_SMA,PRICE_MEDIAN,i);
     }
   return(0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ZoomHistograms()
  {
   int zoom=(int)ChartGetInteger(0,CHART_SCALE,0);
   int px=0;
   switch(zoom)
   {
      case 0 :
         px=1;
         break;
      case 1:
         px=1;
         break;
      case 2:
         px=2;
         break;
      case 3:
         px=3;
         break;
      case 4:
         px=6;
         break;
      case 5:
         px=13;
         break;
   }
   SetIndexStyle(0,DRAW_HISTOGRAM,STYLE_SOLID,px,clrSilver);
   SetIndexStyle(1,DRAW_HISTOGRAM,STYLE_SOLID,px,clrRed);
   SetIndexStyle(2,DRAW_HISTOGRAM,STYLE_SOLID,px,clrOrange);
   SetIndexStyle(3,DRAW_HISTOGRAM,STYLE_SOLID,px,clrYellow);
  }
//+------------------------------------------------------------------+
//| ChartEvent function                                              |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,
                  const long &lparam,
                  const double &dparam,
                  const string &sparam)
  {
   if(id==CHARTEVENT_CHART_CHANGE)
     {
      ZoomHistograms();
     }
  }
//+------------------------------------------------------------------+