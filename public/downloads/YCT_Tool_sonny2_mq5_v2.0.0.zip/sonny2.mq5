
//+------------------------------------------------------------------+
//|                 YCT Tool sonny2_mq5                                |
//|                         城诺科技                            |
//|                         WeChat: Lookee333                        |
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                  SonnyPanel2.mq5 |
//|                                  Copyright 2024, MetaQuotes Ltd. |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "Copyright 2024, MetaQuotes Ltd."
#property link      "https://www.mql5.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                           Brand Panel                             |
//+------------------------------------------------------------------+
#include <mq5\Marketing.mqh>

// 品牌面板将在 OnInit() 中通过 InitMarketing() 初始化
// 品牌面板将在 OnDeinit() 中通过 DeinitMarketing() 清理

#include <Trade\PositionInfo.mqh>
#include <Trade\Trade.mqh>
#include "..\includes\CalculateBreakeven.mqh"
#include "..\includes\OrderManager.mqh"

#include"..\\Includes\\BreakEvenResult.mqh"
#include <Controls\Button.mqh>
#include <Controls\Edit.mqh>
#include <Controls\CheckBox.mqh>

CTrade trade;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
#define BTN_BUY_NAME "Btn Buy"
#define BTN_SELL_NAME "Btn Sell"
#define BTN_CLOSEALL_NAME "Btn CloseAll"
#define EDIT_VOLUME "Edit Volume"

CButton btnBuy;
CButton btnSell;
CButton btnCloseAll;
CEdit CEditMagic;
CButton btnMagicUp;
CButton btnMagicDown;
CButton TrailStartDown;
CButton TrailStartUp;
CButton TrailStepDown;
CButton TrailStepUp;

CEdit CEditLotsize;
CButton btnLotsizeDown;
CButton btnLotsizeUp;


CButton btnHedge;
CButton btnCloseMagic;

CEdit CEditProfit;
CButton btnProfitUp;
CButton btnProfitDown;
CEdit TrailStart;
CEdit TrailStep;

CEdit CEditLotsizeToClose;
CButton btnLotsizeToCloseUp;
CButton btnLotsizeToCloseDown;
CButton btnMoveUpDown;

CCheckBox         CheckStopForToday;
CCheckBox         CheckRecover;


OrderManager orderManager;
long Magic=1;
input bool iUseIndicator=false;
double Lotsize=0.01;
double ProfitTaget=0.07;
double LotsizeToClose=0.01;
bool PanelUp=true;
int MA_handle;
int MA_handle1;
int MA_handle2;
int MA_handle3;
int MA_handle4;
int x=20;

int w=50;
int h=20;
int d=30;
ulong TicketList[100] = {0};
double Step[100] = {0};
double lossprofit=-1;
double totallossprofit=20;
datetime lasthedge=TimeCurrent();
long oldmagic=1;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnInit()
  {
   Magic=1;
   if(iUseIndicator)
     {
      MA_handle=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_total",true,true);
      MA_handle2=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_totalBuy",true,false);
      MA_handle3=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_totalSell",false,true);
      MA_handle4=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_totalMagic",Magic,LotsizeToClose,ProfitTaget);
      MA_handle1=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\candlecountdown");
     }

   Lotsize=DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
   ProfitTaget=0.5;
   LotsizeToClose=DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
   ObjectsDeleteAll(0,0,-1);
//---


   btnBuy.Create(0,BTN_BUY_NAME,0,x+w,h,x+2*w,h+d);
   btnBuy.Text("Buy");
   btnBuy.Color(clrWhite);
   btnBuy.ColorBackground(clrGreen);

   btnSell.Create(0,BTN_SELL_NAME,0,x,h,x+w,h+d);
   btnSell.Text("Sell");
   btnSell.Color(clrWhite);
   btnSell.ColorBackground(clrRed);

   btnCloseAll.Create(0,BTN_CLOSEALL_NAME,0,x+2*w,h,x+3*w,h+d);
   btnCloseAll.Text("CloseAll");
   btnCloseAll.Color(clrWhite);
   btnCloseAll.ColorBackground(clrPurple);

   CEditMagic.Create(0,"Edit Magic",0,x+10,h+d,x+40,h+2*d);
   CEditMagic.Text("1");
   btnMagicUp.Create(0,"Magic Up",0,x,h+d,x+10,h+2*d);
   btnMagicUp.Text("+");
   btnMagicDown.Create(0,"Magic down",0,x+40,h+d,x+50,h+2*d);
   btnMagicDown.Text("-");

   CEditLotsize.Create(0,"Edit Lotsize",0,x+w+10,h+d,x+w+40,h+2*d);
   CEditLotsize.Text(DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN)));
   btnLotsizeUp.Create(0,"Lotsize Up",0,x+w,h+d,x+w+10,h+2*d);
   btnLotsizeUp.Text("+");
   btnLotsizeDown.Create(0,"Lotsize Down",0,x+w+40,h+d,x+w+50,h+2*d);
   btnLotsizeDown.Text("-");

   CEditProfit.Create(0,"Profit",0,x+2*w+10,h+d,x+2*w+40,h+2*d);
   CEditProfit.Text("0.5");
   CEditProfit.ColorBackground(clrLightGreen);


   btnProfitUp.Create(0,"Profit Up",0,x+2*w,h+d,x+2*w+10,h+2*d);
   btnProfitUp.Text("+");
   btnProfitDown.Create(0,"Profit Down",0,x+2*w+40,h+d,x+2*w+50,h+2*d);
   btnProfitDown.Text("-");


   btnHedge.Create(0,"Hedge",0,x,h+2*d,x+w,h+3*d);
   btnHedge.Text("Hedge");
   btnHedge.Color(clrWhite);
   btnHedge.ColorBackground(clrRed);
   btnCloseMagic.Create(0,"Close Magic",0,x+w,h+2*d,x+2*w,h+3*d);
   btnCloseMagic.Text("ClsMagic");

   btnCloseMagic.Color(clrWhite);
   btnCloseMagic.ColorBackground(clrPurple);

   CEditLotsizeToClose.Create(0,"Edit LotsizeToClose",0,x+2*w+10,h+2*d,x+2*w+40,h+3*d);
   CEditLotsizeToClose.Text(DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN)));
   btnLotsizeToCloseUp.Create(0,"LotsizeToClose Up",0,x+2*w,h+2*d,x+2*w+10,h+3*d);
   btnLotsizeToCloseDown.Text("-");
   btnLotsizeToCloseDown.Create(0,"LotsizeToClose Down",0,x+2*w+40,h+2*d,x+2*w+50,h+3*d);
   btnLotsizeToCloseUp.Text("+");

   TrailStartUp.Create(0,"TrailUp",0,x,h+3*d,x+10,h+4*d);
   TrailStartUp.Text("+");
   TrailStart.Create(0,"TrailStart",0,x+10,h+3*d,x+40,h+4*d);
   TrailStart.Text("0.15");
   TrailStartDown.Create(0,"TrailDown",0,x+40,h+3*d,x+50,h+4*d);
   TrailStartDown.Text("-");

   TrailStep.Create(0,"TrailStep",0,x+w+10,h+3*d,x+w+40,h+4*d);
   TrailStep.Text("0.05");
   TrailStepUp.Create(0,"StepUp",0,x+w,h+3*d,x+w+10,h+4*d);
   TrailStepUp.Text("+");
   TrailStepDown.Create(0,"StepDown",0,x+w+40,h+3*d,x+w+50,h+4*d);
   TrailStepDown.Text("-");

   btnMoveUpDown.Create(0,"Move Panel",0,x+2*w,h+3*d,x+3*w,h+4*d);
   btnMoveUpDown.Text("--");
   CheckRecover.Create(0,"CRecover",0,x,h+4*d,x+w,h+5*d);
   CheckRecover.Text("Recover");
   CheckStopForToday.Create(0,"CStop",0,x+w, h+4*d,x+2*w,h+5*d);
   CheckStopForToday.Text("StopToday");


//--- create application dialog


//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void MovePanelUp()
  {

   ObjectSetInteger(0, BTN_BUY_NAME, OBJPROP_YDISTANCE, x);

   ObjectSetInteger(0, BTN_SELL_NAME, OBJPROP_YDISTANCE, x);
   ObjectSetInteger(0,BTN_CLOSEALL_NAME,OBJPROP_YDISTANCE,x);
   ObjectSetInteger(0,"Edit Magic",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Magic Up",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Magic down",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Profit",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Profit Up",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Profit Down",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Edit Lotsize",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Lotsize Up",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Lotsize Down",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Hedge",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"Close Magic",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"Edit LotsizeToClose",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"LotsizeToClose Up",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"LotsizeToClose Down",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"Move Panel",OBJPROP_YDISTANCE,x+3*d);
   ObjectSetInteger(0,"TrailUp",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"TrailStart",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"TrailDown",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"TrailStep",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"StepUp",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"StepDown",OBJPROP_YDISTANCE,h+3*d);


  }
void MovePanelDown()

  {

   long result1=0;
   int dis=120;
   ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0,result1);

   ObjectSetInteger(0, BTN_BUY_NAME, OBJPROP_YDISTANCE, result1-dis);
   ObjectSetInteger(0, BTN_SELL_NAME, OBJPROP_YDISTANCE, result1-dis);
   ObjectSetInteger(0,BTN_CLOSEALL_NAME,OBJPROP_YDISTANCE,result1-dis);
   ObjectSetInteger(0,"Edit Magic",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Magic Up",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Magic down",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Profit",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Profit Up",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Profit Down",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Edit Lotsize",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Lotsize Up",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Lotsize Down",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Hedge",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"Close Magic",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"Edit LotsizeToClose",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"LotsizeToClose Up",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"LotsizeToClose Down",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"Move Panel",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"TrailUp",OBJPROP_YDISTANCE,result1-dis+3*d);

   ObjectSetInteger(0,"TrailStart",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"TrailDown",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"TrailStep",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"StepUp",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"StepDown",OBJPROP_YDISTANCE,result1-dis+3*d);
  }


//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
   ObjectsDeleteAll(0,0,-1);

  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,
                  const long &lparam,
                  const double &dparam,
                  const string &sparam)

  {
   if(!MQLInfoInteger(MQL_TESTER))
     {
      ButtonHandler();

     }

  }



//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ReadParameters()
  {
   Magic=StringToInteger(ObjectGetString(0,"Edit Magic",OBJPROP_TEXT));
   Lotsize=StringToDouble(ObjectGetString(0,"Edit Lotsize",OBJPROP_TEXT));
  }


//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnTick()
  {
   static datetime dtBarCurrent  = WRONG_VALUE;
   datetime dtBarPrevious = dtBarCurrent;
   dtBarCurrent  = iTime(_Symbol, _Period, 0);
   bool     bNewBarEvent  = (dtBarCurrent != dtBarPrevious);
   if(MQLInfoInteger(MQL_TESTER))
      ButtonHandler();
//OrderList();
// CheckForTrail();
//trailing stop
   MqlDateTime rightNow;
   TimeCurrent(rightNow);
   orderManager.TrailTrades(Magic,true,true,ProfitTaget,LotsizeToClose,ProfitTaget,StringToDouble(ObjectGetString(0,"TrailStep",OBJPROP_TEXT,0)),StringToDouble(ObjectGetString(0,"TrailStart",OBJPROP_TEXT,0)));

   if(orderManager.RelativeProfitOnMagic(Magic,Lotsize,lossprofit,LotsizeToClose,lasthedge,false,false)<-totallossprofit)

     {
      orderManager.CloseTrades(0,true,true,0);
      //CheckStopForToday.Checked(true);
      CheckRecover.Checked(false);
      /* if(Magic>1)
          printf("magic");
       orderManager.HedgePositions(Magic);
       Lotsize=2*Lotsize;
       lossprofit=2*lossprofit;
       totallossprofit=2*totallossprofit;
       if(Lotsize>SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX))
          Lotsize+SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX);
       LotsizeToClose=NormalizeDouble(Lotsize/2,2);
       ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(Lotsize));
       Magic=Magic+1;
       ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));
       //orderManager.FirstOrder(Magic,Lotsize);
       lasthedge=TimeCurrent();*/
     }

   if(bNewBarEvent)
     {
      // Detect if this is the first tick received and handle it.
      /* For example, when it is first attached to a chart and
         the bar is somewhere in the middle of its progress and
         it's not actually the start of a new bar. */
      if(dtBarPrevious == WRONG_VALUE)
        {
         // Do something on first tick or middle of bar ...
        }
      else
        {
         if(true)
           {
            if(((PositionsTotal()==0)&&  rightNow.hour>8 && rightNow.hour<22)&& !CheckStopForToday.Checked())
              {
               CheckRecover.Checked(false);
               lossprofit=-1.5;
               totallossprofit=40;
               Magic=1;
               oldmagic=1;
               Lotsize=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN);
               LotsizeToClose=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN);
               ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));
               orderManager.FirstOrder(Magic,Lotsize);
               lasthedge=TimeCurrent();
              }

            if(rightNow.hour<8 || rightNow.hour>22)
              {
               CheckRecover.Checked(false);
               CheckStopForToday.Checked(false);
              }
            if(!CheckStopForToday.Checked())
               orderManager.RelativeProfitOnMagic(Magic,Lotsize,lossprofit,LotsizeToClose,lasthedge,true,CheckRecover.Checked());

           }

        };

      // Do something irrespective of the above condition ...
     }
   else
     {
      // Do something else ...
     };





  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void ButtonHandler()
  {

   double oldprofittarge=ProfitTaget;
   double oldlotstoclose=LotsizeToClose;
   double start = StringToDouble(ObjectGetString(0,"TrailStart",OBJPROP_TEXT,0)),
          step = StringToDouble(ObjectGetString(0,"TrailStep",OBJPROP_TEXT,0));

   if(TrailStartUp.Pressed())
     {
      start=start+0.1;
      ObjectSetString(0,"TrailStart",OBJPROP_TEXT,DoubleToString(start,1));
      TrailStartUp.Pressed(false);
     }

   if(TrailStartDown.Pressed())
     {
      if(start > 0)
         start=start-0.1;
      ObjectSetString(0,"TrailStart",OBJPROP_TEXT,DoubleToString(start,1));
      TrailStartDown.Pressed(false);
     }

   if(TrailStepUp.Pressed())
     {
      step=step+0.1;
      ObjectSetString(0,"TrailStep",OBJPROP_TEXT,DoubleToString(step,1));
      TrailStepUp.Pressed(false);
     }

   if(TrailStepDown.Pressed())
     {
      if(step > 0)
         step=step-0.1;
      ObjectSetString(0,"TrailStep",OBJPROP_TEXT,DoubleToString(step,1));
      TrailStepDown.Pressed(false);
     }

   if(btnMagicUp.Pressed())
     {
      oldmagic=Magic;
      Magic=Magic+1;
      ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));

      btnMagicUp.Pressed(false);
     }

   if(btnMagicDown.Pressed())
     {
      Magic=Magic-1;
      ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));
      btnMagicDown.Pressed(false);
     }

   if(btnBuy.Pressed())
     {
      orderManager.PlaceOrder(POSITION_TYPE_BUY, Lotsize, Magic,NULL);
      btnBuy.Pressed(false);
     }

   if(btnSell.Pressed())
     {
      orderManager.PlaceOrder(POSITION_TYPE_SELL, Lotsize, Magic,NULL);
      btnSell.Pressed(false);
     }
   if(btnCloseAll.Pressed())
     {
      orderManager.CloseTrades(0,true,true,0);
      btnCloseAll.Pressed(false);
     }
   if(btnLotsizeDown.Pressed())
     {
      Lotsize=Lotsize-(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
      if(Lotsize<DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN)))
         Lotsize=DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
      ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(Lotsize));
      btnLotsizeDown.Pressed(false);
     }

   if(btnLotsizeUp.Pressed())
     {
      Lotsize=Lotsize+SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN);

      ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(Lotsize));

      btnLotsizeUp.Pressed(false);
     }


   if(btnLotsizeToCloseDown.Pressed())
     {
      LotsizeToClose=LotsizeToClose-(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
      if(LotsizeToClose<DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN)))
         LotsizeToClose=DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
      ObjectSetString(0,"Edit LotsizeToClose",OBJPROP_TEXT,DoubleToString(LotsizeToClose));

      btnLotsizeToCloseDown.Pressed(false);

     }

   if(btnLotsizeToCloseUp.Pressed())
     {
      LotsizeToClose=LotsizeToClose+(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));

      ObjectSetString(0,"Edit LotsizeToClose",OBJPROP_TEXT,DoubleToString(LotsizeToClose));

      btnLotsizeToCloseUp.Pressed(false);
     }

   if(btnProfitUp.Pressed())
     {
      ProfitTaget=ProfitTaget+0.1;

      ObjectSetString(0,"Profit",OBJPROP_TEXT,DoubleToString(ProfitTaget));

      btnProfitUp.Pressed(false);
     }
   if(btnProfitDown.Pressed())
     {
      ProfitTaget=ProfitTaget-0.3;

      ObjectSetString(0,"Profit",OBJPROP_TEXT,DoubleToString(ProfitTaget));

      btnProfitDown.Pressed(false);
     }

   if(btnCloseMagic.Pressed())
     {
      orderManager.CloseTrades(Magic,true,true,0,LotsizeToClose);

      btnCloseMagic.Pressed(false);
     }
   if(btnHedge.Pressed())
     {
      orderManager.HedgePositions(Magic);

      btnHedge.Pressed(false);
      Magic=Magic+1;
      ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));

     }
   if(Magic==0)
     {
      IndicatorRelease(MA_handle4);
     }
   if(((oldlotstoclose!=LotsizeToClose)||(oldmagic!=Magic)|| (oldprofittarge!=ProfitTaget)) && Magic!=0)
     {
      if(iUseIndicator)
        {
         IndicatorRelease(MA_handle4);
         MA_handle4=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_totalMagic",Magic,LotsizeToClose,ProfitTaget);
        }
      oldmagic=Magic;
     }

   if(btnMoveUpDown.Pressed())
     {
      if(PanelUp==true)
        {

         MovePanelDown();
         PanelUp=false;
        }
      else
        {
         MovePanelUp();
         PanelUp=true;


        }
      btnMoveUpDown.Pressed(false);
     }
   ChartRedraw(0);

  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OrderList()
  {
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      ulong PositionTicket = PositionGetTicket(i);
      if(PositionGetString(POSITION_SYMBOL) == _Symbol)
        {
         if(!InArray(PositionTicket))
            Save(PositionTicket);
        }
     }
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void Save(ulong t)
  {
   for(int i=0;i<ArraySize(TicketList);i++)
     {
      if(TicketList[i] == 0)
        {
         TicketList[i] = t;
         break;
        }
     }
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool InArray(ulong t)
  {
   for(int i=0;i<ArraySize(TicketList);i++)
     {
      if(TicketList[i] == t)
         return true;
     }
   return false;
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CheckForTrail()
  {
   double p = 0,
          start = StringToDouble(ObjectGetString(0,"TrailStart",OBJPROP_TEXT,0)),
          step = StringToDouble(ObjectGetString(0,"TrailStep",OBJPROP_TEXT,0));

   for(int i=0;i<ArraySize(TicketList);i++)
     {
      if(TicketList[i] != 0)
        {
         if(PositionSelectByTicket(TicketList[i]))
           {
            p = PositionGetDouble(POSITION_PROFIT);
            if(p >= start && p-step > Step[i])
               Step[i] = p-step;
            else
              {
               if(Step[i] != 0 && p <= Step[i])
                  trade.PositionClose(TicketList[i]);
              }
           }
         else
           {
            Step[i] = 0;
            TicketList[i] = 0;
           }
        }
     }
  }
//+------------------------------------------------------------------+
