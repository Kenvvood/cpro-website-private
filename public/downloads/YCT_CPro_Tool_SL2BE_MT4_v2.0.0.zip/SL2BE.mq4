//+------------------------------------------------------------------+
//|                                         CPro Tool SL2BE MT4                              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern string EnterBEPips = "Please Enter profit pips to move SL to BE.";
extern double BE_Pips = 30;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
   if(Symbol()=="USDJPY" || Symbol()=="EURJPY" || Symbol()=="GBPJPY")
      return(0);
   int type;
   int ticket;
   int total = OrdersTotal();
   double openPrice, stopPrice;
   for(int i=total-1;i>=0;i--)
   {
      for(int j=i;j>=0;j--)
      if(OrderSelect(i, SELECT_BY_POS))
      {
         ticket = OrderTicket();
         type = OrderType();
         openPrice = OrderOpenPrice();
         stopPrice = OrderStopLoss();
         if(type == OP_SELL && stopPrice > openPrice && Ask<= (openPrice-BE_Pips*0.0001) && OrderSymbol()==Symbol())
            OrderModify(ticket,OrderOpenPrice(),OrderOpenPrice(),OrderTakeProfit(),0,Red);
         else if(type == OP_BUY && stopPrice < openPrice && Bid>= (openPrice+BE_Pips*0.0001)&& OrderSymbol()==Symbol() )
            OrderModify(ticket,OrderOpenPrice(),OrderOpenPrice(),OrderTakeProfit(),0,Blue);
      }
   }
//----
   return(0);
  }
//+------------------------------------------------------------------+