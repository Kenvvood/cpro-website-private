//+------------------------------------------------------------------+
//|                                         CPro Tool MySystem MT4                           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

// USE ON 15 MINUTES
// With THESE PARAMETER ON EURUSD
//---- input parameters
extern double TakeProfit = 86;
extern double Lots = 8.3;
extern double StopLoss = 60;
extern double TrailingStop = 10;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int start()
  {
   double pos1pre, pos2cur, hzbul1, hzbul2, hzbear1, hzbear2;
   int cnt, ticket, total, TotalOpenOrders;
   hzbul1 = iBullsPower(NULL, 0, 13, PRICE_WEIGHTED, 1);
   hzbul2 = iBullsPower(NULL, 0, 13, PRICE_CLOSE, 0);
   hzbear1 = iBearsPower(NULL, 0, 13, PRICE_WEIGHTED, 1);
   hzbear2 = iBearsPower(NULL, 0, 13, PRICE_CLOSE, 0);
   pos1pre = ((hzbear1 + hzbul1) / 2);
   pos2cur = ((hzbear2 + hzbul2) / 2);
   total = OrdersTotal();
   if(pos1pre > pos2cur)
     {
       for(cnt = 0; cnt < total; cnt++)
         {
           OrderSelect(cnt, SELECT_BY_POS, MODE_TRADES);
           if(OrderType() <= OP_BUY && OrderSymbol()==Symbol())
             {
               if(Bid > (OrderSelect(cnt, OrderOpenPrice(), MODE_TRADES) + TrailingStop*Point))
                 {
                   OrderClose(OrderSelect(cnt, Symbol()), Lots, Bid, 3, Violet);
                 }
             }
         }
     }
   if(pos2cur < 0)
     {
       for(cnt = 0; cnt < total; cnt++)
         {
           OrderSelect(cnt, SELECT_BY_POS, MODE_TRADES);
           if(OrderType() <= OP_SELL && OrderSymbol() == Symbol())
             {
               if(Ask > (OrderSelect(cnt, OrderOpenPrice(), MODE_TRADES) - TrailingStop*Point))
                 {
                   OrderClose(OrderSelect(cnt, Symbol()), Lots, Ask, 3, Violet);
                 }
             }
         }
     }
   for(cnt = 0; cnt < total; cnt++)
     {
       if(OrderSymbol() == Symbol())
         {
           TotalOpenOrders = TotalOpenOrders + 1;
         }
     }
   if(OrdersTotal() < 1)
     {
       if(pos1pre > pos2cur && pos2cur > 0)
         {
           OrderSend(Symbol(), OP_SELL, Lots, Bid, 3, Bid + StopLoss*Point, 
                     Bid - TakeProfit*Point, NULL, 0, 0, Red);
         }
       if(pos2cur < 0)
         {
           OrderSend(Symbol(), OP_BUY, Lots, Ask, 3, Ask - StopLoss*Point, 
                     Ask + TakeProfit*Point, NULL, 0, 0, Red);
           TotalOpenOrders = 1;
         }
     }
//----
   return(0);
  }
//+------------------------------------------------------------------+