//+------------------------------------------------------------------+
//|                                         CPro Tool ListSignals MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//---------------------------------------------------------------------------------------------------------------------
// Script Setup
// Script inputs
   input string
      sFileName  = "SignalsData.csv",  // File name of CSV file
      sDelimeter = "\t",               // Delimeter character (default = TAB)
      sDecimal   = ",",                // Decimal character
      sDate      = "-";                // Date delimiter character
   input int
      nDigits    = 2;                  // Number of decimal digits for floating point numbers
// Declare list of properties to collect
   ENUM_SIGNAL_BASE_STRING g_eStringProperty[] =
      { SIGNAL_BASE_NAME, SIGNAL_BASE_AUTHOR_LOGIN, SIGNAL_BASE_BROKER, SIGNAL_BASE_BROKER_SERVER, SIGNAL_BASE_CURRENCY };
   ENUM_SIGNAL_BASE_INTEGER g_eDateProperty[] =
      { SIGNAL_BASE_DATE_PUBLISHED, SIGNAL_BASE_DATE_STARTED, SIGNAL_BASE_DATE_UPDATED };
   ENUM_SIGNAL_BASE_INTEGER g_eIntegerProperty[] =
      { SIGNAL_BASE_ID, SIGNAL_BASE_LEVERAGE, SIGNAL_BASE_PIPS, SIGNAL_BASE_RATING, SIGNAL_BASE_SUBSCRIBERS, SIGNAL_BASE_TRADES, SIGNAL_BASE_TRADE_MODE };
   ENUM_SIGNAL_BASE_DOUBLE g_eDoubleProperty[] =
      { SIGNAL_BASE_BALANCE, SIGNAL_BASE_EQUITY, SIGNAL_BASE_GAIN, SIGNAL_BASE_MAX_DRAWDOWN, SIGNAL_BASE_PRICE, SIGNAL_BASE_ROI };
// OnStart event handler
   void OnStart() {
      int nSinglsTotal = SignalBaseTotal();
      if( nSinglsTotal > 0 ) {
         int hSignalsFile=FileOpen( sFileName, FILE_WRITE | FILE_CSV | FILE_ANSI, "", CP_UTF8 );
         if( hSignalsFile != INVALID_HANDLE ) {
            FileWriteString( hSignalsFile, sField( "INDEX", false ) );
            for( int i = 0; i < ArraySize( g_eStringProperty ); i++ )
               FileWriteString( hSignalsFile, eField( g_eStringProperty[  i ] ) );
            for( int i2 = 0; i2 < ArraySize( g_eDateProperty ); i2++ )
               FileWriteString( hSignalsFile, eField( g_eDateProperty[    i2 ] ) );
            for( int i22 = 0; i22 < ArraySize( g_eIntegerProperty ); i22++ )
               FileWriteString( hSignalsFile, eField( g_eIntegerProperty[ i22 ] ) );
            for( int i23 = 0; i23 < ArraySize( g_eDoubleProperty ); i23++ )
               FileWriteString( hSignalsFile, eField( g_eDoubleProperty[  i23 ] ) );
            FileWriteString( hSignalsFile, "\n" );
            for( int j = 0; j < nSinglsTotal; j++ ) {
               if( SignalBaseSelect( j ) ) {
                  FileWriteString( hSignalsFile, (string) j );
                  for( int i22c = 0; i22c < ArraySize( g_eStringProperty ); i22c++ )
                     FileWriteString( hSignalsFile, sField( SignalBaseGetString(  g_eStringProperty[  i22c ] ) ) );
                  for( int i22d = 0; i22d < ArraySize( g_eDateProperty ); i22d++ )
                     FileWriteString( hSignalsFile, dtField( SignalBaseGetInteger( g_eDateProperty[   i22d ] ) ) );
                  for( int i22e = 0; i22e < ArraySize( g_eIntegerProperty ); i22e++ )
                     FileWriteString( hSignalsFile, lField( SignalBaseGetInteger( g_eIntegerProperty[ i22e ] ) ) );
                  for( int i22f = 0; i22f < ArraySize( g_eDoubleProperty ); i22f++ )
                     FileWriteString( hSignalsFile, dbField( SignalBaseGetDouble( g_eDoubleProperty[  i22f ] ) ) );
               };
               FileWriteString( hSignalsFile, "\n" );
            };
            FileClose( hSignalsFile );
         }
         else
            Print( "Invalid file handle!" );
      }
      else
         Print( "No Signals!" );
   };
// Supprt functions
   string sField(  string   sValue,  bool bDelimeter = true ) { return ( bDelimeter ? sDelimeter : "" ) + sValue; };
   string lField(  long     lValue,  bool bDelimeter = true ) { return sField( IntegerToString( lValue  ), bDelimeter ); };
   string dtField( datetime dtValue, bool bDelimeter = true ) {
      string sValue = TimeToString( dtValue );
      StringReplace( sValue, ".", sDate );
      return sField( sValue, bDelimeter ); };
   string dbField( double   dbValue, bool bDelimeter = true ) {
      string sValue = DoubleToString( dbValue, nDigits );
      StringReplace( sValue, ".", sDecimal );
      return sField( sValue, bDelimeter ); };
   template<typename T>
      string eField( T eValue,  bool bDelimeter = true ) {
         string sValue = EnumToString( eValue );
         StringReplace( sValue, "SIGNAL_BASE_", "" );
         return sField( sValue, bDelimeter ); };