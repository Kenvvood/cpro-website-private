//+------------------------------------------------------------------+
//|                                         CPro Tool closeorders MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
extern    double         inTargetProfitMoney     = 10;       //Target Profit ($)
extern    double         inCutLossMoney          = 0.0;      //Cut Loss ($)
extern    int            inMagicNumber           = 0;        //Magic Number
int      slippage    = 3;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   if(inTargetProfitMoney <= 0)
     {
      Alert("Invalid input");
      return(INIT_PARAMETERS_INCORRECT);
     }
   inCutLossMoney = MathAbs(inCutLossMoney) * -1;
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
   Print("Thank you for using this EA");
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
   double   tFloating = 0.0;
   int tOrder  = OrdersTotal();
   for(int i=tOrder-1; i>=0; i--)
     {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
        {
         if(OrderMagicNumber() == inMagicNumber)
           {
            tFloating   += OrderProfit()+OrderCommission() + OrderSwap();
           }
        }
     }
   if(tFloating >= inTargetProfitMoney || (tFloating <= inCutLossMoney && inCutLossMoney < 0))
     {
      fCloseAllOrders();
     }
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void fCloseAllOrders()
  {
   double   priceClose = 0.0;
   int tOrders = OrdersTotal();
   for(int i=tOrders-1; i>=0; i--)
     {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
        {
         if(OrderMagicNumber() == inMagicNumber && (OrderType() == OP_BUY || OrderType() == OP_SELL))
           {
            priceClose  = (OrderType()==OP_BUY)?MarketInfo(OrderSymbol(), MODE_BID):MarketInfo(OrderSymbol(), MODE_ASK);
            if(!OrderClose(OrderTicket(), OrderLots(), priceClose, slippage, clrGold))
              {
               Print("WARNING: Close Failed");
              }
           }
        }
     }
  }
//+------------------------------------------------------------------+