//+------------------------------------------------------------------+
//|                                         CPro Indicator Constant_Range_Channel MT4        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//---------------------------------------------------------------------------------------------------------------------
//--- Setup
   // Define number of buffers and plots
      #define MName     "Constant Range Channel"
      #define MPlots    3
      #define MBuffers  3
      #ifndef __MQL4__
      #else
      #endif
   // Display properties
      #define     MClrUpper         C'38, 166,154'
      #define     MClrMiddle        C'239,166,154'
      #define     MClrLower         C'239, 83, 80'
//--- Parameter settings
   input uint i_nStepTicks = 50;//channel 范围 步进 尺寸 (ticks)
//--- Macro definitions
   // Define OnCalculate loop sequencing macros
      #ifdef __MQL4__   // for MQL4 (as series)
         #define MOnCalcNext(  _index          ) ( _index--             )
         #define MOnCalcBack(  _index, _offset ) ( _index + _offset     )
         #define MOnCalcCheck( _index          ) ( _index >= 0          )
         #define MOnCalcValid( _index          ) ( _index < rates_total )
         #define MOnCalcStart \
            ( rates_total - ( prev_calculated < 1 ? 1 : prev_calculated ) )
      #else             // for MQL5 (as non-series)
         #define MOnCalcNext(  _index          ) ( _index++             )
         #define MOnCalcBack(  _index, _offset ) ( _index - _offset     )
         #define MOnCalcCheck( _index          ) ( _index < rates_total )
         #define MOnCalcValid( _index          ) ( _index >= 0          )
         #define MOnCalcStart \
            ( prev_calculated < 1 ? 0 : prev_calculated - 1 )
      #endif
   // Define macro for invalid parameter values
      #define MCheckParameter( _condition, _text ) if( _condition ) \
         { Print( "Error: Invalid ", _text ); return INIT_PARAMETERS_INCORRECT; }
//--- Global variable declarations
   // Indicator buffers
      double
         g_dbStepRange,                // Channel range step size
         g_adbUpper[],                 // Buffer for channel's upper level
         g_adbMiddle[],                // Buffer for channel's middle level
         g_adbLower[];                 // Buffer for channel's lower level
//--- Event handling functions
   // Initialisation event handler
      int OnInit(void)
      {
         // Validate input parameters
   CPro_Init();  // CPro营销模块初始化
            MCheckParameter( i_nStepTicks < 1, "Range step size!" );
         // Set initial values
            g_dbStepRange = WRONG_VALUE;
         // Set number of significant digits (precision)
            IndicatorSetInteger( INDICATOR_DIGITS, _Digits );
         // Set buffers
            #ifdef __MQL4__
               IndicatorBuffers( MBuffers ); // Set total number of buffers (MQL4 Only)
            #endif
            int iBuffer = 0;
            SetIndexBuffer( iBuffer++, g_adbUpper,  INDICATOR_DATA );
            SetIndexBuffer( iBuffer++, g_adbMiddle, INDICATOR_DATA );
            SetIndexBuffer( iBuffer++, g_adbLower,  INDICATOR_DATA );
         // Set indicator name
            IndicatorSetString( INDICATOR_SHORTNAME,
               MName + "(" + (string) i_nStepTicks + ")" );
         return INIT_SUCCEEDED;  // Successful initialisation of indicator
      };
   // Calculation event handler
      int
         OnCalculate(
            const int      rates_total,
            const int      prev_calculated,
            const datetime &time[],
            const double   &open[],
            const double   &high[],
            const double   &low[],
            const double   &close[],
            const long     &tick_volume[],
            const long     &volume[],
            const int      &spread[]
         )
      {
         // Convert range step siz from ticks to price quote difference
            if( ( g_dbStepRange < 0 ) && ( rates_total > 0 ) )
            {
               double dbTickSize = WRONG_VALUE;
               if( SymbolInfoDouble( _Symbol, SYMBOL_TRADE_TICK_SIZE, dbTickSize ) && ( dbTickSize > 0 ) )
                  g_dbStepRange = dbTickSize * i_nStepTicks;
               else
                  return 0;
            };
         // Main loop — fill in the buffer arrays with data values
            for( int iCur  = MOnCalcStart, iPrev = MOnCalcBack( iCur, 1 );
                 !IsStopped() && MOnCalcCheck( iCur );
                 MOnCalcNext( iCur ), MOnCalcNext( iPrev ) )
            {
               // Calculate middle value
                  double dbLow    = low[  iCur ],
                         dbHigh   = high[ iCur ],
                         dbMiddle = MOnCalcValid( iPrev )
                                  ? ( dbLow  > g_adbUpper[ iPrev ] ? dbLow
                                    : dbHigh < g_adbLower[ iPrev ] ? dbHigh : g_adbMiddle[ iPrev ] )
                                  : close[ iCur ];
               // Set buffer values
                  g_adbMiddle[ iCur ] = dbMiddle;
                  g_adbUpper[  iCur ] = dbMiddle + g_dbStepRange;
                  g_adbLower[  iCur ] = dbMiddle - g_dbStepRange;
            };
         return rates_total;  // Return value for prev_calculated of next call
      };
//---------------------------------------------------------------------------------------------------------------------