//+------------------------------------------------------------------+
//|                                         CPro Indicator MACD_CW_Mashhadi MT5              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//+------------------------------------------------------------------+
//| Indicator inputs & global variables                              |
//+------------------------------------------------------------------+
input int                InpFastEMA=12;//快速 ema 周期 = 12
input int                InpSlowEMA=26;//止损ow ema 周期 = 26
input int                InpSignalSMA=9;//信号 sma 周期 = 9
input ENUM_APPLIED_PRICE InpAppliedPrice=PRICE_CLOSE;//applied 价格
double Fast_Slow_Buffer[];
double MACD_Buffer[];
double ExtMacdBuffer[];
double ExtSignalBuffer[];
double ExtFastMaBuffer[];
double ExtSlowMaBuffer[];
int ExtFastMaHandle;
int ExtSlowMaHandle;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,Fast_Slow_Buffer,INDICATOR_DATA);
   SetIndexBuffer(1,MACD_Buffer,INDICATOR_DATA);
   SetIndexBuffer(2,ExtMacdBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(3,ExtSignalBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(4,ExtFastMaBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(5,ExtSlowMaBuffer,INDICATOR_CALCULATIONS);
   PlotIndexSetInteger(1,PLOT_DRAW_BEGIN,InpSignalSMA-1);
   IndicatorSetString(INDICATOR_SHORTNAME,"MACD("+string(InpFastEMA)+","+string(InpSlowEMA)+","+string(InpSignalSMA)+")");
   ExtFastMaHandle=iMA(NULL,0,InpFastEMA,0,MODE_EMA,InpAppliedPrice);
   ExtSlowMaHandle=iMA(NULL,0,InpSlowEMA,0,MODE_EMA,InpAppliedPrice);
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Indicator "Calculate" event handler function                     |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime& time[],
                const double& open[],
                const double& high[],
                const double& low[],
                const double& close[],
                const long& tick_volume[],
                const long& volume[],
                const int& spread[])
  {
   CopyBuffer(ExtFastMaHandle,0,0,rates_total,ExtFastMaBuffer);
   CopyBuffer(ExtSlowMaHandle,0,0,rates_total,ExtSlowMaBuffer);
   // Indicator
   int ii;
   for(ii=0;ii<rates_total && !IsStopped();ii++)
     {
      ExtMacdBuffer[ii]=ExtFastMaBuffer[ii]-ExtSlowMaBuffer[ii];
      Fast_Slow_Buffer[ii]=EMPTY_VALUE;
      MACD_Buffer[ii]=EMPTY_VALUE;
     }
   // Reverse Indicator
   for(ii=1;ii<rates_total;ii++)
      Fast_Slow_Buffer[ii]=((1-2/((double)InpFastEMA+1))*ExtFastMaBuffer[ii-1]-(1-2/((double)InpSlowEMA+1))*ExtSlowMaBuffer[ii-1])/(2/((double)InpSlowEMA+1)-2/((double)InpFastEMA+1));
   // Indicator
   for(ii=0;ii<InpSignalSMA-1;ii++)
      ExtSignalBuffer[ii]=0;
   double firstValue=0;
   for(ii=0;ii<InpSignalSMA;ii++)
      firstValue+=ExtMacdBuffer[ii];
   firstValue/=InpSignalSMA;
   ExtSignalBuffer[InpSignalSMA-1]=firstValue;
   for(ii=InpSignalSMA;ii<rates_total;ii++)
      ExtSignalBuffer[ii]=ExtSignalBuffer[ii-1]+(ExtMacdBuffer[ii]-ExtMacdBuffer[ii-InpSignalSMA])/InpSignalSMA;
   // Reverse Indicator
   for(ii=InpSignalSMA;ii<rates_total;ii++)
      MACD_Buffer[ii]=Fast_Slow_Buffer[ii]-(InpSignalSMA*ExtSignalBuffer[ii-1]-ExtMacdBuffer[ii-InpSignalSMA])/(2/((double)InpSlowEMA+1)-2/((double)InpFastEMA+1))/(InpSignalSMA-1);
   return(rates_total);
  }