//+------------------------------------------------------------------+
//|                                         CPro Indicator MI MT5                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <MovingAverages.mqh>

//--- indicator settings
//--- input parametrs
input int InpPeriodEMA=9;//first ema 周期
input int InpSecondPeriodEMA=9;//second ema 周期
input int InpSumPeriod=25;//mass 周期
//--- indicator buffers
double    ExtHLBuffer[];
double    ExtEHLBuffer[];
double    ExtEEHLBuffer[];
double    ExtMIBuffer[];
int       ExtPeriodEMA;
int       ExtSecondPeriodEMA;
int       ExtSumPeriod;
//+------------------------------------------------------------------+
//| MI initialization function                                       |
//+------------------------------------------------------------------+
void OnInit()
  {
//--- check input variables
   CPro_Init();  // CPro营销模块初始化
   if(InpPeriodEMA<=0)
     {
      ExtPeriodEMA=9;
      PrintFormat("Incorrect value for input variable InpPeriodEMA=%d. Indicator will use value=%d for calculations.",
                  InpPeriodEMA,ExtPeriodEMA);
     }
   else
      ExtPeriodEMA=InpPeriodEMA;
   if(InpSecondPeriodEMA<=0)
     {
      ExtSecondPeriodEMA=9;
      PrintFormat("Incorrect value for input variable InpSecondPeriodEMA=%d. Indicator will use value=%d for calculations.",
                  InpSecondPeriodEMA,ExtSecondPeriodEMA);
     }
   else
      ExtSecondPeriodEMA=InpSecondPeriodEMA;
   if(InpSumPeriod<=0)
     {
      ExtSumPeriod=25;
      PrintFormat("Incorrect value for input variable PeriodSum=%d. Indicator will use value=%d for calculations.",
                  InpSumPeriod,ExtSumPeriod);
     }
   else
      ExtSumPeriod=InpSumPeriod;
//--- define buffers
   SetIndexBuffer(0,ExtMIBuffer);
   SetIndexBuffer(1,ExtEHLBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(2,ExtEEHLBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(3,ExtHLBuffer,INDICATOR_CALCULATIONS);
//--- number of digits of indicator value
   IndicatorSetInteger(INDICATOR_DIGITS,2);
//--- name for DataWindow and indicator subwindow label
   IndicatorSetString(INDICATOR_SHORTNAME,"Mass Index("+string(ExtPeriodEMA)+","+string(ExtSecondPeriodEMA)+","+string(ExtSumPeriod)+")");
   PlotIndexSetString(0,PLOT_LABEL,"MI("+string(ExtPeriodEMA)+","+string(ExtSecondPeriodEMA)+","+string(ExtSumPeriod)+")");
//--- indexes draw begin settings
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,ExtPeriodEMA+ExtSecondPeriodEMA+ExtSumPeriod-3);
  }
//+------------------------------------------------------------------+
//| Mass Index                                                       |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int pos_mi=ExtSumPeriod+ExtPeriodEMA+ExtSecondPeriodEMA-3;
   if(rates_total<pos_mi)
      return(0);
//--- start working
   int pos=prev_calculated-1;
//--- correct position
   if(pos<1)
     {
      ExtHLBuffer[0]=high[0]-low[0];
      pos=1;
     }
//--- main cycle
   for(int i=pos; i<rates_total && !IsStopped(); i++)
     {
      //--- fill main data buffer
      ExtHLBuffer[i]=high[i]-low[i];
      //--- calculate EMA values
      ExtEHLBuffer[i]=ExponentialMA(i,ExtPeriodEMA,ExtEHLBuffer[i-1],ExtHLBuffer);
      //--- calculate EMA on EMA values
      ExtEEHLBuffer[i]=ExponentialMA(i,ExtSecondPeriodEMA,ExtEEHLBuffer[i-1],ExtEHLBuffer);
      //--- calculate MI values
      double dtmp=0.0;
      if(i>=pos_mi)
        {
         for(int j=0; j<ExtSumPeriod; j++)
            if(ExtEEHLBuffer[i-j]!=0.0)
               dtmp+=ExtEHLBuffer[i-j]/ExtEEHLBuffer[i-j];
        }
      ExtMIBuffer[i]=dtmp;
     }
//--- OnCalculate done. Return new prev_calculated.
   return(rates_total);
  }
//+------------------------------------------------------------------+