//+------------------------------------------------------------------+
//|                                         CPro Indicator Amplitude MT5                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot amplitude
//--- plot High wick
//--- plot Low Wick
//--- plot Load balance
//--- plot Load balance of wicks
//--- plot candle direction
//--- plot position
//inputs
input double amplitudeUmbral = 0.5;
input double wickUmbral = 0.20;
input int loadBalanceBars = 2;
//--- indicator buffers
double         highWickBuffer[];
double         lowWickBuffer[];
double         amplitudeBuffer[];
double         loadBalanceBuffer[];
double         wickLoadBalanceBuffer[];
double         candleDirectionBuffer[];
double         positionBuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
//chart settings
   CPro_Init();  // CPro营销模块初始化
   ChartSetInteger(0,CHART_COLOR_BACKGROUND,0);
   ChartSetInteger(0, CHART_FOREGROUND,16777215);
   ChartSetInteger(0,CHART_COLOR_CHART_UP,7451452);
   ChartSetInteger(0,CHART_COLOR_CHART_DOWN,255);
   ChartSetInteger(0,CHART_COLOR_CANDLE_BULL,7451452);
   ChartSetInteger(0,CHART_COLOR_CANDLE_BEAR,255);
   ChartSetInteger(0,CHART_COLOR_CHART_LINE,65280);
   ChartSetInteger(0,CHART_COLOR_GRID,2697513);
   ChartSetInteger(0,CHART_SHIFT,1);
   ChartSetInteger(0,CHART_SHOW_ASK_LINE,1);
   ChartSetInteger(0,CHART_SHOW_BID_LINE,1);
   ChartSetInteger(0,CHART_SHOW_LAST_LINE,1);
   ChartSetInteger(0,CHART_SHOW_PERIOD_SEP,1);
   ArraySetAsSeries(amplitudeBuffer,true);
   ArraySetAsSeries(highWickBuffer,true);
   ArraySetAsSeries(lowWickBuffer,true);
   ArraySetAsSeries(loadBalanceBuffer,true);
   ArraySetAsSeries(wickLoadBalanceBuffer,true);
   ArraySetAsSeries(candleDirectionBuffer,true);
   ArraySetAsSeries(positionBuffer,true);
//--- indicator buffers mapping
   SetIndexBuffer(0,amplitudeBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,highWickBuffer,INDICATOR_DATA);
   SetIndexBuffer(2,lowWickBuffer,INDICATOR_DATA);
   SetIndexBuffer(3,loadBalanceBuffer,INDICATOR_DATA);
   SetIndexBuffer(4,wickLoadBalanceBuffer,INDICATOR_DATA);
   SetIndexBuffer(5,candleDirectionBuffer,INDICATOR_DATA);
   SetIndexBuffer(6,positionBuffer,INDICATOR_DATA);
//---
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
//---
//--- convert to series
   ArraySetAsSeries(open,true);
   ArraySetAsSeries(close,true);
   ArraySetAsSeries(high,true);
   ArraySetAsSeries(low,true);
   if(rates_total<loadBalanceBars)
      return(0);
   int forLength = rates_total - loadBalanceBars;
   for(int i=0; i<forLength && !IsStopped(); i++) {
      double amplitude = absDiffInPercent(open[i], close[i]);
      double highWick;
      double lowWick;
      if(open[i] > close[i]) {
         highWick = absDiffInPercent(open[i], high[i]);
         lowWick  = absDiffInPercent(close[i], low[i]);
      } else {
         highWick = absDiffInPercent(close[i], high[i]);
         lowWick  = absDiffInPercent(open[i], low[i]);
      }
      amplitudeBuffer[i] = amplitude;
      highWickBuffer[i] = highWick;
      lowWickBuffer[i] = lowWick;
      double loadBalanceTmp = 0;
      double wickLoadBalanceTmp = 0;
      double init = open[i];
      for(int j=i + 1 ; j <= i + loadBalanceBars; j++) {
         double absDiffInPercentTmp;
         if(high[j] > init) {
            loadBalanceTmp = loadBalanceTmp + absDiffInPercent(init, high[j]);
         }
         if(low[j] < init) {
            loadBalanceTmp = loadBalanceTmp -  absDiffInPercent(init, low[j]);
         }
         if(open[j] < close[j]) {
            wickLoadBalanceTmp = wickLoadBalanceTmp + (absDiffInPercent(close[j], high[j]) - absDiffInPercent(open[j], low[j]));
         } else {
            wickLoadBalanceTmp = wickLoadBalanceTmp + (absDiffInPercent(open[j], high[j]) - absDiffInPercent(close[j], low[j]));
         }
      }
      loadBalanceBuffer[i] = loadBalanceTmp;
      wickLoadBalanceBuffer[i] = wickLoadBalanceTmp;
      candleDirectionBuffer[i] = (open[i] < close[i]) ? 1 : -1;
      positionBuffer[i] = getPosition(i);
   }
//--- return value of prev_calculated for next call
   return(rates_total);
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double absDiffInPercent(const double initExtreme, const double endExtreme) {
   return MathAbs(((endExtreme - initExtreme) * 100) / initExtreme);
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int getPosition(int i) {
   if(amplitudeBuffer[i] <= amplitudeUmbral) {
      return 0;
   }
   if(candleDirectionBuffer[i] == 1) {
      if(highWickBuffer[i] >= wickUmbral) {
         return -1;
      } else {
         return 1;
      }
   }
   if(candleDirectionBuffer[i] == -1 ) {
      if(lowWickBuffer[i] >= wickUmbral) {
         return 1;
      } else {
         return -1;
      }
   }
   return 0;
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+