//+------------------------------------------------------------------+
//|                                         CPro Indicator peterthomet_Auto_Trendlines_autotrendlines MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//---
//---
enum ENUM_LINE_TYPE {
   EXM_EXM,    // 1: By 2 extremums
   EXM_DELTA   // 2: Extremum and delta
};
//+------------------------------------------------------------------+
//| Class CPoint                                                     |
//+------------------------------------------------------------------+
class CPoint {
   private:
      double price;
      datetime time;
   public:
      CPoint();
      CPoint(const double p, const datetime t);
      ~CPoint() {};
      void setPoint(const double p, const datetime t);
      bool operator==(const CPoint &other) const;
      bool operator!=(const CPoint &other) const;
      void operator=(const CPoint &other);
      double getPrice() const;
      datetime getTime() const;
};
//---
CPoint::CPoint(void) {
   price = 0;
   time = 0;
}
//---
CPoint::CPoint(const double p, const datetime t) {
   price = p;
   time = t;
}
//---
void CPoint::setPoint(const double p, const datetime t) {
   price = p;
   time = t;
}
//---
bool CPoint::operator==(const CPoint &other) const {
   return price == other.price && time == other.time;
}
//---
bool CPoint::operator!=(const CPoint &other) const {
   return !operator==(other);
}
//---
void CPoint::operator=(const CPoint &other) {
   price = other.price;
   time = other.time;
}
//---
double CPoint::getPrice(void) const {
   return(price);
}
//---
datetime CPoint::getTime(void) const {
   return(time);
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
CPoint curLeftSup, curRightSup, curLeftRes, curRightRes, nullPoint;
//+------------------------------------------------------------------+
//| input parameters                                                 |
//+------------------------------------------------------------------+
input ENUM_LINE_TYPE InpLineType = EXM_DELTA;//line 类型
input int            InpLeftExmSide = 20;//left extremum side (类型 1, 2)
input int            InpRightExmSide = 3;//right extremum side (类型 1)
input int            InpFromCurrent = 3;//偏移 from the current barŕ (类型 2)
input bool           InpPrevExmBar = false;//account for the bar before the extremum (类型 2)
//---
input int            InpLinesWidth = 1;//lines 宽度
input color          InpSupColor = C'255,121,194';//support line 颜色
input color          InpResColor = C'70,209,255';//resistance line 颜色
input string         InstanceName = "AutoTrendLines1";//instance 名称
//--- global variables
int            minRequiredBars;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
//---
   CPro_Init();  // CPro营销模块初始化
   minRequiredBars = InpLeftExmSide * 2 + MathMax(InpRightExmSide, InpFromCurrent) * 2;
//--- indicator buffers mapping
//---
   return(0);
}
//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
   CPro_Deinit();  // CPro营销模块清理
//---
   ObjectsDeleteAll(0, InstanceName);
//---
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
//---
   int leftIndex, rightIndex;
   double delta, tmpDelta;
//---
   if ( rates_total < minRequiredBars ) {
      Print("Not enough data to calculate");
      return(0);
   }
//---
   if ( prev_calculated != rates_total ) {
      switch ( InpLineType ) {
         case EXM_DELTA:
            //--- Support Left Point
            leftIndex = rates_total - InpLeftExmSide - 2;
            for ( ; !isLowestLow(leftIndex, InpLeftExmSide, low) && leftIndex > minRequiredBars; leftIndex-- );
            curLeftSup.setPoint(low[leftIndex], time[leftIndex]);
            //--- Support Right Point
            rightIndex = rates_total - InpFromCurrent - 2;
            delta = (low[rightIndex] - low[leftIndex]) / (rightIndex - leftIndex);
            if ( !InpPrevExmBar ) {
               leftIndex += 1;
            }
            for ( int tmpIndex = rightIndex - 1; tmpIndex > leftIndex; tmpIndex-- ) {
               tmpDelta = (low[tmpIndex] - curLeftSup.getPrice()) / (tmpIndex - leftIndex);
               if ( tmpDelta < delta ) {
                  delta = tmpDelta;
                  rightIndex = tmpIndex;
               }
            }
            curRightSup.setPoint(low[rightIndex], time[rightIndex]);
            //--- Resistance Left Point
            leftIndex = rates_total - InpLeftExmSide - 2;
            for ( ; !isHighestHigh(leftIndex, InpLeftExmSide, high) && leftIndex > minRequiredBars; leftIndex-- );
            curLeftRes.setPoint(high[leftIndex], time[leftIndex]);
            //--- Resistance Right Point
            rightIndex = rates_total - InpFromCurrent - 2;
            delta = (high[leftIndex] - high[rightIndex]) / (rightIndex - leftIndex);
            if ( !InpPrevExmBar ) {
               leftIndex += 1;
            }
            for ( int tmpIndex = rightIndex - 1; tmpIndex > leftIndex; tmpIndex-- ) {
               tmpDelta = (curLeftRes.getPrice() - high[tmpIndex]) / (tmpIndex - leftIndex);
               if ( tmpDelta < delta ) {
                  delta = tmpDelta;
                  rightIndex = tmpIndex;
               }
            }
            curRightRes.setPoint(high[rightIndex], time[rightIndex]);
            //---
            break;
         case EXM_EXM:
         default:
            //--- Support Right Point
            rightIndex = rates_total - InpRightExmSide - 2;
            for ( ; !isLowestLow(rightIndex, InpRightExmSide, low) && rightIndex > minRequiredBars; rightIndex-- );
            curRightSup.setPoint(low[rightIndex], time[rightIndex]);
            //--- Support Left Point
            leftIndex = rightIndex - InpRightExmSide;
            for ( ; !isLowestLow(leftIndex, InpLeftExmSide, low) && leftIndex > minRequiredBars; leftIndex-- );
            curLeftSup.setPoint(low[leftIndex], time[leftIndex]);
            //--- Resistance Right Point
            rightIndex = rates_total - InpRightExmSide - 2;
            for ( ; !isHighestHigh(rightIndex, InpRightExmSide, high) && rightIndex > minRequiredBars; rightIndex-- );
            curRightRes.setPoint(high[rightIndex], time[rightIndex]);
            //--- Resistance Left Point
            leftIndex = rightIndex - InpRightExmSide;
            for ( ; !isHighestHigh(leftIndex, InpLeftExmSide, high) && leftIndex > minRequiredBars; leftIndex-- );
            curLeftRes.setPoint(high[leftIndex], time[leftIndex]);
            //---
            break;
      }
      //--- Draw Support & Resistance
      if ( curLeftSup != nullPoint && curRightSup != nullPoint ) {
         drawLine("Current_Support", curRightSup, curLeftSup, InpSupColor);
      }
      if ( curLeftRes != nullPoint && curRightRes != nullPoint ) {
         drawLine("Current_Resistance", curRightRes, curLeftRes, InpResColor);
      }
   }
//--- return value of prev_calculated for next call
   return(rates_total);
}
//+------------------------------------------------------------------+
//| The Local Low search function                                    |
//+------------------------------------------------------------------+
bool isLowestLow(int bar, int side, const double &Low[]) {
//---
   for ( int i = 1; i <= side; i++ ) {
      if ( Low[bar] > Low[bar-i] || Low[bar] > Low[bar+i] ) {
         return(false);
      }
   }
//---
   return(true);
}
//+------------------------------------------------------------------+
//| The Local High search function                                   |
//+------------------------------------------------------------------+
bool isHighestHigh(int bar, int side, const double &High[]) {
//---
   for ( int i = 1; i <= side; i++ ) {
      if ( High[bar] < High[bar-i] || High[bar] < High[bar+i] ) {
         return(false);
      }
   }
//---
   return(true);
}
//+------------------------------------------------------------------+
//| Draw trend line function                                         |
//+------------------------------------------------------------------+
void drawLine(string name, CPoint &right, CPoint &left, color clr) {
   name = InstanceName + "-" + name;
   ObjectDelete(0, name);
   ObjectCreate(0, name, OBJ_TREND, 0, right.getTime(), right.getPrice(), left.getTime(), left.getPrice());
   ObjectSetInteger(0, name, OBJPROP_WIDTH, InpLinesWidth);
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_RAY_LEFT, true);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, true);
//---
}
//+------------------------------------------------------------------+