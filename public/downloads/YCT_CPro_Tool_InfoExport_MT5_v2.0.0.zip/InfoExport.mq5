//+------------------------------------------------------------------+
//|                                         CPro Tool InfoExport MT5                         |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <Trade\TerminalInfo.mqh>
#include <Trade\AccountInfo.mqh>
#include <Trade\DealInfo.mqh>
#include <Trade\HistoryOrderInfo.mqh>
#include <Generic\HashMap.mqh>

input group "choose to export terminal info";
input bool exportTerminalInformations = false;//export terminal infor均线tions?
input string terminalInfoName = "Terminal_Info";//terminal info file or sheet 名称
input group "choose to export history deals";
input bool exportHistoricalDeals = false;//export historical 成交s?
input string historyDealsName = "History_Deals";//历史 deals file or sheet 名称
input group "choose to export history orders";
input bool exportHistoricalOrders = false;//export historical 订单s?
input string historyOrdersName = "History_Orders";//历史 orders file or sheet 名称
input group "choose to export account info";
input bool exportAccountInfos = false;//export account infor均线tions?
input string accountInfoName = "Account_Info";//ac数量 info file or sheet 名称
input group "output to file";
input bool doYouWantToWriteToFile = false; // do you want to write to file?
input group "send email";
input bool doYouWantToSendEmail = false;//do you want to send infor均线tions to e均线il?
input group "output to Google Sheet";
input bool doYouWantToExportToGoogleSheet = false; //do you want to export to Google sheet?
input string appsScriptUrl = "Please enter the apps script url here"; //Apps Script deployed url
CHashMap<int, string> codePageLanguage;
// storing code page language number to code in hashmap
void initiateCodePageLanguage() {
   codePageLanguage.Add(0, "CP_ACP");
   codePageLanguage.Add(1, "CP_OEMCP");
   codePageLanguage.Add(2, "CP_MACCP");
   codePageLanguage.Add(3, "CP_THREAD_ACP");
   codePageLanguage.Add(42, "CP_SYMBOL");
   codePageLanguage.Add(65000, "CP_UTF7");
   codePageLanguage.Add(65001, "CP_UTF8");
}
string GetTerminalInfo() {
   initiateCodePageLanguage();
   string terminalCodePageLang;
   CTerminalInfo terminalInfo;
   bool terminalCodePageLangFound = codePageLanguage.TryGetValue(terminalInfo.CodePage(), terminalCodePageLang);
   string terminal_infos = "Terminal_Infos; Values\n";
   string terminalInformations = StringFormat(
      "build number; %d\n" +
      "trade server connected; %s\n" +
      "DLLs are allowed; %s\n" + 
      "trading enabled; %s\n" +
      "email enabled; %s\n" + 
      "ftp enabled; %s\n" +
      "max bars allowed in chart; %d\n" +
      "code page language; %s\n" +
      "cpu cores used; %d\n" +
      "physical memory; %d MB\n" +
      "memory available; %d MB\n" +
      "memory used; %d MB\n" +
      "memory total; %d MB\n" +
      "system is x64; %s\n" +
      "OpenCl version; %s\n" +
      "free disk space; %d MB\n" +
      "terminal language; %s\n" +
      "common data folder of all terminals, installed on the computer; %s\n" +
      "data folder of the terminal; %s\n" +
      "folder of the client terminal; %s\n" +
      "company name of the terminal; %s\n" +
      "name of the terminal; %s"
      ,
      terminalInfo.Build(),
      terminalInfo.IsConnected() ? "yes" : "no",
      terminalInfo.IsDLLsAllowed() ? "yes" : "no",
      terminalInfo.IsTradeAllowed() ? "yes" : "no",
      terminalInfo.IsEmailEnabled() ? "yes" : "no",
      terminalInfo.IsFtpEnabled() ? "yes" : "no",
      terminalInfo.MaxBars(),
      terminalCodePageLangFound ? terminalCodePageLang : "not found",
      terminalInfo.CPUCores(),
      terminalInfo.MemoryPhysical(),
      terminalInfo.MemoryAvailable(),
      terminalInfo.MemoryUsed(),
      terminalInfo.MemoryTotal(),
      terminalInfo.IsX64() ? "yes" : "no",
      terminalInfo.OpenCLSupport() == 0 ? "OpenCL not supported" : IntegerToString(terminalInfo.OpenCLSupport()),
      terminalInfo.DiskSpace(),
      terminalInfo.Language(),
      terminalInfo.CommonDataPath(),
      terminalInfo.DataPath(),
      terminalInfo.Path(),
      terminalInfo.Company(),
      terminalInfo.Name()
   );
   StringAdd(terminal_infos, terminalInformations);
   return terminal_infos;
}
string GetAccountInfo() {
   CAccountInfo accountInfo;
   string account_info = "symbol; name; currency; company; balance; credit; profit; equity; margin; " +
      "login; trade_mode; leverage; limit_orders; margin_mode\n";
   StringAdd(account_info, StringFormat(
      "%s; %s; %s; %s; %f; %f; %f; %f; %f; %d; %d; %d; %d; %d",
      Symbol(),
      accountInfo.Name(), accountInfo.Currency(), accountInfo.Company(),
      accountInfo.Balance(), accountInfo.Credit(), accountInfo.Profit(), accountInfo.Equity(), accountInfo.Margin(),
      accountInfo.Login(), accountInfo.TradeMode(), accountInfo.Leverage(), accountInfo.LimitOrders(),
      accountInfo.MarginMode()
   ));
   return account_info;
}
string GetHistoryDeals() {
   CDealInfo deal;
   HistorySelect(StringToTime("1970.01.01 09:00"), TimeCurrent());
   int totalDeals = HistoryDealsTotal();
   string deals = "ticket; symbol; time; price; profit; type; volume; comment; sl; tp; commission; " +
      "fee; order_id; position_id; magic\n";
   for(int i = 0; i < totalDeals; i++) {
      deal.SelectByIndex(i);
      ulong ticket = deal.Ticket();
      string dealInfo = StringFormat(
         "%d; %s; %s; %f; %f; %s; %d; %s; %f; %f; %f; %f; %d; %d; %d\n",
         ticket,
         deal.Symbol(),
         TimeToString(deal.Time()),
         deal.Price(),
         deal.Profit(),
         deal.Type() == 0 ? "buy" : "sell",
         deal.Volume(),
         deal.Comment(),
         HistoryDealGetDouble(ticket, DEAL_SL),
         HistoryDealGetDouble(ticket, DEAL_TP),
         HistoryDealGetDouble(ticket, DEAL_COMMISSION),
         HistoryDealGetDouble(ticket, DEAL_FEE),
         HistoryDealGetInteger(ticket, DEAL_ORDER),
         HistoryDealGetInteger(ticket, DEAL_POSITION_ID),
         HistoryDealGetInteger(ticket, DEAL_MAGIC)
      );
      StringAdd(deals, dealInfo);
   }
   return deals;
}
string GetHistoryOrders() {
   CHistoryOrderInfo order;
   HistorySelect(StringToTime("1970.01.01 09:00"), TimeCurrent());
   int totalOrders = HistoryOrdersTotal();
   string orders = "ticket; symbol; time; price; type; volume; comment; sl; tp; state; order_time_done; " +
      "order_expire; position_id; magic\n";
   for(int i = 0; i < totalOrders; i++) {
      order.SelectByIndex(i);
      ulong ticket = order.Ticket();
      string orderInfo = StringFormat(
         "%d; %s; %s; %f; %s; %d; %s; %f; %f; %d; %s; %s; %d; %d\n",
         ticket,
         order.Symbol(),
         TimeToString(order.TimeSetup()),
         order.PriceOpen(),
         order.Type() == 0 ? "buy" : "sell",
         order.VolumeInitial(),
         order.Comment(),
         order.StopLoss(),
         order.TakeProfit(),
         HistoryOrderGetInteger(ticket, ORDER_STATE),
         TimeToString(HistoryOrderGetInteger(ticket,ORDER_TIME_DONE)),
         TimeToString(HistoryOrderGetInteger(ticket, ORDER_TIME_EXPIRATION)),
         HistoryOrderGetInteger(ticket, ORDER_POSITION_ID),
         HistoryOrderGetInteger(ticket, ORDER_MAGIC)
      );
      StringAdd(orders, orderInfo);
   }
   return orders;
}
void WriteToFile(string terminalInfos, string historicalDeals, string historicalOrders, string accountInfos) {
   if(terminalInfos != NULL) {
      int fileHandler = FileOpen(terminalInfoName + ".csv", FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI);
      FileSeek(fileHandler, 0, SEEK_SET);
      FileWrite(fileHandler, terminalInfos);
      FileClose(fileHandler);
   }
   if(historicalDeals != NULL) {
      int fileHandler = FileOpen(historyDealsName + ".csv", FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI);
      FileSeek(fileHandler, 0, SEEK_SET);
      FileWrite(fileHandler, historicalDeals);
      FileClose(fileHandler);
   }
   if(historicalOrders != NULL) {
      int fileHandler = FileOpen(historyOrdersName + ".csv", FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI);
      FileSeek(fileHandler, 0, SEEK_SET);
      FileWrite(fileHandler, historicalOrders);
      FileClose(fileHandler);
   }
   if(accountInfos != NULL) {
      int fileHandler = FileOpen(accountInfoName + ".csv", FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI);
      FileSeek(fileHandler, 0, SEEK_SET);
      FileWrite(fileHandler, accountInfos);
      FileClose(fileHandler);
   }
}
void SendEmail(string terminalInfos, string historicalDeals, string historicalOrders, string accountInfos) {
   string emailSubject = NULL;
   string emailBody = NULL;
   if(terminalInfos != NULL) {
      emailSubject = AmmendEmailSubject(emailSubject, true, "Terminal Informations");
      emailBody = AmmendEmailBody(emailBody, "Terminal Informations", terminalInfos);
   }
   if(historicalDeals != NULL) {
      emailSubject = AmmendEmailSubject(emailSubject, emailSubject == NULL, "Historical Deals");
      emailBody = AmmendEmailBody(emailBody, "Historical Deals", historicalDeals);
   }
   if(historicalOrders != NULL) {
      emailSubject = AmmendEmailSubject(emailSubject, emailSubject == NULL, "Historical Orders");
      emailBody = AmmendEmailBody(emailBody, "Historical Orders", historicalOrders);
   }
   if(accountInfos != NULL) {
      emailSubject = AmmendEmailSubject(emailSubject, emailSubject == NULL, "Account Informations");
      emailBody = AmmendEmailBody(emailBody, "Account Informations", accountInfos);
   }
   if(!SendMail(emailSubject, emailBody)) {
      Alert("Email could not be sent with error code " + IntegerToString(GetLastError()));
   } 
}
string AmmendEmailSubject(string subject, bool first, string newSubject) {
   if(!first) {
      subject = subject + " and ";
   }
   StringAdd(subject, newSubject);
   return subject;
}
string AmmendEmailBody(string body, string category, string newBody) {
   body = "\n" + body + "\n" + category + "\n" + newBody + "\n";
   return body;
}
void WriteToGoogleSheet(string terminalInfos, string historicalDeals, string historicalOrders, string accountInfos) {
   if(terminalInfos != NULL) {
      StringReplace(terminalInfos, "\\", "/");
      SheetExporter(terminalInfoName, terminalInfos);
   }
   if(historicalDeals != NULL) {
      SheetExporter(historyDealsName, historicalDeals);
   }
   if(historicalOrders != NULL) {
      SheetExporter(historyOrdersName, historicalOrders);
   }
   if(accountInfos != NULL) {
      SheetExporter(accountInfoName, accountInfos);
   } 
}
void SheetExporter(string sheetName, string data) {
   string headers = "Content-Type: application/json\r\n";
   char postData[], result[];
   string responseHeaders;
   StringReplace(data, "\n", "#;#");
   StringReplace(data, "; ", "#:#");
   string jsonDataWithSheetName = StringFormat("{\"sheetName\": \"%s\", \"data\": \"%s\"}", sheetName, data);
   // Convert to char array
   StringToCharArray(jsonDataWithSheetName, postData, 0, StringLen(jsonDataWithSheetName), CP_UTF8);
   // Send POST request
   int res = WebRequest("POST", appsScriptUrl, headers, 5000, postData, result, responseHeaders);
   // Check response
   if(res != 200) {
     Alert("Account Infos not exported to Google Sheets returned error ", res, " and get last error is ", GetLastError());
   }
}
//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+
void OnStart()
  {
   string terminalInfos = NULL;
   string historicalDeals = NULL;
   string historicalOrders = NULL;
   string accountInfos = NULL;
   if(exportTerminalInformations) terminalInfos = GetTerminalInfo();
   if(exportHistoricalDeals) historicalDeals = GetHistoryDeals();
   if(exportHistoricalOrders) historicalOrders = GetHistoryOrders();
   if(exportAccountInfos) accountInfos = GetAccountInfo();
   Print(terminalInfos);
   if(doYouWantToWriteToFile) {
      WriteToFile(terminalInfos, historicalDeals, historicalOrders, accountInfos);
   }
   if(doYouWantToSendEmail) {
      SendEmail(terminalInfos, historicalDeals, historicalOrders, accountInfos);
   }
   if(doYouWantToExportToGoogleSheet) {
      WriteToGoogleSheet(terminalInfos, historicalDeals, historicalOrders, accountInfos);
   }
   if(!doYouWantToWriteToFile && !doYouWantToExportToGoogleSheet && !doYouWantToSendEmail) {
      //Alert("You forgot to enable one of the export options provided");
   }
  }
//+------------------------------------------------------------------+