//+------------------------------------------------------------------+
//|                                         CPro Tool CHO MT4                                |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern int       SlowPeriod=10;
extern int       FastPeriod=3;
extern int       TypeSmooth=0;// 0 - SMA, 1 - EMA
//---- buffers
double CHO[];
double AD[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int init()
  {
//---- indicators
   string name,smoothString;
   if (TypeSmooth<0 || TypeSmooth>1) TypeSmooth=0;
   if (TypeSmooth==0) smoothString="SMA"; else smoothString="EMA";
   name="Chaikin Oscillator("+SlowPeriod+","+FastPeriod+","+smoothString+")";
   IndicatorBuffers(2);
   SetIndexStyle(0,DRAW_LINE);
   SetIndexBuffer(0,CHO);
   SetIndexLabel(0,name);
   SetIndexEmptyValue(0,0.0);
   SetIndexBuffer(1,AD);
   SetIndexEmptyValue(1,0.0);
   IndicatorShortName(name);
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int start()
  {
   int    counted_bars=IndicatorCounted();
   int limit,i;
//----
   if (counted_bars<0) return(-1);
   if (counted_bars==0) 
      {
      limit=Bars-1;
      for (i=limit;i>=0;i--)
        {
         AD[i]=iAD(NULL,0,i);
        }
      for(i=limit-SlowPeriod;i>=0;i--)
        {
         CHO[i]=iMAOnArray(AD,0,FastPeriod,0,TypeSmooth,i)-iMAOnArray(AD,0,SlowPeriod,0,TypeSmooth,i);
        }
      }
   if (counted_bars>0) 
     {
      limit=Bars-counted_bars;
      for (i=limit;i>=0;i--)
        {
         AD[i]=iAD(NULL,0,i);
        }
      for(i=limit;i>=0;i--)
        {
         CHO[i]=iMAOnArray(AD,0,FastPeriod,0,TypeSmooth,i)-iMAOnArray(AD,0,SlowPeriod,0,TypeSmooth,i);
        }
      }            
//----
   return(0);
  }
//+------------------------------------------------------------------+