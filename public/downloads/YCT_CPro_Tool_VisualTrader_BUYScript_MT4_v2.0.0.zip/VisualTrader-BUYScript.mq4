//+------------------------------------------------------------------+
//|                                         CPro Tool VisualTrader_BUYScript MT4             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| script program start function                                    |
//+------------------------------------------------------------------+
extern double lot=0.1;
extern int SL=20;
extern int TP=40;
int start()
  {
//----
   string prefix="";
   if(IsTesting()) prefix="";
   if(!GlobalVariableCheck(prefix+"NewTrade")){
      GlobalVariableSet(prefix+"NewTrade","1");
      GlobalVariableSet(prefix+"NewTrade_mode",OP_BUY);
      GlobalVariableSet(prefix+"NewTrade_lot",lot);
      GlobalVariableSet(prefix+"NewTrade_tp",TP);
      GlobalVariableSet(prefix+"NewTrade_sl",SL);   
   }
//----
   return(0);
  }
//+------------------------------------------------------------------+