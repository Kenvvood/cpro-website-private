//+------------------------------------------------------------------+
//|                                         CPro EA nkanven_MQL4_Experts_Nkanven_LotCalTrader MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


#define KEY_B             66
#define KEY_S             83
//Parameters
//Enumerative for the base used for risk calculation
enum ENUM_RISK_BASE
  {
   RISK_BASE_EQUITY=1,        //EQUITY
   RISK_BASE_BALANCE=2,       //BALANCE
   RISK_BASE_FREEMARGIN=3,    //FREE MARGIN
   RISK_BASE_INPUT=4,         //INPUT BASE
  };
//Enumerative for the default risk type
enum ENUM_RISK_DEFAULT_TYPE
  {
   FIXED=1,      //FIXED
   Percent=2,       //AMOUNT BASE
  };
//Enumerative for the default risk size
enum ENUM_RISK_DEFAULT_SIZE
  {
   RISK_DEFAULT_FIXED=1,      //FIXED SIZE
   RISK_DEFAULT_AUTO=2,       //AUTOMATIC SIZE BASED ON RISK
  };
input ENUM_RISK_DEFAULT_SIZE InpRiskDefaultSize=RISK_DEFAULT_AUTO;//持仓 尺寸 模式
input double InpDefaultLotSize=0.01;//交易量 尺寸 if fixed 持仓 尺寸 模式 =  fixed
input ENUM_RISK_BASE InpRiskBase=RISK_BASE_BALANCE;//风险 base
input ENUM_RISK_DEFAULT_TYPE InpRiskDefaultType=FIXED;//风险 类型
input double InpFixRiskAmount=10;//max account 风险 ($) if 风险 类型 = fixed
input double InpMaxLossPercent=1.0;//max account 风险 (%)
input double InpTPMultiple=1;//止盈 multiple %
input double InpMinLotSize=0.01;//minimum 交易量 尺寸 allowed
input double InpMaxLotSize=100;//maximum 交易量 尺寸 allowed
input int InpSlippage=1;//滑点
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
string Symb = Symbol();
double RiskBaseAmount=InpFixRiskAmount;
double MaxRiskPerTrade=InpFixRiskAmount;                                    //Percentage To Risk Each Trade
double LotSize=InpDefaultLotSize;
double stopLoss=0.0;
double TakeProfit=0.0;
double risk=0.0;
double StoplossPips=0.0;
//TickValue is the value of the individual price increment for 1 lot of the instrument, expressed in the account currenty
double TickValue=SymbolInfoDouble(Symb,SYMBOL_TRADE_TICK_VALUE);
int ticket;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   CPro_Init();  // CPro营销模块初始化
   Print("The Expert Advisor with name ",MQLInfoString(MQL_PROGRAM_NAME)," is running");
//--- enable object create events
   ChartSetInteger(ChartID(),CHART_EVENT_OBJECT_CREATE,true);
//--- enable object delete events
   ChartSetInteger(ChartID(),CHART_EVENT_OBJECT_DELETE,true);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnTick()
  {
   stopLoss = NormalizeDouble(ObjectGetDouble(0, "sl", OBJPROP_PRICE), _Digits);
//Define the base for the risk calculation depending on the parameter chosen
   if(InpRiskBase==RISK_BASE_BALANCE)
      RiskBaseAmount=AccountInfoDouble(ACCOUNT_BALANCE);
   if(InpRiskBase==RISK_BASE_EQUITY)
      RiskBaseAmount=AccountInfoDouble(ACCOUNT_EQUITY);
   if(InpRiskBase==RISK_BASE_FREEMARGIN)
      RiskBaseAmount=AccountInfoDouble(ACCOUNT_FREEMARGIN);
   displayOnChart();
  }
//+------------------------------------------------------------------+
//| ChartEvent function                                              |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,         // Event identifier
                  const long& lparam,   // Event parameter of long type
                  const double& dparam, // Event parameter of double type
                  const string& sparam) // Event parameter of string type
  {
//--- the object has been deleted
   if(id==CHARTEVENT_OBJECT_DELETE)
     {
      Print("The object with name ",sparam," has been deleted");
     }
//--- the object has been created
   if(id==CHARTEVENT_OBJECT_CREATE)
     {
      Print("The object with name ",sparam," has been created");
     }
   /*--- the object has been moved or its anchor point coordinates has been changed
      if(id==CHARTEVENT_OBJECT_DRAG)
        {
         price = ObjectGetDouble(0, sparam, OBJPROP_PRICE, 0);
         //Print("The anchor point coordinates of the object with name ",sparam," has been changed. Price ", price);
         displayOnChart();
        }*/
   if(id==CHARTEVENT_KEYDOWN)
     {
      switch(lparam)
        {
         case  KEY_B:
            ///SendOrder(TRADE_ACTION_DEAL, ORDER_TYPE_BUY,Symb,last_tick.ask,price,LotSize);
            ticket = OrderSend(Symb, OP_BUY, LotSize, Ask, 1, stopLoss, TakeProfit);
            Alert("Buy " + (string)LotSize + " lot " + Symb + " at " + (string)Ask + " SL at " + (string)stopLoss);
            break;
         case  KEY_S:
            ticket = OrderSend(Symb, OP_SELL, LotSize, Bid, 1, stopLoss,TakeProfit);
            Alert("Sell " + (string)LotSize + " lot " + Symb + " at " + (string)Bid + " SL at " + (string)stopLoss);
            break;
         default:
            //Print("Do nothing");
            break;
        }
      if(ticket<=0)
        {
         int error=GetLastError();
         //---- not enough money
         //if(error==134);
         //---- 10 seconds wait
         Sleep(10000);
         //---- refresh price data
         RefreshRates();
        }
      else
        {
         OrderSelect(ticket,SELECT_BY_TICKET);
         OrderPrint();
        }
     }
  }
//Lot Size Calculator
void LotSizeCalculate(double sLoss)
  {
   double SL=0;
   double PriceAsk=MarketInfo(0,MODE_ASK);
   double PriceBid=MarketInfo(0,MODE_BID);
   double spread = MarketInfo(0,MODE_SPREAD) * _Point;
   double pipDiff = 0.0;
   if(sLoss < PriceAsk)
     {
      pipDiff = PriceAsk-sLoss;
      SL = pipDiff /_Point;
      //Print("TakeProfit ", TakeProfit, " PriceAsk ", PriceAsk, " pipDiff ", pipDiff, " InpTPMultiple ", InpTPMultiple, " spread ", spread);
      TakeProfit = PriceAsk + (pipDiff * InpTPMultiple) + (spread*2);
     }
   if(sLoss > PriceAsk)
     {
      pipDiff = sLoss-PriceBid;
      SL = pipDiff /_Point;
      //Print("TakeProfit ", TakeProfit, " PriceAsk ", PriceBid, " pipDiff ", pipDiff, " InpTPMultiple ", InpTPMultiple, " spread ", spread);
      TakeProfit = PriceBid - (pipDiff * InpTPMultiple) - (spread*2);
     }
   TakeProfit = NormalizeDouble(TakeProfit, _Digits);
//Print("Stop loss distance ", SL);
         StoplossPips = SL;
//If the position size is dynamic
   if(InpRiskDefaultSize==RISK_DEFAULT_AUTO)
     {
      //If the stop loss is not zero then calculate the lot size
      if(SL!=0)
        {
         //Calculate the Position Size
         LotSize=((RiskBaseAmount*MaxRiskPerTrade/100)/(SL*TickValue));
        }
     }
//Normalize the Lot Size to satisfy the allowed lot increment and minimum and maximum position size
   LotSize=MathFloor(LotSize/SymbolInfoDouble(Symb,SYMBOL_VOLUME_STEP))*SymbolInfoDouble(Symb,SYMBOL_VOLUME_STEP);
//Limit the lot size in case it is greater than the maximum allowed by the user
   if(LotSize>InpMaxLotSize)
      LotSize=InpMaxLotSize;
//Limit the lot size in case it is greater than the maximum allowed by the broker
   if(LotSize>SymbolInfoDouble(Symb,SYMBOL_VOLUME_MAX))
      LotSize=SymbolInfoDouble(Symb,SYMBOL_VOLUME_MAX);
//Print("Lot ", LotSize, " Max lot ", SymbolInfoDouble(Symb,SYMBOL_VOLUME_MAX));
//If the lot size is too small then set it to 0 and don't trade
   if(LotSize < SymbolInfoDouble(Symb,SYMBOL_VOLUME_MIN))
     {
      LotSize=0;
      //Print("Lot size too small");
     }
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void displayOnChart()
  {
   double initialLoss = (RiskBaseAmount * InpMaxLossPercent) / 100;
   if(InpRiskDefaultType == FIXED)
     {
      initialLoss = InpFixRiskAmount;
     }
   initialLoss = NormalizeDouble(initialLoss, 2);
   MaxRiskPerTrade = NormalizeDouble((initialLoss * 100) / RiskBaseAmount, 2);
   LotSizeCalculate(stopLoss);
//Comment("Lot size : ", LotSize);
   double StopAmount = StoplossPips * LotSize * TickValue;
   if(InpRiskDefaultSize == RISK_DEFAULT_FIXED)
     {
      MaxRiskPerTrade = NormalizeDouble((StopAmount * 100) / RiskBaseAmount, 2);
     }
   string text ="Lot size for "+ (string)DoubleToString(MaxRiskPerTrade,2) +"% = " + DoubleToString(LotSize,2) + " lot (" + DoubleToString(StopAmount, 2) + " " + AccountInfoString(ACCOUNT_CURRENCY) + ")";
   string name = "Lot";
   ObjectCreate(name, OBJ_LABEL, 0, 0, 0);
   ObjectSetText(name,text, 14, "Corbel Bold", YellowGreen);
   ObjectSet(name, OBJPROP_CORNER, CORNER_RIGHT_UPPER);
   ObjectSet(name, OBJPROP_XDISTANCE, 350);
   ObjectSet(name, OBJPROP_YDISTANCE, 10);
  }
//+------------------------------------------------------------------+