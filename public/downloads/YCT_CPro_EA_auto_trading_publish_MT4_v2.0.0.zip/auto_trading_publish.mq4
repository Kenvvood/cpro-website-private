//+------------------------------------------------------------------+
//|                                         CPro EA auto_trading_publish MT4                 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#include <WinUser32.mqh>

//#import "user32.dll"  // Uncomment This
int GetAncestor(int, int);
#define MT4_WMCMD_EXPERTS  33020 
#import
//extern bool Run=true;
input int            Start_Time     = 1;    //Start AutoTrade Time      
input int            Finish_Time    = 8;    //Stop AutoTrade Time 
int            start_Time;          
int            finish_Time;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   start_Time     = Start_Time;          
   finish_Time    = Finish_Time;
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  } 
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
//---
  //int main = GetAncestor(WindowHandle(Symbol(), Period()), 2/*GA_ROOT*/);   // Uncomment This
  int Current_Time = TimeHour(TimeCurrent());
   if (start_Time == Current_Time)
   {
     if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
     {
       //PostMessageA(main, WM_COMMAND,  MT4_WMCMD_EXPERTS, 0 ) ;  // Uncomment This        
     }
   }
   if (finish_Time == Current_Time)
   {
      if(TerminalInfoInteger(TERMINAL_TRADE_ALLOWED))
      {
        //PostMessageA(main, WM_COMMAND,  MT4_WMCMD_EXPERTS, 0 ) ;   // Uncomment This         
      }
   } 
   if(OrdersTotal()<1)                                                  // Remove this lines
   OrderSend(Symbol(),OP_SELL,1,Bid, 3,0,0,"Test ",111111,0,White);  // Remove this lines
}
//+------------------------------------------------------------------+