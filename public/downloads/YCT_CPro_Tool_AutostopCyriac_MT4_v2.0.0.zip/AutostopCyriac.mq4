//+------------------------------------------------------------------+
//|                                         CPro Tool AutostopCyriac MT4                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern string    AboutAutostop="Automatically sets take profit and stop loss calcul with inital cost on all trades multisymbol";
extern bool      MonitorTakeProfit=true;
extern bool      MonitorStopLoss=true;
extern double    TakeProfit=15;
extern double    StopLoss=20;
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
   int digits=MarketInfo("EURUSD",MODE_DIGITS);
   if(digits==5){int StopMultd=10;} else{StopMultd=1;}
   double TP=NormalizeDouble(TakeProfit*StopMultd,Digits);
   double SL=NormalizeDouble(StopLoss*StopMultd,Digits);
   double slb=0;
   double sls=0;
   double tpb=0;
   double tps=0;
//----
 //-------------------------------------------------------------------+
//Check open orders
//-------------------------------------------------------------------+
if(OrdersTotal()>0){
  for(int i=1; i<=OrdersTotal(); i++)          // Cycle searching in orders
     {
      if (OrderSelect(i-1,SELECT_BY_POS)==true) // If the next is available
        {
               TP=NormalizeDouble(TakeProfit*StopMultd,Digits);
               SL=NormalizeDouble(StopLoss*StopMultd,Digits);
               if((OrderType()==OP_BUY)&&((OrderTakeProfit()==0)))
                { 
                  slb=NormalizeDouble(OrderOpenPrice()-SL*Point,Digits);
                  tpb=NormalizeDouble(OrderOpenPrice()+TP*Point,Digits);
                  OrderModify(OrderTicket(),0,slb,tpb,0,CLR_NONE); 
                }
                if((OrderType()==OP_SELL)&&(OrderTakeProfit()==0))
                { 
                  sls=NormalizeDouble(OrderOpenPrice()+SL*Point,Digits);
                  tps=NormalizeDouble(OrderOpenPrice()-TP*Point,Digits);
                  OrderModify(OrderTicket(),0,sls,tps,0,CLR_NONE); 
                }
        }
     }
}
//----
int Error=GetLastError();
  if(Error==130){Alert("Wrong stops. Retrying."); RefreshRates();}
  if(Error==133){Alert("Trading prohibited.");}
  if(Error==2){Alert("Common error.");}
  if(Error==146){Alert("Trading subsystem is busy. Retrying."); Sleep(500); RefreshRates();}
//----
   return(0);
  }
//+------------------------------------------------------------------+