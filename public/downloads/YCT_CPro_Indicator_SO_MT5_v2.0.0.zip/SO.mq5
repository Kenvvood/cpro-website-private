//+------------------------------------------------------------------+
//|                                         CPro Indicator SO MT5                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- indicator settings
//--- input parameters
input int            InpMAperiod = 100;//moving 均值 周期
input ENUM_MA_METHOD InpMAmethod = MODE_SMA;//moving 均值 模式
input int            InpSPeriod  = 400;//backward-sampling 周期
//--- indicator buffers
double         AvgPosBuffer[];
double         AvgNegBuffer[];
double         SO[];
double         ExtMABuffer[];
double         Distance[];
//--- handles
int            ExtMAHandle;
//+------------------------------------------------------------------+
//| Speed Oscillator initialization function                         |
//+------------------------------------------------------------------+
void OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0, SO, INDICATOR_DATA);
   SetIndexBuffer(1, Distance, INDICATOR_DATA);
   SetIndexBuffer(2, AvgPosBuffer, INDICATOR_CALCULATIONS);
   SetIndexBuffer(3, AvgNegBuffer, INDICATOR_CALCULATIONS);
   SetIndexBuffer(4, ExtMABuffer, INDICATOR_CALCULATIONS);
//--- sets first bar from what index will be drawn
   PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, InpSPeriod);
//--- get MA handles
   ExtMAHandle = iMA(NULL, 0, InpMAperiod, 0, InpMAmethod, PRICE_CLOSE);
//--- name for DataWindow and indicator subwindow label
   PlotIndexSetString(0, PLOT_LABEL, "Speed(" + string(InpMAperiod) + ")");
   PlotIndexSetString(1, PLOT_LABEL, "Distance(%)");
   IndicatorSetString(INDICATOR_SHORTNAME, "SO(" + string(InpMAperiod) + ")");
//--- sets drawing line to empty value
   PlotIndexSetDouble (0, PLOT_EMPTY_VALUE ,0.0);
   PlotIndexSetDouble (1, PLOT_EMPTY_VALUE ,0.0);
  }
//+------------------------------------------------------------------+
//| Speed Oscillator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
//--- get ma buffers
   if(CopyBuffer(ExtMAHandle, 0, 0, rates_total-1, ExtMABuffer) <=0)
     {
      Print("not all MA copied. Will try on next tick Error =", GetLastError());
      return(0);
     }
   if(prev_calculated == 0)
     {
      ArrayInitialize(AvgPosBuffer, 0);
      ArrayInitialize(AvgNegBuffer, 0);
      ArrayInitialize(SO, 0);
     }
//--- SpeedOscillator
   int i;
   int pos_count = 0;
   int neg_count = 0;
   double pos_sum = 0;
   double neg_sum = 0;
   int j = 1;
//--- One-time calculations, all rates history.
   if(prev_calculated == 0)
     {
      for(i = InpSPeriod + 1; i < rates_total && !IsStopped(); i++)
        {
         pos_count = 0;
         neg_count = 0;
         pos_sum = 0;
         neg_sum = 0;
         j = i;       
         while((pos_count < InpSPeriod || neg_count < InpSPeriod) && j > 1)
           {
            j--;
            double diff = ExtMABuffer[j] - ExtMABuffer[j - 1];
            if(diff > 0 && pos_count < InpSPeriod)
              {
               pos_count++;
               pos_sum += diff;
              }
            if(diff < 0 && neg_count < InpSPeriod)
              {
               neg_count++;
               neg_sum += diff;
              }
           }
         AvgPosBuffer[i] = pos_sum / InpSPeriod;
         AvgNegBuffer[i] = neg_sum / InpSPeriod;
         if(ExtMABuffer[i] - ExtMABuffer[i - 1] > 0)
           {
            SO[i] = (ExtMABuffer[i] - ExtMABuffer[i - 1]) / AvgPosBuffer[i];
           }
         else
            if(ExtMABuffer[i] - ExtMABuffer[i - 1] < 0)
              {
               SO[i] = -((ExtMABuffer[i] - ExtMABuffer[i - 1]) / AvgNegBuffer[i]);
              }
            else
              {
               SO[i] = 0;
              }
         Distance[i] = ((close[i] - ExtMABuffer[i]) / close[i]) * 100;
        }
     }
//--- Main calculations, i.e. every tick thereafter, calculate current tick's values [rates_total-1]
   else
     {
      for(i = rates_total - 1; i < rates_total && !IsStopped(); i++)
        {
         pos_count = 0;
         neg_count = 0;
         pos_sum = 0;
         neg_sum = 0;
         j = i;
         while((pos_count < InpSPeriod || neg_count < InpSPeriod) && j > 1)
           {
            j--;
            double diff = ExtMABuffer[j] - ExtMABuffer[j - 1];
            if(diff > 0 && pos_count < InpSPeriod)
              {
               pos_count++;
               pos_sum += diff;
              }
            if(diff < 0 && neg_count < InpSPeriod)
              {
               neg_count++;
               neg_sum += diff;
              }
           }
         AvgPosBuffer[i] = pos_sum / InpSPeriod;
         AvgNegBuffer[i] = neg_sum / InpSPeriod;
         if(ExtMABuffer[i] - ExtMABuffer[i - 1] > 0)
           {
            SO[i] = (ExtMABuffer[i] - ExtMABuffer[i - 1]) / AvgPosBuffer[i];
           }
         else
            if(ExtMABuffer[i] - ExtMABuffer[i - 1] < 0)
              {
               SO[i] = -((ExtMABuffer[i] - ExtMABuffer[i - 1]) / AvgNegBuffer[i]);
              }
            else
              {
               SO[i] = 0;
              }
        }
     }
//--- always do current tick's distance
   Distance[rates_total - 1] = ((close[rates_total - 1] - ExtMABuffer[rates_total - 1]) / close[rates_total - 1]) * 100;
//--- return value of prev_calculated for next call
   return(rates_total);
  }
//+------------------------------------------------------------------+