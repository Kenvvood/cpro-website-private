//+------------------------------------------------------------------+
//|                                         CPro Indicator ICrossAverage MT5                 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <MovingAverages.mqh>

input int   FEMA = 16;
input int   MEMA = 26;
input int   SEMA = 34;
input int   N_CANDLES = 3;
double   bufferFEMA[];
double   bufferMEMA[];
double   bufferSEMA[];
double   trendBuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,trendBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,bufferFEMA,INDICATOR_CALCULATIONS);
   SetIndexBuffer(2,bufferMEMA,INDICATOR_CALCULATIONS);
   SetIndexBuffer(3,bufferSEMA,INDICATOR_CALCULATIONS);
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int ratesTotal, const int prevCalculated, const int begin, const double &price[]) {
   int start,i;
   ArraySetAsSeries(price, true);
   if(ratesTotal<SEMA) {
      return(0);
   }
   if(prevCalculated==0) {
      start=SEMA;
   } else {
      start=prevCalculated-1;
   }
   ExponentialMAOnBuffer(ratesTotal,prevCalculated,begin,FEMA,price,bufferFEMA);
   ExponentialMAOnBuffer(ratesTotal,prevCalculated,begin,MEMA,price,bufferMEMA);
   ExponentialMAOnBuffer(ratesTotal,prevCalculated,begin,SEMA,price,bufferSEMA);
   for(i=start; i<ratesTotal; i++) {
      trendBuffer[i]=0;
      int trend=trendDetector(i);
      if(isLastNCandlesTrendUp(price)) {
         trendBuffer[i]=1;
      } else if(isLastNCandlesDonw(price)) {
         trendBuffer[i]=-1;
      }
   }
   return(ratesTotal);
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool isLastNCandlesTrendUp(const double& price[]) {
   int priceSize = ArraySize(price);
   for(int i=0; i<=N_CANDLES; i++) {
      if(price[i+1]>=price[i+2]) {
         continue;
      } else return false;
   }
   return true;
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool isLastNCandlesDonw(const double& price[]) {
   int priceSize = ArraySize(price);
   for(int i=0; i<=N_CANDLES; i++) {
      if(price[i+1]<=price[i+2]) {
         continue;
      } else return false;
   }
   return true;
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int trendDetector(int position) {
   int trendDirection=0;
   if(bufferFEMA[position] > bufferMEMA[position] && bufferMEMA[position] > bufferSEMA[position]) {
      trendDirection=1;
   } else if(bufferFEMA[position] < bufferMEMA[position] && bufferFEMA[position] > bufferSEMA[position]) {
      trendDirection=-1;
   }
   return(trendDirection);
}
//int trendDetector(int position) {
//   int trendDirection=0;
//   if(bufferFEMA[position] > bufferMEMA[position] && bufferMEMA[position] > bufferSEMA[position]) {
//      trendDirection=1;
//   } else if(bufferFEMA[position] < bufferMEMA[position] && bufferFEMA[position] > bufferSEMA[position]) {
//      trendDirection=2;
//   } else if(bufferFEMA[position] < bufferMEMA[position] && bufferMEMA[position] < bufferSEMA[position]) {
//      trendDirection=-1;
//   } else if(bufferFEMA[position] > bufferMEMA[position] && bufferMEMA[position] < bufferSEMA[position]) {
//     trendDirection=-2;
//   }
//   return(trendDirection);
// }