//+------------------------------------------------------------------+
//|                                         CPro Tool MlrInfo MT5                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input int SetInterval=300; // Set interval in sec
input double Target=100; // Target in USD
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   CPro_Init();  // CPro营销模块初始化
   EventSetTimer(300);
//SendStatus();
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnTimer()
  {
   SendStatus();
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//---
 EventKillTimer();
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
  }
//+------------------------------------------------------------------+
void SendStatus() //The name of the function for sending account information
  {
// SendMail function
   double AccountBalance=AccountInfoDouble(ACCOUNT_BALANCE);
   double AccountEquity=AccountInfoDouble(ACCOUNT_EQUITY);
   double AccountProfit=AccountInfoDouble(ACCOUNT_PROFIT);
   double Remaining=Target-AccountBalance;
   double Hourly=0.20; //Project profit per hour
   double Time=Remaining/Hourly; //Calculate hours till target reachd
   string sp="|";
   string at="@"+Hourly+"c";
   string header=(AccountBalance+sp+AccountEquity+sp+AccountProfit+sp+Target+sp+Remaining+sp+int(Time)+sp+at);
   SendMail(header,"");
  }
//+------------------------------------------------------------------+