//+------------------------------------------------------------------+
//|                                         CPro EA smoothingaverage MT4                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//--- input parameters
input int      Period_MA=200;
input double      Risk=10;
input int      Smoothing=1400;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int CurrentOrder;
double MA;
double MA2;
double highpoint;
double Lots=(AccountEquity()*Point*Risk);
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   Print("You're gonna get bankrupt m8");
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
   Print(AccountEquity());
   Print(Lots);
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
   MA=iMA(NULL,0,Period_MA,0,MODE_SMA,PRICE_CLOSE,0);
   if(OrdersTotal()<1)
     {
      if(Bid<MA+Smoothing*Point)
        {;
         OrderSend(Symbol(),OP_SELL,Lots,Bid,10,0,0);
         CurrentOrder++;
           } else if(Ask>MA-Smoothing*Point){
         OrderSend(Symbol(),OP_BUY,Lots,Ask,10,0,0);
         CurrentOrder++;
        }
      OrderSelect(CurrentOrder,SELECT_BY_TICKET);
     }
   if(OrderType()==OP_SELL && Bid>MA+Smoothing*Point)
     {
      OrderClose(CurrentOrder,Lots,Ask,3,Red);
        } else if(OrderType()==OP_BUY && Ask<MA-Smoothing*Point){
      OrderClose(CurrentOrder,Lots,Bid,3,Red);
     }
  }
//+------------------------------------------------------------------+