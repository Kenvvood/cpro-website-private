//+------------------------------------------------------------------+
//|                                         CPro Tool closemaster MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//-------------------------------------------------------------------------
// Inputs
//-------------------------------------------------------------------------
input datetime CloseTime=D'2030.12.31';     //Close Date and Time
input bool DeletePO = true;                 //Delete Pending Orders
input bool CloseOO = true;                  //Close Open Orders
input bool CloseT = true;                   //Close Terminal
//-------------------------------------------------------------------------
// Variables
//-------------------------------------------------------------------------
int i,oo,po;
bool w;
//-------------------------------------------------------------------------
// 1. Main function
//-------------------------------------------------------------------------
void OnTick(void)
  {
   Comment("Copyright  2016, Il Anokhin\n"+TimeToStr(TimeCurrent(),TIME_DATE|TIME_SECONDS));
//--- 1.1. Deleting pending orders and closing open orders ----------------
   oo=0; po=0;
   for(i=OrdersTotal()-1;i>=0;i--)
     {
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)==true)
        {
         if(OrderType()==OP_BUY || OrderType()==OP_SELL) oo++;
         if(OrderType()==OP_BUYSTOP || OrderType()==OP_SELLSTOP) po++;
         if(OrderType()==OP_BUYLIMIT || OrderType()==OP_SELLLIMIT) po++;
         if(TimeCurrent()>=CloseTime && CloseOO==true && OrderType()==OP_BUY) w=OrderClose(OrderTicket(),OrderLots(),MarketInfo(OrderSymbol(),MODE_BID),90);
         if(TimeCurrent()>=CloseTime && CloseOO==true && OrderType()==OP_SELL) w=OrderClose(OrderTicket(),OrderLots(),MarketInfo(OrderSymbol(),MODE_ASK),90);
         if(TimeCurrent()>=CloseTime && DeletePO==true && OrderType()==OP_BUYSTOP) w=OrderDelete(OrderTicket());
         if(TimeCurrent()>=CloseTime && DeletePO==true && OrderType()==OP_SELLSTOP) w=OrderDelete(OrderTicket());
         if(TimeCurrent()>=CloseTime && DeletePO==true && OrderType()==OP_BUYLIMIT) w=OrderDelete(OrderTicket());
         if(TimeCurrent()>=CloseTime && DeletePO==true && OrderType()==OP_SELLLIMIT) w=OrderDelete(OrderTicket());
        }
     }
//--- 1.2. Removing Expert Advisor ----------------------------------------
   if(TimeCurrent()>=CloseTime && CloseT==true)
     {
      if(DeletePO==true && CloseOO==false && po==0) ExpertRemove();
      if(DeletePO==false && CloseOO==true && oo==0) ExpertRemove();
      if(DeletePO==true && CloseOO==true && oo==0 && po==0) ExpertRemove();
     }
//--- 1.3. End of main function -------------------------------------------
   return;
  }
//-------------------------------------------------------------------------
// 2. Deinitialization and Closing Terminal
//-------------------------------------------------------------------------
int deinit()
  {
   if(TimeCurrent()>=CloseTime && CloseT==true) TerminalClose(0);
   return(0);
  }
//-------------------------------------------------------------------------