//+------------------------------------------------------------------+
//| CProMT4Stub.mqh - MT4 stub                                        |
//+------------------------------------------------------------------+
#ifndef CPRO_MT4_STUB_MQH
#define CPRO_MT4_STUB_MQH
class CProMT4Stub { public: int dummy() { return 0; } };
#endif
