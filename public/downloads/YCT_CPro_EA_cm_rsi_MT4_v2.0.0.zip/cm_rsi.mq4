//+------------------------------------------------------------------+
//|                                         CPro EA cm_rsi MT4                               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//--------------------------------------------------------------------
extern int     period_RSI           = 14,
               stoploss             = 100,
               takeprofit           = 200,
               slippage             = 10,
               buy_level            = 30,
               sell_level           = 70,
               Magic                = 777;
extern double  Lot                  = 0.1;
//--------------------------------------------------------------------
void OnTick()
{
   for (int i=0; i<OrdersTotal(); i++)
      if (OrderSelect(i,SELECT_BY_POS,MODE_TRADES))
         if (OrderSymbol()==Symbol() && Magic==OrderMagicNumber()) return;
   double RSI0  = iRSI(NULL,0,period_RSI,PRICE_OPEN,0);
   double RSI1  = iRSI(NULL,0,period_RSI,PRICE_OPEN,1);
   double SL=0,TP=0;
   if (RSI0 > buy_level && RSI1 < buy_level)
   {
      if (takeprofit!=0) TP  = NormalizeDouble(Ask + takeprofit*Point,Digits);
      if (stoploss!=0)   SL  = NormalizeDouble(Ask - stoploss*  Point,Digits);     
      if (OrderSend(Symbol(),OP_BUY, Lot,NormalizeDouble(Ask,Digits),slippage,SL,TP,NULL,Magic)==-1) Print(GetLastError());
   }
   if (RSI0 < sell_level && RSI1 > sell_level)
   {
      if (takeprofit!=0) TP = NormalizeDouble(Bid - takeprofit*Point,Digits);
      if (stoploss!=0)   SL = NormalizeDouble(Bid + stoploss*  Point,Digits);            
      if (OrderSend(Symbol(),OP_SELL,Lot,NormalizeDouble(Bid,Digits),slippage,SL,TP,NULL,Magic)==-1) Print(GetLastError());
   }
}
//--------------------------------------------------------------------