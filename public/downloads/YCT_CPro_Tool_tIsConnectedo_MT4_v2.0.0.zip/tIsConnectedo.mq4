//+------------------------------------------------------------------+
//|                                         CPro Tool tIsConnectedo MT4                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

bool 		first					= true;
bool 		Now_IsConnected	= false;
bool 		Pre_IsConnected	= true;
datetime Connect_Start = 0, Connect_Stop = 0;
int init() { start(); return(0); }
int start()
{
	int handle = FileOpen( "_IsConnected.txt", FILE_WRITE | FILE_READ, " " );
	FileSeek( handle, 0, SEEK_END );
	FileWrite( handle, "- - - - - - - - - - - Expert initialized  - - - - - - - - - -" );
	while ( !IsStopped() )
	{
		Pre_IsConnected = Now_IsConnected;
		Now_IsConnected = IsConnected();
		if ( first ) { Pre_IsConnected = !Now_IsConnected; }
		if ( Now_IsConnected != Pre_IsConnected )
		{
			if ( Now_IsConnected )
			{
				Connect_Start = LocalTime();
				if ( !first )
				{
					FileSeek( handle, -55, SEEK_CUR );
					FileWrite( handle, "- - - OffLine- - -       " + TimeToStr( Connect_Stop, TIME_DATE ) + "       " + TimeToStr( Connect_Stop, TIME_SECONDS ) + " - " + TimeToStr( Connect_Start, TIME_SECONDS ) );
				}
				if ( IsStopped() ) { break; }
				FileWrite( handle, "+ + + OnLine + + +       " + TimeToStr( Connect_Start, TIME_DATE ) + "       " + TimeToStr( Connect_Start, TIME_SECONDS ) + " - " );
			}
			else
			{
				Connect_Stop = LocalTime();
				if ( !first )
				{
					FileSeek( handle, -55, SEEK_CUR );
					FileWrite( handle, "+ + + OnLine + + +       " + TimeToStr( Connect_Start, TIME_DATE ) + "       " + TimeToStr( Connect_Start, TIME_SECONDS ) + " - " + TimeToStr( Connect_Stop, TIME_SECONDS ) );
				}
				if ( IsStopped() ) { break; }
				FileWrite( handle, "- - - OffLine- - -       " + TimeToStr( Connect_Stop, TIME_DATE ) + "       " + TimeToStr( Connect_Stop, TIME_SECONDS ) + " - " );
			}		
		}
		first = false;
		FileFlush( handle );
		Sleep(1000);
	}
	if ( Now_IsConnected )
	{
		FileSeek( handle, -55, SEEK_CUR );
		FileWrite( handle, "+ + + OnLine + + +       " + TimeToStr( Connect_Start, TIME_DATE ) + "       " + TimeToStr( Connect_Start, TIME_SECONDS ) + " - " + TimeToStr( LocalTime(), TIME_SECONDS ) );
	}
	else
	{
		FileSeek( handle, -55, SEEK_CUR );
		FileWrite( handle, "- - - OffLine- - -       " + TimeToStr( Connect_Stop, TIME_DATE ) + "       " + TimeToStr( Connect_Stop, TIME_SECONDS ) + " - " + TimeToStr( LocalTime(), TIME_SECONDS ) );
	}		
	FileWrite( handle, "- - - - - - - - - - - Expert was stoped - - - - - - - - - - -\n" );
	FileClose( handle );
return(0);
}