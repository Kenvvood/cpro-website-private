//+------------------------------------------------------------------+
//|                                         CPro Tool close_by_equity_percent MT4            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern double equity_percent_from_balances=1.2;
int start()
  {
   Comment("     ",AccountName(),"              ACCOUNT  ",AccountNumber(),"           FREE MARGIN  ",AccountFreeMargin(),"          EQUITY  ",AccountEquity(),"            BALANCE  ",AccountBalance());
   if(AccountEquity()>AccountBalance()*equity_percent_from_balances)
     {
      int total=OrdersTotal();
      for(int i=total-1;i>=0;i--)
        {
         if(OrderSelect(i,SELECT_BY_POS)==true)
           {
            int type=OrderType();
            bool result=false;
            switch(type)
              {
               case OP_BUY       : result=OrderClose(OrderTicket(),OrderLots(),MarketInfo(OrderSymbol(),MODE_BID),5,Red);
               break;
               case OP_SELL      : result=OrderClose(OrderTicket(),OrderLots(),MarketInfo(OrderSymbol(),MODE_ASK),5,Red);
              }
            if(result==false)
              {
               Sleep(0);
              }
           }
        }
     }
   return(0);
  }
//+------------------------------------------------------------------+