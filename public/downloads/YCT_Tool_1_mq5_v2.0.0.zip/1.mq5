
//+------------------------------------------------------------------+
//|                 YCT Tool 1_mq5                                     |
//|                         城诺科技                            |
//|                         WeChat: Lookee333                        |
//+------------------------------------------------------------------+


//+------------------------------------------------------------------+
//|                           Brand Panel                             |
//+------------------------------------------------------------------+
#include <mq5\Marketing.mqh>

// 品牌面板将在 OnInit() 中通过 InitMarketing() 初始化
// 品牌面板将在 OnDeinit() 中通过 DeinitMarketing() 清理

﻿//+------------------------------------------------------------------+
//|                  Multi-Symbol Multi-Timeframe Sweep of 2 Highs   |
//|                                      Copyright 2026, Setup Radar |
//|                                       https://www.Setupradar.app |
//|                                          Author: X.com/Hectorand |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Setupradar."
#property link      "https://www.Setupradar.app"
#property version   "1.00"
#property strict

// Include sector mapping
#include <SymbolToSectorLink.mqh>
#include <Trade/Trade.mqh>

//+------------------------------------------------------------------+
//| INPUT PARAMETERS - Strategy                                      |
//+------------------------------------------------------------------+
input int SwingLeftBars = 5;                     // Number of bars to check on the left
input int SwingRightBars = 5;                    // Number of bars to check on the right
input int LookbackCandles = 50;                  // Candles to look back from L1
input bool TakeScreenshot = true;                 // Take screenshot when raid occurs
input bool SendAlert = false;                     // Show popup alert
input bool SendPushNotification = false;          // Send to mobile
input bool DebugMode = true;                      // Enable detailed debug printing

//+------------------------------------------------------------------+
//| TRADING INPUT PARAMETERS                                         |
//+------------------------------------------------------------------+
input bool EnableTrading = true;                   // Enable automatic trading
input int MagicNumber = 202602;                    // Magic number for orders
input int Slippage = 3;                            // Slippage in points
input int ExpirationHours = 24;                    // Hours to wait for entry
input bool TrackWinRate = true;                    // Track win rate statistics

//+------------------------------------------------------------------+
//| CHART MANAGEMENT                                                 |
//+------------------------------------------------------------------+
input bool CloseChartAfterScreenshot = false;     // true = close chart (save memory)
int ScreenshotWidth = 1350;                       // Screenshot width
int ScreenshotHeight = 1080;                      // Screenshot height
int ChartOpenDelay = 1000;                        // ms to wait before screenshot

//+------------------------------------------------------------------+
//| API CONFIGURATION                                                |
//+------------------------------------------------------------------+
input string API_Data_URL = "https://api.setupradar.app/api/v1/strategy/webhook";
input string API_Screenshot_URL = "https://api.setupradar.app/api/v1/strategy/webhook";
string StrategyName = "Sweep of 2 Hs or Ls + Inducement + POI";
string StrategyID = "0000006";
string allowedTimeframe[];

//+------------------------------------------------------------------+
//| SESSION TRACKING                                                 |
//+------------------------------------------------------------------+
input string SydneySessionStart = "22:00";
input string SydneySessionEnd = "00:00";
input string AsiaSessionStart = "00:00";
input string AsiaSessionEnd = "07:00";
input string LondonSessionStart = "07:00";
input string LondonSessionEnd = "12:00";
input string NewYorkSessionStart = "12:00";
input string NewYorkSessionEnd = "22:00";

//+------------------------------------------------------------------+
//| TIMEFRAMES TO TRADE                                              |
//+------------------------------------------------------------------+
ENUM_TIMEFRAMES TIME_FRAMES[] = {
    PERIOD_D1,   // Daily
    PERIOD_H12,  // 12 Hour
    PERIOD_H4,   // 4 Hour
    PERIOD_H1,   // 1 Hour
    PERIOD_M15   // 15 Minutes
};

string TIMEFRAME_NAMES[] = {
    "D1",
    "H12",
    "H4",
    "H1",
    "M15"
};

int TIMEFRAME_COUNT = 5;

//+------------------------------------------------------------------+
//| ENUMERATIONS                                                     |
//+------------------------------------------------------------------+
enum ENUM_SIGNAL_TYPE { 
    SIGNAL_BUY, 
    SIGNAL_SELL,
    SIGNAL_NEUTRAL
};

enum ENUM_RAID_TYPE {
    RAID_H1,           // Buy H1 raid
    RAID_L2,           // Buy L2 raid
    RAID_SELL_L1,      // Sell L1 raid
    RAID_SELL_H2       // Sell H2 raid
};

enum ENUM_SESSION {
    SESSION_SYDNEY,
    SESSION_ASIAN,
    SESSION_LONDON,
    SESSION_NEWYORK,
    SESSION_OUTSIDE
};

//+------------------------------------------------------------------+
//| ENHANCED TRADE RECORD STRUCTURE                                  |
//+------------------------------------------------------------------+
struct EnhancedTradeRecord {
   string            symbol;
   string            timeframe;
   string            patternID;
   int               orderType;      // 0=Buy, 1=Sell
   double            entryPrice;
   double            exitPrice;
   double            profit;
   datetime          entryTime;
   datetime          exitTime;
   bool              isWin;
   bool              isClosed;
   ulong             ticket;
   int               dayOfWeek;      // 0=Sunday, 1=Monday, ..., 6=Saturday
   string            session;        // London, NewYork, Asian, Sydney, Outside
};

//+------------------------------------------------------------------+
//| TIMEFRAME STATS STRUCTURE                                        |
//+------------------------------------------------------------------+
struct TimeframeStats {
   string            timeframe;
   int               totalTrades;
   int               winningTrades;
   int               losingTrades;
   double            totalProfit;
   double            winRate;
};

//+------------------------------------------------------------------+
//| DAY STATS STRUCTURE                                              |
//+------------------------------------------------------------------+
struct DayStats {
   string            day;
   int               totalTrades;
   int               winningTrades;
   double            winRate;
   double            totalProfit;
};

//+------------------------------------------------------------------+
//| SESSION STATS STRUCTURE                                          |
//+------------------------------------------------------------------+
struct SessionStats {
   string            session;
   int               totalTrades;
   int               winningTrades;
   double            winRate;
   double            totalProfit;
};

//+------------------------------------------------------------------+
//| SYMBOL STATS STRUCTURE                                           |
//+------------------------------------------------------------------+
struct SymbolStats {
   string            symbol;
   int               totalTrades;
   int               winningTrades;
   int               losingTrades;
   double            totalProfit;
   double            avgProfit;
   double            winRate;
   int               buyTrades;
   int               buyWins;
   int               sellTrades;
   int               sellWins;
};

//+------------------------------------------------------------------+
//| SYMBOL TIMEFRAME STATS STRUCTURE                                 |
//+------------------------------------------------------------------+
struct SymbolTimeframeStats {
   string            symbol;
   string            timeframe;
   int               totalTrades;
   int               winningTrades;
   double            winRate;
   double            totalProfit;
};

//+------------------------------------------------------------------+
//| HARDCODED SYMBOL LIST                                            |
//+------------------------------------------------------------------+
string HARDCODED_SYMBOLS[] = {
    "AUDJPY.0",
    "ADAUSD.0",
    "AVAUSD.0",
    "BCHUSD.0",
    "BNBUSD.0",
    "BTCUSD.0",
    "DOGUSD.0",
    "DOTUSD.0",
    "ETHUSD.0",
    "LTCUSD.0",
    "SOLUSD.0",
    "XRPUSD.0",
    "Crash 150 Index.0",
    "Boom 150 Index.0",
    "Boom 1000 Index.0",
    "Boom 300 Index.0",
    "Boom 500 Index.0",
    "Crash 1000 Index.0",
    "Crash 300 Index.0",
    "Crash 500 Index.0",
    "Boom 600 Index.0",
    "Boom 900 Index.0",
    "Crash 600 Index.0",
    "Crash 900 Index.0",
    "Volatility 10 (1s) Index.0",
    "Volatility 10 Index.0",
    "Volatility 100 (1s) Index.0",
    "Volatility 100 Index.0",
    "Volatility 150 (1s) Index.0",
    "Volatility 25 (1s) Index.0",
    "Volatility 25 Index.0",
    "Volatility 50 (1s) Index.0",
    "Volatility 50 Index.0",
    "Volatility 75 (1s) Index.0",
    "Volatility 75 Index.0",
    "Volatility 15 (1s) Index.0",
    "Volatility 30 (1s) Index.0",
    "Volatility 90 (1s) Index.0",
    "Step Index.0",
    "Step Index 200.0",
    "Step Index 300.0",
    "Step Index 400.0",
    "Step Index 500.0",
    "Range Break 100 Index.0",
    "Range Break 200 Index.0",
    "Jump 10 Index.0",
    "Jump 100 Index.0",
    "Jump 25 Index.0",
    "Jump 50 Index.0",
    "Jump 75 Index.0",
    "AUDUSD.0",
    "EURAUD.0",
    "EURCAD.0",
    "EURCHF.0",
    "EURGBP.0",
    "EURJPY.0",
    "EURUSD.0",
    "GBPAUD.0",
    "GBPJPY.0",
    "GBPUSD.0",
    "USDCAD.0",
    "USDCHF.0",
    "USDJPY.0",
    "AUDCAD.0",
    "AUDCHF.0",
    "AUDNZD.0",
    "CADCHF.0",
    "CADJPY.0",
    "CHFJPY.0",
    "EURNZD.0",
    "GBPCAD.0",
    "GBPCHF.0",
    "GBPNZD.0",
    "NZDCAD.0",
    "NZDJPY.0",
    "NZDUSD.0",
    "US Oil.0",
    "XAGEUR.0",
    "XAGUSD.0",
    "XAUEUR.0",
    "XPDUSD.0",
    "XPTUSD.0",
    "UK 100.0",
    "XAUUSD.0",
    "US SP 500.0",
    "Wall Street 30.0",
    "US Tech 100.0"
};

//+------------------------------------------------------------------+
//| GLOBAL VARIABLES FOR ENHANCED STATS COLLECTION                   |
//+------------------------------------------------------------------+
EnhancedTradeRecord g_allTrades[50000];
int g_totalTrades = 0;

//+------------------------------------------------------------------+
//| PENDING ORDER STRUCTURE                                          |
//+------------------------------------------------------------------+
struct PendingOrder {
   string            patternID;
   double            entryPrice;
   double            stopLoss;
   double            takeProfit;
   datetime          entryTime;
   int               orderType;  // 0 = Buy, 1 = Sell
   bool              isActive;
   datetime          expiration;
};

//+------------------------------------------------------------------+
//| BUY PATTERN STRUCTURE                                            |
//+------------------------------------------------------------------+
struct BuyPattern {
   double            L1_price, H1_price;
   datetime          L1_time, H1_time;
   double            L2_price;
   datetime          L2_time;
   double            H3_price, H4_price;
   datetime          H3_time, H4_time;
   datetime          h1RaidTime;
   datetime          l2RaidTime;
   bool              h1RaidDone;
   bool              l2RaidDone;
   bool              patternValid;
   bool              patternComplete;
   bool              screenshotTaken;
   long              raidChartID;
   bool              chartClosed;
   string            patternID;
   datetime          creationTime;
   datetime          h4BreachTime;
};

//+------------------------------------------------------------------+
//| SELL PATTERN STRUCTURE                                           |
//+------------------------------------------------------------------+
struct SellPattern {
   double            H1_price, L1_price;
   datetime          H1_time, L1_time;
   double            H2_price;
   datetime          H2_time;
   double            L3_price, L4_price;
   datetime          L3_time, L4_time;
   datetime          l1RaidTime;
   datetime          h2RaidTime;
   bool              l1RaidDone;
   bool              h2RaidDone;
   bool              patternValid;
   bool              patternComplete;
   bool              screenshotTaken;
   long              raidChartID;
   bool              chartClosed;
   string            patternID;
   datetime          creationTime;
   datetime          l4BreachTime;
};

//+------------------------------------------------------------------+
//| Helper Functions for Statistics                                  |
//+------------------------------------------------------------------+
string GetSessionName(datetime time)
{
    MqlDateTime dt;
    TimeToStruct(time, dt);
    
    int hour = dt.hour;
    int minute = dt.min;
    int totalMinutes = hour * 60 + minute;
    
    int sydneyStart = 22 * 60;
    int sydneyEnd = 0;
    int asiaStart = 0;
    int asiaEnd = 7 * 60;
    int londonStart = 7 * 60;
    int londonEnd = 12 * 60;
    int newyorkStart = 12 * 60;
    int newyorkEnd = 22 * 60;
    
    if(totalMinutes >= sydneyStart || totalMinutes < sydneyEnd)
        return "Sydney";
    else if(totalMinutes >= asiaStart && totalMinutes < asiaEnd)
        return "Asian";
    else if(totalMinutes >= londonStart && totalMinutes < londonEnd)
        return "London";
    else if(totalMinutes >= newyorkStart && totalMinutes < newyorkEnd)
        return "NewYork";
    else
        return "Outside";
}

string GetDayName(int dayOfWeek)
{
    switch(dayOfWeek)
    {
        case 0: return "Sunday";
        case 1: return "Monday";
        case 2: return "Tuesday";
        case 3: return "Wednesday";
        case 4: return "Thursday";
        case 5: return "Friday";
        case 6: return "Saturday";
        default: return "Unknown";
    }
}

string GetTimeframeName(ENUM_TIMEFRAMES tf)
{
    for(int i = 0; i < TIMEFRAME_COUNT; i++)
    {
        if(TIME_FRAMES[i] == tf)
            return TIMEFRAME_NAMES[i];
    }
    return "Unknown";
}

//+------------------------------------------------------------------+
//| Main Strategy Class                                              |
//+------------------------------------------------------------------+
class CMultiSymbolMultiTimeframeStrategy
{
private:
    string            m_symbol;
    ENUM_TIMEFRAMES   m_timeframe;
    string            m_timeframeName;
    datetime          m_startTime;
    
    // Pattern storage
    #define MAX_PATTERNS 50
    BuyPattern        m_buyPatterns[MAX_PATTERNS];
    SellPattern       m_sellPatterns[MAX_PATTERNS];
    int               m_totalBuyPatterns;
    int               m_totalSellPatterns;
    
    // Pending orders
    PendingOrder      m_pendingOrders[MAX_PATTERNS];
    int               m_totalPendingOrders;
    
    // Time tracking
    datetime          m_lastBarTime;
    datetime          m_last15MinBarTime;
    string            m_currentSession;
    
    // Drawing
    static long       m_zCounter;
    string            m_watermarkName;
    int               m_debugCount;
    
    // Trading
    CTrade            m_trade;
    int               m_magicNumber;
    double            m_lotSize;
    int               m_slippage;
    int               m_expirationSeconds;
    
    // Symbol properties
    double            m_pointValue;
    int               m_digits;
    double            m_minLot;
    double            m_maxLot;
    double            m_lotStep;
    double            m_minStopDistance;

public:
    //+------------------------------------------------------------------+
    //| Constructor                                                      |
    //+------------------------------------------------------------------+
    CMultiSymbolMultiTimeframeStrategy(string symbol, ENUM_TIMEFRAMES tf)
    {
        m_symbol = symbol;
        m_timeframe = tf;
        m_timeframeName = GetTimeframeName(tf);
        m_startTime = TimeCurrent() + 60;
        
        m_totalBuyPatterns = 0;
        m_totalSellPatterns = 0;
        m_totalPendingOrders = 0;
        
        m_lastBarTime = 0;
        m_last15MinBarTime = 0;
        m_watermarkName = "WM_" + symbol + "_" + m_timeframeName;
        m_debugCount = 0;
        
        // Get symbol properties
        m_pointValue = SymbolInfoDouble(m_symbol, SYMBOL_POINT);
        m_digits = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);
        
        SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_MIN, m_minLot);
        SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_MAX, m_maxLot);
        SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_STEP, m_lotStep);
        
        // Get minimum stop distance
        int stopsLevel = (int)SymbolInfoInteger(m_symbol, SYMBOL_TRADE_STOPS_LEVEL);
        if(stopsLevel < 10) stopsLevel = 10;
        m_minStopDistance = stopsLevel * m_pointValue;
        
        // Initialize trade settings
        m_magicNumber = MagicNumber + (int)tf;
        m_slippage = Slippage;
        m_expirationSeconds = ExpirationHours * 3600;
        
        // Get minimum lot size
        m_lotSize = GetMinLotSize();
        
        // Setup CTrade
        m_trade.SetExpertMagicNumber(m_magicNumber);
        m_trade.SetDeviationInPoints(m_slippage);
        
        // Initialize arrays
        for(int i = 0; i < MAX_PATTERNS; i++)
        {
            m_buyPatterns[i].patternID = "";
            m_buyPatterns[i].h1RaidDone = false;
            m_buyPatterns[i].l2RaidDone = false;
            m_buyPatterns[i].patternComplete = false;
            
            m_sellPatterns[i].patternID = "";
            m_sellPatterns[i].l1RaidDone = false;
            m_sellPatterns[i].h2RaidDone = false;
            m_sellPatterns[i].patternComplete = false;
            
            m_pendingOrders[i].isActive = false;
            m_pendingOrders[i].patternID = "";
        }
        
        UpdateSession();
        
        if(DebugMode)
        {
            Print(m_symbol, " [", m_timeframeName, "] - Initialized | Point: ", m_pointValue, " | Min Lot: ", m_minLot);
        }
    }
    
    //+------------------------------------------------------------------+
    //| Destructor                                                       |
    //+------------------------------------------------------------------+
    ~CMultiSymbolMultiTimeframeStrategy()
    {
        for(int i = 0; i < m_totalBuyPatterns; i++)
        {
            if(m_buyPatterns[i].raidChartID > 0 && !m_buyPatterns[i].chartClosed)
                ChartClose(m_buyPatterns[i].raidChartID);
        }
        
        for(int i = 0; i < m_totalSellPatterns; i++)
        {
            if(m_sellPatterns[i].raidChartID > 0 && !m_sellPatterns[i].chartClosed)
                ChartClose(m_sellPatterns[i].raidChartID);
        }
        
        ObjectDelete(0, m_watermarkName);
    }
    
    //+------------------------------------------------------------------+
    //| Get minimum lot size                                             |
    //+------------------------------------------------------------------+
    double GetMinLotSize()
    {
        double minLot = 0.01;
        if(SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_MIN, minLot))
            return minLot;
        return 0.01;
    }
    
    //+------------------------------------------------------------------+
    //| Normalize price                                                  |
    //+------------------------------------------------------------------+
    double NormalizePrice(double price)
    {
        return NormalizeDouble(price, m_digits);
    }
    
    //+------------------------------------------------------------------+
    //| Normalize lot size                                               |
    //+------------------------------------------------------------------+
    double NormalizeLot(double lot)
    {
        if(lot < m_minLot) lot = m_minLot;
        if(lot > m_maxLot) lot = m_maxLot;
        if(m_lotStep > 0)
        {
            double steps = MathRound(lot / m_lotStep);
            lot = steps * m_lotStep;
        }
        return NormalizeDouble(lot, 2);
    }
    
    //+------------------------------------------------------------------+
    //| Track trade globally with enhanced info                          |
    //+------------------------------------------------------------------+
    void TrackTradeGlobal(ulong ticket, string symbol, int type, double entryPrice, double exitPrice, 
                          double profit, datetime entryTime, datetime exitTime, bool isWin)
    {
        if(!TrackWinRate) return;
        
        MqlDateTime dt;
        TimeToStruct(entryTime, dt);
        
        g_allTrades[g_totalTrades].symbol = symbol;
        g_allTrades[g_totalTrades].timeframe = m_timeframeName;
        g_allTrades[g_totalTrades].patternID = "";
        g_allTrades[g_totalTrades].orderType = type;
        g_allTrades[g_totalTrades].entryPrice = entryPrice;
        g_allTrades[g_totalTrades].exitPrice = exitPrice;
        g_allTrades[g_totalTrades].profit = profit;
        g_allTrades[g_totalTrades].entryTime = entryTime;
        g_allTrades[g_totalTrades].exitTime = exitTime;
        g_allTrades[g_totalTrades].isWin = isWin;
        g_allTrades[g_totalTrades].isClosed = true;
        g_allTrades[g_totalTrades].ticket = ticket;
        g_allTrades[g_totalTrades].dayOfWeek = dt.day_of_week;
        g_allTrades[g_totalTrades].session = GetSessionName(entryTime);
        g_totalTrades++;
        
        if(DebugMode)
        {
            Print(symbol, " [", m_timeframeName, "] - Trade recorded | ", (type == 0 ? "BUY" : "SELL"), 
                  " | Profit: ", profit, " | Win: ", isWin ? "YES" : "NO");
        }
    }
    
    //+------------------------------------------------------------------+
    //| Check for closed positions and track them                        |
    //+------------------------------------------------------------------+
    void CheckAndTrackClosedPositions()
    {
        if(!TrackWinRate) return;
        
        HistorySelect(0, TimeCurrent());
        int totalHistory = HistoryDealsTotal();
        
        for(int i = 0; i < totalHistory; i++)
        {
            ulong ticket = HistoryDealGetTicket(i);
            if(ticket > 0)
            {
                string symbol = HistoryDealGetString(ticket, DEAL_SYMBOL);
                long magic = HistoryDealGetInteger(ticket, DEAL_MAGIC);
                long type = HistoryDealGetInteger(ticket, DEAL_TYPE);
                
                if(symbol == m_symbol && magic == m_magicNumber && 
                   (type == DEAL_TYPE_BUY || type == DEAL_TYPE_SELL))
                {
                    // Check if already tracked
                    bool alreadyTracked = false;
                    for(int j = 0; j < g_totalTrades; j++)
                    {
                        if(g_allTrades[j].ticket == ticket)
                        {
                            alreadyTracked = true;
                            break;
                        }
                    }
                    
                    if(!alreadyTracked)
                    {
                        double price = HistoryDealGetDouble(ticket, DEAL_PRICE);
                        double profit = HistoryDealGetDouble(ticket, DEAL_PROFIT);
                        datetime time = (datetime)HistoryDealGetInteger(ticket, DEAL_TIME);
                        
                        double entryPrice = 0;
                        datetime entryTime = 0;
                        int orderType = (type == DEAL_TYPE_BUY) ? 0 : 1;
                        
                        // Find corresponding entry
                        for(int j = 0; j < totalHistory; j++)
                        {
                            ulong entryTicket = HistoryDealGetTicket(j);
                            if(entryTicket > 0)
                            {
                                string entrySymbol = HistoryDealGetString(entryTicket, DEAL_SYMBOL);
                                long entryMagic = HistoryDealGetInteger(entryTicket, DEAL_MAGIC);
                                long entryType = HistoryDealGetInteger(entryTicket, DEAL_TYPE);
                                
                                if(entrySymbol == symbol && entryMagic == magic && 
                                   ((type == DEAL_TYPE_BUY && entryType == DEAL_TYPE_SELL) ||
                                    (type == DEAL_TYPE_SELL && entryType == DEAL_TYPE_BUY)))
                                {
                                    entryPrice = HistoryDealGetDouble(entryTicket, DEAL_PRICE);
                                    entryTime = (datetime)HistoryDealGetInteger(entryTicket, DEAL_TIME);
                                    break;
                                }
                            }
                        }
                        
                        bool isWin = (profit > 0);
                        TrackTradeGlobal(ticket, symbol, orderType, entryPrice, price, 
                                        profit, entryTime, time, isWin);
                    }
                }
            }
        }
    }
    
    //+------------------------------------------------------------------+
    //| Adjust stop loss                                                |
    //+------------------------------------------------------------------+
    double AdjustStopLoss(double entry, double stopLoss, bool isBuy)
    {
        double minDistance = m_minStopDistance * 2;
        
        if(isBuy)
        {
            if(stopLoss >= entry)
                stopLoss = entry - minDistance;
            else if(entry - stopLoss < minDistance)
                stopLoss = entry - minDistance;
        }
        else
        {
            if(stopLoss <= entry)
                stopLoss = entry + minDistance;
            else if(stopLoss - entry < minDistance)
                stopLoss = entry + minDistance;
        }
        
        return NormalizePrice(stopLoss);
    }
    
    //+------------------------------------------------------------------+
    //| Adjust take profit                                               |
    //+------------------------------------------------------------------+
    double AdjustTakeProfit(double entry, double takeProfit, bool isBuy)
    {
        double minDistance = m_minStopDistance * 2;
        
        if(isBuy)
        {
            if(takeProfit <= entry)
                takeProfit = entry + minDistance;
            else if(takeProfit - entry < minDistance)
                takeProfit = entry + minDistance;
        }
        else
        {
            if(takeProfit >= entry)
                takeProfit = entry - minDistance;
            else if(entry - takeProfit < minDistance)
                takeProfit = entry - minDistance;
        }
        
        return NormalizePrice(takeProfit);
    }
    
    //+------------------------------------------------------------------+
    //| Generate unique ID                                               |
    //+------------------------------------------------------------------+
    string GenerateUniqueId()
    {
        return IntegerToString(TimeCurrent()) + "_" + IntegerToString(rand()) + "_" + IntegerToString(GetTickCount());
    }
    
    //+------------------------------------------------------------------+
    //| Main tick handler                                                |
    //+------------------------------------------------------------------+
    void OnTick()
    {
        CheckBuyRaids();
        CheckSellRaids();
        CheckPendingOrders();
        CheckAndTrackClosedPositions();
        
        if(IsNewBar())
        {
            if(DebugMode) Print(m_symbol, " [", m_timeframeName, "] - New bar");
            
            DeleteCompletedPatterns();
            FindBuyPatterns();
            FindSellPatterns();
        }
    }
    
    //+------------------------------------------------------------------+
    //| Check for new bar                                                |
    //+------------------------------------------------------------------+
    bool IsNewBar()
    {
        datetime currentBar = iTime(m_symbol, m_timeframe, 0);
        if(m_lastBarTime == 0)
        {
            m_lastBarTime = currentBar;
            return true;
        }
        if(m_lastBarTime != currentBar)
        {
            m_lastBarTime = currentBar;
            return true;
        }
        return false;
    }
    
    //+------------------------------------------------------------------+
    //| Check for new 15-min bar (for session update)                    |
    //+------------------------------------------------------------------+
    bool IsNew15MinBar()
    {
        datetime currentBar = iTime(m_symbol, PERIOD_M15, 0);
        if(m_last15MinBarTime != currentBar)
        {
            m_last15MinBarTime = currentBar;
            return true;
        }
        return false;
    }
    
    //+------------------------------------------------------------------+
    //| Check buy raids                                                  |
    //+------------------------------------------------------------------+
    void CheckBuyRaids()
    {
        double ask = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
        
        for(int i = 0; i < m_totalBuyPatterns; i++)
        {
            if(m_buyPatterns[i].patternComplete) continue;
            
            if(!m_buyPatterns[i].h1RaidDone)
            {
                if(ask > m_buyPatterns[i].H1_price)
                {
                    m_buyPatterns[i].h1RaidTime = TimeCurrent();
                    if(m_buyPatterns[i].h1RaidTime < m_startTime)
                    {
                        DeleteBuyPattern(i);
                        continue;
                    }
                    m_buyPatterns[i].h1RaidDone = true;
                    ProcessH1Raid(i);
                }
            }
            else if(!m_buyPatterns[i].l2RaidDone && m_buyPatterns[i].L2_price > 0)
            {
                if(ask < m_buyPatterns[i].L2_price)
                {
                    m_buyPatterns[i].l2RaidTime = TimeCurrent();
                    if(m_buyPatterns[i].l2RaidTime < m_startTime)
                    {
                        DeleteBuyPattern(i);
                        continue;
                    }
                    m_buyPatterns[i].l2RaidDone = true;
                    ProcessL2Raid(i);
                }
            }
        }
    }
    
    //+------------------------------------------------------------------+
    //| Check sell raids                                                 |
    //+------------------------------------------------------------------+
    void CheckSellRaids()
    {
        double bid = SymbolInfoDouble(m_symbol, SYMBOL_BID);
        
        for(int i = 0; i < m_totalSellPatterns; i++)
        {
            if(m_sellPatterns[i].patternComplete) continue;
            
            if(!m_sellPatterns[i].l1RaidDone)
            {
                if(bid < m_sellPatterns[i].L1_price)
                {
                    m_sellPatterns[i].l1RaidTime = TimeCurrent();
                    if(m_sellPatterns[i].l1RaidTime < m_startTime)
                    {
                        DeleteSellPattern(i);
                        continue;
                    }
                    m_sellPatterns[i].l1RaidDone = true;
                    ProcessL1Raid(i);
                }
            }
            else if(!m_sellPatterns[i].h2RaidDone && m_sellPatterns[i].H2_price > 0)
            {
                if(bid > m_sellPatterns[i].H2_price)
                {
                    m_sellPatterns[i].h2RaidTime = TimeCurrent();
                    if(m_sellPatterns[i].h2RaidTime < m_startTime)
                    {
                        DeleteSellPattern(i);
                        continue;
                    }
                    m_sellPatterns[i].h2RaidDone = true;
                    ProcessH2Raid(i);
                }
            }
        }
    }
    
    //+------------------------------------------------------------------+
    //| Process H1 raid (Buy)                                            |
    //+------------------------------------------------------------------+
    void ProcessH1Raid(int index)
    {
        datetime startTime = m_buyPatterns[index].H1_time + GetTimeframeSeconds();
        datetime endTime = m_buyPatterns[index].h1RaidTime;
        
        m_buyPatterns[index].L2_time = FindLowestLow(startTime, endTime);
        if(m_buyPatterns[index].L2_time == 0)
        {
            DeleteBuyPattern(index);
            return;
        }
        
        int l2Bar = iBarShift(m_symbol, m_timeframe, m_buyPatterns[index].L2_time);
        m_buyPatterns[index].L2_price = iLow(m_symbol, m_timeframe, l2Bar);
        
        if(m_buyPatterns[index].L2_price <= m_buyPatterns[index].L1_price)
        {
            DeleteBuyPattern(index);
            return;
        }
        
        if(!FindH3H4(index))
        {
            DeleteBuyPattern(index);
            return;
        }
        
        if(m_buyPatterns[index].H3_price <= m_buyPatterns[index].L1_price || 
           m_buyPatterns[index].H3_price >= m_buyPatterns[index].H1_price ||
           m_buyPatterns[index].H4_price <= m_buyPatterns[index].L1_price || 
           m_buyPatterns[index].H4_price >= m_buyPatterns[index].H1_price)
        {
            DeleteBuyPattern(index);
            return;
        }
        
        m_buyPatterns[index].h4BreachTime = FindH4Breach(index);
        if(m_buyPatterns[index].h4BreachTime == 0)
        {
            DeleteBuyPattern(index);
            return;
        }
        
        m_buyPatterns[index].patternValid = true;
        
        if(DebugMode) Print(m_symbol, " [", m_timeframeName, "] - BUY pattern validated | ID: ", m_buyPatterns[index].patternID);
        
        ProcessBuyRaidWithChart(index, RAID_H1);
    }
    
    //+------------------------------------------------------------------+
    //| Process L2 raid (Buy confirmation)                               |
    //+------------------------------------------------------------------+
    void ProcessL2Raid(int index)
    {
        ProcessBuyRaidWithChart(index, RAID_L2);
    }
    
    //+------------------------------------------------------------------+
    //| Process L1 raid (Sell)                                           |
    //+------------------------------------------------------------------+
    void ProcessL1Raid(int index)
    {
        datetime startTime = m_sellPatterns[index].L1_time + GetTimeframeSeconds();
        datetime endTime = m_sellPatterns[index].l1RaidTime;
        
        m_sellPatterns[index].H2_time = FindHighestHigh(startTime, endTime);
        if(m_sellPatterns[index].H2_time == 0)
        {
            DeleteSellPattern(index);
            return;
        }
        
        int h2Bar = iBarShift(m_symbol, m_timeframe, m_sellPatterns[index].H2_time);
        m_sellPatterns[index].H2_price = iHigh(m_symbol, m_timeframe, h2Bar);
        
        if(m_sellPatterns[index].H2_price >= m_sellPatterns[index].H1_price)
        {
            DeleteSellPattern(index);
            return;
        }
        
        if(!FindL3L4(index))
        {
            DeleteSellPattern(index);
            return;
        }
        
        if(m_sellPatterns[index].L3_price >= m_sellPatterns[index].H1_price || 
           m_sellPatterns[index].L3_price <= m_sellPatterns[index].L1_price ||
           m_sellPatterns[index].L4_price >= m_sellPatterns[index].H1_price || 
           m_sellPatterns[index].L4_price <= m_sellPatterns[index].L1_price)
        {
            DeleteSellPattern(index);
            return;
        }
        
        m_sellPatterns[index].l4BreachTime = FindL4Breach(index);
        if(m_sellPatterns[index].l4BreachTime == 0)
        {
            DeleteSellPattern(index);
            return;
        }
        
        m_sellPatterns[index].patternValid = true;
        
        if(DebugMode) Print(m_symbol, " [", m_timeframeName, "] - SELL pattern validated | ID: ", m_sellPatterns[index].patternID);
        
        ProcessSellRaidWithChart(index, RAID_SELL_L1);
    }
    
    //+------------------------------------------------------------------+
    //| Process H2 raid (Sell confirmation)                              |
    //+------------------------------------------------------------------+
    void ProcessH2Raid(int index)
    {
        ProcessSellRaidWithChart(index, RAID_SELL_H2);
    }
    
    //+------------------------------------------------------------------+
    //| Process buy raid with chart                                      |
    //+------------------------------------------------------------------+
    void ProcessBuyRaidWithChart(int index, ENUM_RAID_TYPE raidType)
    {
        if(raidType == RAID_H1 && EnableTrading)
        {
            double entryPrice = m_buyPatterns[index].L1_price + 
                                ((m_buyPatterns[index].L2_price - m_buyPatterns[index].L1_price) / 2.0);
            entryPrice = NormalizePrice(entryPrice);
            
            double stopLoss = m_buyPatterns[index].L1_price;
            double takeProfit = m_buyPatterns[index].H1_price;
            
            stopLoss = AdjustStopLoss(entryPrice, stopLoss, true);
            takeProfit = AdjustTakeProfit(entryPrice, takeProfit, true);
            
            AddPendingOrder(m_buyPatterns[index].patternID, entryPrice, stopLoss, takeProfit, 0);
            
            Print(m_symbol, " [", m_timeframeName, "] - Pending BUY added | Entry: ", entryPrice, 
                  " SL: ", stopLoss, " TP: ", takeProfit);
        }
        
        if(raidType == RAID_H1 || raidType == RAID_L2)
        {
            if(raidType == RAID_L2)
                m_buyPatterns[index].patternComplete = true;
        }
    }
    
    //+------------------------------------------------------------------+
    //| Process sell raid with chart                                     |
    //+------------------------------------------------------------------+
    void ProcessSellRaidWithChart(int index, ENUM_RAID_TYPE raidType)
    {
        if(raidType == RAID_SELL_L1 && EnableTrading)
        {
            double entryPrice = m_sellPatterns[index].H1_price - 
                                ((m_sellPatterns[index].H1_price - m_sellPatterns[index].H2_price) / 2.0);
            entryPrice = NormalizePrice(entryPrice);
            
            double stopLoss = m_sellPatterns[index].H1_price;
            double takeProfit = m_sellPatterns[index].L1_price;
            
            stopLoss = AdjustStopLoss(entryPrice, stopLoss, false);
            takeProfit = AdjustTakeProfit(entryPrice, takeProfit, false);
            
            AddPendingOrder(m_sellPatterns[index].patternID, entryPrice, stopLoss, takeProfit, 1);
            
            Print(m_symbol, " [", m_timeframeName, "] - Pending SELL added | Entry: ", entryPrice,
                  " SL: ", stopLoss, " TP: ", takeProfit);
        }
        
        if(raidType == RAID_SELL_L1 || raidType == RAID_SELL_H2)
        {
            if(raidType == RAID_SELL_H2)
                m_sellPatterns[index].patternComplete = true;
        }
    }
    
    //+------------------------------------------------------------------+
    //| Add pending order                                                |
    //+------------------------------------------------------------------+
    void AddPendingOrder(string patternID, double entry, double sl, double tp, int type)
    {
        for(int i = 0; i < MAX_PATTERNS; i++)
        {
            if(!m_pendingOrders[i].isActive)
            {
                m_pendingOrders[i].patternID = patternID;
                m_pendingOrders[i].entryPrice = entry;
                m_pendingOrders[i].stopLoss = sl;
                m_pendingOrders[i].takeProfit = tp;
                m_pendingOrders[i].entryTime = TimeCurrent();
                m_pendingOrders[i].orderType = type;
                m_pendingOrders[i].isActive = true;
                m_pendingOrders[i].expiration = TimeCurrent() + m_expirationSeconds;
                
                if(i >= m_totalPendingOrders)
                    m_totalPendingOrders = i + 1;
                
                if(DebugMode)
                {
                    Print(m_symbol, " [", m_timeframeName, "] - Pending order added | Pattern: ", patternID);
                    Print("   Entry: ", entry, " SL: ", sl, " TP: ", tp);
                }
                return;
            }
        }
    }
    
    //+------------------------------------------------------------------+
    //| Check pending orders                                             |
    //+------------------------------------------------------------------+
    void CheckPendingOrders()
    {
        double bid = SymbolInfoDouble(m_symbol, SYMBOL_BID);
        double ask = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
        
        for(int i = 0; i < m_totalPendingOrders; i++)
        {
            if(!m_pendingOrders[i].isActive) continue;
            
            if(TimeCurrent() > m_pendingOrders[i].expiration)
            {
                if(DebugMode) Print(m_symbol, " [", m_timeframeName, "] - Pending order expired: ", m_pendingOrders[i].patternID);
                m_pendingOrders[i].isActive = false;
                continue;
            }
            
            double tolerance = m_pointValue;
            
            if(m_pendingOrders[i].orderType == 0) // Buy
            {
                if(ask <= m_pendingOrders[i].entryPrice + tolerance)
                {
                    ExecuteMarketBuy(m_pendingOrders[i]);
                    m_pendingOrders[i].isActive = false;
                }
            }
            else // Sell
            {
                if(bid >= m_pendingOrders[i].entryPrice - tolerance)
                {
                    ExecuteMarketSell(m_pendingOrders[i]);
                    m_pendingOrders[i].isActive = false;
                }
            }
        }
    }
    
    //+------------------------------------------------------------------+
    //| Execute market buy                                               |
    //+------------------------------------------------------------------+
    void ExecuteMarketBuy(PendingOrder &order)
    {
        double lot = NormalizeLot(m_lotSize);
        double sl = order.stopLoss;
        double tp = order.takeProfit;
        double currentAsk = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
        
        if(sl >= currentAsk)
        {
            sl = currentAsk - (m_minStopDistance * 2);
            sl = NormalizePrice(sl);
        }
        
        if(tp <= currentAsk)
        {
            tp = currentAsk + (m_minStopDistance * 2);
            tp = NormalizePrice(tp);
        }
        
        if(DebugMode)
        {
            Print("=== EXECUTING MARKET BUY [", m_timeframeName, "] ===");
            Print("Symbol: ", m_symbol);
            Print("Current Ask: ", currentAsk);
            Print("Lot: ", lot);
            Print("SL: ", sl);
            Print("TP: ", tp);
        }
        
        m_trade.PositionOpen(m_symbol, ORDER_TYPE_BUY, lot, currentAsk, sl, tp, "Pattern_" + order.patternID);
        
        if(m_trade.ResultRetcode() == TRADE_RETCODE_DONE)
        {
            Print(m_symbol, " [", m_timeframeName, "] - MARKET BUY executed! Ticket: ", m_trade.ResultOrder());
        }
        else
        {
            Print(m_symbol, " [", m_timeframeName, "] - MARKET BUY failed! Error: ", m_trade.ResultRetcodeDescription());
        }
    }
    
    //+------------------------------------------------------------------+
    //| Execute market sell                                              |
    //+------------------------------------------------------------------+
    void ExecuteMarketSell(PendingOrder &order)
    {
        double lot = NormalizeLot(m_lotSize);
        double sl = order.stopLoss;
        double tp = order.takeProfit;
        double currentBid = SymbolInfoDouble(m_symbol, SYMBOL_BID);
        
        if(sl <= currentBid)
        {
            sl = currentBid + (m_minStopDistance * 2);
            sl = NormalizePrice(sl);
        }
        
        if(tp >= currentBid)
        {
            tp = currentBid - (m_minStopDistance * 2);
            tp = NormalizePrice(tp);
        }
        
        if(DebugMode)
        {
            Print("=== EXECUTING MARKET SELL [", m_timeframeName, "] ===");
            Print("Symbol: ", m_symbol);
            Print("Current Bid: ", currentBid);
            Print("Lot: ", lot);
            Print("SL: ", sl);
            Print("TP: ", tp);
        }
        
        m_trade.PositionOpen(m_symbol, ORDER_TYPE_SELL, lot, currentBid, sl, tp, "Pattern_" + order.patternID);
        
        if(m_trade.ResultRetcode() == TRADE_RETCODE_DONE)
        {
            Print(m_symbol, " [", m_timeframeName, "] - MARKET SELL executed! Ticket: ", m_trade.ResultOrder());
        }
        else
        {
            Print(m_symbol, " [", m_timeframeName, "] - MARKET SELL failed! Error: ", m_trade.ResultRetcodeDescription());
        }
    }
    
    //+------------------------------------------------------------------+
    //| Find lowest low between times                                    |
    //+------------------------------------------------------------------+
    datetime FindLowestLow(datetime start, datetime end)
    {
        int startBar = iBarShift(m_symbol, m_timeframe, start);
        int endBar = iBarShift(m_symbol, m_timeframe, end);
        
        if(startBar < 0 || endBar < 0 || startBar <= endBar) return 0;
        
        double lowest = DBL_MAX;
        datetime lowestTime = 0;
        
        for(int i = startBar; i >= endBar; i--)
        {
            double low = iLow(m_symbol, m_timeframe, i);
            if(low < lowest)
            {
                lowest = low;
                lowestTime = iTime(m_symbol, m_timeframe, i);
            }
        }
        return lowestTime;
    }
    
    //+------------------------------------------------------------------+
    //| Find highest high between times                                  |
    //+------------------------------------------------------------------+
    datetime FindHighestHigh(datetime start, datetime end)
    {
        int startBar = iBarShift(m_symbol, m_timeframe, start);
        int endBar = iBarShift(m_symbol, m_timeframe, end);
        
        if(startBar < 0 || endBar < 0 || startBar <= endBar) return 0;
        
        double highest = -DBL_MAX;
        datetime highestTime = 0;
        
        for(int i = startBar; i >= endBar; i--)
        {
            double high = iHigh(m_symbol, m_timeframe, i);
            if(high > highest)
            {
                highest = high;
                highestTime = iTime(m_symbol, m_timeframe, i);
            }
        }
        return highestTime;
    }
    
    //+------------------------------------------------------------------+
    //| Find H3 and H4                                                   |
    //+------------------------------------------------------------------+
    bool FindH3H4(int index)
    {
        int l1Bar = iBarShift(m_symbol, m_timeframe, m_buyPatterns[index].L1_time);
        if(l1Bar < 0) return false;
        
        int startBar = l1Bar + LookbackCandles;
        int totalBars = iBars(m_symbol, m_timeframe);
        if(startBar >= totalBars) startBar = totalBars - 1;
        
        double highs[];
        datetime highTimes[];
        ArrayResize(highs, 0);
        ArrayResize(highTimes, 0);
        
        for(int i = startBar; i >= l1Bar; i--)
        {
            if(IsSwingHigh(i))
            {
                int size = ArraySize(highs);
                ArrayResize(highs, size + 1);
                ArrayResize(highTimes, size + 1);
                highs[size] = iHigh(m_symbol, m_timeframe, i);
                highTimes[size] = iTime(m_symbol, m_timeframe, i);
            }
        }
        
        if(ArraySize(highs) < 2) return false;
        
        for(int i = 0; i < ArraySize(highs) - 1; i++)
        {
            for(int j = 0; j < ArraySize(highs) - i - 1; j++)
            {
                if(highs[j] < highs[j + 1])
                {
                    double tempPrice = highs[j];
                    highs[j] = highs[j + 1];
                    highs[j + 1] = tempPrice;
                    
                    datetime tempTime = highTimes[j];
                    highTimes[j] = highTimes[j + 1];
                    highTimes[j + 1] = tempTime;
                }
            }
        }
        
        for(int i = 0; i < ArraySize(highs) - 1; i++)
        {
            for(int j = i + 1; j < ArraySize(highs); j++)
            {
                if(highTimes[i] < highTimes[j])
                {
                    m_buyPatterns[index].H4_price = highs[i];
                    m_buyPatterns[index].H4_time = highTimes[i];
                    m_buyPatterns[index].H3_price = highs[j];
                    m_buyPatterns[index].H3_time = highTimes[j];
                    return true;
                }
            }
        }
        return false;
    }
    
    //+------------------------------------------------------------------+
    //| Find L3 and L4                                                   |
    //+------------------------------------------------------------------+
    bool FindL3L4(int index)
    {
        int h1Bar = iBarShift(m_symbol, m_timeframe, m_sellPatterns[index].H1_time);
        if(h1Bar < 0) return false;
        
        int startBar = h1Bar + LookbackCandles;
        int totalBars = iBars(m_symbol, m_timeframe);
        if(startBar >= totalBars) startBar = totalBars - 1;
        
        double lows[];
        datetime lowTimes[];
        ArrayResize(lows, 0);
        ArrayResize(lowTimes, 0);
        
        for(int i = startBar; i >= h1Bar; i--)
        {
            if(IsSwingLow(i))
            {
                int size = ArraySize(lows);
                ArrayResize(lows, size + 1);
                ArrayResize(lowTimes, size + 1);
                lows[size] = iLow(m_symbol, m_timeframe, i);
                lowTimes[size] = iTime(m_symbol, m_timeframe, i);
            }
        }
        
        if(ArraySize(lows) < 2) return false;
        
        for(int i = 0; i < ArraySize(lows) - 1; i++)
        {
            for(int j = 0; j < ArraySize(lows) - i - 1; j++)
            {
                if(lows[j] > lows[j + 1])
                {
                    double tempPrice = lows[j];
                    lows[j] = lows[j + 1];
                    lows[j + 1] = tempPrice;
                    
                    datetime tempTime = lowTimes[j];
                    lowTimes[j] = lowTimes[j + 1];
                    lowTimes[j + 1] = tempTime;
                }
            }
        }
        
        for(int i = 0; i < ArraySize(lows) - 1; i++)
        {
            for(int j = i + 1; j < ArraySize(lows); j++)
            {
                if(lowTimes[i] < lowTimes[j])
                {
                    m_sellPatterns[index].L4_price = lows[i];
                    m_sellPatterns[index].L4_time = lowTimes[i];
                    m_sellPatterns[index].L3_price = lows[j];
                    m_sellPatterns[index].L3_time = lowTimes[j];
                    return true;
                }
            }
        }
        return false;
    }
    
    //+------------------------------------------------------------------+
    //| Find H4 breach time                                              |
    //+------------------------------------------------------------------+
    datetime FindH4Breach(int index)
    {
        int l1Bar = iBarShift(m_symbol, m_timeframe, m_buyPatterns[index].L1_time);
        int h1Bar = iBarShift(m_symbol, m_timeframe, m_buyPatterns[index].H1_time);
        
        if(l1Bar < 0 || h1Bar < 0 || l1Bar <= h1Bar) return 0;
        
        double h4Price = m_buyPatterns[index].H4_price;
        
        for(int i = l1Bar - 1; i > h1Bar; i--)
        {
            double low = iLow(m_symbol, m_timeframe, i);
            double high = iHigh(m_symbol, m_timeframe, i);
            
            if(low < h4Price && high > h4Price)
                return iTime(m_symbol, m_timeframe, i);
        }
        return 0;
    }
    
    //+------------------------------------------------------------------+
    //| Find L4 breach time                                              |
    //+------------------------------------------------------------------+
    datetime FindL4Breach(int index)
    {
        int h1Bar = iBarShift(m_symbol, m_timeframe, m_sellPatterns[index].H1_time);
        int l1Bar = iBarShift(m_symbol, m_timeframe, m_sellPatterns[index].L1_time);
        
        if(h1Bar < 0 || l1Bar < 0 || h1Bar <= l1Bar) return 0;
        
        double l4Price = m_sellPatterns[index].L4_price;
        
        for(int i = h1Bar - 1; i > l1Bar; i--)
        {
            double low = iLow(m_symbol, m_timeframe, i);
            double high = iHigh(m_symbol, m_timeframe, i);
            
            if(high > l4Price && low < l4Price)
                return iTime(m_symbol, m_timeframe, i);
        }
        return 0;
    }
    
    //+------------------------------------------------------------------+
    //| Find buy patterns                                                |
    //+------------------------------------------------------------------+
    void FindBuyPatterns()
    {
        int totalBars = iBars(m_symbol, m_timeframe);
        int startBar = MathMin(200, totalBars - SwingRightBars - 1);
        
        for(int i = startBar; i >= SwingRightBars; i--)
        {
            if(IsSwingLow(i))
            {
                double l1Price = iLow(m_symbol, m_timeframe, i);
                datetime l1Time = iTime(m_symbol, m_timeframe, i);
                
                if(IsL1Used(l1Time)) continue;
                
                for(int j = i - 1; j >= SwingRightBars; j--)
                {
                    if(IsSwingHigh(j))
                    {
                        datetime h1Time = iTime(m_symbol, m_timeframe, j);
                        if(h1Time > l1Time)
                        {
                            double h1Price = iHigh(m_symbol, m_timeframe, j);
                            
                            if(h1Price <= l1Price) continue;
                            if(IsH1PriceDuplicate(h1Price)) continue;
                            
                            if(IsLowestLowBetween(l1Time, h1Time, l1Price) &&
                               IsHighestHighBetween(l1Time, h1Time, h1Price))
                            {
                                CreateBuyPattern(l1Price, l1Time, h1Price, h1Time);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    
    //+------------------------------------------------------------------+
    //| Find sell patterns                                               |
    //+------------------------------------------------------------------+
    void FindSellPatterns()
    {
        int totalBars = iBars(m_symbol, m_timeframe);
        int startBar = MathMin(200, totalBars - SwingRightBars - 1);
        
        for(int i = startBar; i >= SwingRightBars; i--)
        {
            if(IsSwingHigh(i))
            {
                double h1Price = iHigh(m_symbol, m_timeframe, i);
                datetime h1Time = iTime(m_symbol, m_timeframe, i);
                
                if(IsH1Used(h1Time)) continue;
                
                for(int j = i - 1; j >= SwingRightBars; j--)
                {
                    if(IsSwingLow(j))
                    {
                        datetime l1Time = iTime(m_symbol, m_timeframe, j);
                        if(l1Time > h1Time)
                        {
                            double l1Price = iLow(m_symbol, m_timeframe, j);
                            
                            if(l1Price >= h1Price) continue;
                            if(IsL1PriceDuplicate(l1Price)) continue;
                            
                            if(IsHighestHighBetweenSell(h1Time, l1Time, h1Price) &&
                               IsLowestLowBetweenSell(h1Time, l1Time, l1Price))
                            {
                                CreateSellPattern(h1Price, h1Time, l1Price, l1Time);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    
    //+------------------------------------------------------------------+
    //| Create buy pattern                                               |
    //+------------------------------------------------------------------+
    void CreateBuyPattern(double l1Price, datetime l1Time, double h1Price, datetime h1Time)
    {
        if(m_totalBuyPatterns >= MAX_PATTERNS)
        {
            if(m_buyPatterns[0].raidChartID > 0 && !m_buyPatterns[0].chartClosed)
                ChartClose(m_buyPatterns[0].raidChartID);
            
            for(int i = 0; i < MAX_PATTERNS - 1; i++)
                m_buyPatterns[i] = m_buyPatterns[i + 1];
            
            m_totalBuyPatterns = MAX_PATTERNS - 1;
        }
        
        m_debugCount++;
        
        int idx = m_totalBuyPatterns;
        m_buyPatterns[idx].L1_price = l1Price;
        m_buyPatterns[idx].L1_time = l1Time;
        m_buyPatterns[idx].H1_price = h1Price;
        m_buyPatterns[idx].H1_time = h1Time;
        m_buyPatterns[idx].patternID = m_timeframeName + "_" + IntegerToString(TimeCurrent()) + "_" + IntegerToString(rand()) + "_" + IntegerToString(m_debugCount);
        m_buyPatterns[idx].creationTime = TimeCurrent();
        m_buyPatterns[idx].patternValid = false;
        m_buyPatterns[idx].patternComplete = false;
        m_buyPatterns[idx].h1RaidDone = false;
        m_buyPatterns[idx].l2RaidDone = false;
        
        m_totalBuyPatterns++;
        
        if(DebugMode) Print(m_symbol, " [", m_timeframeName, "] - NEW BUY PATTERN | L1: ", l1Price, " H1: ", h1Price);
    }
    
    //+------------------------------------------------------------------+
    //| Create sell pattern                                              |
    //+------------------------------------------------------------------+
    void CreateSellPattern(double h1Price, datetime h1Time, double l1Price, datetime l1Time)
    {
        if(m_totalSellPatterns >= MAX_PATTERNS)
        {
            if(m_sellPatterns[0].raidChartID > 0 && !m_sellPatterns[0].chartClosed)
                ChartClose(m_sellPatterns[0].raidChartID);
            
            for(int i = 0; i < MAX_PATTERNS - 1; i++)
                m_sellPatterns[i] = m_sellPatterns[i + 1];
            
            m_totalSellPatterns = MAX_PATTERNS - 1;
        }
        
        m_debugCount++;
        
        int idx = m_totalSellPatterns;
        m_sellPatterns[idx].H1_price = h1Price;
        m_sellPatterns[idx].H1_time = h1Time;
        m_sellPatterns[idx].L1_price = l1Price;
        m_sellPatterns[idx].L1_time = l1Time;
        m_sellPatterns[idx].patternID = m_timeframeName + "_SELL_" + IntegerToString(TimeCurrent()) + "_" + IntegerToString(rand()) + "_" + IntegerToString(m_debugCount);
        m_sellPatterns[idx].creationTime = TimeCurrent();
        m_sellPatterns[idx].patternValid = false;
        m_sellPatterns[idx].patternComplete = false;
        m_sellPatterns[idx].l1RaidDone = false;
        m_sellPatterns[idx].h2RaidDone = false;
        
        m_totalSellPatterns++;
        
        if(DebugMode) Print(m_symbol, " [", m_timeframeName, "] - NEW SELL PATTERN | H1: ", h1Price, " L1: ", l1Price);
    }
    
    //+------------------------------------------------------------------+
    //| Swing high detection                                             |
    //+------------------------------------------------------------------+
    bool IsSwingHigh(int bar)
    {
        double current = iHigh(m_symbol, m_timeframe, bar);
        for(int i = 1; i <= SwingLeftBars; i++)
        {
            if(iHigh(m_symbol, m_timeframe, bar + i) >= current) return false;
        }
        for(int i = 1; i <= SwingRightBars; i++)
        {
            if(bar - i >= 0 && iHigh(m_symbol, m_timeframe, bar - i) >= current) return false;
        }
        return true;
    }
    
    //+------------------------------------------------------------------+
    //| Swing low detection                                              |
    //+------------------------------------------------------------------+
    bool IsSwingLow(int bar)
    {
        double current = iLow(m_symbol, m_timeframe, bar);
        for(int i = 1; i <= SwingLeftBars; i++)
        {
            if(iLow(m_symbol, m_timeframe, bar + i) <= current) return false;
        }
        for(int i = 1; i <= SwingRightBars; i++)
        {
            if(bar - i >= 0 && iLow(m_symbol, m_timeframe, bar - i) <= current) return false;
        }
        return true;
    }
    
    //+------------------------------------------------------------------+
    //| Check if L1 is lowest low                                        |
    //+------------------------------------------------------------------+
    bool IsLowestLowBetween(datetime l1Time, datetime h1Time, double l1Price)
    {
        int l1Bar = iBarShift(m_symbol, m_timeframe, l1Time);
        int h1Bar = iBarShift(m_symbol, m_timeframe, h1Time);
        
        if(l1Bar < 0 || h1Bar < 0 || l1Bar <= h1Bar) return false;
        
        for(int i = l1Bar - 1; i > h1Bar; i--)
        {
            if(iLow(m_symbol, m_timeframe, i) < l1Price - m_pointValue)
                return false;
        }
        return true;
    }
    
    //+------------------------------------------------------------------+
    //| Check if H1 is highest high                                      |
    //+------------------------------------------------------------------+
    bool IsHighestHighBetween(datetime l1Time, datetime h1Time, double h1Price)
    {
        int l1Bar = iBarShift(m_symbol, m_timeframe, l1Time);
        int h1Bar = iBarShift(m_symbol, m_timeframe, h1Time);
        
        if(l1Bar < 0 || h1Bar < 0 || l1Bar <= h1Bar) return false;
        
        for(int i = l1Bar - 1; i > h1Bar; i--)
        {
            if(iHigh(m_symbol, m_timeframe, i) > h1Price + m_pointValue)
                return false;
        }
        return true;
    }
    
    //+------------------------------------------------------------------+
    //| Sell version checks                                              |
    //+------------------------------------------------------------------+
    bool IsHighestHighBetweenSell(datetime h1Time, datetime l1Time, double h1Price)
    {
        int h1Bar = iBarShift(m_symbol, m_timeframe, h1Time);
        int l1Bar = iBarShift(m_symbol, m_timeframe, l1Time);
        
        if(h1Bar < 0 || l1Bar < 0 || h1Bar <= l1Bar) return false;
        
        for(int i = h1Bar - 1; i > l1Bar; i--)
        {
            if(iHigh(m_symbol, m_timeframe, i) > h1Price + m_pointValue)
                return false;
        }
        return true;
    }
    
    bool IsLowestLowBetweenSell(datetime h1Time, datetime l1Time, double l1Price)
    {
        int h1Bar = iBarShift(m_symbol, m_timeframe, h1Time);
        int l1Bar = iBarShift(m_symbol, m_timeframe, l1Time);
        
        if(h1Bar < 0 || l1Bar < 0 || h1Bar <= l1Bar) return false;
        
        for(int i = h1Bar - 1; i > l1Bar; i--)
        {
            if(iLow(m_symbol, m_timeframe, i) < l1Price - m_pointValue)
                return false;
        }
        return true;
    }
    
    //+------------------------------------------------------------------+
    //| Utility functions                                                |
    //+------------------------------------------------------------------+
    bool IsL1Used(datetime time)
    {
        for(int i = 0; i < m_totalBuyPatterns; i++)
            if(m_buyPatterns[i].L1_time == time) return true;
        return false;
    }
    
    bool IsH1Used(datetime time)
    {
        for(int i = 0; i < m_totalSellPatterns; i++)
            if(m_sellPatterns[i].H1_time == time) return true;
        return false;
    }
    
    bool IsH1PriceDuplicate(double price)
    {
        for(int i = 0; i < m_totalBuyPatterns; i++)
        {
            if(!m_buyPatterns[i].patternComplete && MathAbs(m_buyPatterns[i].H1_price - price) < m_pointValue)
                return true;
        }
        return false;
    }
    
    bool IsL1PriceDuplicate(double price)
    {
        for(int i = 0; i < m_totalSellPatterns; i++)
        {
            if(!m_sellPatterns[i].patternComplete && MathAbs(m_sellPatterns[i].L1_price - price) < m_pointValue)
                return true;
        }
        return false;
    }
    
    //+------------------------------------------------------------------+
    //| Delete functions                                                 |
    //+------------------------------------------------------------------+
    void DeleteBuyPattern(int index)
    {
        if(index < 0 || index >= m_totalBuyPatterns) return;
        
        if(m_buyPatterns[index].raidChartID > 0 && !m_buyPatterns[index].chartClosed)
            ChartClose(m_buyPatterns[index].raidChartID);
        
        for(int i = 0; i < m_totalPendingOrders; i++)
        {
            if(m_pendingOrders[i].isActive && m_pendingOrders[i].patternID == m_buyPatterns[index].patternID)
                m_pendingOrders[i].isActive = false;
        }
        
        for(int i = index; i < m_totalBuyPatterns - 1; i++)
            m_buyPatterns[i] = m_buyPatterns[i + 1];
        
        m_totalBuyPatterns--;
    }
    
    void DeleteSellPattern(int index)
    {
        if(index < 0 || index >= m_totalSellPatterns) return;
        
        if(m_sellPatterns[index].raidChartID > 0 && !m_sellPatterns[index].chartClosed)
            ChartClose(m_sellPatterns[index].raidChartID);
        
        for(int i = 0; i < m_totalPendingOrders; i++)
        {
            if(m_pendingOrders[i].isActive && m_pendingOrders[i].patternID == m_sellPatterns[index].patternID)
                m_pendingOrders[i].isActive = false;
        }
        
        for(int i = index; i < m_totalSellPatterns - 1; i++)
            m_sellPatterns[i] = m_sellPatterns[i + 1];
        
        m_totalSellPatterns--;
    }
    
    void DeleteCompletedPatterns()
    {
        for(int i = m_totalBuyPatterns - 1; i >= 0; i--)
        {
            if(m_buyPatterns[i].patternComplete)
            {
                if(m_buyPatterns[i].raidChartID > 0 && !m_buyPatterns[i].chartClosed)
                    ChartClose(m_buyPatterns[i].raidChartID);
                
                for(int j = i; j < m_totalBuyPatterns - 1; j++)
                    m_buyPatterns[j] = m_buyPatterns[j + 1];
                
                m_totalBuyPatterns--;
            }
        }
        
        for(int i = m_totalSellPatterns - 1; i >= 0; i--)
        {
            if(m_sellPatterns[i].patternComplete)
            {
                if(m_sellPatterns[i].raidChartID > 0 && !m_sellPatterns[i].chartClosed)
                    ChartClose(m_sellPatterns[i].raidChartID);
                
                for(int j = i; j < m_totalSellPatterns - 1; j++)
                    m_sellPatterns[j] = m_sellPatterns[j + 1];
                
                m_totalSellPatterns--;
            }
        }
    }
    
    //+------------------------------------------------------------------+
    //| Update session                                                   |
    //+------------------------------------------------------------------+
    void UpdateSession()
    {
        datetime now = TimeCurrent();
        
        if(IsInSession(SydneySessionStart, SydneySessionEnd, now))
            m_currentSession = "Sydney";
        else if(IsInSession(AsiaSessionStart, AsiaSessionEnd, now))
            m_currentSession = "Asian";
        else if(IsInSession(LondonSessionStart, LondonSessionEnd, now))
            m_currentSession = "London";
        else if(IsInSession(NewYorkSessionStart, NewYorkSessionEnd, now))
            m_currentSession = "NewYork";
        else
            m_currentSession = "OutsideSession";
    }
    
    bool IsInSession(string start, string end, datetime time)
    {
        MqlDateTime tm;
        TimeToStruct(time, tm);
        
        string today = TimeToString(time, TIME_DATE);
        datetime sessionStart = StringToTime(today + " " + start);
        datetime sessionEnd = StringToTime(today + " " + end);
        
        if(sessionEnd <= sessionStart)
            sessionEnd += 24 * 60 * 60;
        
        return (time >= sessionStart && time < sessionEnd);
    }
    
    //+------------------------------------------------------------------+
    //| Get timeframe seconds                                            |
    //+------------------------------------------------------------------+
    int GetTimeframeSeconds()
    {
        switch(m_timeframe)
        {
            case PERIOD_M1: return 60;
            case PERIOD_M5: return 300;
            case PERIOD_M15: return 900;
            case PERIOD_M30: return 1800;
            case PERIOD_H1: return 3600;
            case PERIOD_H4: return 14400;
            case PERIOD_H12: return 43200;
            case PERIOD_D1: return 86400;
            default: return 3600;
        }
    }
};

// Initialize static member
long CMultiSymbolMultiTimeframeStrategy::m_zCounter = 10000;

//+------------------------------------------------------------------+
//| Global strategy instances                                        |
//+------------------------------------------------------------------+
CMultiSymbolMultiTimeframeStrategy* strategies[];
int totalStrategies = 0;

//+------------------------------------------------------------------+
//| Calculate timeframe statistics                                   |
//+------------------------------------------------------------------+
void CalculateTimeframeStats(TimeframeStats &stats[], int &count)
{
    count = 0;
    
    for(int t = 0; t < TIMEFRAME_COUNT; t++)
    {
        TimeframeStats tfStat;
        tfStat.timeframe = TIMEFRAME_NAMES[t];
        tfStat.totalTrades = 0;
        tfStat.winningTrades = 0;
        tfStat.losingTrades = 0;
        tfStat.totalProfit = 0;
        
        for(int i = 0; i < g_totalTrades; i++)
        {
            if(g_allTrades[i].timeframe == TIMEFRAME_NAMES[t])
            {
                tfStat.totalTrades++;
                tfStat.totalProfit += g_allTrades[i].profit;
                
                if(g_allTrades[i].isWin)
                    tfStat.winningTrades++;
                else
                    tfStat.losingTrades++;
            }
        }
        
        if(tfStat.totalTrades > 0)
        {
            tfStat.winRate = (double)tfStat.winningTrades / tfStat.totalTrades * 100;
            stats[count] = tfStat;
            count++;
        }
    }
}

//+------------------------------------------------------------------+
//| Calculate day of week statistics                                 |
//+------------------------------------------------------------------+
void CalculateDayStats(DayStats &stats[], int &count)
{
    string days[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    count = 0;
    
    for(int d = 0; d < 7; d++)
    {
        DayStats dayStat;
        dayStat.day = days[d];
        dayStat.totalTrades = 0;
        dayStat.winningTrades = 0;
        dayStat.totalProfit = 0;
        
        for(int i = 0; i < g_totalTrades; i++)
        {
            if(g_allTrades[i].dayOfWeek == d)
            {
                dayStat.totalTrades++;
                dayStat.totalProfit += g_allTrades[i].profit;
                
                if(g_allTrades[i].isWin)
                    dayStat.winningTrades++;
            }
        }
        
        if(dayStat.totalTrades > 0)
        {
            dayStat.winRate = (double)dayStat.winningTrades / dayStat.totalTrades * 100;
            stats[count] = dayStat;
            count++;
        }
    }
}

//+------------------------------------------------------------------+
//| Calculate session statistics                                     |
//+------------------------------------------------------------------+
void CalculateSessionStats(SessionStats &stats[], int &count)
{
    string sessions[] = {"London", "NewYork", "Asian", "Sydney", "Outside"};
    count = 0;
    
    for(int s = 0; s < 5; s++)
    {
        SessionStats sessionStat;
        sessionStat.session = sessions[s];
        sessionStat.totalTrades = 0;
        sessionStat.winningTrades = 0;
        sessionStat.totalProfit = 0;
        
        for(int i = 0; i < g_totalTrades; i++)
        {
            if(g_allTrades[i].session == sessions[s])
            {
                sessionStat.totalTrades++;
                sessionStat.totalProfit += g_allTrades[i].profit;
                
                if(g_allTrades[i].isWin)
                    sessionStat.winningTrades++;
            }
        }
        
        if(sessionStat.totalTrades > 0)
        {
            sessionStat.winRate = (double)sessionStat.winningTrades / sessionStat.totalTrades * 100;
            stats[count] = sessionStat;
            count++;
        }
    }
}

//+------------------------------------------------------------------+
//| Calculate symbol statistics                                      |
//+------------------------------------------------------------------+
void CalculateSymbolStats(SymbolStats &stats[], int &count)
{
    count = 0;
    
    // First, collect unique symbols
    string symbols[];
    int symbolCount = 0;
    
    for(int i = 0; i < g_totalTrades; i++)
    {
        bool found = false;
        for(int s = 0; s < symbolCount; s++)
        {
            if(symbols[s] == g_allTrades[i].symbol)
            {
                found = true;
                break;
            }
        }
        if(!found)
        {
            ArrayResize(symbols, symbolCount + 1);
            symbols[symbolCount] = g_allTrades[i].symbol;
            symbolCount++;
        }
    }
    
    // Calculate stats for each symbol
    for(int s = 0; s < symbolCount; s++)
    {
        SymbolStats symStat;
        symStat.symbol = symbols[s];
        symStat.totalTrades = 0;
        symStat.winningTrades = 0;
        symStat.losingTrades = 0;
        symStat.totalProfit = 0;
        symStat.buyTrades = 0;
        symStat.buyWins = 0;
        symStat.sellTrades = 0;
        symStat.sellWins = 0;
        
        for(int i = 0; i < g_totalTrades; i++)
        {
            if(g_allTrades[i].symbol == symbols[s])
            {
                symStat.totalTrades++;
                symStat.totalProfit += g_allTrades[i].profit;
                
                if(g_allTrades[i].isWin)
                {
                    symStat.winningTrades++;
                }
                else
                {
                    symStat.losingTrades++;
                }
                
                if(g_allTrades[i].orderType == 0) // Buy
                {
                    symStat.buyTrades++;
                    if(g_allTrades[i].isWin) symStat.buyWins++;
                }
                else // Sell
                {
                    symStat.sellTrades++;
                    if(g_allTrades[i].isWin) symStat.sellWins++;
                }
            }
        }
        
        if(symStat.totalTrades > 0)
        {
            symStat.winRate = (double)symStat.winningTrades / symStat.totalTrades * 100;
            symStat.avgProfit = symStat.totalProfit / symStat.totalTrades;
            stats[count] = symStat;
            count++;
        }
    }
}

//+------------------------------------------------------------------+
//| Calculate symbol + timeframe statistics                          |
//+------------------------------------------------------------------+
void CalculateSymbolTimeframeStats(SymbolTimeframeStats &stats[], int &count)
{
    count = 0;
    
    for(int i = 0; i < g_totalTrades; i++)
    {
        bool found = false;
        string key = g_allTrades[i].symbol + "_" + g_allTrades[i].timeframe;
        
        for(int s = 0; s < count; s++)
        {
            string existingKey = stats[s].symbol + "_" + stats[s].timeframe;
            if(existingKey == key)
            {
                found = true;
                stats[s].totalTrades++;
                stats[s].totalProfit += g_allTrades[i].profit;
                if(g_allTrades[i].isWin)
                    stats[s].winningTrades++;
                break;
            }
        }
        
        if(!found)
        {
            ArrayResize(stats, count + 1);
            stats[count].symbol = g_allTrades[i].symbol;
            stats[count].timeframe = g_allTrades[i].timeframe;
            stats[count].totalTrades = 1;
            stats[count].winningTrades = g_allTrades[i].isWin ? 1 : 0;
            stats[count].totalProfit = g_allTrades[i].profit;
            count++;
        }
    }
    
    // Calculate win rates
    for(int i = 0; i < count; i++)
    {
        if(stats[i].totalTrades > 0)
            stats[i].winRate = (double)stats[i].winningTrades / stats[i].totalTrades * 100;
        else
            stats[i].winRate = 0;
    }
}

//+------------------------------------------------------------------+
//| Export enhanced statistics                                       |
//+------------------------------------------------------------------+
void ExportEnhancedStatistics()
{
    string timeframe = "";
    switch(_Period)
    {
        case PERIOD_M1: timeframe = "M1"; break;
        case PERIOD_M5: timeframe = "M5"; break;
        case PERIOD_M15: timeframe = "M15"; break;
        case PERIOD_M30: timeframe = "M30"; break;
        case PERIOD_H1: timeframe = "H1"; break;
        case PERIOD_H4: timeframe = "H4"; break;
        case PERIOD_D1: timeframe = "D1"; break;
        default: timeframe = "Unknown";
    }
    
    string filename = "WinRate_Enhanced_" + timeframe + "_" + IntegerToString(TimeCurrent()) + ".txt";
    int handle = FileOpen(filename, FILE_WRITE|FILE_TXT|FILE_COMMON);
    
    if(handle == INVALID_HANDLE)
    {
        Print("Failed to create stats file: ", filename);
        return;
    }
    
    // Write header
    FileWrite(handle, "========================================");
    FileWrite(handle, "ENHANCED WIN RATE STATISTICS");
    FileWrite(handle, "========================================");
    FileWrite(handle, "");
    
    // 1. Statistics by Symbol
    FileWrite(handle, "=== STATISTICS BY SYMBOL ===");
    FileWrite(handle, "Symbol\tTotal Trades\tWins\tLosses\tWin Rate %\tTotal Profit\tAvg Profit\tBuy Trades\tBuy Wins\tBuy Win Rate %\tSell Trades\tSell Wins\tSell Win Rate %");
    
    SymbolStats symStats[200];
    int symCount = 0;
    CalculateSymbolStats(symStats, symCount);
    
    for(int i = 0; i < symCount; i++)
    {
        double buyWinRate = (symStats[i].buyTrades > 0) ? ((double)symStats[i].buyWins / symStats[i].buyTrades * 100) : 0;
        double sellWinRate = (symStats[i].sellTrades > 0) ? ((double)symStats[i].sellWins / symStats[i].sellTrades * 100) : 0;
        
        FileWrite(handle, 
            symStats[i].symbol + "\t" +
            IntegerToString(symStats[i].totalTrades) + "\t" +
            IntegerToString(symStats[i].winningTrades) + "\t" +
            IntegerToString(symStats[i].losingTrades) + "\t" +
            DoubleToString(symStats[i].winRate, 2) + "\t" +
            DoubleToString(symStats[i].totalProfit, 2) + "\t" +
            DoubleToString(symStats[i].avgProfit, 2) + "\t" +
            IntegerToString(symStats[i].buyTrades) + "\t" +
            IntegerToString(symStats[i].buyWins) + "\t" +
            DoubleToString(buyWinRate, 2) + "\t" +
            IntegerToString(symStats[i].sellTrades) + "\t" +
            IntegerToString(symStats[i].sellWins) + "\t" +
            DoubleToString(sellWinRate, 2));
    }
    FileWrite(handle, "");
    
    // 2. Statistics by Timeframe
    FileWrite(handle, "=== STATISTICS BY TIMEFRAME ===");
    FileWrite(handle, "Timeframe\tTotal Trades\tWins\tLosses\tWin Rate %\tTotal Profit");
    
    TimeframeStats tfStats[10];
    int tfCount = 0;
    CalculateTimeframeStats(tfStats, tfCount);
    
    for(int i = 0; i < tfCount; i++)
    {
        FileWrite(handle, tfStats[i].timeframe + "\t" +
                  IntegerToString(tfStats[i].totalTrades) + "\t" +
                  IntegerToString(tfStats[i].winningTrades) + "\t" +
                  IntegerToString(tfStats[i].losingTrades) + "\t" +
                  DoubleToString(tfStats[i].winRate, 2) + "\t" +
                  DoubleToString(tfStats[i].totalProfit, 2));
    }
    FileWrite(handle, "");
    
    // 3. Statistics by Day of Week
    FileWrite(handle, "=== STATISTICS BY DAY OF WEEK ===");
    FileWrite(handle, "Day\tTotal Trades\tWins\tWin Rate %\tTotal Profit");
    
    DayStats dayStats[7];
    int dayCount = 0;
    CalculateDayStats(dayStats, dayCount);
    
    for(int i = 0; i < dayCount; i++)
    {
        FileWrite(handle, dayStats[i].day + "\t" +
                  IntegerToString(dayStats[i].totalTrades) + "\t" +
                  IntegerToString(dayStats[i].winningTrades) + "\t" +
                  DoubleToString(dayStats[i].winRate, 2) + "\t" +
                  DoubleToString(dayStats[i].totalProfit, 2));
    }
    FileWrite(handle, "");
    
    // 4. Statistics by Trading Session
    FileWrite(handle, "=== STATISTICS BY TRADING SESSION ===");
    FileWrite(handle, "Session\tTotal Trades\tWins\tWin Rate %\tTotal Profit");
    
    SessionStats sessionStats[10];
    int sessionCount = 0;
    CalculateSessionStats(sessionStats, sessionCount);
    
    for(int i = 0; i < sessionCount; i++)
    {
        FileWrite(handle, sessionStats[i].session + "\t" +
                  IntegerToString(sessionStats[i].totalTrades) + "\t" +
                  IntegerToString(sessionStats[i].winningTrades) + "\t" +
                  DoubleToString(sessionStats[i].winRate, 2) + "\t" +
                  DoubleToString(sessionStats[i].totalProfit, 2));
    }
    FileWrite(handle, "");
    
    // 5. Statistics by Symbol + Timeframe (Deep Dive)
    FileWrite(handle, "=== STATISTICS BY SYMBOL + TIMEFRAME (Deep Dive) ===");
    FileWrite(handle, "Symbol\tTimeframe\tTotal Trades\tWins\tWin Rate %\tTotal Profit");
    
    SymbolTimeframeStats stStats[500];
    int stCount = 0;
    CalculateSymbolTimeframeStats(stStats, stCount);
    
    // Sort by symbol name for better readability
    for(int i = 0; i < stCount - 1; i++)
    {
        for(int j = i + 1; j < stCount; j++)
        {
            if(stStats[i].symbol > stStats[j].symbol)
            {
                SymbolTimeframeStats temp = stStats[i];
                stStats[i] = stStats[j];
                stStats[j] = temp;
            }
        }
    }
    
    for(int i = 0; i < stCount; i++)
    {
        if(stStats[i].totalTrades > 0)
        {
            FileWrite(handle, stStats[i].symbol + "\t" +
                      stStats[i].timeframe + "\t" +
                      IntegerToString(stStats[i].totalTrades) + "\t" +
                      IntegerToString(stStats[i].winningTrades) + "\t" +
                      DoubleToString(stStats[i].winRate, 2) + "\t" +
                      DoubleToString(stStats[i].totalProfit, 2));
        }
    }
    FileWrite(handle, "");
    
    // 6. Detailed trade list
    FileWrite(handle, "=== DETAILED TRADE LIST ===");
    FileWrite(handle, "Symbol\tTimeframe\tType\tEntry Time\tDay\tSession\tProfit\tWin");
    
    for(int i = 0; i < g_totalTrades; i++)
    {
        string type = (g_allTrades[i].orderType == 0) ? "BUY" : "SELL";
        string day = GetDayName(g_allTrades[i].dayOfWeek);
        string win = g_allTrades[i].isWin ? "YES" : "NO";
        
        FileWrite(handle, g_allTrades[i].symbol + "\t" +
                  g_allTrades[i].timeframe + "\t" +
                  type + "\t" +
                  TimeToString(g_allTrades[i].entryTime) + "\t" +
                  day + "\t" +
                  g_allTrades[i].session + "\t" +
                  DoubleToString(g_allTrades[i].profit, 2) + "\t" +
                  win);
    }
    
    FileClose(handle);
    Print("==================================================");
    Print("Enhanced statistics exported to: ", filename);
    Print("Location: MetaTrader 5\\MQL5\\Files\\Common\\");
    Print("==================================================");
}

//+------------------------------------------------------------------+
//| Print enhanced summary to console                                |
//+------------------------------------------------------------------+
void PrintEnhancedSummary()
{
    Print("");
    Print("==================================================");
    Print("        ENHANCED STRATEGY PERFORMANCE SUMMARY     ");
    Print("==================================================");
    Print("Total Trades: ", g_totalTrades);
    Print("");
    
    // Symbol Summary (Top 10 by trades)
    Print("--- TOP 10 SYMBOLS BY TRADE VOLUME ---");
    SymbolStats symStats[200];
    int symCount = 0;
    CalculateSymbolStats(symStats, symCount);
    
    // Sort by total trades
    for(int i = 0; i < symCount - 1; i++)
    {
        for(int j = i + 1; j < symCount; j++)
        {
            if(symStats[i].totalTrades < symStats[j].totalTrades)
            {
                SymbolStats temp = symStats[i];
                symStats[i] = symStats[j];
                symStats[j] = temp;
            }
        }
    }
    
    Print(StringFormat("%-30s %10s %8s %10s %12s %12s", 
          "Symbol", "Trades", "Wins", "Win Rate %", "Total Profit", "Avg Profit"));
    Print(StringFormat("%-30s %10s %8s %10s %12s %12s", 
          "------------------------------", "----------", "--------", "----------", "------------", "------------"));
    
    int displayCount = (symCount < 20) ? symCount : 20;
    for(int i = 0; i < displayCount; i++)
    {
        Print(StringFormat("%-30s %10d %8d %9.2f%% %12.2f %12.2f",
              symStats[i].symbol, symStats[i].totalTrades, symStats[i].winningTrades,
              symStats[i].winRate, symStats[i].totalProfit, symStats[i].avgProfit));
    }
    Print("");
    
    // Timeframe Summary
    Print("--- BY TIMEFRAME ---");
    TimeframeStats tfStats[10];
    int tfCount = 0;
    CalculateTimeframeStats(tfStats, tfCount);
    
    Print(StringFormat("%-10s %10s %8s %8s %10s %12s", 
          "Timeframe", "Trades", "Wins", "Losses", "Win Rate %", "Total Profit"));
    Print(StringFormat("%-10s %10s %8s %8s %10s %12s", 
          "----------", "----------", "--------", "--------", "----------", "------------"));
    
    for(int i = 0; i < tfCount; i++)
    {
        Print(StringFormat("%-10s %10d %8d %8d %9.2f%% %12.2f",
              tfStats[i].timeframe, tfStats[i].totalTrades, tfStats[i].winningTrades, 
              tfStats[i].losingTrades, tfStats[i].winRate, tfStats[i].totalProfit));
    }
    Print("");
    
    // Day Summary
    Print("--- BY DAY OF WEEK ---");
    DayStats dayStats[7];
    int dayCount = 0;
    CalculateDayStats(dayStats, dayCount);
    
    Print(StringFormat("%-10s %10s %8s %10s %12s", 
          "Day", "Trades", "Wins", "Win Rate %", "Total Profit"));
    Print(StringFormat("%-10s %10s %8s %10s %12s", 
          "----------", "----------", "--------", "----------", "------------"));
    
    for(int i = 0; i < dayCount; i++)
    {
        Print(StringFormat("%-10s %10d %8d %9.2f%% %12.2f",
              dayStats[i].day, dayStats[i].totalTrades, dayStats[i].winningTrades,
              dayStats[i].winRate, dayStats[i].totalProfit));
    }
    Print("");
    
    // Session Summary
    Print("--- BY TRADING SESSION ---");
    SessionStats sessionStats[10];
    int sessionCount = 0;
    CalculateSessionStats(sessionStats, sessionCount);
    
    Print(StringFormat("%-10s %10s %8s %10s %12s", 
          "Session", "Trades", "Wins", "Win Rate %", "Total Profit"));
    Print(StringFormat("%-10s %10s %8s %10s %12s", 
          "----------", "----------", "--------", "----------", "------------"));
    
    for(int i = 0; i < sessionCount; i++)
    {
        Print(StringFormat("%-10s %10d %8d %9.2f%% %12.2f",
              sessionStats[i].session, sessionStats[i].totalTrades, sessionStats[i].winningTrades,
              sessionStats[i].winRate, sessionStats[i].totalProfit));
    }
    Print("==================================================");
    Print("");
}

//+------------------------------------------------------------------+
//| Expert initialization                                            |
//+------------------------------------------------------------------+
int OnInit()
{
    int symbolsCount = ArraySize(HARDCODED_SYMBOLS);
    totalStrategies = symbolsCount * TIMEFRAME_COUNT;
    ArrayResize(strategies, totalStrategies);
    
    Print("==================================================");
    Print("Multi-Symbol Multi-Timeframe Strategy");
    Print("Number of symbols: ", symbolsCount);
    Print("Number of timeframes: ", TIMEFRAME_COUNT);
    Print("Total strategy instances: ", totalStrategies);
    Print("==================================================");
    
    int idx = 0;
    for(int s = 0; s < symbolsCount; s++)
    {
        for(int t = 0; t < TIMEFRAME_COUNT; t++)
        {
            strategies[idx] = new CMultiSymbolMultiTimeframeStrategy(HARDCODED_SYMBOLS[s], TIME_FRAMES[t]);
            idx++;
        }
    }
    
    Print("All strategy instances created successfully!");
    Print("==================================================");
    
    return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization                                          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
    Print("");
    Print("==================================================");
    Print("           EA TERMINATED - FINAL STATS            ");
    Print("==================================================");
    
    if(TrackWinRate && g_totalTrades > 0)
    {
        ExportEnhancedStatistics();
        PrintEnhancedSummary();
    }
    else if(TrackWinRate && g_totalTrades == 0)
    {
        Print("No trades were executed during this session.");
    }
    
    Print("Deinitializing Multi-Symbol Multi-Timeframe Strategy");
    
    for(int i = 0; i < totalStrategies; i++)
    {
        if(strategies[i] != NULL)
        {
            delete strategies[i];
        }
    }
    
    ArrayFree(strategies);
}

//+------------------------------------------------------------------+
//| Expert tick                                                      |
//+------------------------------------------------------------------+
void OnTick()
{
    for(int i = 0; i < totalStrategies; i++)
    {
        if(strategies[i] != NULL)
            strategies[i].OnTick();
    }
}
//+------------------------------------------------------------------+