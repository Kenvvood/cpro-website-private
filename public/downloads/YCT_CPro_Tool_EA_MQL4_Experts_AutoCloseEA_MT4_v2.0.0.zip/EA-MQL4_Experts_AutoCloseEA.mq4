//+------------------------------------------------------------------+
//|                                         CPro Tool EA_MQL4_Experts_AutoCloseEA MT4        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//--- 输入参数
input double CloseAtProfit         =100;        //平仓盈利额，默认100
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
//---
   CPro_Init();  // CPro营销模块初始化
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{   
   // 遍历订单，统计盈利
   double totalProfit = SumProfit();
   Print("DEBUG=>统计利润=[",totalProfit,"]，设定退出利润=[",CloseAtProfit,"]");
   if(totalProfit >CloseAtProfit)
   {      
      CloseAllOrder();
   }   
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| 统计盈利
//+------------------------------------------------------------------+
double SumProfit()
{
   double sum = 0;
   // 遍历订单，关闭全部
   for(int i=0;i<OrdersTotal();i++)
   {      
      // 选中仓单，选择不成功时，跳过本次循环
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)==false)
      {
         Print("统计盈利=>注意！选中仓单失败！序号=[",i,"]");
         continue;
      }
      sum += OrderProfit();
    }
    return sum;
}
//+------------------------------------------------------------------+
//| 平仓，关闭所有订单
//+------------------------------------------------------------------+
void CloseAllOrder()
{
   // 遍历订单，关闭全部
   for(int i=0;i<OrdersTotal();i++)
   {      
      // 选中仓单，选择不成功时，跳过本次循环
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)==false)
      {
         Print("自动平仓=>注意！选中仓单失败！序号=[",i,"]");
         continue;
      }
      //如果 仓单编号不是本系统编号，或者 仓单货币对不是当前货币对时，跳过本次循环
      /*if(OrderMagicNumber() != MAGICMA || OrderSymbol()!= _Symbol)
      { 
         Print("注意！订单魔术标记不符！仓单魔术编号=[",OrderMagicNumber(),"]","本EA魔术编号=[",MAGICMA,"]");
         continue;
      }*/
      Print("自动平仓=>处理订单ticket=[",OrderTicket(),"],品种=[",OrderSymbol(),"],手数=[",OrderLots(),"]");
      // 多单平仓：
      if(OrderType()==OP_BUY)
      {
         if(!OrderClose(OrderTicket(),OrderLots(),Bid,2,White)) Print("自动平仓=>关闭[多]单出错",GetLastError());
         continue;
      }
      // 空单平仓：
      if(OrderType()==OP_SELL)
      {
         if(!OrderClose(OrderTicket(),OrderLots(),Ask,3,White)) Print("自动平仓=>关闭[空]单出错",GetLastError());
         continue;
      }
   }
}