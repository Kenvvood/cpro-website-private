//+------------------------------------------------------------------+
//|                                         CPro Tool SHE_kanskigor MT4                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#define MAGIC 130306
extern double        Lots=0.1;         //    
extern int           Profit=35;        //  ,  0 -   
extern int           Stop=55;          //  ,  0 -   
extern int           Slippage=5;       // 
extern string        Symb="*";         //   .  *     
                                       //      EURUSD
extern string        StartTime="00:05";//    
datetime             TimeStart;
double               stoplevel,profitlevel;
string               SMB;
bool                 trade=false;
//+------------------------------------------------------------------+
//|                                                   |
//+------------------------------------------------------------------+
int start()
{
   int      i,b;
   //      StartTime   TimeStart
   TimeStart=StrToTime(StartTime);
   //          5 ,      .
   //     trade .     ,   .
   if(CurTime()<TimeStart || CurTime()>TimeStart+300) { trade=false; return(0); }
   //  trade ,    .
   if(trade) return(0);
   //        ,    
   if(iOpen(SMB,PERIOD_D1,1)>iClose(SMB,PERIOD_D1,1)) b=OP_BUY; else b=OP_SELL;
   //  
   if(b==OP_BUY)
   {
      //  Stop   0,     0,  Ask-Stop
      if(Stop==0) stoplevel=0; else stoplevel=MarketInfo(SMB,MODE_ASK)-Stop*MarketInfo(SMB,MODE_POINT);
      //      
      if(Profit==0) profitlevel=0; else profitlevel=MarketInfo(SMB,MODE_ASK)+Profit*MarketInfo(SMB,MODE_POINT);
      //      Ask   stoplevel   profitlevel
      i=OrderSend(SMB,OP_BUY,Lots,MarketInfo(SMB,MODE_ASK),Slippage,stoplevel,profitlevel,NULL,MAGIC,0,Red);
      //    ,   torg   ,     
      if(i!=-1) trade=true;
   }
   //     ,    .
   if(b==OP_SELL)
   {
      if(Stop==0) stoplevel=0; else stoplevel=MarketInfo(SMB,MODE_BID)+Stop*MarketInfo(SMB,MODE_POINT);
      if(Profit==0) profitlevel=0; else profitlevel=MarketInfo(SMB,MODE_BID)-Profit*MarketInfo(SMB,MODE_POINT);
      i=OrderSend(SMB,OP_SELL,Lots,MarketInfo(SMB,MODE_BID),Slippage,stoplevel,profitlevel,NULL,MAGIC,0,Blue);
      if(i!=-1) trade=true;
   }
   return(0);
}
//+------------------------------------------------------------------+
//|                                     |
//+------------------------------------------------------------------+
int init()
{
   int i;
   //    
   if(Symb=="*") SMB=Symbol(); else SMB=Symb;
   return(0);
}
//+------------------------------------------------------------------+
//|                                   |
//+------------------------------------------------------------------+
int deinit() { return(0); }
//+------------------------------------------------------------------+