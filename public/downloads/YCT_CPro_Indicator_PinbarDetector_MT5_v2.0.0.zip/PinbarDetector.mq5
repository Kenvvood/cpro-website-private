//+------------------------------------------------------------------+
//|                                         CPro Indicator PinbarDetector MT5                |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input int  CountBars = 0;//countK线数 - 数量 of K线数 to 数量 on, 0 = all.
input int  DisplayDistance = 5;//display距离 - the higher it is the the 距离 from faces to candles.
input bool UseAlerts = true;//使用 alerts
input bool UseEmailAlerts = false;//使用 email alerts (configure sm止盈 parameters in tools->options->emails)
input bool UseNotificationAlerts = false;//使用 notification alerts (configure push-notifications in tools->options->notifications)
input bool UseCustomSettings = false;//使用 custom settings - if true = 使用 below parameters:
input double CustomMaxNoseBodySize = 0.33;//均线x. body / candle length 比例 of the nose bar
input double CustomNoseBodyPosition = 0.4;//body 持仓 in nose bar (e.g. top/bottom 40%)
input bool   CustomLeftEyeOppositeDirection = true; // true = Direction of Left Eye Bar should be opposite to pattern (bearish bar for bullish Pinbar pattern and vice versa)
input bool   CustomNoseSameDirection = false; // true = Direction of Nose Bar should be the same as of pattern (bullish bar for bullish Pinbar pattern and vice versa)
input bool   CustomNoseBodyInsideLeftEyeBody = false; // true = Nose Body should be contained inside Left Eye Body
input double CustomLeftEyeMinBodySize = 0.1;//min. body / candle length 比例 of the left eye bar
input double CustomNoseProtruding = 0.5; // Minimum protrusion of Nose Bar compared to Nose Bar length
input double CustomNoseBodyToLeftEyeBody = 1;//均线ximum relative 尺寸 of the nose bar body to left eye bar body
input double CustomNoseLengthToLeftEyeLength = 0;//minimum relative 尺寸 of the nose bar length to left eye bar length
input double CustomLeftEyeDepth = 0.1; // Minimum relative depth of the Left Eye to its length; depth is difference with Nose's back
input int    CustomMinimumNoseLength = 1;//minimum nose candlestick length in 点数
// Indicator buffers
double UpDown[];
double Color[];
// Global variables
int    LastBars = 0;
double MaxNoseBodySize = 0.33;
double NoseBodyPosition = 0.4;
bool   LeftEyeOppositeDirection = true;
bool   NoseSameDirection = false;
bool   NoseBodyInsideLeftEyeBody = false;
double LeftEyeMinBodySize = 0.1;
double NoseProtruding = 0.5;
double NoseBodyToLeftEyeBody = 1;
double NoseLengthToLeftEyeLength = 0;
double LeftEyeDepth = 0.1;
int    MinimumCandlestickLength = 1;
void OnInit()
{
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, UpDown, INDICATOR_DATA);
    SetIndexBuffer(1, Color, INDICATOR_COLOR_INDEX);
    ArraySetAsSeries(UpDown, true);
    ArraySetAsSeries(Color, true);
    PlotIndexSetInteger(0, PLOT_ARROW, 74);
    PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
    PlotIndexSetString(0, PLOT_LABEL, "Pinbar");
    if (UseCustomSettings)
    {
        MaxNoseBodySize = CustomMaxNoseBodySize;
        NoseBodyPosition = CustomNoseBodyPosition;
        LeftEyeOppositeDirection = CustomLeftEyeOppositeDirection;
        NoseSameDirection = CustomNoseSameDirection;
        LeftEyeMinBodySize = CustomLeftEyeMinBodySize;
        NoseProtruding = CustomNoseProtruding;
        NoseBodyToLeftEyeBody = CustomNoseBodyToLeftEyeBody;
        NoseLengthToLeftEyeLength = CustomNoseLengthToLeftEyeLength;
        LeftEyeDepth = CustomLeftEyeDepth;
        MinimumCandlestickLength = CustomMinimumNoseLength;
    }
}
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &Open[],
                const double &High[],
                const double &Low[],
                const double &Close[],
                const long &tickvolume[],
                const long &volume[],
                const int &spread[])
{
    int NeedBarsCounted;
    double NoseLength, NoseBody, LeftEyeBody, LeftEyeLength;
    ArraySetAsSeries(Open, true);
    ArraySetAsSeries(High, true);
    ArraySetAsSeries(Low, true);
    ArraySetAsSeries(Close, true);
    if (LastBars == rates_total) return rates_total;
    NeedBarsCounted = rates_total - LastBars;
    if ((CountBars > 0) && (NeedBarsCounted > CountBars)) NeedBarsCounted = CountBars;
    LastBars = rates_total;
    if (NeedBarsCounted == rates_total) NeedBarsCounted--;
    UpDown[0] = EMPTY_VALUE;
    for (int i = NeedBarsCounted; i >= 1; i--)
    {
        // Prevents bogus indicator arrows from appearing (looks like PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE); is not enough.)
        UpDown[i] = EMPTY_VALUE;
        // Won't have Left Eye for the left-most bar.
        if (i == rates_total - 1) continue;
        // Left Eye and Nose bars' parameters.
        NoseLength = High[i] - Low[i];
        if (NoseLength < MinimumCandlestickLength * _Point) continue; // Nose candlestick too short.
        if (NoseLength == 0) NoseLength = _Point;
        LeftEyeLength = High[i + 1] - Low[i + 1];
        if (LeftEyeLength == 0) LeftEyeLength = _Point;
        NoseBody = MathAbs(Open[i] - Close[i]);
        if (NoseBody == 0) NoseBody = _Point;
        LeftEyeBody = MathAbs(Open[i + 1] - Close[i + 1]);
        if (LeftEyeBody == 0) LeftEyeBody = _Point;
        // Bearish Pinbar
        if (High[i] - High[i + 1] >= NoseLength * NoseProtruding) // Nose protrusion
        {
            if (NoseBody / NoseLength <= MaxNoseBodySize) // Nose body to candle length ratio
            {
                if (1 - (High[i] - MathMax(Open[i], Close[i])) / NoseLength < NoseBodyPosition) // Nose body position in bottom part of the bar
                {
                    if ((!LeftEyeOppositeDirection) || (Close[i + 1] > Open[i + 1])) // Left Eye bullish if required
                    {
                        if ((!NoseSameDirection) || (Close[i] < Open[i])) // Nose bearish if required
                        {
                            if (LeftEyeBody / LeftEyeLength  >= LeftEyeMinBodySize) // Left eye body to candle length ratio
                            {
                                if ((MathMax(Open[i], Close[i]) <= High[i + 1]) && (MathMin(Open[i], Close[i]) >= Low[i + 1])) // Nose body inside Left Eye bar
                                {
                                    if (NoseBody / LeftEyeBody <= NoseBodyToLeftEyeBody) // Nose body to Left Eye body ratio
                                    {
                                        if (NoseLength / LeftEyeLength >= NoseLengthToLeftEyeLength) // Nose length to Left Eye length ratio
                                        {
                                            if (Low[i] - Low[i + 1] >= LeftEyeLength * LeftEyeDepth)  // Left Eye low is low enough
                                            {
                                                if ((!NoseBodyInsideLeftEyeBody) || ((MathMax(Open[i], Close[i]) <= MathMax(Open[i + 1], Close[i + 1])) && (MathMin(Open[i], Close[i]) >= MathMin(Open[i + 1], Close[i + 1])))) // Nose body inside Left Eye body if required
                                                {
                                                    UpDown[i] = High[i] + DisplayDistance * _Point + NoseLength / 5;
                                                    Color[i] = 1;
                                                    if (i == 1) SendAlert("Bearish"); // Send alerts only for the latest fully formed bar
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // Bullish Pinbar
        if (Low[i + 1] - Low[i] >= NoseLength * NoseProtruding) // Nose protrusion
        {
            if (NoseBody / NoseLength <= MaxNoseBodySize) // Nose body to candle length ratio
            {
                if (1 - (MathMin(Open[i], Close[i]) - Low[i]) / NoseLength < NoseBodyPosition) // Nose body position in top part of the bar
                {
                    if ((!LeftEyeOppositeDirection) || (Close[i + 1] < Open[i + 1])) // Left Eye bearish if required
                    {
                        if ((!NoseSameDirection) || (Close[i] > Open[i])) // Nose bullish if required
                        {
                            if (LeftEyeBody / LeftEyeLength >= LeftEyeMinBodySize) // Left eye body to candle length ratio
                            {
                                if ((MathMax(Open[i], Close[i]) <= High[i + 1]) && (MathMin(Open[i], Close[i]) >= Low[i + 1])) // Nose body inside Left Eye bar
                                {
                                    if (NoseBody / LeftEyeBody <= NoseBodyToLeftEyeBody) // Nose body to Left Eye body ratio
                                    {
                                        if (NoseLength / LeftEyeLength >= NoseLengthToLeftEyeLength) // Nose length to Left Eye length ratio
                                        {
                                            if (High[i + 1] - High[i] >= LeftEyeLength * LeftEyeDepth) // Left Eye high is high enough
                                            {
                                                if ((!NoseBodyInsideLeftEyeBody) || ((MathMax(Open[i], Close[i]) <= MathMax(Open[i + 1], Close[i + 1])) && (MathMin(Open[i], Close[i]) >= MathMin(Open[i + 1], Close[i + 1])))) // Nose body inside Left Eye body if required
                                                {
                                                    UpDown[i] = Low[i] - DisplayDistance * _Point - NoseLength / 5;
                                                    Color[i] = 0;
                                                    if (i == 1) SendAlert("Bullish"); // Send alerts only for the latest fully formed bar
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return rates_total;
}
string TimeframeToString(ENUM_TIMEFRAMES P)
{
    return StringSubstr(EnumToString(P), 7);
}
void SendAlert(string dir)
{
    string per = TimeframeToString(_Period);
    if (UseAlerts)
    {
        Alert(dir + " Pinbar on ", _Symbol, " @ ", per);
        PlaySound("alert.wav");
    }
    if (UseEmailAlerts)
        SendMail(_Symbol + " @ " + per + " - " + dir + " Pinbar", dir + " Pinbar on " + _Symbol + " @ " + per + " as of " + TimeToString(TimeCurrent()));
    if (UseNotificationAlerts)
        SendNotification(dir + " Pinbar on " + _Symbol + " @ " + per + " as of " + TimeToString(TimeCurrent()));
}
//+------------------------------------------------------------------+