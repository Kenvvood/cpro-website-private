//+------------------------------------------------------------------+
//|                                         CPro Indicator IndTripleEMA MT5                  |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


// indicator settings
// drawing settings
//+------------------------------------------------------------------+
//| How to handle 'begin' parameter in OnCalculate function          |
//+------------------------------------------------------------------+
enum BEGIN_POLICY
{
   STRICT, // strict
   CUSTOM, // custom
   NONE,   // no
};
// inputs
input int InpPeriodEMA = 14;//ema 周期:
input BEGIN_POLICY InpHandleBegin = STRICT;  // Handle 'begin' parameter:
// indicator buffers
double TemaBuffer[];
double Ema[];
double EmaOfEma[];
double EmaOfEmaOfEma[];
//+------------------------------------------------------------------+
//| EMA internal settings                                            |
//+------------------------------------------------------------------+
// 'Offset' is reserved to define indeterminate region of warming up,
// where available number of elements is less than smoothing 'period'.
// But it's not actually needed for EMA, because unlike other MAs
// EMA's 'period' is not used directly to process 'period' elements,
// but affects inertial part of accumulation, which implicitly involves
// much more previous data trails (over 'period' elements).
// For triple EMA it's sometimes set to '3 * InpPeriodEMA - 3'.
// In this source code, being a part of the book, Offset = 0,
// which makes it easier to analize where source data begins.
const int Offset = 0;
const double K = 2.0 / (InpPeriodEMA + 1);
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
void OnInit()
{
   // indicator setting
   CPro_Init();  // CPro营销模块初始化
   const string caption = StringFormat("EMA³(%d)%s", InpPeriodEMA,
      StringSubstr(EnumToString(InpHandleBegin), 0, 1));
   IndicatorSetString(INDICATOR_SHORTNAME, caption);
   IndicatorSetInteger(INDICATOR_DIGITS, _Digits);
   // indicator buffers mapping
   SetIndexBuffer(0, TemaBuffer, INDICATOR_DATA);
   SetIndexBuffer(1, Ema, INDICATOR_CALCULATIONS);
   SetIndexBuffer(2, EmaOfEma, INDICATOR_CALCULATIONS);
   SetIndexBuffer(3, EmaOfEmaOfEma, INDICATOR_CALCULATIONS);
   // plot setup
   PlotIndexSetString(0, PLOT_LABEL, caption);
}
//+------------------------------------------------------------------+
//| Triple Exponential Moving Average                                |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const int begin,
                const double &price[])
{
   if(rates_total < Offset) return 0;
   const int _begin = InpHandleBegin == STRICT ? (begin < rates_total ? begin : fmax(rates_total - 1, 0)) : 0;
   // fresh start or refresh
   if(prev_calculated == 0)
   {
      Print("begin=", _begin, " ", EnumToString(InpHandleBegin));
      // we can adjust plot settings dynamically
      PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, _begin + Offset);
      // prepare arrays
      ArrayInitialize(Ema, EMPTY_VALUE);
      ArrayInitialize(EmaOfEma, EMPTY_VALUE);
      ArrayInitialize(EmaOfEmaOfEma, EMPTY_VALUE);
      ArrayInitialize(TemaBuffer, EMPTY_VALUE);
      Ema[_begin] = EmaOfEma[_begin] = EmaOfEmaOfEma[_begin] = price[_begin];
   }
   // main loop with respect to _begin
   for(int i = fmax(prev_calculated - 1, _begin);
      i < rates_total && !IsStopped(); i++)
   {
      EMA(price, Ema, i, _begin);
      EMA(Ema, EmaOfEma, i, _begin);
      EMA(EmaOfEma, EmaOfEmaOfEma, i, _begin);
      if(InpHandleBegin == CUSTOM) // empty data guard
      {
         if(Ema[i] == EMPTY_VALUE
         || EmaOfEma[i] == EMPTY_VALUE
         || EmaOfEmaOfEma[i] == EMPTY_VALUE)
            continue;
      }
      TemaBuffer[i] = 3 * Ema[i] - 3 * EmaOfEma[i] + EmaOfEmaOfEma[i];
   }
   return rates_total;
}
//+------------------------------------------------------------------+
//| Exponential Moving Average                                       |
//| Precondition: pos is in bounds of both arrays                    |
//+------------------------------------------------------------------+
void EMA(const double &source[], double &result[], const int pos, const int begin = 0)
{
   if(InpHandleBegin == CUSTOM) // empty data guard
   {
      if(source[pos] == EMPTY_VALUE || !MathIsValidNumber(source[pos]))
      {
         result[pos] = EMPTY_VALUE;
         return;
      }
      else
      if(pos > 0 && result[pos - 1] == EMPTY_VALUE)
      {
         result[pos] = source[pos];
         return;
      }
   }
   if(pos <= begin)
   {
      result[pos] = source[pos];
   }   
   else
   {
      result[pos] = source[pos] * K + result[pos - 1] * (1 - K);
   }
}
//+------------------------------------------------------------------+