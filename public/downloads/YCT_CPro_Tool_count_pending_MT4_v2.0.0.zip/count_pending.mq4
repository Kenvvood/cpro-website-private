//+------------------------------------------------------------------+
//|                                         CPro Tool count_pending MT4                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

// this EA will count all the pending orders                         |
// for the chart it has been placed on                               |
//                                                                   |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int OpenBuyOrders;
int OpenSellOrders;
int total;
int start()
  {
OpenBuyOrders=0;
OpenSellOrders=0;
total=0;
//Count Pending Stop Orders
   for(int i=0;i<OrdersTotal(); i++ )
   {
      if(OrderSelect(i, SELECT_BY_POS)==true)
         {
         if (OrderType()==OP_BUYSTOP)
            OpenBuyOrders++;
         if (OrderType()==OP_SELLSTOP)
            OpenSellOrders++;   
         }
total=OpenBuyOrders + OpenSellOrders;    
   }
   Comment ("buy_stop=",OpenBuyOrders,"   sell_stop=",OpenSellOrders,"   total=",total);
  }
//+------------------------------------------------------------------+