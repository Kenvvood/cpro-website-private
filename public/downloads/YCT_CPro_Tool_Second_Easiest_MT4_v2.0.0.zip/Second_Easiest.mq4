//+------------------------------------------------------------------+
//|                                         CPro Tool Second_Easiest MT4                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern double lot = 1;
extern double marketclosehour = 20; // on friday
int start()
  {
     double h1 = iHigh(NULL,1440,0);
     double l1 = iLow(NULL,1440,0); 
     double o1 = iOpen(NULL,1440,0);
     {
     if ((Bid>o1 && (o1-l1)>15*Point) && OrdersTotal()<1 && Hour()<16)
     OrderSend(Symbol(),OP_BUY,lot,Ask,0,0,0,"Easiest ever",0,0);
     if ((Ask<o1 && (h1-o1)>15*Point) && OrdersTotal()<1 && Hour()<16)
     OrderSend(Symbol(),OP_SELL,lot,Bid,0,0,0,"Easiest ever",0,0);
       {
          for (int i=0; i<OrdersTotal(); i++)
         {                                               
            if (OrderSelect(i,SELECT_BY_POS,MODE_TIME)==true)
             if (OrderType()==OP_BUY && Hour()>marketclosehour-1)
             OrderClose(OrderTicket(),OrderLots(),Bid,0,CLR_NONE);
            if (OrderType()==OP_SELL && Hour()>marketclosehour-1)
            OrderClose(OrderTicket(),OrderLots(),Ask,0,CLR_NONE);
         }   
       }
     }
   return(0);
  }
//+------------------------------------------------------------------+