//+------------------------------------------------------------------+
//|                                         CPro Indicator DeMarker MT5                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <MovingAverages.mqh>

//--- indicator settings
//--- input parameters
input int InpDeMarkerPeriod=14;//周期
//--- indicator buffers
double    ExtDeMarkerBuffer[];
double    ExtDeMaxBuffer[];
double    ExtDeMinBuffer[];
double    ExtAvgDeMaxBuffer[];
double    ExtAvgDeMinBuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
void OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,ExtDeMarkerBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,ExtDeMaxBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(2,ExtDeMinBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(3,ExtAvgDeMaxBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(4,ExtAvgDeMinBuffer,INDICATOR_CALCULATIONS);
//--- set accuracy
   IndicatorSetInteger(INDICATOR_DIGITS,3);
//--- sets first bar from what index will be drawn
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,InpDeMarkerPeriod);
//--- name for DataWindow and indicator subwindow label
   string short_name=StringFormat("DeM(%d)",InpDeMarkerPeriod);
   IndicatorSetString(INDICATOR_SHORTNAME,short_name);
  }
//+------------------------------------------------------------------+
//| DeMarker                                                         |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(rates_total<InpDeMarkerPeriod)
      return(0);
   int i,start;
//--- preliminary calculations
   if(prev_calculated==0)
     {
      ExtDeMaxBuffer[0]=0.0;
      ExtDeMinBuffer[0]=0.0;
      //--- filling out the array of True Range values for each period
      for(i=1; i<InpDeMarkerPeriod; i++)
        {
         if(high[i]>high[i-1])
            ExtDeMaxBuffer[i]=high[i]-high[i-1];
         else
            ExtDeMaxBuffer[i]=0.0;
         if(low[i-1]>low[i])
            ExtDeMinBuffer[i]=low[i-1]-low[i];
         else
            ExtDeMinBuffer[i]=0.0;
        }
      for(i=0; i<InpDeMarkerPeriod; i++)
         ExtDeMarkerBuffer[i]=0.0;
      start=InpDeMarkerPeriod-1;
     }
   else
      start=prev_calculated-1;
//--- the main loop of calculations
   for(i=start; i<rates_total && !IsStopped(); i++)
     {
      if(high[i]>high[i-1])
         ExtDeMaxBuffer[i]=high[i]-high[i-1];
      else
         ExtDeMaxBuffer[i]=0.0;
      if(low[i-1]>low[i])
         ExtDeMinBuffer[i]=low[i-1]-low[i];
      else
         ExtDeMinBuffer[i]=0.0;
      ExtAvgDeMaxBuffer[i]=SimpleMA(i,InpDeMarkerPeriod,ExtDeMaxBuffer);
      ExtAvgDeMinBuffer[i]=SimpleMA(i,InpDeMarkerPeriod,ExtDeMinBuffer);
      double dnum=ExtAvgDeMaxBuffer[i]+ExtAvgDeMinBuffer[i];
      if(dnum!=0)
         ExtDeMarkerBuffer[i]=ExtAvgDeMaxBuffer[i]/dnum;
      else
         ExtDeMarkerBuffer[i]=0.0;
     }
//--- OnCalculate done. Return new prev_calculated.
   return(rates_total);
  }
//+------------------------------------------------------------------+