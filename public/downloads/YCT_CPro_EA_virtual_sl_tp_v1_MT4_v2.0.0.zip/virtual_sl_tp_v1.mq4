//+------------------------------------------------------------------+
//|                                         CPro EA virtual_sl_tp_v1 MT4                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

// Input parameters
extern int StopLossPoints = 20;          // Initial Stop Loss in points
extern int TakeProfitPoints = 40;        // Initial Take Profit in points
extern double SpreadThreshold = 2.0;    // Spread threshold for virtual stop loss/take profit in points
extern int TrailingStopPoints = 10;      // Trailing stop in points for virtual pending order
extern bool EnableTrailing = false ;       // Enable or disable trailing stop
// Global variables
double initialSpread;
double virtualStopLoss, virtualTakeProfit;
double pendingOrderPrice;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
    // Store initial spread in pips
    initialSpread = MarketInfo(Symbol(), MODE_SPREAD) / Point;
    // Calculate initial virtual stop loss and take profit in pips
    virtualStopLoss = NormalizeDouble(Ask - StopLossPoints * Point, Digits) / Point;
    virtualTakeProfit = NormalizeDouble(Ask + TakeProfitPoints * Point, Digits) / Point;
    // Set pending order price
    pendingOrderPrice = NormalizeDouble(Ask + TrailingStopPoints * Point, Digits);
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
    // Check if spread has increased beyond threshold
    double currentSpread = MarketInfo(Symbol(), MODE_SPREAD) / Point;
    if (currentSpread > initialSpread + SpreadThreshold)
    {
        // Adjust virtual stop loss and take profit in pips
        virtualStopLoss = NormalizeDouble(virtualStopLoss + (currentSpread - initialSpread), Digits);
        virtualTakeProfit = NormalizeDouble(virtualTakeProfit + (currentSpread - initialSpread), Digits);
        // Adjust pending order price
        pendingOrderPrice = NormalizeDouble(pendingOrderPrice + (currentSpread - initialSpread), Digits);
    }
    // Check if the price hits the virtual stop loss or take profit
    if (Bid <= virtualStopLoss || Bid >= virtualTakeProfit)
    {
        // Close the position
        ClosePosition();
    }
    // Check if trailing stop is enabled and the price reaches the pending order price
    if (EnableTrailing && Ask >= pendingOrderPrice)
    {
        // Place the virtual pending order with trailing stop
        PlacePendingOrder();
    }
}
//+------------------------------------------------------------------+
//| Close the position                                               |
//+------------------------------------------------------------------+
void ClosePosition()
{
    if (OrderSelect(0, SELECT_BY_POS) && OrderClose(OrderTicket(), OrderLots(), MarketInfo(OrderSymbol(), MODE_BID), 3))
    {
        Print("Position closed at virtual stop loss or take profit");
    }
}
//+------------------------------------------------------------------+
//| Place the virtual pending order with trailing stop               |
//+------------------------------------------------------------------+
void PlacePendingOrder()
{
    double stopLoss = pendingOrderPrice - TrailingStopPoints * Point;
    double takeProfit = pendingOrderPrice + TakeProfitPoints * Point;
    if (OrderSend(Symbol(), OP_BUYSTOP, 0.1, pendingOrderPrice, 3, stopLoss, takeProfit, "Virtual Pending Order", 0, 0, clrNONE) > 0)
    {
        Print("Virtual pending order placed at ", pendingOrderPrice);
    }
    else
    {
        Print("Failed to place virtual pending order: ", GetLastError());
    }
}