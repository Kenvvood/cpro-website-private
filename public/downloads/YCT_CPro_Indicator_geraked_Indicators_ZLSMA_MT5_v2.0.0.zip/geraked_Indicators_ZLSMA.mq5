//+------------------------------------------------------------------+
//|                                         CPro Indicator geraked_Indicators_ZLSMA MT5      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


double B1[];
double B2[];
input int LRPeriod = 14;//周期
input bool HeikenAshi = true;//使用 heikenashi
#define PATH_HA "Indicators\\Examples\\Heiken_Ashi.ex5"
#define I_HA "::" + PATH_HA
#resource "\\" + PATH_HA
int HA_handle;
double HA_C[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, B1);
    PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, 0.0);
    ArraySetAsSeries(B1, true);
    SetIndexBuffer(1, B2, INDICATOR_CALCULATIONS);
    PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, 0.0);
    ArraySetAsSeries(B2, true);
    if (HeikenAshi) {
        HA_handle = iCustom(NULL, 0, I_HA);
        if (HA_handle < 0) {
            Print("Runtime error = ", GetLastError());
            return(INIT_FAILED);
        }
    }
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    ArraySetAsSeries(close, true);
    if (HeikenAshi && BarsCalculated(HA_handle) < rates_total) return(0);
    if (rates_total <= LRPeriod + 1) return(0);
    int limit = rates_total - prev_calculated;
    int hcnt = limit;
    if (limit > 1) {
        ArrayInitialize(B1, 0.0);
        ArrayInitialize(B2, 0.0);
        limit = rates_total - LRPeriod - 1;
        hcnt = rates_total;
    }
    if (HeikenAshi) {
        hcnt = MathMax(LRPeriod + 1, hcnt);
        if (CopyBuffer(HA_handle, 3, 0, hcnt, HA_C) != hcnt) Print("Err: ", GetLastError());
        ArraySetAsSeries(HA_C, true);
    }
    for (int pos = limit; pos >= 0; pos--) {
        B2[pos] = HeikenAshi ? LRMA(pos, LRPeriod, HA_C) : LRMA(pos, LRPeriod, close);
    }
    for (int pos = limit; pos >= 0; pos--) {
        B1[pos] = 2 * B2[pos] - LRMA(pos, LRPeriod, B2);
    }
    return(rates_total);
}
//+------------------------------------------------------------------+
//| Calculate LRMA                                                   |
//+------------------------------------------------------------------+
double LRMA(const int pos, const int period, const double &price[]) {
    double res = 0;
    double tmpS = 0, tmpW = 0, wsum = 0;;
    for (int i = 0; i < period; i++) {
        tmpS += price[pos + i];
        tmpW += price[pos + i] * (period - i);
        wsum += (period - i);
    }
    tmpS /= period;
    tmpW /= wsum;
    res = 3.0 * tmpW - 2.0 * tmpS;
    return res;
}
//+------------------------------------------------------------------+