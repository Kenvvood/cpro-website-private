//+------------------------------------------------------------------+
//|                                         CPro EA buy_order MT4                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//#include <HPCS_libfunctions_include.mqh>
bool check = true;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int count = 0;
int OnInit()
 {
 EventSetTimer(1);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
 /* while(CloseAllMarketOrders(16772,20)==0)
  {
   Print("calling Sleep______________");
   Sleep(20);
  }*/
  }
//+------------------------------------------------------------------+
void OnTimer()
{
 if(TimeSeconds(TimeCurrent())==count)
 { 
 string timesec = IntegerToString(TimeSeconds(TimeCurrent()));
 int ticket = OrderSend(Symbol(),OP_BUY,0.01,Ask,3,0,0,timesec,16772,0,clrGreen);
 if(ticket>0)
 Print("Buy Order Placed");
 else
 Print("OrderSend failed, error#",GetLastError());
 count++;
 if(count>59)
 ExpertRemove();
 }
}