//+------------------------------------------------------------------+
//|                                         CPro Tool 0Graal_CROSSmuvingi MT4                |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern int       FastPeriod=13;
extern int       SlowPeriod=34;
extern int       MomPeriod=14;
extern double    MomFilter=0.1;
extern double    PercentCapital=10.0;
extern double    Lots=0.1;
extern int       Slippage=3;
extern int       StopLoss=20;
extern int       TakeProfit=200;
extern int       ExpertMagicNumber=2002;
int myBars;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
  int cnt;
  double curFastMA=iMA(NULL,0,FastPeriod,0,MODE_EMA,PRICE_CLOSE,1);
  double curSlowMA=iMA(NULL,0,SlowPeriod,0,MODE_EMA,PRICE_OPEN,1);
  double prevFastMA=iMA(NULL,0,FastPeriod,0,MODE_EMA,PRICE_CLOSE,2);
  double prevSlowMA=iMA(NULL,0,SlowPeriod,0,MODE_EMA,PRICE_OPEN,2);
  double curMom=iMomentum(NULL,0,MomPeriod,PRICE_CLOSE,1)-100.0;
  double prevMom=iMomentum(NULL,0,MomPeriod,PRICE_CLOSE,2)-100.0;
//----
   if (Bars!=myBars)
      {
      myBars=Bars;
      if (curFastMA>curSlowMA && prevFastMA<prevSlowMA && curMom>MomFilter && curMom>prevMom)
         {
         if (OrdersTotal()>0)
            {
            for (cnt=OrdersTotal()-1;cnt>=0;cnt--)
               {
               OrderSelect(cnt, SELECT_BY_POS, MODE_TRADES);
               if (OrderType()==OP_SELL) {OrderClose(OrderTicket(),OrderLots(),Ask,Slippage,White);Sleep(30000);}
               }
            }
         OrderSend(Symbol(),OP_BUY,Lots,Ask,Slippage,0,Ask+TakeProfit*Point,"buy",ExpertMagicNumber,0,Blue);
         }
      if (curFastMA<curSlowMA && prevFastMA>prevSlowMA && curMom<-MomFilter && curMom<prevMom)
         {
         if (OrdersTotal()>0)
            {
            for (cnt=OrdersTotal()-1;cnt>=0;cnt--)
               {
               OrderSelect(cnt, SELECT_BY_POS, MODE_TRADES);
               if (OrderType()==OP_BUY) {OrderClose(OrderTicket(),OrderLots(),Bid,Slippage,White);Sleep(30000);}
               }
            }
         OrderSend(Symbol(),OP_SELL,Lots,Bid,Slippage,0,Bid-TakeProfit*Point,"sell",ExpertMagicNumber,0,Red);
         }
      }
//----
   return(0);
  }
//+------------------------------------------------------------------+