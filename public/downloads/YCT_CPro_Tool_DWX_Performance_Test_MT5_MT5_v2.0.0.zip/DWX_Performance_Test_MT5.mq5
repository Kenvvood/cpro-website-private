//+------------------------------------------------------------------+
//|                                         CPro Tool DWX_Performance_Test_MT5 MT5           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}

#include<Trade\Trade.mqh>

/*
this script will send 100 pending orders to compare the execution time to DWX_Connect. 
*/
//--- object for performing trade operations
CTrade  trade;
bool first = true;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit() {
   trade.SetAsyncMode(false);
   trade.SetTypeFilling(ORDER_FILLING_RETURN);  // will fill the complete order, there are also FOK and IOC modes: ORDER_FILLING_FOK, ORDER_FILLING_IOC. 
   trade.LogLevel(LOG_LEVEL_ERRORS);  // else it will print a lot on tester. 
   return INIT_SUCCEEDED;
}
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
}
//+------------------------------------------------------------------+
//| Expert tick function                                            |
//+------------------------------------------------------------------+
void OnTick() {
   if (first) {
      first = false;
      int n = 100;
      double openPrice = ask() - 0.01;  // ask() - 0.01
      long beforeOpen = GetTickCount();
      for (int i=0; i<n; i++) {
         bool res = trade.BuyLimit(0.01, openPrice, Symbol(), 0, 0, ORDER_TIME_GTC, 0, "");
         // bool res = trade.Buy(0.01, Symbol(), openPrice, 0, 0, "");
      }
      double openDuration = ((double)GetTickCount() - beforeOpen)/n;
      Sleep(2000);
      long beforeModification = GetTickCount();
      for (int i=OrdersTotal()-1; i>=0; i--) {
         ulong ticket = OrderGetTicket(i);
         if(!OrderSelect(ticket) || OrderGetInteger(ORDER_TYPE) != ORDER_TYPE_BUY_LIMIT) continue;
         bool res = trade.OrderModify(ticket, OrderGetDouble(ORDER_PRICE_OPEN), NormalizeDouble(openPrice-0.01, Digits()), OrderGetDouble(ORDER_TP), ORDER_TIME_GTC, 0);
      }
      // for filled positions:
      // for (int i=PositionsTotal()-1; i>=0; i--) {
      //    ulong ticket = PositionGetTicket(i);
      //    if (!PositionSelectByTicket(ticket) || PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_BUY) continue;
      //    bool res = trade.PositionModify(ticket, NormalizeDouble(openPrice-0.01, Digits()), PositionGetDouble(POSITION_TP ));
      // }
      double modifyDuration = ((double)GetTickCount() - beforeModification)/n;
      Sleep(2000);
      long beforeClose = GetTickCount();
      for (int i=OrdersTotal()-1; i>=0; i--) {
         ulong ticket = OrderGetTicket(i);
         if(!OrderSelect(ticket) || OrderGetInteger(ORDER_TYPE) != ORDER_TYPE_BUY_LIMIT) continue;
         bool res = trade.OrderDelete(ticket);
      }
      // for filled positions:
      // for (int i=PositionsTotal()-1; i>=0; i--) {
      //    ulong ticket = PositionGetTicket(i);
      //    if (!PositionSelectByTicket(ticket) || PositionGetInteger(POSITION_TYPE) != POSITION_TYPE_BUY) continue;
      //    bool res = trade.PositionClose(ticket);
      // }
      double closeDuration = ((double)GetTickCount() - beforeClose)/n;
      Print(StringFormat("Close duration: %.1f milliseconds per order", closeDuration));
      Print(StringFormat("Modify duration: %.1f milliseconds per order", modifyDuration));
      Print(StringFormat("Open duration: %.1f milliseconds per order", openDuration));
   }
}
MqlTick tick;
double ask() {
   if(SymbolInfoTick(Symbol(), tick)) return tick.ask;
   return SymbolInfoDouble(Symbol(), SYMBOL_ASK);
}