//+------------------------------------------------------------------+
//|                                         CPro Tool bLinRegrBuf MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//////////////////////////////////////////////////////////////////////
extern bool UseClose = true;
extern int  barsToCount=50;
double LR_line[];
double Sup_line[];
double Res_line[];
//////////////////////////////////////////////////////////////////////
int init()
{
   //IndicatorShortName("LinearRegressionChannel:"+barsToCount);
   SetIndexStyle(0,DRAW_LINE);
   SetIndexBuffer(0,LR_line);
   SetIndexEmptyValue(0,0.0);
   SetIndexStyle(1,DRAW_LINE);
   SetIndexBuffer(1,Sup_line);
   SetIndexEmptyValue(1,0.0);
   SetIndexStyle(2,DRAW_LINE);
   SetIndexBuffer(2,Res_line);
   SetIndexEmptyValue(2,0.0);
   return(0);
}
//////////////////////////////////////////////////////////////////////
int deinit()
{  
   return(0);
}
//////////////////////////////////////////////////////////////////////
int start()
{
   // variables
   double a,b,c,
          sumy=0.0,
          sumx=0.0,
          sumxy=0.0,
          sumx2=0.0,
          h=0.0,l=0.0;   
   int x;
   // calculate linear regression
   for(int i=0; i<barsToCount; i++)
   {
      sumy+=Close[i];
      sumxy+=Close[i]*i;
      sumx+=i;
      sumx2+=i*i;
   }
   c=sumx2*barsToCount-sumx*sumx;
   if(c==0.0)
   {
      Alert("Error in linear regression!");
      return;
   }
   // Line equation    
   b=(sumxy*barsToCount-sumx*sumy)/c;
   a=(sumy-sumx*b)/barsToCount;
   // Linear regression line in buffer
   for(x=0;x<barsToCount;x++)
      LR_line[x]=a+b*x;
   // Use PRICE_CLOSE for support-resistance
   if (UseClose)
     for(x=0;x<barsToCount;x++)
     {
       if(Close[x]-LR_line[x] > h) h = Close[x]-LR_line[x];
       if(LR_line[x] - Close[x]> l) l = LR_line[x] - Close[x];
     }  
   // Use HIGH - LOW
   else
     for(x=0;x<barsToCount;x++)
     {
       if(High[x]-LR_line[x] > h) h = High[x]-LR_line[x];
       if(LR_line[x] - Low[x]> l) l = LR_line[x] - Low[x];
     }
   // Drawing support - resistance lines   
   if (h>l)
   {
     for(x=0;x<barsToCount;x++)
     {
       Sup_line[x]=a-h+b*x;
       Res_line[x]=a+h+b*x;
     } 
   }
   else
   {
     for(x=0;x<barsToCount;x++)
     {
       Sup_line[x]=a-l+b*x;
       Res_line[x]=a+l+b*x;
     }
   }
   LR_line[x]  = 0.0;
   Sup_line[x] = 0.0;
   Res_line[x] = 0.0;
   return(0);
}