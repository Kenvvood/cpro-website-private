//+------------------------------------------------------------------+
//|                                         CPro Indicator MACrossAlerterV2 MT5              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


double indvalue[];
double slowma[];
int handle;
int max_bars;
input int slowPeriod = 200;//moving 均值 length
input int pointNum = 130;//amount of 点数 on 均线 crossover that should 启用 a 信号
double value_buf_a[];
double value_buf_b[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
   // ChartSetInteger(0, CHART_FOREGROUND, false);
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, value_buf_a);
    SetIndexBuffer(1, value_buf_b);
    SetIndexBuffer(2, indvalue); 
    PlotIndexSetInteger(0, PLOT_ARROW, 233);   
    PlotIndexSetInteger(1, PLOT_ARROW, 234);
    handle = iMA(_Symbol, PERIOD_CURRENT, slowPeriod, 0, MODE_SMA, PRICE_CLOSE);
    if (handle == INVALID_HANDLE){
        Print("Get MA Handle failed!");
        return INIT_FAILED;
    }
    ArrayInitialize(value_buf_a, 0.0);    
    ArrayInitialize(value_buf_b, 0.0);
    return INIT_SUCCEEDED;
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]){
    if (Bars(_Symbol, _Period) < rates_total)
      return (-1);
    // Copy data from indicator buffers
    CopyBuffer(handle, 0, 0, rates_total, slowma);
    // Calculate the indicator values
    for (int i = prev_calculated - (rates_total==prev_calculated); i < rates_total; i++){
         indvalue[i] = slowma[i];
         value_buf_a[i] = 0;
         value_buf_b[i] = 0; 
         // Check for MA crossovers
         if (i >= 0 && (i - 2) >= 0 && close[i] > (indvalue[i] + pointNum * _Point) && close[i - 2] < indvalue[i]){
            value_buf_a[i] = low[i];                 
         } 
         else{
            value_buf_a[i] = 0;
         }
         if (i >= 0 && (i - 2) >= 0 && close[i] < (indvalue[i] - pointNum * _Point) && close[i - 2] > indvalue[i]){      
            value_buf_b[i] = high[i];     
         }
         else{
            value_buf_b[i] = 0; 
         }  
    }
    return rates_total;
}
//+------------------------------------------------------------------+
void OnDeinit(const int reason){
    ArrayFree(slowma);
    IndicatorRelease(handle);
   CPro_Deinit();  // CPro营销模块清理
}