//+------------------------------------------------------------------+
//|                                         CPro Tool check_trade_time_func_ea MT4           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

input string TradeStartTime; //Trade Start Time (hh:mm)
input string TradeEndTime;   //Trade End Time (hh:mm)
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
  if(!CheckTradeTime(TradeStartTime,TradeEndTime))
  {
     Alert("Invalid time entry. Please enter valid start and end times.");
     ExpertRemove();
  }   
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
  }
//+------------------------------------------------------------------+
bool CheckTradeTime(string st,string et)
{
   int Strlen1=StringLen(st);
   int Strlen2=StringLen(et);
   int st1=0,st2=0,et1=0,et2=0;
   if((Strlen1==5) && (StringGetChar(st,2)==':'))
   {
      st1=StringToInteger(StringSubstr(st,0,2));
      st2=StringToInteger(StringSubstr(st,3,2));
      if((Strlen2==5) && (StringGetChar(et,2)==':'))
      {
         et1=StringToInteger(StringSubstr(et,0,2));
         et2=StringToInteger(StringSubstr(et,3,2));
      }
      else if((Strlen2==4) && (StringGetChar(et,1)==':'))
      {
         et1=StringToInteger(StringSubstr(et,0,1));
         et2=StringToInteger(StringSubstr(et,2,2));
      }
      else
      return false;
   } 
   else if((Strlen1==4) && (StringGetChar(st,1)==':'))   
   {
      st1=StringToInteger(StringSubstr(st,0,1));
      st2=StringToInteger(StringSubstr(st,2,2));
      if((Strlen2==5) && (StringGetChar(et,2)==':'))
      {
         et1=StringToInteger(StringSubstr(et,0,2));
         et2=StringToInteger(StringSubstr(et,3,2));
      }
      else if((Strlen2==4) && (StringGetChar(et,1)==':'))
      {
         et1=StringToInteger(StringSubstr(et,0,1));
         et2=StringToInteger(StringSubstr(et,2,2));
      }
      else
      return false;
   }
   else 
   return false;
   if((st1<0) || (st2<0) || (st1>23) || (st2>59) || (et1<0) || (et2<0) || (et1>23) || (et2>59))
   return false;
   else
   {
      datetime StartTime=StrToTime(st);     
      datetime EndTime=StrToTime(et);  
      datetime curr_time=TimeCurrent();
      if(StartTime<EndTime && curr_time>=StartTime && curr_time<EndTime)  
      return true;
      else
      return false;
   }   
}   