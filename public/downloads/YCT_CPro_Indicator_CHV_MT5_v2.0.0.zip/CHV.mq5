//+------------------------------------------------------------------+
//|                                         CPro Indicator CHV MT5                           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <MovingAverages.mqh>

//--- indicator settings
//--- enum
enum SmoothMethod
  {
   SMA=0,// Simple MA
   EMA=1 // Exponential MA
  };
//--- input parameters
input int          InpSmoothPeriod=10;//smoothing 周期
input int          InpCHVPeriod=10;//chv 周期
input SmoothMethod InpSmoothType=EMA;   // Smoothing method
//--- indicator buffers
double ExtCHVBuffer[];
double ExtHLBuffer[];
double ExtSHLBuffer[];
int    ExtSmoothPeriod,ExtCHVPeriod;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
void OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   string ma_name=EnumToString(InpSmoothType);
//--- check inputs
   if(InpSmoothPeriod<=0)
     {
      ExtSmoothPeriod=10;
      PrintFormat("Incorrect value for input variable InpSmoothPeriod=%d. Indicator will use value=%d for calculations.",InpSmoothPeriod,ExtSmoothPeriod);
     }
   else
      ExtSmoothPeriod=InpSmoothPeriod;
   if(InpCHVPeriod<=0)
     {
      ExtCHVPeriod=10;
      PrintFormat("Incorrect value for input variable InpCHVPeriod=%d. Indicator will use value=%d for calculations.",InpCHVPeriod,ExtCHVPeriod);
     }
   else
      ExtCHVPeriod=InpCHVPeriod;
//--- define buffers
   SetIndexBuffer(0,ExtCHVBuffer);
   SetIndexBuffer(1,ExtHLBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(2,ExtSHLBuffer,INDICATOR_CALCULATIONS);
//--- set draw begin
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,ExtSmoothPeriod+ExtCHVPeriod-1);
//--- set name and index label
   string params=StringFormat("(%d,%s)",ExtSmoothPeriod,ma_name);
   IndicatorSetString(INDICATOR_SHORTNAME,"Chaikin Volatility"+params);
   PlotIndexSetString(0,PLOT_LABEL,"CHV"+params);
//--- round settings
   IndicatorSetInteger(INDICATOR_DIGITS,1);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int i,pos,pos_chv;
//--- check for rates total
   pos_chv=ExtCHVPeriod+ExtSmoothPeriod-2;
   if(rates_total<pos_chv)
      return(0);
//--- start working
   if(prev_calculated<1)
      pos=0;
   else
      pos=prev_calculated-1;
//--- fill H-L(i) buffer
   for(i=pos; i<rates_total && !IsStopped(); i++)
      ExtHLBuffer[i]=high[i]-low[i];
//--- calculate smoothed H-L(i) buffer
   if(pos<ExtSmoothPeriod-1)
     {
      pos=ExtSmoothPeriod-1;
      for(i=0; i<pos; i++)
         ExtSHLBuffer[i]=0.0;
     }
   if(InpSmoothType==SMA)
      SimpleMAOnBuffer(rates_total,prev_calculated,0,ExtSmoothPeriod,ExtHLBuffer,ExtSHLBuffer);
   else
      ExponentialMAOnBuffer(rates_total,prev_calculated,0,ExtSmoothPeriod,ExtHLBuffer,ExtSHLBuffer);
//--- correct calc position
   if(pos<pos_chv)
      pos=pos_chv;
//--- calculate CHV buffer
   for(i=pos; i<rates_total && !IsStopped(); i++)
     {
      if(ExtSHLBuffer[i-ExtCHVPeriod]!=0.0)
         ExtCHVBuffer[i]=100.0*(ExtSHLBuffer[i]-ExtSHLBuffer[i-ExtCHVPeriod])/ExtSHLBuffer[i-ExtCHVPeriod];
      else
         ExtCHVBuffer[i]=0.0;
     }
//---
   return(rates_total);
  }
//+------------------------------------------------------------------+