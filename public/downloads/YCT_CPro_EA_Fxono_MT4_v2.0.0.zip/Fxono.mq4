//+------------------------------------------------------------------+
//|                                         CPro EA Fxono MT4                                |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//+------------------------------------------------------------------+
//| Expert variables                                                 |
//+------------------------------------------------------------------+
#define LABEL  225588
//--- Inputs
input double Lot = 0.1;
input int    Sl =  50;
input int    Tp =  50;
input int    TrailingStop = 0;
input bool   Week = true;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- create timer
   CPro_Init();  // CPro营销模块初始化
   EventSetTimer(60);      
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//--- destroy timer
   EventKillTimer();
  }
//+------------------------------------------------------------------+
//| Check for open order conditions                                  |
//+------------------------------------------------------------------+
void CheckForOpen()
{
   double ma;
   int    res;
   // week level start position
   if(Week == true)
     {
      ma= iOpen(NULL,PERIOD_W1,0);   
     }else{
      ma= iOpen(NULL,PERIOD_MN1,0);
     } 
   if(Open[1]<ma && Close[1]<ma)
     {
      res=OrderSend(Symbol(),OP_SELL,Lot,Bid,3,ma + Sl*Point*10,Bid - Tp*Point*10,"investFX",LABEL,0,Red);
      return;
     }
   //--- buy conditions
   if(Open[1]>ma && Close[1]>ma)
     {
      res=OrderSend(Symbol(),OP_BUY,Lot,Ask,3,ma - Sl*Point*10,Ask + Tp*Point*10,"investFX",LABEL,0,Green);
      return;
     }
}
void CheckForTrailing(){
   int Trailing = TrailingStop *10;
   int orders=OrdersTotal();
   for(int i=0;i<orders;i++)
     {
      if( OrderSelect(i,SELECT_BY_POS,MODE_TRADES) && OrderCloseTime()==0 ) {
             if( OrderType()==OP_BUY && OrderMagicNumber() == LABEL) {
               //--- check for trailing stop
               if(Trailing>0)
                 {
                  if(Bid-OrderOpenPrice()>Point*Trailing)
                    {
                     if(OrderStopLoss()<Bid-Point*Trailing)
                       {
                        //--- modify order and exit
                        if(!OrderModify(OrderTicket(),OrderOpenPrice(),Bid-Point*Trailing,OrderTakeProfit(),0,Green))
                           Print("OrderModify error ",GetLastError());
                        return;
                       }
                    }
                 }
              }
             }
             else if( OrderType()==OP_SELL && OrderMagicNumber() == LABEL) {
               //--- check for trailing stop
               if(Trailing>0)
                 {
                  if((OrderOpenPrice()-Ask)>(Point*Trailing))
                    {
                     if((OrderStopLoss()>(Ask+Point*Trailing)) || (OrderStopLoss()==0))
                       {
                        //--- modify order and exit
                        if(!OrderModify(OrderTicket(),OrderOpenPrice(),Ask+Point*Trailing,OrderTakeProfit(),0,Red))
                           Print("OrderModify error ",GetLastError());
                        return;
                       }
                    }
                 }
            }
      }
}  
void OnTick()
{
   if(Bars<10)return;  
   if(OrdersTotal() == 0)CheckForOpen();
   if(OrdersTotal() > 0)CheckForTrailing();
}
//+------------------------------------------------------------------+
//| Timer function                                                   |
//+------------------------------------------------------------------+
void OnTimer()
  {
  }
//+------------------------------------------------------------------+