//+------------------------------------------------------------------+
//|                                         CPro Indicator 9nix6_Indicators_MedianRenko_VEMA_Wilders_DMI MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <AZ-INVEST/CustomBarConfig.mqh>

//------------------------------------------------------------------
//
//
//
//
//
enum enVolume
{
   vol_noVolume,  // do not use volume
   vol_ticks,     // use ticks
   vol_real       // use real volume
};
//
//
//
//
//
input int       AdxPeriod    = 14;//ADX (dmi) 周期
input double    AdxLevel     = 20;//ADX指标 级别
input bool      ShowADX      = true;//ADX指标 visible
input bool      ShowADXR     = false;//ADX指标r visible
input enVolume  VolumeType   = vol_ticks;//交易量 to 使用
//
//
//
//
//
double DIp[];
double DIm[];
double ADX[];
double ADXR[];
double Level[];
//
//
//------------------------------------------------------------------
//                                                                  
//------------------------------------------------------------------
//
//
//
//
//
// Stub class to satisfy compilation - customChartIndicator from CustomBarConfig.mqh
class CCustomChartIndicatorStub
{
   public:
      void SetGetVolumesFlag() {}
};
CCustomChartIndicatorStub customChartIndicator;
//
//
//------------------------------------------------------------------
//
//
//
//
int OnInit()
{
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,DIp,INDICATOR_DATA);
   SetIndexBuffer(1,DIm,INDICATOR_DATA);
   SetIndexBuffer(2,ADX,INDICATOR_DATA);
   SetIndexBuffer(3,ADXR,INDICATOR_DATA);
   SetIndexBuffer(4,Level,INDICATOR_DATA);
   //
   //
   //
   //
   //
   IndicatorSetString(INDICATOR_SHORTNAME," VEMA Wilder's DMI ("+string(AdxPeriod)+")");
   customChartIndicator.SetGetVolumesFlag();
   return(0);
}
//------------------------------------------------------------------
//