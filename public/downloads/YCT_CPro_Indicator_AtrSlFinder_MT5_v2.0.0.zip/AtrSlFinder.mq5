//+------------------------------------------------------------------+
//|                                         CPro Indicator AtrSlFinder MT5                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input int Length = 14;
input double Multiplier = 1.5;
double Upper[];
double Lower[];
double C1[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, Upper);
    SetIndexBuffer(1, Lower);
    SetIndexBuffer(2, C1, INDICATOR_CALCULATIONS);
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    if (rates_total <= Length) return(0);
    int limit = rates_total - prev_calculated;
    if (limit == 0) limit = 1;
    ArraySetAsSeries(close, true);
    ArraySetAsSeries(high, true);
    ArraySetAsSeries(low, true);
    ArraySetAsSeries(Upper, true);
    ArraySetAsSeries(Lower, true);
    ArraySetAsSeries(C1, true);
    for (int i = 0; i < limit && !IsStopped(); i++) {
        if (i + 1 >= rates_total) break;
        double t = MathMax(high[i] - low[i], MathAbs(high[i] - close[i + 1]));
        C1[i] = MathMax(t, MathAbs(low[i] - close[i + 1]));
    }
    for (int i = 0; i < limit && !IsStopped(); i++) {
        if (i + 1 >= rates_total) break;
        double s = 0;
        for (int j = i; j < i + Length && j < rates_total; j++)
            s += C1[j];
        double ma = s / Length;
        Upper[i] = ma * Multiplier + high[i];
        Lower[i] = low[i] - ma * Multiplier;
    }
    return(rates_total);
}
//+------------------------------------------------------------------+