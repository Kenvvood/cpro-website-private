//+------------------------------------------------------------------+
//|                                         CPro Tool RunnerWF MT5                           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include "Main.mqh"

//+------------------------------------------------------------------+
//| Include                                                          |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
input long InpCharId = 0;             // Chart id padre
input string InpFileNameStart = "";   // Nombre del archivo temporal (comuniacion)
input bool InpCommonFolder = false;   // Common folder
//+------------------------------------------------------------------+
//| Global variables                                                 |
//+------------------------------------------------------------------+
CWfCallBack* g_callback;
CWorkflow g_wf;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
 {
//--- Ahora mismo solo inciaremos el callback
// Nota aqui el callback no solo escucha los eventos del wf
// Si no que sirve de comunicador entre el panel y la clase de wf
// CallBack
   CPro_Init();  // CPro营销模块初始化
  g_callback = new CWfCallBack();
  g_callback.Set(InpCharId, &g_wf, InpFileNameStart, InpCommonFolder);
  g_wf.AddCallBack(g_callback);
//---
  return(INIT_SUCCEEDED);
 }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
 {
   CPro_Deinit();  // CPro营销模块清理
//---
  if(CheckPointer(g_callback) == POINTER_DYNAMIC)
    delete g_callback;
 }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
 {
//---
 }
//+------------------------------------------------------------------+
//| ChartEvent function                                              |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,
                  const long &lparam,
                  const double &dparam,
                  const string &sparam)
 {
//---
// 1ero siempre el callback (escuhar eventos de inifio de wf)
  g_callback.ChartEvent(id, lparam, dparam, sparam);
// Luego el wf real el que corre
  g_wf.ChartEvent(id, lparam, dparam, sparam);
 }
//+------------------------------------------------------------------+