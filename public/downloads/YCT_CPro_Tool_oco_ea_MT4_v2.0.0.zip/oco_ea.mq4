//+------------------------------------------------------------------+
//|                                         CPro Tool OCO_EA MT4                             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+-----------------------------------------------------------------------+
//| Return the local time, \n, Bid Ask High Low                           |
//+-----------------------------------------------------------------------+
string dtbahl()
{
  string dt = "Local Time : "+ TimeToStr(LocalTime(),TIME_DATE|TIME_SECONDS)+
  "      "+((Time[0]-Time[1])/60)+" mins Chart"+"        tradeprocom@hotmail.com"+"\n"+
  "Bid :"+DoubleToStr(Bid,Digits)+" Ask :"+DoubleToStr(Ask,Digits) +
  " High :"+DoubleToStr(High[0],Digits)+" Low :"+DoubleToStr(Low[0],Digits);
  return (dt) ;
} 
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
  bool GlobalVar_init() 
  {
  bool InitGlobalVar = false;
  if(!GlobalVariableCheck("OCO_lots"))
  {
  GlobalVariableSet("OCO_lots",0.1); 
  InitGlobalVar = (InitGlobalVar || true);
  }
  if(!GlobalVariableCheck("OCO_tP_Pips"))
  {
  GlobalVariableSet("OCO_tP_Pips",300);
  InitGlobalVar = (InitGlobalVar || true);
  }
  if(!GlobalVariableCheck("OCO_sL_Pips"))
  {
  GlobalVariableSet("OCO_sL_Pips",300);
  InitGlobalVar = (InitGlobalVar || true);
  }
  //if(!GlobalVariableCheck("OCO_pips_Price"))
  //{
  //GlobalVariableSet("OCO_pips_Price",0);
  //InitGlobalVar = (InitGlobalVar || true);
  //}
  if(!GlobalVariableCheck("OCO_oCO"))
  {
  GlobalVariableSet("OCO_oCO",1);
  InitGlobalVar = (InitGlobalVar || true);
  }
  if(!GlobalVariableCheck("OCO_BUY_LIMIT"))
  {
  GlobalVariableSet("OCO_BUY_LIMIT",0);
  InitGlobalVar = (InitGlobalVar || true);
  }
  if(!GlobalVariableCheck("OCO_SELL_LIMIT"))
  {
  GlobalVariableSet("OCO_SELL_LIMIT",0);
  InitGlobalVar = (InitGlobalVar || true);
  }  
  if(!GlobalVariableCheck("OCO_BUY_STOP"))
  {
  GlobalVariableSet("OCO_BUY_STOP",0);
  InitGlobalVar = (InitGlobalVar || true);
  }
  if(!GlobalVariableCheck("OCO_SELL_STOP"))
  {
  GlobalVariableSet("OCO_SELL_STOP",0);
  InitGlobalVar = (InitGlobalVar || true);
  }
  if(!GlobalVariableCheck("OCO_confirmation"))
  {
  GlobalVariableSet("OCO_confirmation",0);
  InitGlobalVar = (InitGlobalVar || true);
  }
  return(InitGlobalVar);
  }  // End of bool GlobalVar_init() 
int init()
  {
//----
  GlobalVar_init() ; 
  reset_variable();
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
   void reset_variable()
   {
   GlobalVariableSet("OCO_BUY_LIMIT",0);
   GlobalVariableSet("OCO_SELL_LIMIT",0);
   GlobalVariableSet("OCO_BUY_STOP",0);
   GlobalVariableSet("OCO_SELL_STOP",0);
   GlobalVariableSet("OCO_confirmation",0);
   }
   int  ticket  = 0;
   double takeprofit = 0;
   double stoploss = 0;
  int start()
  {
  if (GlobalVariableGet("OCO_confirmation") == 1)
  {
  string DisplayTime = dtbahl();
  if (GlobalVariableGet("OCO_BUY_STOP")   > 0)
  DisplayTime = DisplayTime+"\n"+"BUY STOP  AT "+DoubleToStr(GlobalVariableGet("OCO_BUY_STOP"),Digits); 
  if (GlobalVariableGet("OCO_BUY_LIMIT")  > 0)
  DisplayTime = DisplayTime+"\n"+"BUY LIMIT AT "+DoubleToStr(GlobalVariableGet("OCO_BUY_LIMIT"),Digits); 
  if (GlobalVariableGet("OCO_SELL_LIMIT") > 0)
  DisplayTime = DisplayTime+"\n"+"SELL LIMIT AT "+DoubleToStr(GlobalVariableGet("OCO_SELL_LIMIT"),Digits); 
  if (GlobalVariableGet("OCO_SELL_STOP")  > 0)
  DisplayTime = DisplayTime+"\n"+"SELL STOP AT "+DoubleToStr(GlobalVariableGet("OCO_SELL_STOP"),Digits); 
  Comment(DisplayTime) ; 
  // Check GlobalVariableGet
  if (GlobalVariableGet("OCO_BUY_LIMIT") > 0 && Ask <= GlobalVariableGet("OCO_BUY_LIMIT"))
  {
  ticket=OrderSend(Symbol(),OP_BUY,GlobalVariableGet("OCO_lots"),Ask,0,0,0,"OCO_LIMIT_BUY",255,0,CLR_NONE);
    if (ticket>1 && OrderSelect(ticket, SELECT_BY_TICKET)==true)
    {
    OrderModify(ticket,OrderOpenPrice(),OrderOpenPrice()-GlobalVariableGet("OCO_sL_Pips")*Point,OrderOpenPrice()+GlobalVariableGet("OCO_tP_Pips")*Point,0,CLR_NONE);
    PlaySound("ok.wav");
    GlobalVariableSet("OCO_BUY_LIMIT",0); 
    if (GlobalVariableGet("OCO_oCO") == 1) reset_variable();
    }
  }
  if (GlobalVariableGet("OCO_SELL_LIMIT") > 0 && Bid >= GlobalVariableGet("OCO_SELL_LIMIT"))
  {
  ticket=OrderSend(Symbol(),OP_SELL,GlobalVariableGet("OCO_lots"),Bid,0,0,0,"OCO_LIMIT_SELL",255,0,CLR_NONE);
    if (ticket>1 && OrderSelect(ticket, SELECT_BY_TICKET)==true)
    {
    OrderModify(ticket,OrderOpenPrice(),OrderOpenPrice()+GlobalVariableGet("OCO_sL_Pips")*Point,(OrderOpenPrice()-GlobalVariableGet("OCO_tP_Pips")*Point),0,CLR_NONE);
    PlaySound("ok.wav");
    GlobalVariableSet("OCO_SELL_LIMIT",0); 
    if (GlobalVariableGet("OCO_oCO") == 1) reset_variable();
    }
  }
  if (GlobalVariableGet("OCO_BUY_STOP") > 0 && Ask >= GlobalVariableGet("OCO_BUY_STOP"))
  {
  ticket=OrderSend(Symbol(),OP_BUY,GlobalVariableGet("OCO_lots"),Ask,0,0,0,"OCO_BUY_STOP",255,0,CLR_NONE);
    if (ticket>1 && OrderSelect(ticket, SELECT_BY_TICKET)==true)
    {
    OrderModify(ticket,OrderOpenPrice(),OrderOpenPrice()-GlobalVariableGet("OCO_sL_Pips")*Point,OrderOpenPrice()+GlobalVariableGet("OCO_tP_Pips")*Point,0,CLR_NONE);
    PlaySound("ok.wav");
    GlobalVariableSet("OCO_BUY_STOP",0); 
    if (GlobalVariableGet("OCO_oCO") == 1) reset_variable();
    }
  }
  if (GlobalVariableGet("OCO_SELL_STOP") > 0 && Bid <= GlobalVariableGet("OCO_SELL_STOP"))
  {
  ticket=OrderSend(Symbol(),OP_SELL,GlobalVariableGet("OCO_lots"),Bid,0,0,0,"OCO_STOP_SELL",255,0,CLR_NONE);
    if (ticket>1 && OrderSelect(ticket, SELECT_BY_TICKET)==true)
    {
    OrderModify(ticket,OrderOpenPrice(),OrderOpenPrice()+GlobalVariableGet("OCO__sL_Pips")*Point,OrderOpenPrice()-GlobalVariableGet("OCO_tP_Pips")*Point,0,CLR_NONE);
    PlaySound("ok.wav");
    GlobalVariableSet("OCO_SELL_STOP",0);
    if (GlobalVariableGet("OCO_oCO") == 1) reset_variable();
    }
  }
  if (GlobalVariableGet("OCO_BUY_STOP") == 0 && GlobalVariableGet("OCO_BUY_LIMIT")  == 0 && 
  GlobalVariableGet("OCO_SELL_LIMIT") == 0 && GlobalVariableGet("OCO_SELL_LIMIT") ==0 )
  GlobalVariableSet("OCO_confirmation",0);  
  } // End Of if (GlobalVariableGet("OCO_Confirmation") == 1)
//----
   return(0);
  }
//+------------------------------------------------------------------+