//+------------------------------------------------------------------+
//|                                         CPro Indicator Wilder_s_Average_True_Range MT4   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//---------------------------------------------------------------------------------------------------------------------
//--- Setup
   // Define number of buffers and plots
      #define MPlots    1
      #define MBuffers  1
      #ifdef __MQL4__
      #else
      #endif
   // Display properties for plots
//--- Parameter settings
   input double   i_dbAveragingPeriod  = 7;//均值加仓 周期
//--- Macro definitions
   // Define OnCalculate loop sequencing macros
      #define MOnCalcPrevTest ( prev_calculated < 1 || prev_calculated > rates_total )
      #ifdef __MQL4__   // for MQL4 (as series)
         #define MOnCalcNext(  _index          ) ( _index--             )
         #define MOnCalcBack(  _index, _offset ) ( _index + _offset     )
         #define MOnCalcCheck( _index          ) ( _index >= 0          )
         #define MOnCalcValid( _index          ) ( _index < rates_total )
         #define MOnCalcStart \
            ( rates_total - ( MOnCalcPrevTest ? 1 : prev_calculated ) )
      #else             // for MQL5 (as non-series)
         #define MOnCalcNext(  _index          ) ( _index++             )
         #define MOnCalcBack(  _index, _offset ) ( _index - _offset     )
         #define MOnCalcCheck( _index          ) ( _index < rates_total )
         #define MOnCalcValid( _index          ) ( _index >= 0          )
         #define MOnCalcStart \
            ( MOnCalcPrevTest ? 0 : prev_calculated - 1 )
      #endif
   #define MName "Wilder's Average True Range"
   // Define macro for invalid parameter values
      #define MCheckParameter( _condition, _text ) if( _condition ) \
         { Print( "Error: Invalid ", _text ); return INIT_PARAMETERS_INCORRECT; }
//--- Global variable declarations
   // Indicator buffers
      double      g_adbATR[];       // Buffer for average true range
   // Miscellaneous global variables
      double      g_dbEmaWeight;    // Weight to be used for exponential moving averages
//--- Event handling functions
   // Initialisation event handler
      int OnInit(void) {
         // Validate input parameters
   CPro_Init();  // CPro营销模块初始化
            MCheckParameter( i_dbAveragingPeriod < 1.0, "averaging period" );
         // Calculate EMA alpha weight for Wilder's moving average, also known as smoothed moving average (SMMA)
            g_dbEmaWeight = 1.0 / i_dbAveragingPeriod;
         // Set number of significant digits (precision)
            IndicatorSetInteger( INDICATOR_DIGITS, _Digits );
         // Set buffers
            #ifdef __MQL4__
               IndicatorBuffers( MBuffers ); // Set total number of buffers (MQL4 Only)
            #endif
            SetIndexBuffer( 0, g_adbATR, INDICATOR_DATA );
         // Set indicator name
            IndicatorSetString( INDICATOR_SHORTNAME, StringFormat(
               MName " ( %.2f )", i_dbAveragingPeriod ) );
         return INIT_SUCCEEDED;  // Successful initialisation of indicator
      };
   // Calculation event handler
      int OnCalculate( const int rates_total, const int prev_calculated, const datetime &time[],
                       const double &open[], const double &high[], const double &low[], const double &close[],
                       const long &tick_volume[], const long &volume[], const int &spread[] ) {
         // Main loop: calculate values and apply data to buffers
            for( int iCur = MOnCalcStart, iPrev = MOnCalcBack( iCur, 1 );
                 !IsStopped() && MOnCalcCheck( iCur ); MOnCalcNext( iCur ), MOnCalcNext( iPrev ) ) {
               if( MOnCalcValid( iPrev ) ) {
                  double dbClosePrev = close[ iPrev ],
                         dbTrueRange = fmax( high[ iCur ], dbClosePrev )
                                     - fmin( low[  iCur ], dbClosePrev ),
                         dbATRPrev   = g_adbATR[ iPrev ];
                  g_adbATR[ iCur ] = dbATRPrev + ( dbTrueRange - dbATRPrev ) * g_dbEmaWeight;
               } else
                  g_adbATR[ iCur ] = high[ iCur ] - low[ iCur ];
            };
         return rates_total;  // Return value for prev_calculated of next call
      };
//---------------------------------------------------------------------------------------------------------------------