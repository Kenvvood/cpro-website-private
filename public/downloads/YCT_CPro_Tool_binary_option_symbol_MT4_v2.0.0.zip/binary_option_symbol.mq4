//+------------------------------------------------------------------+
//|                                         CPro Tool binary_option_symbol MT4               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
  /* for(int i=0;i<SymbolsTotal(false);i++)
   {
    if(StringSubstr(SymbolName(i,false),6)=="bo")
    Print(" ",SymbolName(i,false));
   }*/
   for(int i=0;i<SymbolsTotal(false);i++)
   {
    double profitcalc = MarketInfo(SymbolName(i,false),MODE_PROFITCALCMODE);
    double stoplevel = MarketInfo(SymbolName(i,false),MODE_STOPLEVEL);
    if(profitcalc==2 && stoplevel==0)
    Print(" ",SymbolName(i,false));
   }
 /*Print("EURUSDbo ",MarketInfo("EURUSD",MODE_EXPIRATION));
   Print("NAS100 ",MarketInfo("NAS100",MODE_EXPIRATION));
   Print("XAUUSD ",MarketInfo("XAUUSD",MODE_EXPIRATION));
   Print("EURGBP ",MarketInfo("EURGBP",MODE_EXPIRATION));*/
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
  }
//+------------------------------------------------------------------+