//+------------------------------------------------------------------+
//|                                         CPro Indicator AverageDayRange MT5               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <MovingAverages.mqh>

//--- plot ADR
//--- includes
//--- input parameters
input uint     InpLength   =  14;   // Length
//--- indicator buffers
double         ExtBufferADR[];
double         ExtBufferTMP[];
//--- global variables
int            period_sma;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,ExtBufferADR,INDICATOR_DATA);
   SetIndexBuffer(1,ExtBufferTMP,INDICATOR_CALCULATIONS);
//--- setting buffer arrays as timeseries
   ArraySetAsSeries(ExtBufferADR,true);
   ArraySetAsSeries(ExtBufferTMP,true);
//--- setting the period for calculating the moving average and a short name for the indicator
   period_sma=int(InpLength<2 ? 14 : InpLength);
   IndicatorSetString(INDICATOR_SHORTNAME,StringFormat("ADR(%lu)",period_sma));
//--- success
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
//--- checking for the minimum number of bars for calculation
   if(rates_total<period_sma)
      return 0;
//--- setting predefined indicator arrays as timeseries
   ArraySetAsSeries(high,true);
   ArraySetAsSeries(low,true);
//--- checking and calculating the number of bars to be calculated
   int limit=rates_total-prev_calculated;
   if(limit>1)
     {
      limit=rates_total-1;
      ArrayInitialize(ExtBufferADR,EMPTY_VALUE);
      ArrayInitialize(ExtBufferTMP,0);
     }
//--- calculation of price data
   for(int i=limit;i>=0;i--)
      ExtBufferTMP[i]=high[i]-low[i];
//--- calculation of a simple MA and return of the indicator calculation result for next call
   return(SimpleMAOnBuffer(rates_total,prev_calculated,0,period_sma,ExtBufferTMP,ExtBufferADR));
  }
//+------------------------------------------------------------------+