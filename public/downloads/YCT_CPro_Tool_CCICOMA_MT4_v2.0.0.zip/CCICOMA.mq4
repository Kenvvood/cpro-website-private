//+------------------------------------------------------------------+
//|                                         CPro Tool CCICOMA MT4                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#define SIGNAL_NONE 0
#define SIGNAL_BUY   1
#define SIGNAL_SELL  2
#define SIGNAL_CLOSEBUY 3
#define SIGNAL_CLOSESELL 4
extern int MagicNumber = 100000;
extern bool SignalMail = False;
extern bool EachTickMode = True;
extern double Lots = 1.0;
extern int Slippage = 3;
extern bool UseStopLoss = True;
extern int StopLoss = 18;
extern bool UseTakeProfit = True;
extern int TakeProfit = 40;
extern bool UseTrailingStop = True;
extern int TrailingStop = 30;
int BarCount;
int Current;
bool TickCheck = False;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init() {
   BarCount = Bars;
   if (EachTickMode) Current = 0; else Current = 1;
   return(0);
}
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit() {
   return(0);
}
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start() {
   int Order = SIGNAL_NONE;
   int Total, Ticket;
   double StopLossLevel, TakeProfitLevel;
   if (EachTickMode && Bars != BarCount) TickCheck = False;
   Total = OrdersTotal();
   Order = SIGNAL_NONE;
   //+------------------------------------------------------------------+
   //| Variable Begin                                                   |
   //+------------------------------------------------------------------+
double Buyc_1 = iCCI(NULL, 0, 3, PRICE_CLOSE, Current + 0);
double Buyc_2 = 0 &&  -73 && 73  && 100 && -100;
double Sellc_1 = iRSI(NULL, 0, 3, PRICE_MEDIAN, Current + 0);
double Sellc_2 = 0&& 73&& -73 && -100 && 100;
double Buy1_R = iRSI(NULL, 0, 3, PRICE_MEDIAN, Current + 0);
double Buy1_R1 = 30  &&  70;
double Sell1_R2 = iRSI(NULL, 0, 3, PRICE_MEDIAN, Current + 0);
double Sell1_R3 = 70 && 30;
double BuyC_1 = iClose(NULL, 0, Current + 0);
double BuyO_2 = iOpen(NULL, 0, Current + 0);
double SellC_1 = iClose(NULL, 0, Current + 0);
double SellO_2 = iOpen(NULL, 0, Current + 0);
double DD = iClose(NULL, 0, Current + 0);
double BB = iMA(NULL, PERIOD_M15, 1, 0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double EE = iMA(NULL, PERIOD_M15, 1, 0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy1_1 = iMA(NULL, PERIOD_M5, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy1_2 = iMA(NULL, PERIOD_M5, 1, 0, MODE_SMA,PRICE_TYPICAL, Current + 0);
double Buy2_1 = iMA(NULL, PERIOD_M15, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy2_2 = iMA(NULL, PERIOD_M15, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy3_1 = iMA(NULL, PERIOD_M30, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy3_2 = iMA(NULL, PERIOD_M30, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy4_1 = iMA(NULL, PERIOD_H1, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy4_2 = iMA(NULL, PERIOD_H1, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy5_1 = iMA(NULL, PERIOD_H4, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy5_2 = iMA(NULL, PERIOD_H4, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy6_1 = iMA(NULL, PERIOD_D1, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Buy6_2 = iMA(NULL, PERIOD_D1, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell1_1 = iMA(NULL, PERIOD_M5, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell1_2 = iMA(NULL, PERIOD_M5, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell2_1 = iMA(NULL, PERIOD_M15, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell2_2 = iMA(NULL, PERIOD_M15, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell3_1 = iMA(NULL, PERIOD_M30, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell3_2 = iMA(NULL, PERIOD_M30, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell4_1 = iMA(NULL, PERIOD_H1, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell4_2 = iMA(NULL, PERIOD_H1, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell5_1 = iMA(NULL, PERIOD_H4, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell5_2 = iMA(NULL, PERIOD_H4, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell6_1 = iMA(NULL, PERIOD_D1, 2,1, MODE_SMA, PRICE_TYPICAL, Current + 0);
double Sell6_2 = iMA(NULL, PERIOD_D1, 1,0, MODE_SMA, PRICE_TYPICAL, Current + 0);
   //+------------------------------------------------------------------+
   //| Variable End                                                     |
   //+------------------------------------------------------------------+
   //Check position
   bool IsTrade = False;
   for (int i = 0; i < Total; i ++) {
      OrderSelect(i, SELECT_BY_POS, MODE_TRADES);
      if(OrderType() <= OP_BUY &&  OrderSymbol() == Symbol()) {
         IsTrade = True;
         if(OrderType() == OP_SELL) {
            //Close
            //+------------------------------------------------------------------+
            //| Signal Begin(Exit Buy)                                           |
            //+------------------------------------------------------------------+
   //if ((Sell1_1 <= Sell1_2 && Sell2_1 <= Sell2_2 && Sell3_1 <= Sell3_2 && Sell4_1 <= Sell4_2 && Sell5_1 <= Sell5_2 && Sell6_1 <= Sell6_2)&&DD <=BB) Order = SIGNAL_CLOSEBUY;
            //+------------------------------------------------------------------+
            //| Signal End(Exit Buy)                                             |
            //+------------------------------------------------------------------+
            if (Order == SIGNAL_CLOSEBUY && ((EachTickMode && !TickCheck) || (!EachTickMode && (Bars != BarCount)))) {
               OrderClose(OrderTicket(), OrderLots(), Bid, Slippage, MediumSeaGreen);
               if (SignalMail) SendMail("[Signal Alert]", "[" + Symbol() + "] " + DoubleToStr(Bid, Digits) + " Close Buy");
               if (!EachTickMode) BarCount = Bars;
               IsTrade = False;
               continue;
            }
            //Trailing stop
            if(UseTrailingStop && TrailingStop > 0) {                 
               if(Bid - OrderOpenPrice() > Point * TrailingStop) {
                  if(OrderStopLoss() < Bid - Point * TrailingStop) {
                     OrderModify(OrderTicket(), OrderOpenPrice(), Bid - Point * TrailingStop, OrderTakeProfit(), 0, MediumSeaGreen);
                     if (!EachTickMode) BarCount = Bars;
                     continue;
                  }
               }
            }
         } else {
            //Close
            //+------------------------------------------------------------------+
            //| Signal Begin(Exit Sell)                                          |
            //+------------------------------------------------------------------+
            //if ((Buy1_1 >= Buy1_2 && Buy2_1 >= Buy2_2 && Buy3_1 >= Buy3_2 && Buy4_1 >= Buy4_2 && Buy5_1 >= Buy5_2 && Buy6_1 >= Buy6_2)&& DD>=BB) Order = SIGNAL_CLOSESELL;
            //+------------------------------------------------------------------+
            //| Signal End(Exit Sell)                                            |
            //+------------------------------------------------------------------+
            if (Order == SIGNAL_CLOSESELL && ((EachTickMode && !TickCheck) || (!EachTickMode && (Bars != BarCount)))) {
               OrderClose(OrderTicket(), OrderLots(), Ask, Slippage, DarkOrange);
               if (SignalMail) SendMail("[Signal Alert]", "[" + Symbol() + "] " + DoubleToStr(Ask, Digits) + " Close Sell");
               if (!EachTickMode) BarCount = Bars;
               IsTrade = False;
               continue;
            }
            //Trailing stop
            if(UseTrailingStop && TrailingStop > 0) {                 
               if((OrderOpenPrice() - Ask) > (Point * TrailingStop)) {
                  if((OrderStopLoss() > (Ask + Point * TrailingStop)) || (OrderStopLoss() == 0)) {
                     OrderModify(OrderTicket(), OrderOpenPrice(), Ask + Point * TrailingStop, OrderTakeProfit(), 0, DarkOrange);
                     if (!EachTickMode) BarCount = Bars;
                     continue;
                  }
               }
            }
         }
      }
   }
   //+------------------------------------------------------------------+
   //| Signal Begin(Entry)                                              |
   //+------------------------------------------------------------------+
    //if (BuyC_1 > BuyO_2) Order = SIGNAL_BUY;
   //if (SellC_1 < SellO_2) Order = SIGNAL_SELL;
     //if (Buy1_R >= Buy1_R1) Order = SIGNAL_BUY;
   //if (Sell1_R2 <= Sell1_R3) Order = SIGNAL_SELL;
   //if (Buyc_1 <= Buyc_2) Order = SIGNAL_BUY;
   //if (Sellc_1 >= Sellc_2) Order = SIGNAL_SELL;
   if (((Buyc_1 >= Buyc_2&&Buy1_1 >= Buy1_2 && Buy2_1 >= Buy2_2 && Buy3_1 >= Buy3_2 && Buy4_1 >= Buy4_2 && Buy5_1 >= Buy5_2 && Buy6_1 >= Buy6_2)&& DD >= BB && DD >= EE)&&BuyC_1 >= BuyO_2 && Buy1_R >= Buy1_R1) Order = SIGNAL_BUY;
if (((Buyc_1 <= Buyc_2&&Buy1_1 <= Buy1_2 && Buy2_1 <= Buy2_2 && Buy3_1 <= Buy3_2 && Buy4_1 <= Buy4_2 && Buy5_1 <= Buy5_2 && Buy6_1 <= Buy6_2)&& DD <= BB && DD <= EE)&&BuyC_1 <= BuyO_2 && Buy1_R <= Buy1_R1) Order = SIGNAL_SELL;
  // if (((Sellc_1 <= Sellc_2&&Sell1_1 <= Sell1_2 && Sell2_1 <= Sell2_2 && Sell3_1 <= Sell3_2 && Sell4_1 <= Sell4_2 && Sell5_1 <= Sell5_2 && Sell6_1 <= Sell6_2)&& DD <=BB && DD <= EE  )&&SellC_1 < SellO_2 && Sell1_R2 <= Sell1_R3)Order = SIGNAL_SELL;
   //+------------------------------------------------------------------+
   //| Signal End                                                       |
   //+------------------------------------------------------------------+
   //Buy
   if (Order == SIGNAL_BUY && ((EachTickMode && !TickCheck) || (!EachTickMode && (Bars != BarCount)))) {
      if(!IsTrade) {
         //Check free margin
         if (AccountFreeMargin() < (1000 * Lots)) {
            Print("We have no money. Free Margin = ", AccountFreeMargin());
            return(0);
         }
         if (UseStopLoss) StopLossLevel = Ask - StopLoss * Point; else StopLossLevel = 0.0;
         if (UseTakeProfit) TakeProfitLevel = Ask + TakeProfit * Point; else TakeProfitLevel = 0.0;
         Ticket = OrderSend(Symbol(), OP_BUY, Lots, Ask, Slippage, StopLossLevel, TakeProfitLevel, "Buy(#" + MagicNumber + ")", MagicNumber, 0, DodgerBlue);
         if(Ticket > 0) {
            if (OrderSelect(Ticket, SELECT_BY_TICKET, MODE_TRADES)) {
				Print("BUY order opened : ", OrderOpenPrice());
                if (SignalMail) SendMail("[Signal Alert]", "[" + Symbol() + "] " + DoubleToStr(Ask, Digits) + " Open Buy");
			} else {
				Print("Error opening BUY order : ", GetLastError());
			}
         }
         if (EachTickMode) TickCheck = True;
         if (!EachTickMode) BarCount = Bars;
         return(0);
      }
   }
   //Sell
   if (Order == SIGNAL_SELL && ((EachTickMode && !TickCheck) || (!EachTickMode && (Bars != BarCount)))) {
      if(!IsTrade) {
         //Check free margin
         if (AccountFreeMargin() < (1000 * Lots)) {
            Print("We have no money. Free Margin = ", AccountFreeMargin());
            return(0);
         }
         if (UseStopLoss) StopLossLevel = Bid + StopLoss * Point; else StopLossLevel = 0.0;
         if (UseTakeProfit) TakeProfitLevel = Bid - TakeProfit * Point; else TakeProfitLevel = 0.0;
         Ticket = OrderSend(Symbol(), OP_SELL, Lots, Bid, Slippage, StopLossLevel, TakeProfitLevel, "Sell(#" + MagicNumber + ")", MagicNumber, 0, DeepPink);
         if(Ticket > 0) {
            if (OrderSelect(Ticket, SELECT_BY_TICKET, MODE_TRADES)) {
				Print("SELL order opened : ", OrderOpenPrice());
                if (SignalMail) SendMail("[Signal Alert]", "[" + Symbol() + "] " + DoubleToStr(Bid, Digits) + " Open Sell");
			} else {
				Print("Error opening SELL order : ", GetLastError());
			}
         }
         if (EachTickMode) TickCheck = True;
         if (!EachTickMode) BarCount = Bars;
         return(0);
      }
   }
   if (!EachTickMode) BarCount = Bars;
   return(0);
}
//+------------------------------------------------------------------+