//+------------------------------------------------------------------+
//|                                         CPro Tool PriceActionMultiPostionV28_08_08_20 MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include<Trade\Trade.mqh>
#include <Expert\Trailing\TrailingNone.mqh>
#include <Expert\Money\MoneyFixedLot.mqh>

//+------------------------------------------------------------------+
//| Include                                                          |
//+------------------------------------------------------------------+
  // include the file Trade.mqh
// Create an instance of Ctrade
CTrade trade;
//--- available trailing
//--- available money management
//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
//--- inputs for main signal
input static double             Signal_TakeLevel     =90.0;//take 利润 级别 (in 点数)
input double                      Price_Trigger        =50.0;//价格 trigger
input static double                       Close_All_Trigger    =600.0;//平仓 all 交易s trigger
input int                          Balance_Range         =200.0;//余额 trigger
input int                          Max_Positions_Total   =700.0;//均线x positions to be held
input int                        Number_Of_Levels     =10.0;//# of 级别s
//--- inputs for money
input double                          Money_FixLot_Percent =1.0;//百分比
input double                          Money_FixLot_Lots    =0.10;//固定交易量
//+------------------------------------------------------------------+
//| Global expert object                                             |
//+------------------------------------------------------------------+
//CExpert ExtExpert;
//+------------------------------------------------------------------+
//| Initialization function of the expert                            |
//+------------------------------------------------------------------+
 static double High_Since_Open=0.0;
 static double Low_Since_Open=99999999;
void OnTick()
{
   // Get the ask & bid price
   double Ask=NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_ASK),4);
   double Bid=NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),4);  
      //Get the Account Balance
   double Balance=AccountInfoDouble(ACCOUNT_BALANCE);
   //Get the Account Equity
   double Equity=AccountInfoDouble(ACCOUNT_EQUITY);  
   //Get the Account Margin Free
  double Free_Margin=AccountInfoDouble(ACCOUNT_MARGIN_FREE); 
  //Get the Account Margin
  double Account_Margin=AccountInfoDouble(ACCOUNT_MARGIN);
  //Get total positions
  int Total_Positions=PositionsTotal();
  // Calculate the deposit load
  double Deposit_Load = Account_Margin/Equity;
  //Create an equity starting point
 static double Base_Price=0;
  if (PositionsTotal()==0)
  {
  Base_Price=Ask;
  }
  // ++++++++++++ Add High and Low Price Counters to set off levels
              if(PositionsTotal()>=1 && Bid*-1>Base_Price*-1)  
        {
        Low_Since_Open=Bid;
        }
        else
        {
        Low_Since_Open=99999999;
        }
             if(PositionsTotal()>=1 && Ask>Base_Price)  
        {
        High_Since_Open=Ask;
        } 
        else
        {
        High_Since_Open=0.0;
        }
 //+++++++++++++Putting Highs and Lows Into An Array++++++++++++
    // create arrays for highes and lowest candle
   double High_Since_Open_Array[], Low_Since_Open_Array[];
   // sort array downwards from the current candle
   ArraySetAsSeries(High_Since_Open_Array,true);
   // sort array downwards from the current candle
   ArraySetAsSeries(Low_Since_Open_Array,true);
   // Fill array with data for 10 candles -- CopyHigh is part of a series of functions we could use to copy what we need for our strategy -- "we need the data from candle 0 for 10 candles
  CopyHigh(_Symbol,_Period,0,10,High_Since_Open_Array);
    // Fill array with data for 10 candles
    CopyLow(_Symbol,_Period,0,10,Low_Since_Open_Array); 
      //Create an Array for prices
      MqlRates PriceInformation[];
      // Sort it from current candle to oldest candle
      ArraySetAsSeries(PriceInformation,true);
   //Copy price data into the array ------ old text that was in place of 50 --- Bars(Symbol(),Period())
      int Data=CopyRates(Symbol(),_Period,0,10,PriceInformation);
 //ORDER HISTORY PROFIT TUTORIAL START
   uint   TotalNumberOfDeals=HistoryDealsTotal();
   ulong  TicketNumber=0;
   long   OrderType, DealEntry;
   double OrderProfit=0;
   string MySymbol="";
   string PositionDirection="";
   string MyResult="";
 static  double open_price=0;
 double Position_Volume;
   //get the history
   HistorySelect(0,TimeCurrent());
   //go through all the deals
   for(uint i=0; i<TotalNumberOfDeals;i++)
   {
      //we look for a ticket number  -- use an if statement, because if there are no open positions this avoids an error
      if((TicketNumber=HistoryDealGetTicket(i))>0)
         {
         //Get the profit
         OrderProfit=HistoryDealGetDouble(TicketNumber,DEAL_PROFIT);
         // get the type
         OrderType = HistoryDealGetInteger(TicketNumber,DEAL_TYPE);
         //get the currency pair
         MySymbol=HistoryDealGetString(TicketNumber,DEAL_SYMBOL);
         //get the deal entry type to check for close types
         DealEntry=HistoryDealGetInteger(TicketNumber,DEAL_ENTRY);
         open_price=HistoryDealGetDouble(TicketNumber,DEAL_PRICE);
  //==================================================================
         //If the currency pair fits
         if (MySymbol==_Symbol)
         //if it is a buy or a sell order
         if(OrderType==ORDER_TYPE_BUY || OrderType==ORDER_TYPE_SELL)
         //if the order was closed
         if (DealEntry==1)
         {
            // set sell order type if close type was buy
            if (OrderType==ORDER_TYPE_BUY)
            PositionDirection="SELL-TRADE";
            //set buy order type if close type was sell
            if (OrderType==ORDER_TYPE_SELL)
            PositionDirection="BUY-TRADE";
        //    MyResult = "Profit:"+OrderProfit+ "Ticket:" +TicketNumber+ "Position Direction:"+PositionDirection;  
  //ORDER HISTORY PROFIT TUTORIAL END
 }
   }
      }
     if(PositionsTotal()<1)
     {
      trade.Buy(Money_FixLot_Percent*0.01,NULL,Ask,NULL,(Ask+Signal_TakeLevel*_Point),NULL);
         }
      //check all open positions for the current symbol +++++++++++++++++++++++++++++CHANGED i=PositionsTotal ()-1; i>=0
      for(int i=PositionsTotal()-1; i>=0; i--) // count all currency pair positions
      {
         string symbol=PositionGetSymbol(i); // get position symbol
            if(_Symbol==symbol) // if chart symbol equals position symbol
               // get the ticket number
               ulong PositionTicket=PositionGetInteger(POSITION_TICKET);   
               //get the current Stop Loss
               double CurrentStopLoss=PositionGetDouble(POSITION_SL);
                              //get the open price
           //    double open_price=PositionGetDouble(POSITION_PRICE_OPEN);
            //   datetime open_start_time=PositionGetDouble(POSITION_TIME_MSC);
            }
      if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
         if(Ask>=open_price+Price_Trigger*_Point)
            if(PositionsTotal()<=Max_Positions_Total)
              trade.Buy(Money_FixLot_Percent,NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL);
       if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
         if(Bid<=open_price-Price_Trigger*_Point)
            if(PositionsTotal()<=Max_Positions_Total)
             trade.Sell(Money_FixLot_Percent, NULL, Bid, 0, (Bid-Signal_TakeLevel*_Point),NULL);
      //  
      //++++++++++++++Balancing Trades+++++++
      //Buy & Sell Counter Variables
  int Buy_Position_Counter=0;
  int Sell_Position_Counter=0;    
    // count down until there are no positions left
   for(int i=PositionsTotal()-1; i>=0; i--) // go through all positions
   {
         //Get the ticket number for the current position
         int ticket=PositionGetTicket(i);
         // Get the position volume
         Position_Volume=PositionGetDouble(POSITION_VOLUME);
         // Get the positon direction
         int PositionDirection=PositionGetInteger(POSITION_TYPE);
         //if it is a buy position
         if (PositionDirection==POSITION_TYPE_BUY)
         //close the current position add to buy counter here
               // add 1 to the candleCounter
      Buy_Position_Counter=Buy_Position_Counter+1;
               //if it is a buy position
         if (PositionDirection==POSITION_TYPE_SELL)
         //close the current position add to buy counter here
               // add 1 to the candleCounter
      Sell_Position_Counter=Sell_Position_Counter+1;
   }//End for loop
      // Pull the counters into the logic for buying/selling balance trades
  if((Buy_Position_Counter-Sell_Position_Counter)>=Balance_Range)
             trade.Sell((Money_FixLot_Percent),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL);
  if((Sell_Position_Counter-Buy_Position_Counter)>=Balance_Range)
              trade.Buy((Money_FixLot_Percent),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL);  
      //if we have a profit, close all positions "if the equity is above the balance, that means we made a profit"  +++++++  Equity>=Balance)Free_Margin<=0 || 
   if (Ask>=(Base_Price+(Close_All_Trigger*_Point)) || Bid<(Base_Price-(Close_All_Trigger*_Point)))
         {
            CloseAllPositions();
         }
double Level_Size;
Level_Size=(Close_All_Trigger*_Point)/Number_Of_Levels;
double  B_Level1;
double  B_Level2;
double  B_Level3;
double  B_Level4;
double  B_Level5;
double  B_Level6;
double  B_Level7;
double  B_Level8;
double  B_Level9;
double  B_Level10;
double  B_Level11;
double  B_Level12;
B_Level1 = (1*Level_Size)+ Base_Price;
B_Level2 = (2*Level_Size)+ Base_Price;
B_Level3 = (3*Level_Size)+ Base_Price;
B_Level4 = (4*Level_Size)+ Base_Price;
B_Level5 = (5*Level_Size)+ Base_Price;
B_Level6 = (6*Level_Size)+ Base_Price;
B_Level7 = (7*Level_Size)+ Base_Price;
B_Level8 = (8*Level_Size)+ Base_Price;
B_Level9 = (9*Level_Size)+ Base_Price;
B_Level10 = (10*Level_Size)+ Base_Price;
B_Level11 = (11*Level_Size)+ Base_Price;
B_Level12 = (12*Level_Size)+ Base_Price;
if(High_Since_Open>=B_Level1)
          if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
            if(High_Since_Open_Array[0]<B_Level1)
   {
            trade.Buy(Money_FixLot_Percent,NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }
  if(High_Since_Open>=B_Level2)
         if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                        if(High_Since_Open_Array[0]<B_Level2)
   {
            trade.Buy((Money_FixLot_Percent*2),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }           
   if(High_Since_Open>=B_Level3)
          if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
           if(High_Since_Open_Array[0]<B_Level3)
   {
            trade.Buy((Money_FixLot_Percent*3),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }      
   if(High_Since_Open>=B_Level4)
             if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                if(High_Since_Open_Array[0]<B_Level4)
   {
            trade.Buy((Money_FixLot_Percent*4),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }   
     if(High_Since_Open>=B_Level5)
             if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                if(High_Since_Open_Array[0]<B_Level5)
   {
            trade.Buy((Money_FixLot_Percent*5),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            } 
      if(High_Since_Open>=B_Level6)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                   if(High_Since_Open_Array[0]<B_Level6)
   {
            trade.Buy((Money_FixLot_Percent*6),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }     
      if(High_Since_Open>=B_Level7)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                   if(High_Since_Open_Array[0]<B_Level7)
   {
            trade.Buy((Money_FixLot_Percent*7),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }
       if(High_Since_Open>=B_Level8)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                   if(High_Since_Open_Array[0]<B_Level8)
   {
            trade.Buy((Money_FixLot_Percent*8),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }      
      if(High_Since_Open>=B_Level9)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                   if(High_Since_Open_Array[0]<B_Level9)
   {
            trade.Buy((Money_FixLot_Percent*9),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }
       if(High_Since_Open>=B_Level10)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                   if(High_Since_Open_Array[0]<B_Level10)
   {
            trade.Buy((Money_FixLot_Percent*10),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }      
       if(High_Since_Open>=B_Level11)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                   if(High_Since_Open_Array[0]<B_Level11)
   {
            trade.Buy((Money_FixLot_Percent*11),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }   
       if(High_Since_Open>=B_Level12)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                   if(High_Since_Open_Array[0]<B_Level12)
   {
            trade.Buy((Money_FixLot_Percent*12),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL); 
            }
// +++++++++++++++++++++++ Begin Sell Level Code  ++++++++++++++++++++++++++++++++++
double  S_Level1;
double  S_Level2;
double  S_Level3;
double  S_Level4;
double  S_Level5;
double  S_Level6;
double  S_Level7;
double  S_Level8;
double  S_Level9;
double  S_Level10;
double  S_Level11;
double  S_Level12;
S_Level1 = (-1*Level_Size)+ Base_Price;
S_Level2 = (-2*Level_Size)+ Base_Price;
S_Level3 = (-3*Level_Size)+ Base_Price;
S_Level4 = (-4*Level_Size)+ Base_Price;
S_Level5 = (-5*Level_Size)+ Base_Price;
S_Level6 = (-6*Level_Size)+ Base_Price;
S_Level7 = (-7*Level_Size)+ Base_Price;
S_Level8 = (-8*Level_Size)+ Base_Price;
S_Level9 = (-9*Level_Size)+ Base_Price;
S_Level10 = (-10*Level_Size)+ Base_Price;
S_Level11 = (-11*Level_Size)+ Base_Price;
S_Level12 = (-12*Level_Size)+ Base_Price;
if(Low_Since_Open<=S_Level1)
          if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
             if(Low_Since_Open_Array[0]>S_Level1)
   {
            trade.Sell((Money_FixLot_Percent),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }
 if(Low_Since_Open<=S_Level2)
          if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
            if(Low_Since_Open_Array[0]>S_Level2)
   {
            trade.Sell((Money_FixLot_Percent*2),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }           
  if(Low_Since_Open<=S_Level3)
          if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
            if(Low_Since_Open_Array[0]>S_Level3)
   {
            trade.Sell((Money_FixLot_Percent*3),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }      
   if(Low_Since_Open<=S_Level4)
             if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
               if(Low_Since_Open_Array[0]>S_Level4)
   {
            trade.Sell((Money_FixLot_Percent*4),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }   
     if(Low_Since_Open<=S_Level5)
             if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
               if(Low_Since_Open_Array[0]>S_Level5)
   {
            trade.Sell((Money_FixLot_Percent*5),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            } 
      if(Low_Since_Open<=S_Level6)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                  if(Low_Since_Open_Array[0]>S_Level6)
   {
            trade.Sell((Money_FixLot_Percent*6),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }     
      if(Low_Since_Open<=S_Level7)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                  if(Low_Since_Open_Array[0]>S_Level7)
   {
            trade.Sell((Money_FixLot_Percent*7),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }
       if(Low_Since_Open<=S_Level8)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                  if(Low_Since_Open_Array[0]>S_Level8)
   {
            trade.Sell((Money_FixLot_Percent*8),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }      
      if(Low_Since_Open<=S_Level9)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                  if(Low_Since_Open_Array[0]>S_Level9)
   {
            trade.Sell((Money_FixLot_Percent*9),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }
       if(Low_Since_Open<=S_Level10)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                  if(Low_Since_Open_Array[0]>S_Level10)
   {
            trade.Sell((Money_FixLot_Percent*10),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }      
       if(Low_Since_Open<=S_Level11)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                  if(Low_Since_Open_Array[0]>S_Level11)
   {
            trade.Sell((Money_FixLot_Percent*11),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }   
       if(Low_Since_Open<=S_Level12)
                if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
                  if(Low_Since_Open_Array[0]>S_Level12)
   {
            trade.Sell((Money_FixLot_Percent*12),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL); 
            }
}// End of OnTick
// EXTERNAL CLOSE FUNCTION 
void CloseAllPositions()
   {
   // from the number of positions count down to zero
   for(int i=PositionsTotal()-1; i>=0; i--) //look at all positions
   {
      // get the ticket number for the current position
      int ticket=PositionGetTicket(i);
      // close the current postion
      trade.PositionClose(ticket);
   }   // End the for loop
 } // CloseAllPositions end