//+------------------------------------------------------------------+
//|                                         CPro Tool sltp_currency MT4                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

// this EA will use the deposit currency as stop loss and take profit|
// for each trade. It does NOT use pips to measure values.           |
// Once profit or loss has been reached it will close the entire trade|
//                                                                   |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
extern double stop_loss=8;     // stop loss input in currency    
extern double take_profit=5;   // take profit input in currency
int i;
int ticket;
int start()  {                 //start of prog
if(OrdersTotal() !=0) // if total orders are not zero
{
int total = OrdersTotal(); // the word total represents total orders
for(i = total - 1; i >= 0; i--)// count each order backwards
{
OrderSelect(i, SELECT_BY_POS, MODE_TRADES); //select each order by postiton
if(OrderSymbol() != Symbol()) continue; //if it is not equal to our symbol, skip it
if((OrderType() == OP_BUY) || (OrderType() == OP_SELL))
{
//----- order profit -----------------
if(OrderProfit() >= (take_profit))  // OrderProfit is measured in the deposit currency - not pips
OrderClose(OrderTicket(),OrderLots(),Ask,3,White);
}
{
//----- end order profit -----------------
//----- order stop -----------------
if(OrderProfit() <= -(stop_loss))
OrderClose(OrderTicket(),OrderLots(),Ask,3,White);
//----- end order stop -----------------
Comment ("Take Profit " ,take_profit ," Stop Loss " ,stop_loss);
}
}
}
}