//+------------------------------------------------------------------+
//|                                         CPro Tool MyEA MT5                               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include <Trade\Trade.mqh>

// === 1. Input Parameters ===
// These can be changed by the user from the EA settings in MetaTrader
input double   LotSize      = 0.1;//交易时段 交易量 尺寸
input int      StopLoss     = 100;//停止 亏损 in 点数
input int      TakeProfit   = 200;//take 利润 in 点数
// === 2. Include Required Library ===
// Provides trading functions (buy, sell, etc.)
// === 3. Global Variables ===
CTrade trade; // Trading object for executing orders
// === 4. Main Event Functions ===
// Called once when the EA is attached to a chart
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
   Print("EA started");
   return(INIT_SUCCEEDED);
}
// Called once when the EA is removed from the chart
void OnDeinit(const int reason) {
   Print("EA stopped");
   CPro_Deinit();  // CPro营销模块清理
}
// Called on every new market tick
void OnTick() {
   // Simple trading logic: open buy if no position exists
   if(PositionsTotal() == 0) {
      // Open a buy position with the specified lot size, stop loss, and take profit
      trade.Buy(LotSize, _Symbol, Bid, (Bid-StopLoss*_Point), (Bid+TakeProfit*_Point));
   }
}