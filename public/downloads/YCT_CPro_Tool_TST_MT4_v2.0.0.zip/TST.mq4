//+------------------------------------------------------------------+
//|                                         CPro Tool TST MT4                                |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int    StopLoss         = 500;           //    
extern int    TakeProfit       = 100;           //    
extern double Lots             = 0.1;           //  
extern int timeframe           = 0;             //  
extern int pips                = 500;           //   
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
   double bid  = MarketInfo(Symbol(),MODE_BID);
   double open = iOpen(Symbol(),timeframe,0);
   double high = iHigh(Symbol(),timeframe,0);
   double low  = iLow(Symbol(),timeframe,0);
//----
   if(open-bid>0 && high-bid>pips*Point)
    {
     if(NevBar())
     OrderSend(Symbol(),OP_BUY,Lots,Ask,3,Bid-StopLoss*Point,Ask+TakeProfit*Point,"TST",0,0,Green);
    }
   if(bid-open>0 && bid-low>pips*Point)
    {
     if(NevBar())      
     OrderSend(Symbol(),OP_SELL,Lots,Bid,3,Ask+StopLoss*Point,Bid-TakeProfit*Point,"TST",0,0,Red);
    }
//----
   return(0);
  }
//+----------------------------------------------------------------------------+
//                                                    |
//-----------------------------------------------------------------------------+
 bool NevBar()
  {
   static int PrevTime=0;
   if (PrevTime==Time[0]) return(false);
   PrevTime=Time[0];
   return(true);
  }