//+------------------------------------------------------------------+
//|                                         CPro Tool DailyElderStab MT5                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <trade/trade.mqh>

CTrade trade;
input double MaxCandleRange = 0.00002;
input double MaxCandleHeigth = 0.00001;
input double TPDifference = 0.0001;
input double SLDifference = 0.0001;
input double TriggerPDifference = 0.00001;
input int ExpirySec = 120;
input int DelOrderSec = 120;
double TriggerPSell;
double TriggerPBuy;
input double TrailingSLDistance = 0.0001;
input double TrailingSLMovements = 0.00005;
input bool TrailingSLHard = false;
input double Lotsize = 1.0;
datetime TimerDelete;
datetime CurrentTime;
double askit;
double bidit;
ulong posTicket;
ulong posTicketBuy;
ulong posTicketSell;
ulong lastdeletedorderbuy;
ulong lastdeletedordersell;
bool OrderdeletableBuy;
bool OrderdeletableSell;
double accountbalancebeginning;
bool CheckfornewCandle (int CandleNumber)
   {
   static int LastCandleNumber;
   bool IsNewCandle= false;
   if (CandleNumber>LastCandleNumber)
      {
      IsNewCandle = true;
      LastCandleNumber = CandleNumber;
      Print("New Candle",
            "\nLastOpenTime: ",iTime(_Symbol,PERIOD_CURRENT,1),
            "\nLastOpen: ",iOpen(_Symbol,PERIOD_CURRENT,1),
            "\nLastClose: ",iClose(_Symbol,PERIOD_CURRENT,1),
            "\nLastHigh: ",iHigh(_Symbol,PERIOD_CURRENT,1),
            "\nLastLow: ",iLow(_Symbol,PERIOD_CURRENT,1));
      }
    return IsNewCandle;
   }
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   accountbalancebeginning = AccountInfoDouble(ACCOUNT_BALANCE);
   return(INIT_SUCCEEDED);
  }
void OnTick()
  {
  //CHECK FOR NEW CANDLE
  int CandleNumber = Bars(_Symbol,_Period);
  bool NewCandleAppeared;
  NewCandleAppeared = CheckfornewCandle(CandleNumber);
  //---- MAIN ---- NEW 0 CANDLE => TRADE ---
  if (NewCandleAppeared)
   {
      double LastClose = iClose(_Symbol,PERIOD_CURRENT,0);
      double LastHigh = iHigh(_Symbol,PERIOD_CURRENT,0);
      double LastLow = iLow(_Symbol,PERIOD_CURRENT,0);
      double LastRange = MathAbs(LastHigh - LastLow);
      double PreLastClose = iClose(_Symbol,PERIOD_CURRENT,1);
      double PreLastHigh = iHigh(_Symbol,PERIOD_CURRENT,1);
      double PreLastLow = iLow(_Symbol,PERIOD_CURRENT,1);
      double PreLastRange = MathAbs(PreLastHigh - PreLastLow);
      double CandleHeight = MathAbs(LastClose - PreLastClose);   
      if(CandleHeight <= MaxCandleHeigth && PreLastRange <= MaxCandleRange)
      {
         Print("---------- I SEEEEEEE A CAAANDLE ---------- AVAAADAAA KEEEDAAAVRAAA!!!");
         if(PositionsTotal() == 0 && OrdersTotal() == 0)
         {   
            askit = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_ASK),_Digits);
            bidit = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);
            TriggerPSell = bidit - TriggerPDifference;
            TriggerPBuy = askit + TriggerPDifference;
            CurrentTime = TimeCurrent();
            if(trade.SellStop(Lotsize, TriggerPSell, _Symbol, TriggerPSell + SLDifference, TriggerPSell - TPDifference,ORDER_TIME_SPECIFIED, CurrentTime + ExpirySec))
            {
               posTicketSell = trade.ResultOrder();
               OrderdeletableSell = true;
               TimerDelete = CurrentTime + DelOrderSec;
            }
            if(trade.BuyStop(Lotsize, TriggerPBuy, _Symbol, TriggerPBuy - SLDifference, TriggerPBuy + TPDifference,ORDER_TIME_SPECIFIED, CurrentTime + ExpirySec))
            {
               posTicketBuy = trade.ResultOrder();
               OrderdeletableBuy = true;
               TimerDelete = CurrentTime + DelOrderSec;
            }
         }
      }
   }
   if (PositionsTotal() > 0)
   {
      ulong ExecutedOrder = PositionGetTicket(0);
      //CLOSE POSITION IF TRADE IS TRIGGERED
      if(ExecutedOrder == posTicketBuy && posTicketSell != lastdeletedordersell)
      { 
            trade.OrderDelete(posTicketSell);
            lastdeletedordersell = posTicketSell;
      }
      else if(ExecutedOrder == posTicketSell && posTicketBuy != lastdeletedorderbuy)
      {
         trade.OrderDelete(posTicketBuy);
         lastdeletedorderbuy = posTicketBuy;
      }
      //TRAILINGSTOP
      double bidnow = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);
      double asknow = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_ASK),_Digits);
      Print("Ask: ",asknow,
            "\nBid: ", bidnow);
      Checktrailingstop(bidnow, asknow);
      CurrentTime = TimeCurrent();
      if(TimerDelete <= CurrentTime)
         {
            trade.OrderDelete(ExecutedOrder);
         }
   }
   //STATISTICS
      double accountbalance = AccountInfoDouble(ACCOUNT_BALANCE);
      double accountprofit = AccountInfoDouble(ACCOUNT_PROFIT);
      double accountequity = AccountInfoDouble(ACCOUNT_EQUITY);
      accountprofit = accountequity - accountbalancebeginning;
      accountprofit = NormalizeDouble(accountprofit,2);
    // DISPLAY OF VALUES ON CHART   
    Comment("\nServertime: ", TimeCurrent(),
            "\nCurrenttime: ",TimeCurrent(),
            "\nProfit: ",accountprofit,
            "\nEquity: ",accountequity);
   }
//FUNCTION TRAILING STOP LOSS
void Checktrailingstop (double bidnow, double asknow)
   {
      double ShouldSLSell = NormalizeDouble(bidnow + TrailingSLDistance,_Digits);
      double ShouldSLBuy = NormalizeDouble(asknow - TrailingSLDistance,_Digits);
      for (int i = PositionsTotal()-1; i >= 0; i --)
      {
         string symbol = PositionGetSymbol(i);
         if(_Symbol == symbol)
         {
            ulong CurrentPositionTicket = PositionGetInteger(POSITION_TICKET);
            double CurrentStopLoss = PositionGetDouble(POSITION_SL);
            // IF SL MOVES IN DEFINED STEPS
            if(TrailingSLHard == false)
            {
               if (posTicketSell == CurrentPositionTicket && CurrentStopLoss > ShouldSLSell)
               {
                  trade.PositionModify(CurrentPositionTicket, CurrentStopLoss - TrailingSLMovements, bidnow - TPDifference);
               }
               if (posTicketBuy == CurrentPositionTicket && CurrentStopLoss < ShouldSLBuy)
               {
                  trade.PositionModify(CurrentPositionTicket, CurrentStopLoss + TrailingSLMovements, asknow + TPDifference);
               }
            }
            //IF SL MOVES TO HARD DISTANCE
            else if(TrailingSLHard == true)
            {
               if (posTicketSell == CurrentPositionTicket && CurrentStopLoss > ShouldSLSell)
               {
                  trade.PositionModify(CurrentPositionTicket, ShouldSLSell, bidnow - TPDifference);
               }
               if (posTicketBuy == CurrentPositionTicket && CurrentStopLoss < ShouldSLBuy)
               {
                  trade.PositionModify(CurrentPositionTicket, ShouldSLBuy, asknow + TPDifference);
               }            
            }  
         }
      }
   }