//+------------------------------------------------------------------+
//|                                         CPro Tool Break_the_Range_Bound MT4              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#define      MAGICMA  223
double       MacdBuffer[];
double       highspot[];
double       lowspot[];
int          shake=250;//when in the range bound, the shake range of 3 SMA 
int          m=200;//when in the range bound, the bars number
double       lot=0.1;
extern int   FastSMA=38;
extern int   MidSMA=140;
extern int   SlowSMA=210;
double       sellhighest;//when sell order, the highest price during the range bound period before order
double       selllowest;//when sell order, the lowest price during the range bound period before order
double       buyhighest;//when buy order, the highest price during the range bound period before order
double       buylowest;//when buy order, the lowest price during the range bound period before order
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {   
      if(Bars<210 || IsTradeAllowed()==false) return;
//----calculate the difference among 3 SMA, to find the big difference
      for(int i=1;i<m;i++)
      {
      if(iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i)>=iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)
         &&iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)>iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i))
         MacdBuffer[i]=(iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i)-iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i));
      if(iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i)>=iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)
         &&iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)>iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i))
         MacdBuffer[i]=(iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i)-iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i));
      if(iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)>=iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i)
         &&iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i)>iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i))
         MacdBuffer[i]=(iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)-iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i));
      if(iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)>=iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)
         &&iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)>iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i))
         MacdBuffer[i]=(iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)-iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i));
      if(iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)>=iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i)
         &&iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i)>iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i))
         MacdBuffer[i]=(iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)-iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i));
      if(iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)>=iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)
         &&iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)>iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i))
         MacdBuffer[i]=(iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)-iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i));
      if(iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)==iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)
         &&iMA(NULL,0,MidSMA,0,MODE_SMA,PRICE_CLOSE,i)==iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i))
         MacdBuffer[i]=(iMA(NULL,0,SlowSMA,0,MODE_SMA,PRICE_CLOSE,i)-iMA(NULL,0,FastSMA,0,MODE_SMA,PRICE_CLOSE,i));
      if(MacdBuffer[i]>shake/Point) break;
      else return;
      }
//when bigger difference price among 3 SMA<shake range, find the highest & lowest spot during the range bound period
      ArrayCopy(highspot,High,0,0,m);
      ArrayCopy(lowspot,Low,0,0,m);
      ArraySort(highspot,WHOLE_ARRAY,0,MODE_DESCEND);
      ArraySort(lowspot,WHOLE_ARRAY,0,MODE_ASCEND);
//sell condition:when dull period be checked successful, sell order while the price < the lowest spot during the range bound period
      if(i==m && Bid<lowspot[0])
      {
      OrderSend(Symbol(),OP_SELL,lot,Bid,3,0,0,"",MAGICMA,0,Blue);
      sellhighest=highspot[0];
      selllowest=lowspot[0];
      }
//buy condition:when dull period be checked successful, buy order while the price > the lowest spot during the range bound period
      if(i==m && Ask<highspot[0])
      {
      OrderSend(Symbol(),OP_BUY,lot,Ask,3,0,0,"",MAGICMA,0,Red);
      buyhighest=highspot[0];
      buylowest=lowspot[0];      
      }
//close order condition
      for(int x=0;x<OrdersTotal();x++)
     {
      if(OrderSelect(x,SELECT_BY_POS,MODE_TRADES)==false)        break;
      if(OrderMagicNumber()!=MAGICMA || OrderSymbol()!=Symbol()) continue;
      //---- check order type
      if(OrderType()==OP_BUY)
        {
        if(Bid<buylowest || Bid-OrderOpenPrice()>4*(buyhighest-buylowest)) OrderClose(OrderTicket(),OrderLots(),Bid,3,White);
         break;
        }
      if(OrderType()==OP_SELL)
        {
         if(Ask>sellhighest || OrderOpenPrice()-Ask>4*(sellhighest-selllowest)) OrderClose(OrderTicket(),OrderLots(),Ask,3,White);
         break;
        }
     }
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+