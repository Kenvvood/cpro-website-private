//+------------------------------------------------------------------+
//|                                         CPro Tool MACDcrossAUDD1 MT4                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#define  LOTS           0.1
#define  STOPLOSSPIPS   40
#define  REWARDRATIO    3
int init()
{
  Print("Start of AUDUSD D1 MACD cross Robot trading.");
  Print("Trading volume: ",LOTS," lot, StopLoss: ", STOPLOSSPIPS, " pips, Reward ratio: ",REWARDRATIO);
  return(0);
}
int deinit()
{
  Print("End   of AUDUSD D1 MACD cross Robot trading.");
  return(0);
}
int start()
{     
      if (OrdersTotal() < 1)         // 1 trade per time.
      if(Hour() > 5 && Hour() < 15)  // during peak times
      if( Symbol() == "AUDUSD" )     // trading AUDUSD only
      if( Period() == 1440 )         // using daily chart only
          if( iMACD(NULL,0,12,26,9,PRICE_CLOSE,MODE_MAIN,2) < iMACD(NULL,0,12,26,9,PRICE_CLOSE,MODE_SIGNAL,2)     // Buy when MACD is crossing from sell zone      
              &&
              iMACD(NULL,0,12,26,9,PRICE_CLOSE,MODE_MAIN,1) > iMACD(NULL,0,12,26,9,PRICE_CLOSE,MODE_SIGNAL,1) )   // to buy zone      
                  OrderSend(Symbol(),OP_BUY,LOTS,Ask,3,Ask-STOPLOSSPIPS*0.0001,Ask+STOPLOSSPIPS*0.0001*REWARDRATIO,"MACD cross Buy",12345,0,Blue);
          else if( iMACD(NULL,0,12,26,9,PRICE_CLOSE,MODE_MAIN,2) > iMACD(NULL,0,12,26,9,PRICE_CLOSE,MODE_SIGNAL,2) // Sell when MACD is crossing from buy zone     
              &&
              iMACD(NULL,0,12,26,9,PRICE_CLOSE,MODE_MAIN,1) < iMACD(NULL,0,12,26,9,PRICE_CLOSE,MODE_SIGNAL,1) )    // to sell zone      
                  OrderSend(Symbol(),OP_SELL,LOTS, Bid,3,Bid+STOPLOSSPIPS*0.0001,Bid-STOPLOSSPIPS*0.0001*REWARDRATIO,"MACD cross Sell",12345,0,Red); 
      // return
      return(0);              
}