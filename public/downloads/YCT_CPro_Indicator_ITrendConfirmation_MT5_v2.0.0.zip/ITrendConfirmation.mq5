//+------------------------------------------------------------------+
//|                                         CPro Indicator ITrendConfirmation MT5            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


// MACDline
//signalLine
//histogram
//--- input parameters
input int      FMA=12;
input int      SMA=26;
input int      SIGNAL=9;
input double   CONFIRMATION_UMBRAL=10;
//--- indicator buffers
double         MACDlineBuffer[];
double         signallineBuffer[];
double         histogramBuffer[];
double         trendConfirmationBuffer[];
double         histogramColors[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,MACDlineBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,signallineBuffer,INDICATOR_DATA);
   SetIndexBuffer(2,trendConfirmationBuffer,INDICATOR_DATA);
   SetIndexBuffer(3,histogramBuffer,INDICATOR_DATA);
   SetIndexBuffer(4,histogramColors,INDICATOR_COLOR_INDEX);
   PlotIndexSetInteger(0,PLOT_DRAW_TYPE,DRAW_NONE);
   PlotIndexSetInteger(1,PLOT_DRAW_TYPE,DRAW_NONE);
//PlotIndexSetInteger(4,PLOT_DRAW_TYPE,DRAW_NONE);
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int ratesTotal, const int prevCalculated, const int begin, const double &price[]) {
   int MACDhadling=iMACD(NULL,0,FMA,SMA,SIGNAL,PRICE_CLOSE);
   CopyBuffer(MACDhadling,0,0,ratesTotal,MACDlineBuffer);
   CopyBuffer(MACDhadling,1,0,ratesTotal,signallineBuffer);
   for(int i=0; i<ratesTotal; i++) {
      int trendDirection=getTrendDirection(i);
      trendConfirmationBuffer[i]=trendDirection;
      if(trendDirection==2||trendDirection==0) {
         histogramColors[i]=0;
      }
      if(trendDirection==-1) {
         histogramColors[i]=2;
      }
      if(trendDirection==1) {
         histogramColors[i]=1;
      }
   }
   return(ratesTotal);
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int getTrendDirection(int position) {
   int direction=2;
   histogramBuffer[position]=MACDlineBuffer[position]-signallineBuffer[position];
   if(histogramBuffer[position] <= CONFIRMATION_UMBRAL && histogramBuffer[position] >= -CONFIRMATION_UMBRAL) {
      return 2;
   }
   if(position>1) {
      if(isValidDownTrend(position)&& isValidDownTrend(position-1))  return -1;
      if(isValidUpTrend(position)&& isValidUpTrend(position-1)) return 1;
      if((closeUpTrend(position)&& closeUpTrend(position-1))||(closeDownTrend(position)&&closeDownTrend(position-1))) return 0;
   }
   return direction;
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int isValidDownTrend(int position) {
   histogramBuffer[position]=MACDlineBuffer[position]-signallineBuffer[position];
   if(histogramBuffer[position] < histogramBuffer[position-1] && histogramBuffer[position] < histogramBuffer[position-2] && histogramBuffer[position-1] < histogramBuffer[position-2]) {
      return true;
   } else {
      return false;
   }
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int isValidUpTrend(int position) {
   histogramBuffer[position]=MACDlineBuffer[position]-signallineBuffer[position];
   if(histogramBuffer[position] >= histogramBuffer[position-1] && histogramBuffer[position] >= histogramBuffer[position-2]&& histogramBuffer[position-1] >= histogramBuffer[position-2]) {
      return true;
   } else {
      return false;
   }
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int closeUpTrend(int position) {
   histogramBuffer[position]=MACDlineBuffer[position]-signallineBuffer[position];
   if(histogramBuffer[position]<= histogramBuffer[position-1] && histogramBuffer[position-1] <= histogramBuffer[position-2]) {
      return true;
   }
   return false;
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int closeDownTrend(int position) {
   histogramBuffer[position]=MACDlineBuffer[position]-signallineBuffer[position];
   if(histogramBuffer[position] > histogramBuffer[position-1]&& histogramBuffer[position-1] > histogramBuffer[position-2]) {
      return true;
   }
   return false;
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+