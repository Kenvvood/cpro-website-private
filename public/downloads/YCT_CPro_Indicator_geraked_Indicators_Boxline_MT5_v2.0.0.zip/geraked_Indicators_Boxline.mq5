//+------------------------------------------------------------------+
//|                                         CPro Indicator geraked_Indicators_Boxline MT5    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#define PREFIX "ger_boxline_"
input bool showBoxes = true;
input color hcolor = clrLightBlue;//颜色 of bullish box
input color lcolor = clrLightPink;//颜色 of bearish box
//--- buffers
double middle[];
double top[];
double bottom[];
double boxColor[];
int k;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    ObjectsDeleteAll(0, PREFIX);
    IndicatorSetInteger(INDICATOR_DIGITS, _Digits);
    SetIndexBuffer(0, middle);
    SetIndexBuffer(1, top);
    SetIndexBuffer(2, bottom);
    SetIndexBuffer(3, boxColor);
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
    ObjectsDeleteAll(0, PREFIX);
   CPro_Deinit();  // CPro营销模块清理
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
//---
    if (rates_total < 2) return 0;
    ArraySetAsSeries(open, false);
    ArraySetAsSeries(high, false);
    ArraySetAsSeries(low, false);
    ArraySetAsSeries(close, false);
    ArraySetAsSeries(time, false);
    ArraySetAsSeries(top, false);
    ArraySetAsSeries(bottom, false);
    ArraySetAsSeries(boxColor, false);
    ArraySetAsSeries(middle, false);
    if (prev_calculated == 0) {
        k = 0;
        top[k] = high[k];
        bottom[k] = low[k];
        boxColor[k] = false;
        middle[k] = (top[k] + bottom[k]) / 2;
    }
    int pos = 0;
    if (prev_calculated > 1) pos = prev_calculated - 1;
    for (int i = pos; i < rates_total - 1 && !IsStopped(); i++) {
        bool check = (close[i] > top[k] || close[i] < bottom[k]);
        //if (openCheck) check = (check || open[i] > top[k] || open[i] < bottom[k]);
        if (check) {
            for (int j = k; j < i; j++) {
                top[j] = top[k];
                bottom[j] = bottom[k];
                boxColor[j] = boxColor[k];
                middle[j] = (top[j] + bottom[j]) / 2;
            }
            if (showBoxes) {
                color objcolor = !boxColor[k] ? lcolor : hcolor;
                string bname = PREFIX + "b" + (string) k;
                ObjectCreate(ChartID(), bname, OBJ_RECTANGLE, 0, time[k], top[k], time[i], bottom[k]);
                ObjectSetInteger(ChartID(), bname, OBJPROP_COLOR, objcolor);
                ObjectSetInteger(ChartID(), bname, OBJPROP_FILL, objcolor);
                ObjectSetInteger(ChartID(), bname, OBJPROP_BACK, true);
            }
            k = i;
            top[k] = high[k];
            bottom[k] = low[k];
            boxColor[k] = !(k > 0 && close[k] < bottom[k - 1]);
            middle[k] = (top[k] + bottom[k]) / 2;
        }
        top[i] = top[k];
        bottom[i] = bottom[k];
        boxColor[i] = boxColor[k];
        middle[i] = (top[i] + bottom[i]) / 2;
        if (high[i] > top[k] || low[i] < bottom[k]) {
            if (high[i] > top[k]) top[k] = high[i];
            if (low[i] < bottom[k]) bottom[k] = low[i];
            for (int j = k; j <= i; j++) {
                top[j] = top[k];
                bottom[j] = bottom[k];
                middle[j] = (top[j] + bottom[j]) / 2;
            }
        }
    }
//--- return value of prev_calculated for next call
    return(rates_total);
}
//+------------------------------------------------------------------+