//+------------------------------------------------------------------+
//|                                         CPro Tool recordspreadstopandfreezelevel MT4     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include <C_LOG.mqh>

//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
input int I_RecordPeriodInMinutes=1;//how often the ea records the 点差 etc.
input string I_InputSymbols="EURGBP+;GBPUSD+";//list of 品种s, delimited by ;
input string I_BeginningOfLogFile="MktData";//beginning of log file 名称 to record data.
//+------------------------------------------------------------------+
//| Global Variables                                                 |
//+------------------------------------------------------------------+
string g_strSymbols[];
C_LOG *g_objLog;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- create timer
   CPro_Init();  // CPro营销模块初始化
   EventSetTimer(I_RecordPeriodInMinutes*60);
//--- Load Global Variable Array with the Symbols that we are interested in.
   PopulateSymbolArray();
//--- Initiate the Log File
   string strFileName=I_BeginningOfLogFile+"_Acc_"+IntegerToString(AccountNumber())+".txt";
   g_objLog=new C_LOG(strFileName);
//--- Archive any previous Log Files
   g_objLog.ArchiveAndRemoveLogFile();   
//--- Add titles to the log file
   addTitlesToLogFile();
//---
   return(INIT_SUCCEEDED);
  }
void PopulateSymbolArray()
{
   //Clear the array.
   if(ArraySize(g_strSymbols)>0) ArrayFree(g_strSymbols);
   ushort uSep=StringGetCharacter(";",0);
   StringSplit(I_InputSymbols,uSep,g_strSymbols);
   //Print out the array
   string strPrint="";
   for(int i=0;i<ArraySize(g_strSymbols);i++)
   {
      strPrint+="["+g_strSymbols[i]+"],";
   }
   Print(__FILE__+" "+__FUNCTION__,"Symbols Array: "+strPrint);
}
void addTitlesToLogFile()
{
   string strWrite="TimeLocal;TimeBroker;IsConnected;";
   int intCount=ArraySize(g_strSymbols);
   for(int i=0;i<intCount;i++)
   {
      string strSymb=g_strSymbols[i];
      strWrite+=(strSymb+"_Spread;");
      strWrite+=(strSymb+"_StopLevel;");
      strWrite+=(strSymb+"_FreezeLevel;");
   }  
   g_objLog.AppendStringToLog(strWrite);
}
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//--- destroy timer
   EventKillTimer();
//--- clear the global variable array.
   if(ArraySize(g_strSymbols)>0) ArrayFree(g_strSymbols);
//--- clear the Log File.
   if(g_objLog!="")   delete g_objLog;   
  }
//+------------------------------------------------------------------+
//| Timer function                                                   |
//+------------------------------------------------------------------+
void OnTimer()
  {
//---
   string strWrite=TimeToString(TimeLocal())+";"+TimeToString(TimeCurrent())+";";
   string strAppend="True;";
   if(!IsConnected())   strAppend="False;";
   strWrite+=strAppend;
   int intCount=ArraySize(g_strSymbols);
   for(int i=0;i<intCount;i++)
   {
      string strSymb=g_strSymbols[i];
      double dblBid=MarketInfo(strSymb,MODE_BID);
      double dblAsk=MarketInfo(strSymb,MODE_ASK);
      double dblStop=MarketInfo(strSymb,MODE_STOPLEVEL);
      double dblFreeze=MarketInfo(strSymb,MODE_FREEZELEVEL);
      if(dblBid>0 && dblAsk>0)
      {
         strWrite+=DoubleToString(dblAsk-dblBid)+";";
         strWrite+=DoubleToString(dblStop)+";";
         strWrite+=DoubleToString(dblFreeze)+";";
      }
      else
      {
         strWrite+=("N/A;N/A;N/A;");     
      }
   }  
   g_objLog.AppendStringToLog(strWrite);
  }
//+------------------------------------------------------------------+
