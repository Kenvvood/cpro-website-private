//+------------------------------------------------------------------+
//|                                         CPro Tool FirstEA MT5                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <Trade\Trade.mqh>

//+------------------------------------------------------------------+
//| Variable                                                         |
//+------------------------------------------------------------------+
input int openHour;
input int closeHour;
input double lotsize =0.1;
bool isTradeOpen = false;
CTrade trade;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit(){
   CPro_Init();  // CPro营销模块初始化
   if(openHour == closeHour){return INIT_PARAMETERS_INCORRECT;}
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason){
   CPro_Deinit();  // CPro营销模块清理
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick(){
   // get current time
   MqlDateTime timeNow;
   TimeToStruct(TimeCurrent(), timeNow);
   // check for trade open
   if(openHour == timeNow.hour && !isTradeOpen){
      //open trade
      trade.PositionOpen(_Symbol,ORDER_TYPE_BUY,lotsize,SymbolInfoDouble(_Symbol,SYMBOL_ASK),0,0);
      //set flag
      isTradeOpen = true;
   }
  // check for trade close
   if(closeHour == timeNow.hour && isTradeOpen){
      //open trade
      trade.PositionClose(_Symbol);
      //set flag
      isTradeOpen = false;
   }
}