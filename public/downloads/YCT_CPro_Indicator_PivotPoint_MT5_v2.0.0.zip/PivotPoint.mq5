//+------------------------------------------------------------------+
//|                                         CPro Indicator PivotPoint MT5                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot pivot
//--- plot R1
//--- plot R2
//--- plot R3
//--- plot S1
//--- plot S2
//--- plot S3
//--- indicator buffers
double         pivotBuffer[];
double         R1Buffer[];
double         R2Buffer[];
double         R3Buffer[];
double         S1Buffer[];
double         S2Buffer[];
double         S3Buffer[];
//--- input parameters and variables
//input ENUM_TIMEFRAMES TFpivot = PERIOD_D1;
input bool weekend;//merge saturday and sunday with 周五
double P;
double R1;
double R2;
double R3;
double S1;
double S2;
double S3;
int prevPeriod;
double H=0;
double L=0;
double O=0;
double newO=0;
double C=0;
MqlDateTime current;
int pos;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,pivotBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,R1Buffer,INDICATOR_DATA);
   SetIndexBuffer(2,R2Buffer,INDICATOR_DATA);
   SetIndexBuffer(3,R3Buffer,INDICATOR_DATA);
   SetIndexBuffer(4,S1Buffer,INDICATOR_DATA);
   SetIndexBuffer(5,S2Buffer,INDICATOR_DATA);
   SetIndexBuffer(6,S3Buffer,INDICATOR_DATA);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
//---
   pos = prev_calculated -1;
   if(pos < 1){
      pos = 1;
   }
   for(int i=pos; i<rates_total; i++){
      TimeToStruct(time[i],current);
      //if same day, check if new high or low
      if(prevPeriod == current.day_of_year || ((current.day_of_week == 7 || current.day_of_week == 0) && weekend)){
         if(high[i]>H){
            H = high[i];
         }
         if(low[i]<L){
            L = low[i];
         }
      }
      //if new day
      else{ 
         //set open and close
         O = newO;
         newO = open[i];
         C = close[i-1];
         //calculate pivot, supports and resistances for the day with data from previous day
         P = (H+L+C)/3;
         R1 = 2*P-L;
         S1 = 2*P-H;
         R2 = P+(H-L);
         S2 = P-(H-L);
         R3 = R1+(H-L);
         S3 = S1-(H-L);
         //reset high and low
         H = high[i];
         L = low[i];
      }
      //pass the values to the indicator buffers
      pivotBuffer[i] = P;
      R1Buffer[i] = R1;
      S1Buffer[i] = S1;
      R2Buffer[i] = R2;
      S2Buffer[i] = S2;
      R3Buffer[i] = R3;
      S3Buffer[i] = S3;
      //reset period
      prevPeriod = current.day_of_year; 
   }
//--- return value of prev_calculated for next call
   return(rates_total);
  }
//+------------------------------------------------------------------+