//+------------------------------------------------------------------+
//|                                         CPro Indicator FlameChart MT5                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <Canvas\FlameCanvas.mqh>

//+------------------------------------------------------------------+
//| Indicator properties                                             |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Input parameters                                                 |
//+------------------------------------------------------------------+
input  int        InpFuturefBars     =50;
//+------------------------------------------------------------------+
//| global variables                                                 |
//+------------------------------------------------------------------+
CFlameCanvas      ExtCanvas;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   if(!ExtCanvas.FlameCreate("FlameChart",TimeCurrent(),InpFuturefBars,0))
      return(INIT_FAILED);
//--- succeed
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int      rates_total,
                const int      prev_calculated,
                const datetime &time[],
                const double   &open[],
                const double   &high[],
                const double   &low[],
                const double   &close[],
                const long     &tick_volume[],
                const long     &volume[],
                const int      &spread[])
  {
   datetime xb1=time[rates_total-1];
   double   yb1=high[rates_total-1];
   datetime xe1=xb1+InpFuturefBars*PeriodSeconds();
   double   ye1=ChartGetDouble(0,CHART_PRICE_MAX);
   datetime xb2=xb1;
   double   yb2=low[rates_total-1];
   datetime xe2=xe1;
   double   ye2=ChartGetDouble(0,CHART_PRICE_MIN);
//--- "nozzle" is defined using two lines: ((xb1,yb1),(xe1,ye1)) and ((xb2,yb2),(xe2,ye2))
   ExtCanvas.FlameSet(xb1,yb1,xe1,ye1,xb2,yb2,xe2,ye2);
//--- result
   return(rates_total);
  }
//+------------------------------------------------------------------+
//| Custom indicator chart's event handler                           |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,const long& lparam,const double& dparam,const string& sparam)
  {
   ExtCanvas.ChartEventHandler(id,lparam,dparam,sparam);
  }
//+------------------------------------------------------------------+