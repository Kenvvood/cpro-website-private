//+------------------------------------------------------------------+
//|                                         CPro Tool mo_bidir_v0_1 MT4                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#define MAGIC  1234
#define IDENT  "mo_bidir_v0_1"
extern double  lots           = 1;
extern double  stop_loss      = 80;   // (8 pips) optimise 50-2000
extern double  take_profit    = 750;  // (75 pips) optimise 50-2000
int            last_bar       = 0;
int start(){
   if (last_bar == Bars) return(0);
   last_bar = Bars;
   if (OrdersTotal() == 0){
         OrderSend(Symbol(), OP_BUY, lots ,Ask, 3, Ask - stop_loss * Point, Bid + take_profit * Point, IDENT, MAGIC, 0, Blue);
         OrderSend(Symbol(), OP_SELL, lots ,Bid, 3, Bid + stop_loss * Point, Ask - take_profit * Point, IDENT, MAGIC, 0, Red);
   } 
   return(0);
}