//+------------------------------------------------------------------+
//|                                         CPro Tool simple_trailing_stop MT4               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//--- Set up parameters to trailing stop
   trailing(NULL,"My expert",777,25);
  }
//+------------------------------------------------------------------+
//| Trailing stop script                                             |
//| (Symbol for trailing, Comment in order,                          |
//| Magic number of order, points for trail)                         |
//+------------------------------------------------------------------+
void trailing(string symbol,string comment,int magic,int trail_p)
  {
   if(symbol==NULL) symbol=Symbol();
   for(int i=0;i<OrdersTotal();i++)
     {
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES))
        {
         if(OrderSymbol()==symbol && OrderComment()==comment && OrderMagicNumber()==magic)
           {
            switch(OrderType())
              {
               case OP_BUY:
                  if(OrderOpenPrice()+(trail_p*Point)<Ask && OrderStopLoss()+(trail_p*Point)<Ask)
                    {
                     if(!OrderModify(OrderTicket(),OrderOpenPrice(),Ask-(trail_p*Point),OrderTakeProfit(),OrderExpiration(),clrNONE))
                       {
                        Print("OrderModify    #",GetLastError());
                       }
                    }
                  break;
               case OP_SELL:
                  if(OrderOpenPrice()-(trail_p*Point)>Bid && OrderStopLoss()-(trail_p*Point)>Bid)
                    {
                     if(!OrderModify(OrderTicket(),OrderOpenPrice(),Bid+(trail_p*Point),OrderTakeProfit(),OrderExpiration(),clrNONE))
                       {
                        Print("OrderModify    #",GetLastError());
                       }
                    }
                  break;
              }
           }
        }
     }
  }
//+------------------------------------------------------------------+