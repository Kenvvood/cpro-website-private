//+------------------------------------------------------------------+
//|                                         CPro Indicator I_MA_HK_v1 MT5                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot HK
//--- plot MA_Oben
//--- plot MA_Unten
//--- plot SUN
//#property indicator_style4  STYLE_SOLID
//--- plot TradeSignal
//#property indicator_style5  STYLE_SOLID
//--- input parameters
input int      MA_Periode=5;
input int      Input1;
//--- indicator buffers
double         HKBuffer_O[];
double         HKBuffer_H[];
double         HKBuffer_L[];
double         HKBuffer_C[];
double         HKColors[];
double         MA_ObenBuffer[];
double         MA_UntenBuffer[];
double         SUNBuffer[];
double         TradeSignal[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,HKBuffer_O,INDICATOR_DATA);
   SetIndexBuffer(1,HKBuffer_H,INDICATOR_DATA);
   SetIndexBuffer(2,HKBuffer_L,INDICATOR_DATA);
   SetIndexBuffer(3,HKBuffer_C,INDICATOR_DATA);
   SetIndexBuffer(4,HKColors,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(5,MA_ObenBuffer,INDICATOR_DATA);
   SetIndexBuffer(6,MA_UntenBuffer,INDICATOR_DATA);
   SetIndexBuffer(7,SUNBuffer,INDICATOR_DATA);   
   SetIndexBuffer(8,TradeSignal,INDICATOR_DATA);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
//int OnCalculate(const int rates_total,
//                const int prev_calculated,
//                const datetime &time[],
//                const double &open[],
//                const double &high[],
//                const double &low[],
//                const double &close[],
//                const long &tick_volume[],
//                const long &volume[],
//                const int &spread[])
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const int begin,
                const double &price[])
  {
//---
//--- return value of prev_calculated for next call
   return(rates_total);
  }
//+------------------------------------------------------------------+