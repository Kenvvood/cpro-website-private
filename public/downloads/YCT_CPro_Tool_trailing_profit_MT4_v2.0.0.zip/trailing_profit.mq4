//+------------------------------------------------------------------+
//|                                         CPro Tool trailing_profit MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern double percent_of_profit =33;
extern double minimum_profit = 1000;
double profit,profit_off,result;
bool trail_enable=false,close_start=false;
int init()
   {
   profit_off=0;
   result = 0;
   Comment ("");
   return(0);
   }
int start()
   {
   while (IsExpertEnabled())
      {
      Sleep (50);
      RefreshRates(); 
//----
      if (close_start)
         {
         for (int i=OrdersTotal();i>=1;i--)
            {
            OrderSelect (i-1,SELECT_BY_POS,MODE_TRADES);
               {
               if (OrderType()==OP_BUY)
                  {
                  double price = MarketInfo (OrderSymbol(),MODE_BID);
                  OrderClose (OrderTicket(),OrderLots(),price,3,0);
                  result = OrderProfit()+result;
                  }
               if (OrderType()==OP_SELL)
                  {
                  price = MarketInfo (OrderSymbol(),MODE_ASK);
                  OrderClose (OrderTicket(),OrderLots(),price,3,0);
                  result = OrderProfit()+result;
                  }
               }
            }
         }
      for (i=OrdersTotal();i>=1;i--)
         {
         OrderSelect(i-1,SELECT_BY_POS,MODE_TRADES);
         profit = OrderProfit()+OrderSwap()+profit;
         }
      if (close_start&&OrdersTotal()==0)
         {
         trail_enable=false;
         close_start= false;
         Alert ("     ", result);
         profit_off=0;
         result = 0;
         }
      if (!trail_enable&&OrdersTotal()!=0)
         {
         Comment ("  ." ,"\n","        ",minimum_profit,
                  "   ", profit);
         }
      if ((profit_off==0&&minimum_profit < profit)||(profit_off!=0&&profit_off<profit-profit*(percent_of_profit/100)))
         {
         trail_enable=true;
         profit_off=profit-profit*(percent_of_profit/100);
         Comment("  ." ,"\n","       ",profit_off,
                  "   ", profit);
         }
      if (trail_enable&&profit_off>profit)
         {
         close_start=true;
         }
      profit =0;
      }
//----
   return(0);
   }
//+------------------------------------------------------------------+