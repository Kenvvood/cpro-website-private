//+------------------------------------------------------------------+
//|                                         CPro Tool autosltp_upd MT4                       |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

input bool   AllPairs=True;
input double TakeProfit=400; //40-->4 digits; 400-->5 digits
input double StopLoss=150; //15-->4 digits; 150-->5 digits
input double DurasiTime=60;
//---
int ticket;
double poen;
string pair="";
double iTakeProfit,iStopLoss;
double slbuy;
double tpbuy;
double slsell;
double tpsell;
double stoplevel;
double digi;
double poin;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
   for(int cnt=0; cnt<OrdersTotal(); cnt++)
     {
      if(OrderSelect(cnt,SELECT_BY_POS,MODE_TRADES))
        {
         if(OrderTicket()>0 && OrderMagicNumber()==0 && OrderTakeProfit()==0 && TimeCurrent()-OrderOpenTime()<=DurasiTime)
           {
            if(AllPairs) pair=OrderSymbol(); else pair=Symbol();
            //---
            stoplevel=MarketInfo(pair,MODE_STOPLEVEL);
            digi=MarketInfo(pair,MODE_DIGITS);
            poin=MarketInfo(pair,MODE_POINT);
            iStopLoss=StopLoss;
            iTakeProfit=TakeProfit;
            if(StopLoss<stoplevel) iStopLoss=stoplevel;
            if(TakeProfit<stoplevel) iTakeProfit=stoplevel;
            //---
            slbuy=NormalizeDouble(OrderOpenPrice()-iStopLoss*poin,digi);
            tpbuy=NormalizeDouble(OrderOpenPrice()+iTakeProfit*poin,digi);
            slsell=NormalizeDouble(OrderOpenPrice()+iStopLoss*poin,digi);
            tpsell=NormalizeDouble(OrderOpenPrice()-iTakeProfit*poin,digi);
            //---
            if(OrderSymbol()==pair && (OrderType()==OP_BUY || OrderType()==OP_BUYLIMIT || OrderType()==OP_BUYSTOP))
              {
               ticket=OrderModify(OrderTicket(),OrderOpenPrice(),slbuy,tpbuy,0,Blue);
              }
            if(OrderSymbol()==pair && (OrderType()==OP_SELL || OrderType()==OP_SELLLIMIT || OrderType()==OP_SELLSTOP))
              {
               ticket=OrderModify(OrderTicket(),OrderOpenPrice(),slsell,tpsell,0,Red);
              }
           }
        }
     }
//----
   return(0);
  }
//+------------------------------------------------------------------+