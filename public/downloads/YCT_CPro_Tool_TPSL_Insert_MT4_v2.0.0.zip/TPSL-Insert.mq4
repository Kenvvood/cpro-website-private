//+------------------------------------------------------------------+
//|                                         CPro Tool TPSL_Insert MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern double        TakeProfitPips=35;
extern double        StopLossPips=100;
      int         Faktor, Digt, cnt;
   double         TPp, SLp;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init(){}
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit(){}
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
      if(Close[0]>10)  {Faktor=1000; Digt=3;}  else
      if(Close[0]<10)  {Faktor=100000; Digt=5;}
      if(OrdersTotal()!=0)
         {
         for(cnt=0; cnt<OrdersTotal(); cnt++)
            {
            OrderSelect(cnt,SELECT_BY_POS);
//--------------Take Profit--------------------------------
            if(OrderTakeProfit()==0 && TakeProfitPips !=0)
               {
                  if(OrderType()==OP_BUY && OrderSymbol()==Symbol())
                     {TPp = OrderOpenPrice()+TakeProfitPips/Faktor;}
                  if(OrderType()==OP_SELL && OrderSymbol()==Symbol())                     
                     {TPp = OrderOpenPrice()-TakeProfitPips/Faktor;}
               } else TPp = OrderTakeProfit();
//--------------Stop Loss--------------------------------
            if(OrderStopLoss()==0 && StopLossPips !=0)
               {
                  if(OrderType()==OP_BUY && OrderSymbol()==Symbol())
                     {SLp = OrderOpenPrice()-StopLossPips/Faktor;}
                  if(OrderType()==OP_SELL && OrderSymbol()==Symbol())                     
                     {SLp = OrderOpenPrice()+StopLossPips/Faktor;}
               } else SLp = OrderStopLoss();
//---------------Modify Order--------------------------
            if (OrderType()==OP_BUY || OrderType()==OP_SELL)   
            OrderModify(OrderTicket(),OrderOpenPrice(),SLp,TPp,0);               
//-----------------------------------------------------
            } // for cnt
         }//if OrdersTotal
  return(0);
  }// Start()
//+------------------------------------------------------------------+