//+------------------------------------------------------------------+
//|                                         CPro Tool Abovebelowma_www_forex_instruments_info MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//----
double Lots=1;
//     ?  , :  ,    
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool CheckOrders(int Type)
  {
   int ticket,i;
   bool Result;
//----
   Result=True;
   if(OrdersTotal()!=0)
     {
      for(i=0;i<OrdersTotal();i++)
        {
         ticket=OrderSelect(i,SELECT_BY_POS);
         if(OrderMagicNumber()==553)
           {
            if(OrderType()==Type)
              {
               if(Type==OP_BUY)
                 {
                  if(OrderClose(OrderTicket(),OrderLots(),Bid,10)==False)
                     Result=False;
                 }
               if(Type==OP_SELL)
                 {
                  if(OrderClose(OrderTicket(),OrderLots(),Ask,20)==False)
                     Result=False;
                 }
              }
            else Result=False;
           }
        }
     }
   return(Result);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int start()
  {
   double MA, MAPrev;
   int ticket;
//----
   MA=iMA("GBPUSD",15,1,0,MODE_EMA,PRICE_TYPICAL,0);
   MAPrev=iMA("GBPUSD",15,1,0,MODE_EMA,PRICE_TYPICAL,1);
   //  
   if(Open[0]<MA-Point && Ask<MA)
      if(CheckOrders(OP_SELL)==True && MAPrev<MA)
        {
         Lots=NormalizeDouble(AccountFreeMargin()/10000, 1);
         if(Lots>5)
            Lots=5;
         ticket=OrderSend("GBPUSD",OP_BUY,Lots,Ask,10,0,0,NULL,553);
         if(ticket<0)
            Print("    BUY.  N", GetLastError());
        }
   //  
   if(Open[0]>MA+Point && Bid>MA)
      if(CheckOrders(OP_BUY)==True && MAPrev>MA)
        {
         Lots=NormalizeDouble(AccountFreeMargin()/10000, 1);
         if(Lots>5)
            Lots=5;
         ticket=OrderSend("GBPUSD",OP_SELL,Lots,Bid,10,0,0,NULL,553);
         if(ticket<0)
            Print("    SELL.  N", GetLastError());
        }
//----
   return(0);
  }
//+------------------------------------------------------------------+