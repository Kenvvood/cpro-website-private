//+------------------------------------------------------------------+
//|                                        CProWatermark.mqh        |
//|                         CPro Trading 圆形水印模块                  |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+
//
//  PURPOSE:
//    CProWatermark draws a circular company logo watermark
//    in the bottom-right corner of the chart. This provides
//    subtle brand visibility without obstructing price data.
//
//  FEATURES:
//    - Circular logo display (via OBJ_BITMAP_LABEL)
//    - Bottom-right corner positioning
//    - Semi-transparent appearance
//    - Always on top (background display)
//    - Resource-based image loading
//
//  DESIGN:
//    - Position: Bottom-right corner of chart
//    - Size: 60x60 pixels (configurable)
//    - Color: Follows CPRO_COLOR_WATERMARK
//    - Transparency: Uses bitmap alpha channel
//
//  USAGE:
//    #include "CPro\CProWatermark.mqh"
//    CProWatermark watermark;
//    watermark.Init();
//    watermark.DrawWatermark();
//
//  NOTE:
//    Requires CPRO logo resource to be included via:
//    #resource "CPro\\CPRO-LOGO-circle.bmp"
//
//+------------------------------------------------------------------+

#ifndef CPRO_WATERMARK_MQH
#define CPRO_WATERMARK_MQH

#include "CProConfig.mqh"

//+------------------------------------------------------------------+
//| CProWatermark - Circular Logo Watermark Class                    |
//+------------------------------------------------------------------+
class CProWatermark {
private:
    bool        m_initialized;
    int         m_logoX;
    int         m_logoY;
    bool        m_positionSet;

public:
    CProWatermark();
    ~CProWatermark();

    //=== Lifecycle ===
    void         Init();
    void         Deinit();

    //=== Watermark Operations ===
    void         DrawWatermark();
    void         SetPosition(int x, int y);
    void         ClearWatermark();

private:
    // Get default position (bottom-right)
    void         GetDefaultPosition(int &x, int &y);
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CProWatermark::CProWatermark() {
    m_initialized = false;
    m_logoX = -1;
    m_logoY = -1;
    m_positionSet = false;
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CProWatermark::~CProWatermark() {
    Deinit();
}

//+------------------------------------------------------------------+
//| Init - Initialize watermark module                               |
//+------------------------------------------------------------------+
void CProWatermark::Init() {
    if(m_initialized) return;
    m_initialized = true;
    m_logoX = -1;
    m_logoY = -1;
    m_positionSet = false;
}

//+------------------------------------------------------------------+
//| Deinit - Cleanup watermark objects                               |
//+------------------------------------------------------------------+
void CProWatermark::Deinit() {
    ClearWatermark();
    m_initialized = false;
}

//+------------------------------------------------------------------+
//| SetPosition - Set custom watermark position                      |
//+------------------------------------------------------------------+
void CProWatermark::SetPosition(int x, int y) {
    m_logoX = x;
    m_logoY = y;
    m_positionSet = true;
}

//+------------------------------------------------------------------+
//| ClearWatermark - Remove watermark from chart                     |
//+------------------------------------------------------------------+
void CProWatermark::ClearWatermark() {
    long chartId = ChartID();
    CPRO_DELETE_OBJECT(chartId, CPRO_WATERMARK_NAME);
    CPRO_CHART_REDRAW;
}

//+------------------------------------------------------------------+
//| GetDefaultPosition - Calculate default bottom-right position     |
//+------------------------------------------------------------------+
void CProWatermark::GetDefaultPosition(int &x, int &y) {
    long chartId = ChartID();

    // Get chart dimensions (with MT4 fallback)
    int chartWidth, chartHeight;

    #ifdef __MQL5__
        chartWidth = (int)ChartGetInteger(chartId, CHART_WIDTH_IN_PIXELS);
        chartHeight = (int)ChartGetInteger(chartId, CHART_HEIGHT_IN_PIXELS);
    #else
        // MT4: Use screen resolution as fallback
        chartWidth = CPRO_CHART_WIDTH_IN_PIXELS;
        chartHeight = CPRO_CHART_HEIGHT_IN_PIXELS;
    #endif

    // Position in bottom-right corner with margin
    x = chartWidth - CPRO_LOGO_SIZE_W - CPRO_PANEL_MARGIN;
    y = chartHeight - CPRO_LOGO_SIZE_H - CPRO_PANEL_MARGIN;
}

//+------------------------------------------------------------------+
//| DrawWatermark - Draw circular watermark in corner                 |
//+------------------------------------------------------------------+
void CProWatermark::DrawWatermark() {
    if(!m_initialized) return;

    long chartId = ChartID();

    // Calculate position
    int x, y;
    if(m_positionSet) {
        x = m_logoX;
        y = m_logoY;
    } else {
        GetDefaultPosition(x, y);
    }

    // Delete existing watermark (idempotent)
    ClearWatermark();

    // Create bitmap label for watermark
    if(!ObjectCreate(chartId, CPRO_WATERMARK_NAME, OBJ_BITMAP_LABEL, 0, 0, 0)) {
        Print("[CProWatermark] ERROR: Failed to create watermark object!");
        return;
    }

    // Set watermark resource
    // Note: Place CPRO-LOGO-final-90x.png in MQL5\Images\CPro\ folder
    // and rename to CPRO-LOGO-circle.bmp, or use the path below directly
    string watermarkResource = "CPro\\CPRO-LOGO-final-90x.png";

    #ifdef __MQL5__
        // MT5 uses resource system
        ObjectSetString(chartId, CPRO_WATERMARK_NAME, OBJPROP_BMPFILE, 0, watermarkResource);
        ObjectSetString(chartId, CPRO_WATERMARK_NAME, OBJPROP_BMPFILE, 1, watermarkResource);
    #else
        // MT4 uses Images folder
        ObjectSetString(chartId, CPRO_WATERMARK_NAME, OBJPROP_BMPFILE, 0, watermarkResource);
        ObjectSetString(chartId, CPRO_WATERMARK_NAME, OBJPROP_BMPFILE, 1, watermarkResource);
    #endif

    // Set position and size
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_XDISTANCE, x);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_YDISTANCE, y);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_XSIZE, CPRO_LOGO_SIZE_W);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_YSIZE, CPRO_LOGO_SIZE_H);

    // Set corner (bottom-right)
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_CORNER, CPRO_LOGO_CORNER);

    // Set as background (semi-transparent effect)
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_BACK, true);

    // Anchor to bottom-right
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_ANCHOR, ANCHOR_RIGHT_LOWER);

    // Set watermark color tint
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_COLOR, CPRO_COLOR_WATERMARK);

    CPRO_CHART_REDRAW;

    Print("[CProWatermark] Watermark drawn at (", x, ", ", y, ")");
}

#endif // CPRO_WATERMARK_MQH
