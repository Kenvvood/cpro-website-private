//+------------------------------------------------------------------+
//|                                           CProDialog.mqh         |
//|                         CPro Trading 启动弹窗模块                    |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+
//
//  PURPOSE:
//    CProDialog displays a startup dialog when the EA/indicator
//    first loads. It shows product branding, company info,
//    and requires user acknowledgment before operation begins.
//
//  FINALIZED DESIGN:
//    ┌──────────────────────────────────────────────────┐
//    │                                                  │
//    │           城诺科技 · CPro Trading               │
//    │                                                  │
//    │              ═══════════════════════             │
//    │                                                  │
//    │        专业MQL量化解决方案供应商                  │
//    │                                                  │
//    │           ─────────────────────                  │
//    │                                                  │
//    │           核心引擎: 动态ATR物理通道              │
//    │           风控中枢: 毫秒级单K线冷却锁            │
//    │                                                  │
//    │           ─────────────────────                  │
//    │                                                  │
//    │           合作联系微信: jialie-li               │
//    │           技术支持微信: Lookee333               │
//    │           版本: v1.0                            │
//    │                                                  │
//    │              [ 确 认 进 入 ]                    │
//    │                                                  │
//    │           ─────────────────────                  │
//    │                                                  │
//    │  警告: 本系统基于非对称概率模型，                │
//    │  请严格遵守资金管理底线。                        │
//    └──────────────────────────────────────────────────┘
//
//  USAGE:
//    #include "CPro\CProDialog.mqh"
//    CProDialog dialog;
//    dialog.Init();
//    dialog.ShowStartupDialog();
//
//+------------------------------------------------------------------+

#ifndef CPRO_DIALOG_MQH
#define CPRO_DIALOG_MQH

#include "CProConfig.mqh"

//+------------------------------------------------------------------+
//| CProDialog - Startup Dialog Class                                |
//+------------------------------------------------------------------+
class CProDialog {
private:
    bool        m_initialized;
    bool        m_dialogShown;
    string      m_dialogKey;

public:
    CProDialog();
    ~CProDialog();

    //=== Lifecycle ===
    void         Init();
    void         Deinit();

    //=== Dialog Operations ===
    void         ShowStartupDialog();
    bool         WasShown() { return m_dialogShown; }

private:
    // Build dialog message text
    string       BuildDialogText();
    // Check if dialog was ever shown
    bool         WasEverShown();
    // Mark dialog as shown
    void         MarkAsShown();
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CProDialog::CProDialog() {
    m_initialized = false;
    m_dialogShown = false;
    m_dialogKey = CPRO_PREFIX + "DialogShown_" + Symbol();
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CProDialog::~CProDialog() {
    Deinit();
}

//+------------------------------------------------------------------+
//| Init - Initialize dialog                                         |
//+------------------------------------------------------------------+
void CProDialog::Init() {
    if(m_initialized) return;
    m_initialized = true;
    m_dialogShown = false;
}

//+------------------------------------------------------------------+
//| Deinit - Cleanup dialog                                          |
//+------------------------------------------------------------------+
void CProDialog::Deinit() {
    Comment("");
}

//+------------------------------------------------------------------+
//| ShowStartupDialog - Display startup dialog (blocking)             |
//+------------------------------------------------------------------+
void CProDialog::ShowStartupDialog() {
    if(m_dialogShown) return;

    // Check if dialog was ever shown persistently
    if(WasEverShown()) {
        Print("[CProDialog] Dialog already shown, skipping");
        m_dialogShown = true;
        return;
    }

    m_dialogShown = true;

    // Build and display dialog text
    string message = BuildDialogText();
    Comment(message);

    // Show blocking MessageBox
    int result = MessageBox(
        message,
        CPRO_PRODUCT_NAME_CN + " " + CPRO_PRODUCT_VERSION + " - 启动确认",
        MB_OK | MB_ICONINFORMATION | MB_TOPMOST
    );

    if(result != IDOK) {
        Print("[CProDialog] User cancelled startup dialog");
        Comment("操作已取消。如需重新启动，请重启本工具。");
        Sleep(3000);
    } else {
        Print("[CProDialog] User acknowledged startup dialog");
        MarkAsShown();
    }

    // Clear comment after acknowledgment
    Comment("");
}

//+------------------------------------------------------------------+
//| WasEverShown - Check if dialog was ever shown (persistent)       |
//+------------------------------------------------------------------+
bool CProDialog::WasEverShown() {
    return GlobalVariableCheck(m_dialogKey);
}

//+------------------------------------------------------------------+
//| MarkAsShown - Mark dialog as shown persistently                  |
//+------------------------------------------------------------------+
void CProDialog::MarkAsShown() {
    GlobalVariableSet(m_dialogKey, TimeCurrent());
    Print("[CProDialog] Dialog marked as shown");
}

//+------------------------------------------------------------------+
//| BuildDialogText - Build dialog message with final design         |
//+------------------------------------------------------------------+
string CProDialog::BuildDialogText() {
    string text = "";

    // Top decorative line
    text += "================================================\n\n";

    // Company name with decorative
    text += "           城诺科技 · CPro Trading\n\n";

    // Main decorative line
    text += "              ═══════════════════════\n\n";

    // Main slogan
    text += "         「" + CPRO_SLOGAN_MAIN + "」\n\n";

    // Product type
    text += "        专业MQL量化解决方案供应商\n\n";

    // Separator
    text += "           ─────────────────────\n\n";

    // Product categories
    text += "     [产品类型] 智能交易EA / 技术指标 / 实用脚本\n\n";

    // Core advantages
    text += "     [核心优势] 严选代码 · 深度优化 · 稳定可靠\n\n";

    // Separator
    text += "           ─────────────────────\n\n";

    // Contact info
    text += "     合作联系微信: " + CPRO_WEIXIN_BIZ + "\n";
    text += "     技术支持微信: " + CPRO_WEIXIN_SUPPORT + "\n";
    text += "     官方资源站: " + CPRO_WEBSITE + "\n";
    text += "           版本: " + CPRO_PRODUCT_VERSION + "\n\n";

    // Action button
    text += "              [ 确 认 进 入 ]\n\n";

    // Separator
    text += "           ─────────────────────\n\n";

    // Disclaimer
    text += "  友情提醒：本系统仅供技术交流与学习，\n";
    text += "        资金风险自行承担。\n";

    return text;
}

#endif // CPRO_DIALOG_MQH
