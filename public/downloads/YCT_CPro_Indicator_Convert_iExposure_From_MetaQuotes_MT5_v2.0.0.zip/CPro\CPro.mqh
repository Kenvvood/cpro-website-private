//+------------------------------------------------------------------+
//|                                               CPro.mqh           |
//|                         CPro Trading 营销模块主入口                |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+
//
//  PURPOSE:
//    CPro.mqh is the main entry point for all CPro Trading
//    marketing shell components. It provides startup dialogs,
//    statistics panels, and brand watermarks.
//
//  COMPONENTS:
//    - CProConfig.mqh   : Configuration and constants
//    - CProDialog.mqh   : Startup authorization dialog
//    - CProPanel.mqh    : Statistics panel with About tab
//    - CProWatermark.mqh: Circular logo watermark
//
//  USAGE:
//    #include "CPro\CPro.mqh"
//
//    CProDialog dialog;
//    CProPanel panel;
//    CProWatermark watermark;
//
//    dialog.Init();
//    dialog.ShowStartupDialog();
//
//    panel.Init();
//
//    watermark.Init();
//    watermark.DrawWatermark();
//
//+------------------------------------------------------------------+

#ifndef CPRO_MQH
#define CPRO_MQH

// Include all CPro modules
#include "CProConfig.mqh"
#include "CProDialog.mqh"
#include "CProPanel.mqh"
#include "CProWatermark.mqh"

//+------------------------------------------------------------------+
//| Convenience Initialization Macro                                 |
//+------------------------------------------------------------------+
#define CPRO_INIT_ALL(dialog, panel, watermark) \
    dialog.Init(); \
    panel.Init(); \
    watermark.Init();

#define CPRO_SHOW_STARTUP(dialog) \
    dialog.ShowStartupDialog();

#define CPRO_DRAW_WATERMARK(watermark) \
    watermark.DrawWatermark();

#define CPRO_DEINIT_ALL(dialog, panel, watermark) \
    dialog.Deinit(); \
    panel.Deinit(); \
    watermark.Deinit();

//+------------------------------------------------------------------+
//| Global convenience functions for EAs using m_cpro_* instances    |
//| These functions find and initialize/deinit the marketing panel   |
//+------------------------------------------------------------------+
void CPro_Init() {
    // Global instances used by patched EAs (if declared)
    #ifdef m_cpro_dialog
        m_cpro_dialog.Init();
    #endif
    #ifdef m_cpro_panel
        m_cpro_panel.Init();
    #endif
    #ifdef m_cpro_watermark
        m_cpro_watermark.Init();
    #endif
}

void CPro_Deinit() {
    #ifdef m_cpro_watermark
        m_cpro_watermark.Deinit();
    #endif
    #ifdef m_cpro_panel
        m_cpro_panel.Deinit();
    #endif
    #ifdef m_cpro_dialog
        m_cpro_dialog.Deinit();
    #endif
}

#endif // CPRO_MQH
