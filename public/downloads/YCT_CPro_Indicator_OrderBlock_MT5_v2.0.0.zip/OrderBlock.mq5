//+------------------------------------------------------------------+
//|                                         CPro Indicator OrderBlock MT5                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}

//--- User Inputs
input double Multiplier          = 2.0;   // Multiplier for candle body comparison (current vs. next candle)
input bool   UseAdditionalFilter = true;  // Use an extra filter based on recent average candle body size?
input int    AvgPeriod           = 10;    // Number of bars for average body size calculation
input double MinRangeFactor      = 1.5;   // Current candle body must exceed (average body * this factor)
//--- Global buffer for order block signals
double obBuffer[];
//+------------------------------------------------------------------+
//| OnInit()                                                         |
//+------------------------------------------------------------------+
int OnInit()
  {
   // Optionally, you can set the indicator's short name here.
   // IndicatorShortName("OrderBlockDetector (Updated MQL5)");
   // Bind obBuffer[] to buffer 0 as indicator data.
   SetIndexBuffer(0, obBuffer, INDICATOR_DATA);
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| OnCalculate()                                                    |
//| Processes each bar to determine if an order block condition is     |
//| met. Returns 1.0 for bullish blocks, -1.0 for bearish blocks, and     |
//| 0.0 otherwise.                                                     |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   // Ensure there are enough bars for average calculation and for a "next" candle
   if(rates_total < AvgPeriod + 2)
      return(0);
   // Re-calculate starting index to handle boundary changes
   int start = MathMax(prev_calculated - 1, 1);
   // Loop through each bar from 'start' to the last bar
   for(int i = start; i < rates_total; i++)
     {
      // Calculate the current candle's body size
      double currentBody = MathAbs(close[i] - open[i]);
      // Calculate the average body size over the previous AvgPeriod bars (if enabled)
      double avgBody = 0.0;
      if(UseAdditionalFilter)
        {
         int count = 0;
         for(int j = i - AvgPeriod; j < i && j >= 0; j++)
           {
            avgBody += MathAbs(close[j] - open[j]);
            count++;
           }
         if(count > 0)
            avgBody /= count;
        }
      // Get the next candle's body size (if available)
      double nextBody = 0.0;
      if(i + 1 < rates_total)
         nextBody = MathAbs(close[i + 1] - open[i + 1]);
      // Initialize signal to 0 (no order block)
      double signal = 0.0;
      // Only check if the next candle exists and its body is nonzero
      if(nextBody > 0)
        {
         // Primary condition: current candle's body must be larger than next candle's body times Multiplier
         bool conditionPrimary = (currentBody > (nextBody * Multiplier));
         // Additional filter: current candle's body must exceed the average body * MinRangeFactor (if enabled)
         bool conditionAdditional = true;
         if(UseAdditionalFilter)
            conditionAdditional = (currentBody > (avgBody * MinRangeFactor));
         // If both conditions are met, assign a bullish (1.0) or bearish (-1.0) signal
         if(conditionPrimary && conditionAdditional)
           {
            if(close[i] > open[i])
               signal = 1.0;   // Bullish order block (demand zone)
            else if(close[i] < open[i])
               signal = -1.0;  // Bearish order block (supply zone)
           }
        }
      // Store the calculated signal in the buffer for bar i
      obBuffer[i] = signal;
     }
   // Return the total number of bars processed
   return(rates_total);
  }
//+------------------------------------------------------------------+
//| Usage in EA:                                                   |
//|   double obValue = iCustom(_Symbol, PERIOD_CURRENT,              |
//|                            "OrderBlock", 0, shift);             |
//|   // obValue returns -1, 0, or 1 depending on the detected block   |
//+------------------------------------------------------------------+