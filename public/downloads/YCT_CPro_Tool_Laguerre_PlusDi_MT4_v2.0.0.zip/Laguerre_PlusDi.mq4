//+------------------------------------------------------------------+
//|                                         CPro Tool Laguerre_PlusDi MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//----
//---- input parameters
extern double periods=14;
extern double timeperiods=0;
extern double gamma=0.764;
extern int CountBars=300;
//----
double L0=0;
double L1=0;
double L2=0;
double L3=0;
double L0A=0;
double L1A=0;
double L2A=0;
double L3A=0;
double LRSI=0;
double CU=0;
double CD=0;
double val1[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int init()
  {
//---- indicators
//----
   SetIndexBuffer(0,val1);
   return(0);
  }
//+------------------------------------------------------------------+
//| Custor indicator deinitialization function                       |
//+------------------------------------------------------------------+
int deinit()
  {
//---- TODO: add your code here
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int start()
  {
   if (CountBars>Bars) CountBars=Bars;
   SetIndexDrawBegin(0,Bars-CountBars);
//----
   int i;
   int    counted_bars=IndicatorCounted();
   //if(CountBars<=Lookback) return(0);
//---- initial zero
   //if(counted_bars<1)
   //{
   //   for(i=1;i<=Lookback;i++) val1[CountBars-i]=0.0;
   //}
   i=CountBars-1;
   while(i>=0)
     {
      L0A=L0;
      L1A=L1;
      L2A=L2;
      L3A=L3;
      L0=((1 - gamma)*iADX(NULL,timeperiods,periods,PRICE_HIGH,MODE_PLUSDI,i)) + gamma*L0A;
      L1=((- gamma *L0) + L0A) + (gamma *L1A);
      L2=((- gamma *L1) + L1A) + (gamma *L2A);
      L3=((- gamma *L2) + L2A) + (gamma *L3A);
//----
      CU=0;
      CD=0;
//----
      if (L0>=L1) CU=L0 - L1; else CD=L1 - L0;
      if (L1>=L2) CU=CU + L1 - L2; else CD=CD + L2 - L1;
      if (L2>=L3) CU=CU + L2 - L3; else CD=CD + L3 - L2;
      if (CU + CD!=0) LRSI=CU/(CU + CD);
      val1[i]=LRSI;
      i--;
     }
   return(0);
  }
//+------------------------------------------------------------------+