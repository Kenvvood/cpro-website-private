//+------------------------------------------------------------------+
//|                                         CPro Indicator UTBot MT5                         |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input double AtrCoef = 2;//ATR指标 coefficient (sensitivity)
input int AtrLen = 1;//ATR 周期
// Buffers
double Bull[];
double Bear[];
double C1[];
int ATR_handle;
double ATR[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, Bull);
    PlotIndexSetInteger(0, PLOT_ARROW, 233);
    SetIndexBuffer(1, Bear);
    PlotIndexSetInteger(1, PLOT_ARROW, 234);
    SetIndexBuffer(2, C1, INDICATOR_CALCULATIONS);
    ATR_handle = iATR(NULL, 0, AtrLen);
    if (ATR_handle == INVALID_HANDLE) {
        Print("Runtime error = ", GetLastError());
        return(INIT_FAILED);
    }
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    int limit = rates_total - prev_calculated;
    int toCopy = limit + 1;
    if (prev_calculated == 0) {
        ArrayInitialize(Bull, 0);
        ArrayInitialize(Bear, 0);
        ArrayInitialize(C1, 0);
        limit = limit - 1 - MathMax(1, AtrLen);
        toCopy = rates_total;
    }
    if (rates_total <= MathMax(1, AtrLen)) return(0);
    if (limit < 0) return(0);
    if (BarsCalculated(ATR_handle) != rates_total) return(0);
    if (CopyBuffer(ATR_handle, 0, 0, toCopy, ATR) <= 0) return(0);
    ArraySetAsSeries(ATR, true);
    ArraySetAsSeries(time, true);
    ArraySetAsSeries(open, true);
    ArraySetAsSeries(high, true);
    ArraySetAsSeries(low, true);
    ArraySetAsSeries(close, true);
    ArraySetAsSeries(Bull, true);
    ArraySetAsSeries(Bear, true);
    ArraySetAsSeries(C1, true);
    for (int i = limit; i >= 0 && !IsStopped(); i--) {
        double loss = ATR[i] * AtrCoef;
        double t1 = close[i] > C1[i + 1] ? close[i] - loss : close[i] + loss;
        double t2 = close[i] < C1[i + 1] && close[i + 1] < C1[i + 1] ? MathMin(C1[i + 1], close[i] + loss) : t1;
        C1[i] = close[i] > C1[i + 1] && close[i + 1] > C1[i + 1] ? MathMax(C1[i + 1], close[i] - loss) : t2;
        double h = MathAbs(high[i + 1] - low[i + 1]);
        Bull[i] = close[i] > C1[i] && close[i + 1] <= C1[i + 1] ? low[i] - h : 0;
        Bear[i] = close[i] < C1[i] && close[i + 1] >= C1[i + 1] ? high[i] + h : 0;
    }
    return(rates_total);
}
//+------------------------------------------------------------------+