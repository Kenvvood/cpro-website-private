//+------------------------------------------------------------------+
//|                                         CPro Indicator TSIsCDiCust MT5                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot TSIsCD
//--- plot Tsi
//#property indicator_label2  "Tsi"
//#property indicator_type2   DRAW_LINE
//#property indicator_color2  clrRed
//#property indicator_style2  STYLE_SOLID
//#property indicator_width2  1
//--- plot TsiSignal
//#property indicator_label3  "TsiSignal"
//#property indicator_type3   DRAW_LINE
//#property indicator_color3  clrRed
//#property indicator_style3  STYLE_SOLID
//#property indicator_width3  1
//--- input parameters
input int r=25;
input int s=13;
input int sp=5;//smoothing 周期
input ENUM_MA_METHOD sm=MODE_EMA;//smoothing 类型
int iHandle;
//--- indicator buffers
double         TSIsCDBuffer[];
double         TSIsCDColors[];
double         TsiBuffer[];
double         TsiSignalBuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,TSIsCDBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,TSIsCDColors,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(2,TsiBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(3,TsiSignalBuffer,INDICATOR_CALCULATIONS);
   iHandle=iCustom(_Symbol,PERIOD_CURRENT,"Tendenz\\Moving Average");
   Print(__FUNCTION__+" iHandle = "+(string)iHandle);
   if(iHandle == INVALID_HANDLE) return(INIT_FAILED);
//---
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const int begin,
                const double &price[])
{
//---
   Print(__FUNCTION__+" rates_total = "+(string)rates_total);
   Print(__FUNCTION__+" prev_calculated = "+(string)prev_calculated);
   Print(__FUNCTION__+" begin = "+(string)begin);
   Print(__FUNCTION__+" price = "+(string)price[0]);
   static bool error=true; 
   int start;
   if(prev_calculated==0) // First execution of the OnCalculate() function after the indicator start
     {
      error=true; // Set the value True for the indicator to be calculated for all bars
     }
   if(error) // If value of error=true, then it is the first execution of the function after 
             // the start of the indicator, or there was an error of copying of data at the previous start
     {
      start=begin+1;
      error=false;
     }
   else
     {
      start=prev_calculated-1;
     }
   if(CopyBuffer(iHandle,0,0,rates_total-start,TsiBuffer)==-1) // Copying data of main line of the indicator
     {
      error=true; // Failed to copy data, set the value True for the error variable to recalculate the whole 
                 // indicator at the next call of OnCalculate()
      return(0);  // End working of the function
     }
   if(CopyBuffer(iHandle,1,0,rates_total-start,TsiSignalBuffer)==-1) // Copy data of the signal line of the indicator
     {
      error=true; // Failed to copy data, set the value true for the error variable to recalculate the whole
                 // indicator at the next call of the OnCalculate() function
      return(0);  // End working of the function
     }
//--- return value of prev_calculated for next call
   return(rates_total);
}
//+------------------------------------------------------------------+