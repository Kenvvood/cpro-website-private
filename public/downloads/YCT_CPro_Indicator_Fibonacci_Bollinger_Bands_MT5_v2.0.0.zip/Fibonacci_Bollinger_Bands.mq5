//+------------------------------------------------------------------+
//|                                         CPro Indicator Fibonacci_Bollinger_Bands MT5     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


// Plot Properties
// Input Parameters
input int                  Length = 200;//bb 周期
input double               Mult   = 3.0;//bb 乘数
input ENUM_APPLIED_PRICE   Applied_price = PRICE_TYPICAL; // Stdev Source
// Buffers
double basisBuffer[];
double upperBuffer[];
double lowerBuffer[];
double devValue[];
// Buffers for fibonacci
double upper764[];
double upper618[];
double upper5[];
double upper382[];
double upper236[];
double lower764[];
double lower618[];
double lower5[];
double lower382[];
double lower236[];
// Handle
int devHandle;
// Initialization
int OnInit()
  {
// Mapping Buffers
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0, upperBuffer, INDICATOR_DATA);
   SetIndexBuffer(1, lowerBuffer, INDICATOR_DATA);
   SetIndexBuffer(2, basisBuffer, INDICATOR_DATA);
   SetIndexBuffer(3, upper764, INDICATOR_DATA);
   SetIndexBuffer(4, upper618, INDICATOR_DATA);
   SetIndexBuffer(5, upper5, INDICATOR_DATA);
   SetIndexBuffer(6, upper382, INDICATOR_DATA);
   SetIndexBuffer(7, upper236, INDICATOR_DATA);
   SetIndexBuffer(8, lower764, INDICATOR_DATA);
   SetIndexBuffer(9, lower618, INDICATOR_DATA);
   SetIndexBuffer(10, lower5, INDICATOR_DATA);
   SetIndexBuffer(11, lower382, INDICATOR_DATA);
   SetIndexBuffer(12, lower236, INDICATOR_DATA);
// Initialize Arrays
   ArraySetAsSeries(basisBuffer, true);
   ArraySetAsSeries(upperBuffer, true);
   ArraySetAsSeries(lowerBuffer, true);
   ArraySetAsSeries(devValue, true);
   ArraySetAsSeries(upper764, true);
   ArraySetAsSeries(upper618, true);
   ArraySetAsSeries(upper5, true);
   ArraySetAsSeries(upper382, true);
   ArraySetAsSeries(upper236, true);
   ArraySetAsSeries(lower764, true);
   ArraySetAsSeries(lower618, true);
   ArraySetAsSeries(lower5, true);
   ArraySetAsSeries(lower382, true);
   ArraySetAsSeries(lower236, true);
// Create StdDev Indicator
   devHandle = iStdDev(_Symbol, PERIOD_CURRENT, Length, 0, MODE_SMA, Applied_price);
   if(devHandle == INVALID_HANDLE)
     {
      Print("Error creating StdDev handle");
      return(INIT_FAILED);
     }
   return(INIT_SUCCEEDED);
  }
// VWMA Calculation
double vwma(const double &src[], int lengthVWMA, int index)
  {
   double s1 = 0, s2 = 0;
   for(int i = index; i < MathMin(index + lengthVWMA, ArraySize(src)); i++)
     {
      double vol = (double)iVolume(_Symbol, PERIOD_CURRENT, i);
      if(vol == 0)
         continue; // Skip invalid volume
      s1 += src[i] * vol;
      s2 += vol;
     }
   return s2 == 0 ? 0 : s1 / s2; // Prevent division by zero
  }
// OnCalculate Function
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const int begin,
                const double &price[])
  {
   ArraySetAsSeries(price, true);
   if(CopyBuffer(devHandle, 0, 0, rates_total, devValue) <= 0 || ArraySize(devValue) < rates_total)
     {
      Print("Failed to copy StdDev values or devValue array size mismatch");
      return(prev_calculated);
     }
   // Define the calculation limit based on the number of previously calculated bars.
   int limit = rates_total - prev_calculated;
   if (prev_calculated == 0)
      limit = rates_total - 2;
   else
      limit++; 
   if(limit > rates_total - 2) 
      limit = rates_total - 2;
   /// Loop through each bar for calculation.
   for(int i = limit; i >= 0; i--)
     {
      // Calculate the basis using the VWMA.
      double basis = vwma(price, Length, i);
      if (basis == 0 || basis == EMPTY_VALUE)
        {
         basisBuffer[i] = EMPTY_VALUE;
         upperBuffer[i] = EMPTY_VALUE;
         lowerBuffer[i] = EMPTY_VALUE;
         upper236[i] = EMPTY_VALUE;
         lower236[i] = EMPTY_VALUE;
         continue; // Skip this bar's calculation.
        }
      basisBuffer[i] = basis;
      double dev = devValue[i];
      if (dev == EMPTY_VALUE || dev <= 0)
        {
         basisBuffer[i] = EMPTY_VALUE;
         upperBuffer[i] = EMPTY_VALUE;
         lowerBuffer[i] = EMPTY_VALUE;
         upper236[i] = EMPTY_VALUE;
         lower236[i] = EMPTY_VALUE;
         continue;
        }
      // Calculate the upper and lower bands based on the multiplier and standard deviation.
      upperBuffer[i] = basis + Mult * dev;  // Upper Band
      lowerBuffer[i] = basis - Mult * dev;  // Lower Band
      // Calculate Fibonacci levels for the bands.
      upper236[i] = basis + Mult * dev * 0.236;
      upper382[i] = basis + Mult * dev * 0.382;
      upper5[i]   = basis + Mult * dev * 0.5;
      upper618[i] = basis + Mult * dev * 0.618;
      upper764[i] = basis + Mult * dev * 0.764;
      lower236[i] = basis - Mult * dev * 0.236;
      lower382[i] = basis - Mult * dev * 0.382;
      lower5[i]   = basis - Mult * dev * 0.5;
      lower618[i] = basis - Mult * dev * 0.618;
      lower764[i] = basis - Mult * dev * 0.764;
     }
   return rates_total;
  }