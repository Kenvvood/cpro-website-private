//+------------------------------------------------------------------+
//|                                         CPro Tool Teste_Configuracao MT5                 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- Parâmetros de entrada
input bool TestSymbolInfo = true;//testar infor均线ções do símbolo
input bool TestAccount = true;//testar infor均线ções da conta
input bool TestIndicators = true;        // Testar criação de indicadores
input bool TestConnection = true;        // Testar conexão com servidor
//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+
void OnStart()
{
    Print("===============================================");
    Print("   TESTE DE CONFIGURAÇÃO - ADA/USD FXPRO");
    Print("===============================================");
    bool allTestsPassed = true;
    if(TestSymbolInfo)
    {
        Print("\n🔍 TESTANDO INFORMAÇÕES DO SÍMBOLO...");
        if(!TestSymbol())
            allTestsPassed = false;
    }
    if(TestAccount)
    {
        Print("\n💰 TESTANDO INFORMAÇÕES DA CONTA...");
        if(!TestAccountInfo())
            allTestsPassed = false;
    }
    if(TestIndicators)
    {
        Print("\n📊 TESTANDO CRIAÇÃO DE INDICADORES...");
        if(!TestIndicatorCreation())
            allTestsPassed = false;
    }
    if(TestConnection)
    {
        Print("\n🌐 TESTANDO CONEXÃO COM SERVIDOR...");
        if(!TestServerConnection())
            allTestsPassed = false;
    }
    Print("\n===============================================");
    if(allTestsPassed)
    {
        Print("✅ TODOS OS TESTES PASSARAM!");
        Print("✅ AMBIENTE CONFIGURADO CORRETAMENTE");
        Print("✅ PRONTO PARA USAR O EA ADA/USD");
    }
    else
    {
        Print("❌ ALGUNS TESTES FALHARAM!");
        Print("❌ VERIFIQUE AS CONFIGURAÇÕES ANTES DE USAR");
    }
    Print("===============================================");
}
//+------------------------------------------------------------------+
//| Testar informações do símbolo                                   |
//+------------------------------------------------------------------+
bool TestSymbol()
{
    string symbol = _Symbol;
    bool success = true;
    Print("Símbolo atual: ", symbol);
    // Verificar se é ADA/USD
    if(StringFind(symbol, "ADA") == -1)
    {
        Print("⚠️ AVISO: Símbolo não contém 'ADA'. Símbolo atual: ", symbol);
    }
    // Testar informações básicas do símbolo
    double tickSize = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_SIZE);
    double tickValue = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_VALUE);
    double minLot = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
    double maxLot = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
    double lotStep = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
    int digits = (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS);
    Print("📏 Tamanho do tick: ", DoubleToString(tickSize, digits));
    Print("💵 Valor do tick: ", DoubleToString(tickValue, 5));
    Print("📦 Lote mínimo: ", DoubleToString(minLot, 2));
    Print("📦 Lote máximo: ", DoubleToString(maxLot, 2));
    Print("📦 Passo do lote: ", DoubleToString(lotStep, 2));
    Print("🔢 Dígitos: ", digits);
    // Verificar configurações específicas da FXPro para ADA/USD
    if(tickSize != 0.00001)
    {
        Print("⚠️ AVISO: Tick size esperado 0.00001, atual: ", DoubleToString(tickSize, digits));
    }
    if(minLot != 0.01)
    {
        Print("⚠️ AVISO: Lote mínimo esperado 0.01, atual: ", DoubleToString(minLot, 2));
    }
    // Testar preços atuais
    double ask = SymbolInfoDouble(symbol, SYMBOL_ASK);
    double bid = SymbolInfoDouble(symbol, SYMBOL_BID);
    double spread = ask - bid;
    if(ask > 0 && bid > 0)
    {
        Print("💹 Ask: ", DoubleToString(ask, digits));
        Print("💹 Bid: ", DoubleToString(bid, digits));
        Print("📊 Spread: ", DoubleToString(spread, digits), " (", DoubleToString(spread/tickSize, 1), " pontos)");
        if(spread > 0.001)
        {
            Print("⚠️ AVISO: Spread alto: ", DoubleToString(spread, digits));
        }
    }
    else
    {
        Print("❌ ERRO: Não foi possível obter preços atuais");
        success = false;
    }
    return success;
}
//+------------------------------------------------------------------+
//| Testar informações da conta                                     |
//+------------------------------------------------------------------+
bool TestAccountInfo()
{
    bool success = true;
    // Informações da conta
    string company = AccountInfoString(ACCOUNT_COMPANY);
    string server = AccountInfoString(ACCOUNT_SERVER);
    string name = AccountInfoString(ACCOUNT_NAME);
    long leverage = AccountInfoInteger(ACCOUNT_LEVERAGE);
    double balance = AccountInfoDouble(ACCOUNT_BALANCE);
    double equity = AccountInfoDouble(ACCOUNT_EQUITY);
    double margin = AccountInfoDouble(ACCOUNT_MARGIN);
    double freeMargin = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
    Print("🏢 Corretora: ", company);
    Print("🖥️ Servidor: ", server);
    Print("👤 Nome da conta: ", name);
    Print("⚖️ Alavancagem: 1:", leverage);
    Print("💰 Saldo: $", DoubleToString(balance, 2));
    Print("💰 Equity: $", DoubleToString(equity, 2));
    Print("💰 Margem usada: $", DoubleToString(margin, 2));
    Print("💰 Margem livre: $", DoubleToString(freeMargin, 2));
    // Verificar se é FXPro
    if(StringFind(company, "FxPro") == -1 && StringFind(server, "FxPro") == -1)
    {
        Print("⚠️ AVISO: Não parece ser uma conta FXPro");
        Print("⚠️ Corretora detectada: ", company);
    }
    // Verificar alavancagem
    if(leverage != 50)
    {
        Print("⚠️ AVISO: Alavancagem esperada 50:1, atual: 1:", leverage);
    }
    // Verificar saldo mínimo
    if(balance < 100)
    {
        Print("⚠️ AVISO: Saldo baixo para trading. Recomendado: $300+ USD");
    }
    return success;
}
//+------------------------------------------------------------------+
//| Testar criação de indicadores                                   |
//+------------------------------------------------------------------+
bool TestIndicatorCreation()
{
    bool success = true;
    string symbol = _Symbol;
    // Testar criação de indicadores
    int handleMA = iMA(symbol, PERIOD_H1, 21, 0, MODE_EMA, PRICE_CLOSE);
    int handleRSI = iRSI(symbol, PERIOD_H1, 14, PRICE_CLOSE);
    if(handleMA == INVALID_HANDLE)
    {
        Print("❌ ERRO: Não foi possível criar indicador MA");
        success = false;
    }
    else
    {
        Print("✅ Indicador MA criado com sucesso");
        IndicatorRelease(handleMA);
    }
    if(handleRSI == INVALID_HANDLE)
    {
        Print("❌ ERRO: Não foi possível criar indicador RSI");
        success = false;
    }
    else
    {
        Print("✅ Indicador RSI criado com sucesso");
        IndicatorRelease(handleRSI);
    }
    // Testar dados históricos
    MqlRates rates[];
    int copied = CopyRates(symbol, PERIOD_H1, 0, 10, rates);
    if(copied > 0)
    {
        Print("✅ Dados históricos disponíveis: ", copied, " candles");
        Print("📅 Último candle: ", TimeToString(rates[copied-1].time));
    }
    else
    {
        Print("❌ ERRO: Não foi possível obter dados históricos");
        success = false;
    }
    return success;
}
//+------------------------------------------------------------------+
//| Testar conexão com servidor                                     |
//+------------------------------------------------------------------+
bool TestServerConnection()
{
    bool success = true;
    // Verificar conexão
    bool connected = TerminalInfoInteger(TERMINAL_CONNECTED);
    long ping = TerminalInfoInteger(TERMINAL_PING_LAST);
    if(connected)
    {
        Print("✅ Conectado ao servidor");
        Print("🏓 Ping: ", ping, " ms");
        if(ping > 100)
        {
            Print("⚠️ AVISO: Ping alto (>100ms). Pode afetar execução de ordens");
        }
    }
    else
    {
        Print("❌ ERRO: Não conectado ao servidor");
        success = false;
    }
    // Verificar permissões de trading
    bool tradingAllowed = TerminalInfoInteger(TERMINAL_TRADE_ALLOWED);
    bool autoTradingEnabled = TerminalInfoInteger(TERMINAL_MQID);
    if(tradingAllowed)
    {
        Print("✅ Trading permitido no terminal");
    }
    else
    {
        Print("❌ ERRO: Trading não permitido no terminal");
        success = false;
    }
    // Verificar horário de mercado
    MqlDateTime time_struct;
    TimeToStruct(TimeCurrent(), time_struct);
    Print("⏰ Hora do servidor: ", TimeToString(TimeCurrent()));
    Print("📅 Dia da semana: ", time_struct.day_of_week, " (1=Segunda, 5=Sexta)");
    if(time_struct.day_of_week == 0 || time_struct.day_of_week == 6)
    {
        Print("⚠️ AVISO: Fim de semana - mercado fechado");
    }
    return success;
}
//+------------------------------------------------------------------+
//| Função auxiliar para verificar EA permissions                   |
//+------------------------------------------------------------------+
void CheckEAPermissions()
{
    Print("\n🔐 VERIFICANDO PERMISSÕES DO EA...");
    bool dllAllowed = TerminalInfoInteger(TERMINAL_DLLS_ALLOWED);
    bool tradeAllowed = TerminalInfoInteger(TERMINAL_TRADE_ALLOWED);
    Print("DLL Permitido: ", dllAllowed ? "Sim" : "Não");
    Print("Trading Permitido: ", tradeAllowed ? "Sim" : "Não");
    if(!tradeAllowed)
    {
        Print("❌ Para usar o EA, habilite o Auto Trading (Ctrl+E)");
    }
} 