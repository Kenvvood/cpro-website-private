//+------------------------------------------------------------------+
//|                                         CPro Indicator PriceDensity_MT5 MT5              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//Input parameters
input int    InpPeriods                = 20;//indicator 周期s
input double InpNoiseThresholdLevel    = 5.0;//价格 density noise threshold 级别
input color  InpLineColor              = clrBlack;//threshold 级别 颜色
//Indicator Buffers
double PriceDensityBuffer[];
double SumHighsLowsBuffer[];
double HighestHighBuffer[];
double LowestLowBuffer[];
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0, PriceDensityBuffer, INDICATOR_DATA);
   SetIndexBuffer(1, SumHighsLowsBuffer, INDICATOR_CALCULATIONS);
   SetIndexBuffer(2, HighestHighBuffer, INDICATOR_CALCULATIONS);
   SetIndexBuffer(3, LowestLowBuffer, INDICATOR_CALCULATIONS);
   IndicatorSetInteger(INDICATOR_DIGITS, 5);
   IndicatorSetString(INDICATOR_SHORTNAME, "Price Density - Market Noise Index (" + IntegerToString(InpPeriods) + ")");
   PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, InpPeriods);
   IndicatorSetDouble(INDICATOR_LEVELVALUE, 0, InpNoiseThresholdLevel);
   IndicatorSetInteger(INDICATOR_LEVELCOLOR, 0, InpLineColor);
   IndicatorSetString(INDICATOR_LEVELTEXT, 0, "Threshold Level");
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
//if the rates_total is less than the period return
   if(rates_total <= InpPeriods)
      return(0);
   int currentPosition = prev_calculated - 1;
   if(currentPosition < InpPeriods)
      currentPosition = InpPeriods;
//Loop from the current position to rates_total
   for(int i = currentPosition; i < rates_total && !IsStopped(); i++)
     {
      if(rates_total != prev_calculated)
        {
         SumHighsLowsBuffer[i] = 0;
         HighestHighBuffer[i] = DBL_MIN;
         LowestLowBuffer[i] = DBL_MAX;
         //Loop to get the highest index and the lowest.
         for(int j = i - 1; j > i - InpPeriods; j--)
           {
            SumHighsLowsBuffer[i] += high[j] - low[j];
            if(high[j] > HighestHighBuffer[i])
               HighestHighBuffer[i] = high[j];
            if(low[j] < LowestLowBuffer[i])
               LowestLowBuffer[i] = low[j];
           }
        }
      //get the highest value and the lowest value.
      double highestHigh = MathMax(HighestHighBuffer[i], high[i]);
      double lowestLow = MathMin(LowestLowBuffer[i], low[i]);
      //Price density formula
      if(highestHigh - lowestLow != 0)
         PriceDensityBuffer[i] = (SumHighsLowsBuffer[i] + (high[i] - low[i])) / (highestHigh - lowestLow);
      else
         PriceDensityBuffer[i] = 0.0;
     }
   return(rates_total);
  }
//+------------------------------------------------------------------+