//+------------------------------------------------------------------+
//|                                         CPro Tool Strategy_of_Regularities_of_Exchange_Rates MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int optime=9; //
extern int cltime=2; //
extern int point=20;//
extern double Lots=0.1;//
extern int TakeProfit=20;//
extern int StopLoss=500;//
//     
int bars;
int start()
  {
  Comment("FORTRADER.RU -   ");
  if(IsDemo()==FALSE && IsTesting()==FALSE){Print("FORTRADER.RU -version only testing");return(0);}
 PosManager();
  //     
 if(Period()>60){Print("Period must be < hour");return(0);}
 if(bars!=Bars)
 {bars=Bars;
 TimePattern();
 }
   return(0);
  }
int TimePattern()
{
if(Hour() ==optime)
{
//           
OrderSend(Symbol(),OP_SELLSTOP,Lots,NormalizeDouble(Ask-point*Point,Digits),3,NormalizeDouble(Ask+StopLoss*Point,Digits),0,"FORTRADER.RU",0,0,Red);
OrderSend(Symbol(),OP_BUYSTOP,Lots,NormalizeDouble(Bid+point*Point,Digits),3,NormalizeDouble(Bid-StopLoss*Point,Digits),0,"FORTRADER.RU",0,0,Red);
}
return(0);
}
int deletebstop()
{
   for( int i=1; i<=OrdersTotal(); i++)          
   {
    if(OrderSelect(i-1,SELECT_BY_POS)==true) 
    {                                       
     if(OrderType()==OP_BUYSTOP && OrderSymbol()==Symbol())
     {
      OrderDelete(OrderTicket()); 
     }//if
    }//if
   }
   return(0);
}
int deletesstop()
{
   for( int i=1; i<=OrdersTotal(); i++)          
   {
    if(OrderSelect(i-1,SELECT_BY_POS)==true) 
    {                                       
     if(OrderType()==OP_SELLSTOP && OrderSymbol()==Symbol())
     {
      OrderDelete(OrderTicket()); 
     }//if
    }//if
   }
   return(0);
}
int PosManager()
{int i,z;
if(Hour() ==cltime){deletebstop();deletesstop();}
for(  i=1; i<=OrdersTotal(); i++)          
   {
    if(OrderSelect(i-1,SELECT_BY_POS)==true) 
    {                                       
     if(OrderType()==OP_SELL && ((OrderOpenPrice()-Ask)>=(TakeProfit)*Point || Hour()==cltime))
     {
     OrderClose(OrderTicket(),OrderLots(),Ask,3,Violet);   
     }//if
    }//if
   }
   for(i=1; i<=OrdersTotal(); i++)          
   {
    if(OrderSelect(i-1,SELECT_BY_POS)==true) 
    {                      
     if(OrderType()==OP_BUY && ((Bid-OrderOpenPrice())>=(TakeProfit)*Point || Hour()==cltime))
     {OrderClose(OrderTicket(),OrderLots(),Bid,3,Violet);         
     }//if
    }//if
   }
return(0);
}