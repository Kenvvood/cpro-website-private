//+------------------------------------------------------------------+
//|                                         CPro EA hpcs_inter4_mt4_v01_we MT4               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
input int igi_stoploss = 10;
input int igi_takeprofit = 10;
input int igi_lots = 01;
input int  igi_magicNum = 2233;
int li_ticket=-1;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   int factor = 1;
   if(Digits == 5 || Digits ==3)
     { factor = 10; }
   double ld_takeprofit = Ask + igi_takeprofit*Point()*factor;
   double ld_stopLoss = Ask - igi_stoploss*Point()*factor;
   if(ld_stopLoss > (Bid - MarketInfo(_Symbol,MODE_STOPLEVEL)*Point()))
     {
      ld_stopLoss = Bid - MarketInfo(_Symbol,MODE_STOPLEVEL)*Point();
     }
   li_ticket = OrderSend(Symbol(),OP_BUY,igi_lots,Ask,10,ld_stopLoss,ld_takeprofit,NULL,igi_magicNum);
   if(li_ticket < 0)
     {
      Print("Order Send fail! ",GetLastError());
     }
   if(OrderSelect(li_ticket,SELECT_BY_TICKET))
     {
      OrderPrint();
      if(!OrderModify(OrderTicket(),OrderOpenPrice(),ld_stopLoss-(10*Point()*factor),ld_takeprofit,0))
        {
         Print("Order Not Modifiy Wth Error! ",GetLastError());
        }
      else
      {
         Print("Order Modified");
      }
     }
   //EventSetTimer(30);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
EventKillTimer();
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnTimer()
  {
   /*if(OrderSelect(li_ticket,SELECT_BY_TICKET))
      if(OrderCloseTime() == 0)
         if(!OrderClose(li_ticket,igi_lots,OrderClosePrice(),10))
            Print("Order Not Closed Wth Error! ",GetLastError());
   */
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
   if(OrderSelect(li_ticket,SELECT_BY_TICKET))
      if(TimeCurrent() >= (OrderOpenTime()+ 30))
         if(OrderCloseTime() == 0)
            if(!OrderClose(li_ticket,igi_lots,OrderClosePrice(),10))
               Print("Order Not Closed Wth Error! ",GetLastError());
            else
            {
               Print("Order Closed after 30 Seconds");
            }
  }
//+------------------------------------------------------------------+