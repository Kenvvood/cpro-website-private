//+------------------------------------------------------------------+
//|                                         CPro Indicator KnitPkgSMA MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


#include "../knitpkg/flat/KnitPkgSMA_flat.mqh"

//---
//--- input parametrs
input int     InpSMAPeriod=10;//周期
//--- indicator buffers
double         SMABuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,SMABuffer,INDICATOR_DATA);
//--- set index labels
   PlotIndexSetString(0,PLOT_LABEL,"KnitPkg SMA("+string(InpSMAPeriod)+")");
//--- indicator name
   IndicatorShortName("KnitPkg SMA");
//--- indexes draw begin settings
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,InpSMAPeriod);
//--- number of digits of indicator value
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);  
//---
   ArraySetAsSeries(SMABuffer, true); 
//---   
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long& tick_volume[],
                const long& volume[],
                const int& spread[])
  {
//---
   int start;
   if(prev_calculated==0)
      start=InpSMAPeriod;
   else
      start=prev_calculated-1;
//---
   for(int i=start;i<rates_total && !IsStopped();i++)
     {
      double sum=0.0;
      int count=0;
      for(int j=0;j<InpSMAPeriod;j++)
        {
         int idx=i+j;
         if(idx>=rates_total)
            break;
         sum+=close[idx];
         count++;
        }
      if(count>0)
         SMABuffer[i]=sum/count;
      else
         SMABuffer[i]=EMPTY_VALUE;
     }
//---
   return(rates_total);
  }
//+------------------------------------------------------------------+