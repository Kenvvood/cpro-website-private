//+------------------------------------------------------------------+
//|                                         CPro Tool AiDataTaskRunnerByLeo MT5              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include "Global.mqh"
#include "Backend\\All.mqh"

//#define RELEASE_VERSION
//+------------------------------------------------------------------+
//| Include                                                          |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
sinput group "-- Panel folder --"
input ENUM_VERBOSE_LOG_LEVEL InpLogLevelPanelFronted = VERBOSE_LOG_LEVEL_ALL;//log 级别s
input string InpGeneralBaseFolder = "AiDataTaskRunner\\"; // Folder for panel files
input bool InpGeneralCommonFolder = true; // In common folder ?
sinput group "-- Generation  --"
input ENUM_VERBOSE_LOG_LEVEL InpLogLevelPanelBackend = VERBOSE_LOG_LEVEL_ALL;//log 级别s
input bool InpBackendCommonIn = true; // Files EA input in common folder ?
input bool InpBackendCommonOut = true;//files ea ou止盈ut in common folder ?
sinput group "-- Telegram bot  --"
input string InpTelegramBotPath = EXPERT_TELEGRAM_PATH; // Put the path of telegram (Full incluyed Experts\\)
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
sinput group "-- Training (Py comunication files)--"
sinput group "- Files comuniction -"
input string InpComment1 = "The files located here are relative to the common folder if 'Files EA output in common folder ?' is true"; // -
input string InpComment2 = "Otherwise, they are relative to MQL5\\Files\\"; // -
input string InpTrainingPyComPathJson = "AiDataTaskRunner\\Comunication\\res.json"; // Put the path of json
input string InpTrainingPyComPathBin = "AiDataTaskRunner\\Comunication\\lock.bin"; // Put the path of bin file
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
sinput group "- Py interprete (only for execute .py) -"
input string InpTrainingPyInterpete = "python.exe"; // Path to python interpreter (e.g. python.exe or C:\Python311\python.exe)
input string InpTrainingPyPath = "C:\\Users\\USER\\AppData\\Roaming\\MetaQuotes\\Terminal\\D0E8209F77C8CF37AD8BF550E51FF075\\MQL5\\Shared Projects";//pythonpath sepa比率d by ;
sinput group "- EA Launcher -"
input string InpTrainingPyLauncherEa = "Shared Projects\\AiDataTaskRuner\\Backend\\Training\\TrainingLauncher.ex5"; // Put the path of EA launcher (Relative at Experts\\)
sinput group "-- Workflows --"
input string InpWFEaRevPath = "Shared Projects\\AiDataTaskRuner\\Backend\\Workflows\\RunnerWF.ex5"; // Put the path of EA launcher (Relative at Experts\\)
//+------------------------------------------------------------------+
//| Global variables                                                 |
//+------------------------------------------------------------------+
// Fronted de la aplicacion
CProgram g_program;
//---
// Backend (Ejecucion del tester para la generacion de datos)
CExecutionTester g_backend_executor_tester;
// Comunicacion entre el Tab Ai y el telegram bot (Esto para modificar paraemtors del bot de telegram)
CChatTelegramAgentLLmBase* g_sender_to_telegram;
//  Backend Tab config (Esto para ir comunicandose con el py, se hace un pool de un archivo)
CTrainingTabConfig* g_backend_trainer_config;
// Tab workflows (capturar eventos)
CTabWorkflows* g_tab_wf;
//--- Api
// Esta es la encarga de ir recibiendo cualquier evento que le manden al panel y lo procesa
CAiDataTaskRunnerApiReciber g_api;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
 {
//--- Configracion general del panel
   CPro_Init();  // CPro营销模块初始化
  g_aidatatask_runner_config_g.base_folder = InpGeneralBaseFolder;
  g_aidatatask_runner_config_g.comon_flag = InpGeneralCommonFolder;
//--- Configraucion del backend
// Backend
  g_backend_executor_tester.AddLogFlags(InpLogLevelPanelBackend);
  g_backend_executor_tester.Set(g_program.GetSecTaskRunerAiDGenPtr(), InpBackendCommonIn, InpBackendCommonOut);
// Fronted
  g_program.GetSecTaskRunerAiDGenPtr().SetRunner(&g_backend_executor_tester);
// Api
  if(!g_api.Init())
   {
    FastLog(FATAL_ERROR_TEXT, FUNCION_ACTUAL, "Fallo al inicar la api del panel");
    return INIT_FAILED;
   }
  g_api.SetDataGeneration(&g_backend_executor_tester, g_program.GetSecTaskRunerAiDGenPtr());
// Tab ai
  g_sender_to_telegram = new CChatTelegramAgentLLmBase();
  g_program.GetSecAi().Initialize(g_aidatatask_runner_config_g.base_folder, AIDATATASK_RUNNER_COMON_FLAG, g_sender_to_telegram);
  g_sender_to_telegram.RunEA(InpTelegramBotPath); // Corremos el EA (tlgm) esto es la comuncacion entre el panel que le dice que parameotrs cambiar a telegram bot
//---
// Tab wf
  g_tab_wf = g_program.GetTabWF();
  g_tab_wf.Init(InpWFEaRevPath);
  if(!g_tab_wf.RunEA())
   {
    return INIT_FAILED;
   }
// Config del training tab
  TrainingTabConfig config;
  config.config_py_path_json_file =  InpTrainingPyComPathJson;
  config.config_py_path_lock_bin_file = InpTrainingPyComPathBin;
  config.proyect_common_flag = InpBackendCommonOut;
  config.config_path_to_ea_launcher = InpTrainingPyLauncherEa;
  config.config_path_interpete_py = InpTrainingPyInterpete;
  config.config_path_py_env = InpTrainingPyPath;
  g_backend_trainer_config = g_program.GetTrainingTab().Config();
//--- Creacion final de la GUI
  g_program.CreateGUI(700, 500, InpLogLevelPanelFronted, config);
//---
  return(INIT_SUCCEEDED);
 }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
 {
   CPro_Deinit();  // CPro营销模块清理
//--- Matamos al timer
  EventKillTimer();
//--- Deinit del panel
  g_program.OnDeinitEvent(reason);
//--- Finalizamos la api
  g_api.Deinit();
//--- Deinit final del DSL
  CAutoCleaner::Deinit(reason); // lamamos para que elimine todo lo relaciion a las depndicas del dsl (esto del feature editor)
 }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
 {
//--- Nada aqui
 }
//+------------------------------------------------------------------+
//| Timer function                                                   |
//+------------------------------------------------------------------+
void OnTimer()
 {
//---
  g_backend_trainer_config.OnTimerEvent();
  g_program.OnTimerEvent();
 }
//+------------------------------------------------------------------+
//| ChartEvent function                                              |
//+------------------------------------------------------------------+
void OnChartEvent(const int32_t id,
                  const long &lparam,
                  const double &dparam,
                  const string &sparam)
 {
//---
  g_api.ChartEvent(id, lparam, dparam, sparam); // Api tiene prioridad
  g_backend_executor_tester.ChartEvent(id, lparam, dparam, sparam); // Luego los eventos del tester ()
  g_tab_wf.ChartEvent(id, lparam, dparam, sparam); // Eventos de wf
  g_program.ChartEvent(id, lparam, dparam, sparam); // Por ultimo el renderizado de la GUI
 }
//+------------------------------------------------------------------+