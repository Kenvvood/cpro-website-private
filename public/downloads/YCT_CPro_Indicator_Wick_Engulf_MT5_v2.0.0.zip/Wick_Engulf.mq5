//+------------------------------------------------------------------+
//|                                         CPro Indicator Wick_Engulf MT5                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot Bullish Marubozu
//--- plot Bearish Marubozu
//--- input parameters
input group             "Bearish"
input uchar               InpBullishWECode              = 233;         // BullishWE: code for style DRAW_ARROW (font Wingdings)
input int                 InpBullishWEShift             = 10;//bullishwe: vertical 偏移 of arrows in pixels
input group             "Bullish"
input uchar               InpBearishWECode              = 234;         // BearishWE: code for style DRAW_ARROW (font Wingdings)
input int                 InpBearishWEShift             =10;//bearishwe: vertical 偏移 of arrows in pixels
//--- indicator buffers
double   BullishWEBuffer[];
double   BearishWEBuffer[];
int min_rates_total;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
   min_rates_total=2;
//--- indicator buffers mapping
   SetIndexBuffer(0,BullishWEBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,BearishWEBuffer,INDICATOR_DATA);
   IndicatorSetInteger(INDICATOR_DIGITS,Digits());
//--- setting a code from the Wingdings charset as the property of PLOT_ARROW
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,min_rates_total);
   PlotIndexSetInteger(1,PLOT_DRAW_BEGIN,min_rates_total);
   PlotIndexSetInteger(0,PLOT_ARROW,InpBullishWECode);
   PlotIndexSetInteger(1,PLOT_ARROW,InpBearishWECode);
   ArraySetAsSeries(BullishWEBuffer,true);
   ArraySetAsSeries(BearishWEBuffer,true);
//--- set the vertical shift of arrows in pixels
   PlotIndexSetInteger(0,PLOT_ARROW_SHIFT,InpBullishWEShift);
   PlotIndexSetInteger(1,PLOT_ARROW_SHIFT,-InpBearishWEShift);
//--- set as an empty value 0.0
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,0.0);
   PlotIndexSetDouble(1,PLOT_EMPTY_VALUE,0.0);
//---
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
//---
   if(rates_total<min_rates_total)
      return(0);
   int limit;
   if(prev_calculated>rates_total || prev_calculated<=0) {
      limit=rates_total-min_rates_total;
   } else {
      limit=rates_total-prev_calculated;
   }
   ArraySetAsSeries(open,true);
   ArraySetAsSeries(high,true);
   ArraySetAsSeries(low,true);
   ArraySetAsSeries(close,true);
//---
   for(int i=limit; i>=0 && !IsStopped(); i--) {
      BullishWEBuffer[i]=0.0;
      BearishWEBuffer[i]=0.0;
      BearishWEBuffer[0]=0.0;
      if(
         (open[i]<close[i] && open[i+1]<close[i+1] && high[i+1]>high[i] && open[i]>=close[i+1]) ||
         (open[i]<close[i] && open[i+1]>close[i+1] && high[i+1]>high[i] && open[i]>=open[i+1])
      )
         BearishWEBuffer[i]=high[i];
      BullishWEBuffer[0]=0.0;
      if(
         (open[i]>close[i] && open[i+1]>close[i+1] && low[i+1]<low[i] && open[i]<=close[i+1]) ||
         (open[i]>close[i] && open[i+1]<close[i+1] && low[i+1]<low[i] && open[i]<=open[i+1])
      )
         BullishWEBuffer[i]=low[i];
   }
//--- return value of prev_calculated for next call
   return(rates_total);
}
//+------------------------------------------------------------------+