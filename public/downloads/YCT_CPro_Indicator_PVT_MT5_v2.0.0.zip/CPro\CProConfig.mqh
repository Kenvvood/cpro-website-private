//+------------------------------------------------------------------+
//|                                            CProConfig.mqh         |
//|                         CPro Trading 营销模块配置                   |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+
//
//  PURPOSE:
//    CProConfig contains all company info, product branding,
//    color scheme, and layout constants shared across all
//    CPro marketing shell components.
//
//  USAGE:
//    #include "CPro\CProConfig.mqh"
//
//+------------------------------------------------------------------+

#ifndef CPRO_CONFIG_MQH
#define CPRO_CONFIG_MQH

//=== Company Information ===

#define CPRO_COMPANY_NAME     "城诺科技"
#define CPRO_COMPANY_EN      "CPro Trading"
#define CPRO_WEIXIN_SUPPORT  "Lookee333"       // 技术支持微信
#define CPRO_WEIXIN_BIZ      "jialie-li"        // 官方合作微信
#define CPRO_WEBSITE         "www.cprotrading.com"  // 官方网站
#define CPRO_HOTLINE         "7×24小时在线"     // 技术支持

//=== Product Branding ===

#define CPRO_PRODUCT_NAME_CN "CPro Trading"
#define CPRO_PRODUCT_NAME_EN "CPro Trading"
#define CPRO_PRODUCT_VERSION "v1.0"

//=== Slogans ===

#define CPRO_SLOGAN_MAIN     "严选精品，稳健抵达"
#define CPRO_SLOGAN_SUB      "专业MQL量化解决方案"
#define CPRO_SLOGAN_DESC     "智能交易EA · 精准技术指标 · 高效实用脚本"

//=== Color Scheme (Blue-Green Teal Theme) ===

// Primary Colors (Teal/Cyan)
#define CPRO_COLOR_PRIMARY       C'0, 180, 166'    // Teal (#00B4A6)
#define CPRO_COLOR_ACCENT        C'0, 212, 188'    // Light Teal (#00D4BC)
#define CPRO_COLOR_BLUE          C'0, 119, 182'    // Deep Blue (#0077B6)

// Status Colors
#define CPRO_COLOR_PROFIT        C'0, 212, 188'    // Profit (Light Teal)
#define CPRO_COLOR_LOSS          C'220, 68, 68'    // Loss (Soft Red)
#define CPRO_COLOR_HOLDING       C'255, 215, 0'    // Holding (Gold)

// Background Colors (Dark Theme)
#define CPRO_COLOR_BG            C'3, 13, 16'      // Deep Dark (#030D10)
#define CPRO_COLOR_SURFACE       C'10, 26, 31'     // Surface (#0A1A1F)
#define CPRO_COLOR_PANEL         C'17, 37, 48'    // Panel (#112530)
#define CPRO_COLOR_BORDER        C'0, 180, 166'    // Border (Teal)

// Text Colors
#define CPRO_COLOR_TEXT_PRIMARY  C'232, 244, 248' // Primary (#E8F4F8)
#define CPRO_COLOR_TEXT_SECONDARY C'126, 184, 201' // Secondary (#7EB8C9)
#define CPRO_COLOR_TEXT_MUTED     C'126, 184, 201' // Muted (#7EB8C9)

// Watermark Colors
#define CPRO_COLOR_WATERMARK     C'126, 184, 201'  // Watermark (Secondary)

//=== Layout Configuration ===

// Panel Dimensions
#define CPRO_PANEL_WIDTH        200
#define CPRO_PANEL_HEIGHT       280
#define CPRO_PANEL_CORNER       CORNER_RIGHT_UPPER
#define CPRO_PANEL_PADDING      10
#define CPRO_PANEL_MARGIN       8

// Logo Dimensions (Watermark)
#define CPRO_LOGO_SIZE_W         60
#define CPRO_LOGO_SIZE_H         60
#define CPRO_LOGO_CORNER        CORNER_RIGHT_LOWER  // 右下角

// Dialog Dimensions
#define CPRO_DIALOG_WIDTH        380
#define CPRO_DIALOG_HEIGHT       320

//=== Object Prefixes ===

#define CPRO_PREFIX             "CPro_"
#define CPRO_WATERMARK_NAME     "CPro_Watermark"
#define CPRO_DIALOG_PREFIX      "CPro_Dialog_"

//=== MT4/MT5 Compatibility ===

#ifdef __MQL5__
    #property copyright "CPro Trading"
    #property link      "https://CProTrading.com"
    #property version   "1.00"

    // MT5 uses ChartGetInteger/ChartSetInteger
    #define CPRO_CHART_WIDTH_IN_PIXELS  CHART_WIDTH_IN_PIXELS
    #define CPRO_CHART_HEIGHT_IN_PIXELS CHART_HEIGHT_IN_PIXELS
#else
    // MT4 compatibility
    #define CPRO_CHART_WIDTH_IN_PIXELS  1024
    #define CPRO_CHART_HEIGHT_IN_PIXELS 768
#endif

//=== Common Macros ===

#define CPRO_CHART_REDRAW ChartRedraw(0)

#define CPRO_DELETE_OBJECT(chart_id, name) \
    do { \
        if(ObjectFind(chart_id, name) >= 0) { \
            ObjectDelete(chart_id, name); \
        } \
    } while(false)

#endif // CPRO_CONFIG_MQH
