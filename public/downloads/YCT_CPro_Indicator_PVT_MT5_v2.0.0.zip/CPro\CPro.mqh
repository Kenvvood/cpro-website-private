//+------------------------------------------------------------------+
//|                                               CPro.mqh           |
//|                         CPro Trading 营销模块主入口                |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+
//
//  USAGE:
//    #include "CPro\CPro.mqh"
//
//    CProDialog dialog;
//    CProPanel panel;
//    CProWatermark watermark;
//
//    dialog.Init();
//    dialog.ShowStartupDialog();  // 显示启动弹窗（含关于信息）
//    panel.Init();
//    watermark.Init();
//    watermark.DrawWatermark();
//
//+------------------------------------------------------------------+

#ifndef CPRO_MQH
#define CPRO_MQH

#include "CProConfig.mqh"
#include "CProDialog.mqh"
#include "CProPanel.mqh"
#include "CProWatermark.mqh"

//+------------------------------------------------------------------+
//| Global instances                                                  |
//+------------------------------------------------------------------+
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| Initialize all CPro modules                                       |
//+------------------------------------------------------------------+
void CPro_Init() {
    m_cpro_dialog.Init();
    m_cpro_panel.Init();
    m_cpro_watermark.Init();
}

//+------------------------------------------------------------------+
//| Show startup dialog (brand info + about)                          |
//+------------------------------------------------------------------+
void CPro_ShowDialog() {
    m_cpro_dialog.ShowStartupDialog();
}

//+------------------------------------------------------------------+
//| Draw brand watermark                                              |
//+------------------------------------------------------------------+
void CPro_DrawWatermark() {
    m_cpro_watermark.DrawWatermark();
}

//+------------------------------------------------------------------+
//| Cleanup all CPro modules                                          |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_watermark.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_dialog.Deinit();
}

#endif // CPRO_MQH
