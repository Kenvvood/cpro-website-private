//+------------------------------------------------------------------+
//|                                           CProDialog.mqh         |
//|                         CPro Trading 启动弹窗模块                    |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+
//
//  PURPOSE:
//    CProDialog displays a startup dialog when the EA/indicator
//    first loads. It shows product branding, company info,
//    and requires user acknowledgment before operation begins.
//
//  ABOUT TAB CONTENT:
//    ┌──────────────────────────────────────────────────┐
//    │           城诺科技 · CPro Trading               │
//    │              ═══════════════════════             │
//    │        专业MQL量化解决方案供应商                  │
//    │           ─────────────────────                  │
//    │           官方网站: www.cprotrading.com         │
//    │           官方合作微信: jialie-li               │
//    │           技术支持微信: Lookee333               │
//    │              [ 确 认 进 入 ]                    │
//    │           ─────────────────────                  │
//    │  友情提醒：本系统仅供技术交流与学习，              │
//    │  资金风险自行承担。                              │
//    └──────────────────────────────────────────────────┘
//
//  USAGE:
//    #include "CPro\CProDialog.mqh"
//    CProDialog dialog;
//    dialog.Init();
//    dialog.ShowStartupDialog();
//
//+------------------------------------------------------------------+

#ifndef CPRO_DIALOG_MQH
#define CPRO_DIALOG_MQH

#include "CProConfig.mqh"

//+------------------------------------------------------------------+
//| CProDialog - Startup Dialog Class                                |
//+------------------------------------------------------------------+
class CProDialog {
private:
    bool        m_initialized;
    bool        m_dialogShown;
    string      m_dialogKey;

public:
    CProDialog();
    ~CProDialog();

    void         Init();
    void         Deinit();
    void         ShowStartupDialog();
    bool         WasShown() { return m_dialogShown; }

private:
    string       BuildDialogText();
    bool         WasEverShown();
    void         MarkAsShown();
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CProDialog::CProDialog() {
    m_initialized = false;
    m_dialogShown = false;
    m_dialogKey = CPRO_PREFIX + "DialogShown_" + Symbol();
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CProDialog::~CProDialog() {
    Deinit();
}

//+------------------------------------------------------------------+
//| Init                                                             |
//+------------------------------------------------------------------+
void CProDialog::Init() {
    if(m_initialized) return;
    m_initialized = true;
    m_dialogShown = false;
}

//+------------------------------------------------------------------+
//| Deinit                                                           |
//+------------------------------------------------------------------+
void CProDialog::Deinit() {
    Comment("");
}

//+------------------------------------------------------------------+
//| ShowStartupDialog - Display startup dialog (blocking)             |
//+------------------------------------------------------------------+
void CProDialog::ShowStartupDialog() {
    if(m_dialogShown) return;

    if(WasEverShown()) {
        Print("[CProDialog] Dialog already shown, skipping");
        m_dialogShown = true;
        return;
    }

    m_dialogShown = true;

    string message = BuildDialogText();
    Comment(message);

    int result = MessageBox(
        message,
        CPRO_PRODUCT_NAME_CN + " " + CPRO_PRODUCT_VERSION + " - 启动确认",
        MB_OK | MB_ICONINFORMATION | MB_TOPMOST
    );

    if(result != IDOK) {
        Print("[CProDialog] User cancelled startup dialog");
        Comment("操作已取消。如需重新启动，请重启本工具。");
        Sleep(3000);
    } else {
        Print("[CProDialog] User acknowledged startup dialog");
        MarkAsShown();
    }

    Comment("");
}

//+------------------------------------------------------------------+
//| WasEverShown                                                    |
//+------------------------------------------------------------------+
bool CProDialog::WasEverShown() {
    return GlobalVariableCheck(m_dialogKey);
}

//+------------------------------------------------------------------+
//| MarkAsShown                                                     |
//+------------------------------------------------------------------+
void CProDialog::MarkAsShown() {
    GlobalVariableSet(m_dialogKey, TimeCurrent());
    Print("[CProDialog] Dialog marked as shown");
}

//+------------------------------------------------------------------+
//| BuildDialogText                                                  |
//+------------------------------------------------------------------+
string CProDialog::BuildDialogText() {
    string text = "";

    text += "================================================\n\n";
    text += "           城诺科技 · CPro Trading\n\n";
    text += "              ═══════════════════════\n\n";
    text += "         「" + CPRO_SLOGAN_MAIN + "」\n\n";
    text += "        专业MQL量化解决方案供应商\n\n";
    text += "           ─────────────────────\n\n";
    text += "     [产品类型] 智能交易EA / 技术指标 / 实用脚本\n\n";
    text += "     [核心优势] 严选代码 · 深度优化 · 稳定可靠\n\n";
    text += "           ─────────────────────\n\n";
    text += "     官方网站: " + CPRO_WEBSITE + "\n";
    text += "     官方合作微信: " + CPRO_WEIXIN_BIZ + "\n";
    text += "     技术支持微信: " + CPRO_WEIXIN_SUPPORT + "\n";
    text += "           版本: " + CPRO_PRODUCT_VERSION + "\n\n";
    text += "              [ 确 认 进 入 ]\n\n";
    text += "           ─────────────────────\n\n";
    text += "  友情提醒：本系统仅供技术交流与学习，\n";
    text += "        资金风险自行承担。\n";

    return text;
}

#endif // CPRO_DIALOG_MQH
