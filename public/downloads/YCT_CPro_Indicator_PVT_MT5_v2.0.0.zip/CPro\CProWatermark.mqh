//+------------------------------------------------------------------+
//|                                        CProWatermark.mqh        |
//|                         CPro Trading 圆形水印模块                  |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+

#ifndef CPRO_WATERMARK_MQH
#define CPRO_WATERMARK_MQH

#include "CProConfig.mqh"

//+------------------------------------------------------------------+
//| CProWatermark - Circular Logo Watermark Class                    |
//+------------------------------------------------------------------+
class CProWatermark {
private:
    bool        m_initialized;
    int         m_logoX;
    int         m_logoY;
    bool        m_positionSet;

public:
    CProWatermark();
    ~CProWatermark();

    void         Init();
    void         Deinit();
    void         DrawWatermark();
    void         SetPosition(int x, int y);
    void         ClearWatermark();

private:
    void         GetDefaultPosition(int &x, int &y);
};

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CProWatermark::CProWatermark() {
    m_initialized = false;
    m_logoX = -1;
    m_logoY = -1;
    m_positionSet = false;
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CProWatermark::~CProWatermark() {
    Deinit();
}

//+------------------------------------------------------------------+
//| Init                                                              |
//+------------------------------------------------------------------+
void CProWatermark::Init() {
    if(m_initialized) return;
    m_initialized = true;
    m_logoX = -1;
    m_logoY = -1;
    m_positionSet = false;
}

//+------------------------------------------------------------------+
//| Deinit                                                            |
//+------------------------------------------------------------------+
void CProWatermark::Deinit() {
    ClearWatermark();
    m_initialized = false;
}

//+------------------------------------------------------------------+
//| SetPosition                                                       |
//+------------------------------------------------------------------+
void CProWatermark::SetPosition(int x, int y) {
    m_logoX = x;
    m_logoY = y;
    m_positionSet = true;
}

//+------------------------------------------------------------------+
//| ClearWatermark                                                    |
//+------------------------------------------------------------------+
void CProWatermark::ClearWatermark() {
    long chartId = ChartID();
    CPRO_DELETE_OBJECT(chartId, CPRO_WATERMARK_NAME);
    CPRO_CHART_REDRAW;
}

//+------------------------------------------------------------------+
//| GetDefaultPosition                                                 |
//+------------------------------------------------------------------+
void CProWatermark::GetDefaultPosition(int &x, int &y) {
    long chartId = ChartID();

    int chartWidth, chartHeight;

    #ifdef __MQL5__
        chartWidth = (int)ChartGetInteger(chartId, CHART_WIDTH_IN_PIXELS);
        chartHeight = (int)ChartGetInteger(chartId, CHART_HEIGHT_IN_PIXELS);
    #else
        chartWidth = CPRO_CHART_WIDTH_IN_PIXELS;
        chartHeight = CPRO_CHART_HEIGHT_IN_PIXELS;
    #endif

    x = chartWidth - CPRO_LOGO_SIZE_W - CPRO_PANEL_MARGIN;
    y = chartHeight - CPRO_LOGO_SIZE_H - CPRO_PANEL_MARGIN;
}

//+------------------------------------------------------------------+
//| DrawWatermark                                                      |
//+------------------------------------------------------------------+
void CProWatermark::DrawWatermark() {
    if(!m_initialized) return;

    long chartId = ChartID();

    int x, y;
    if(m_positionSet) {
        x = m_logoX;
        y = m_logoY;
    } else {
        GetDefaultPosition(x, y);
    }

    ClearWatermark();

    if(!ObjectCreate(chartId, CPRO_WATERMARK_NAME, OBJ_BITMAP_LABEL, 0, 0, 0)) {
        Print("[CProWatermark] ERROR: Failed to create watermark object!");
        return;
    }

    string watermarkResource = "CPro\CPRO-LOGO-final-90x.png";

    #ifdef __MQL5__
        ObjectSetString(chartId, CPRO_WATERMARK_NAME, OBJPROP_BMPFILE, 0, watermarkResource);
        ObjectSetString(chartId, CPRO_WATERMARK_NAME, OBJPROP_BMPFILE, 1, watermarkResource);
    #else
        ObjectSetString(chartId, CPRO_WATERMARK_NAME, OBJPROP_BMPFILE, 0, watermarkResource);
        ObjectSetString(chartId, CPRO_WATERMARK_NAME, OBJPROP_BMPFILE, 1, watermarkResource);
    #endif

    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_XDISTANCE, x);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_YDISTANCE, y);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_XSIZE, CPRO_LOGO_SIZE_W);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_YSIZE, CPRO_LOGO_SIZE_H);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_CORNER, CPRO_LOGO_CORNER);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_BACK, true);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_ANCHOR, ANCHOR_RIGHT_LOWER);
    ObjectSetInteger(chartId, CPRO_WATERMARK_NAME, OBJPROP_COLOR, CPRO_COLOR_WATERMARK);

    CPRO_CHART_REDRAW;

    Print("[CProWatermark] Watermark drawn at (", x, ", ", y, ")");
}

#endif // CPRO_WATERMARK_MQH
