//+------------------------------------------------------------------+
//|                                            CProPanel.mqh         |
//|                         CPro Trading 面板模块（含关于标签）           |
//|                                         Version 1.0              |
//+------------------------------------------------------------------+
//
//  ABOUT TAB CONTENT:
//    ┌─[ 关于 ]─────────────────────────────────────┐
//    │  CPro Trading  城诺科技                        │
//    │  专业MQL量化解决方案供应商                       │
//    │  ───────────────────────────                  │
//    │  产品优势：                                    │
//    │  ✓ 军工级品质 · 严格测试验证                  │
//    │  ✓ 持续迭代 · 技术团队优化                    │
//    │  ✓ 全方位支持 · 7×24服务                     │
//    │  ───────────────────────────                  │
//    │  官方网站: www.cprotrading.com               │
//    │  官方合作微信: jialie-li                     │
//    │  技术支持微信: Lookee333                      │
//    └────────────────────────────────────────────────┘
//
//  USAGE:
//    #include "CPro\CProPanel.mqh"
//    CProPanel panel;
//    panel.Init();
//    panel.RefreshPanel();
//
//+------------------------------------------------------------------+

#ifndef CPRO_PANEL_MQH
#define CPRO_PANEL_MQH

#include "CProConfig.mqh"

//+------------------------------------------------------------------+
//| Panel Labels                                                     |
//+------------------------------------------------------------------+
#define CPRO_LABEL_ABOUT_TITLE      "关于"
#define CPRO_LABEL_COMPANY_NAME    "CPro Trading 城诺科技"
#define CPRO_LABEL_PRODUCT_DESC    "专业MQL量化解决方案供应商"
#define CPRO_LABEL_PRODUCTS        "产品优势："
#define CPRO_LABEL_PRODUCT_1       "✓ 军工级品质 · 严格测试验证"
#define CPRO_LABEL_PRODUCT_2       "✓ 持续迭代 · 技术团队优化"
#define CPRO_LABEL_PRODUCT_3       "✓ 全方位支持 · 7×24服务"
#define CPRO_LABEL_CONTACT         "联系方式"
#define CPRO_LABEL_WEBSITE         "官方网站"
#define CPRO_LABEL_WECHAT_BIZ      "官方合作微信"
#define CPRO_LABEL_WECHAT_SUPPORT  "技术支持微信"

//+------------------------------------------------------------------+
//| CProPanel - Panel Class with About Tab                           |
//+------------------------------------------------------------------+
class CProPanel {
private:
    bool        m_initialized;
    bool        m_minimized;
    int         m_panelX;
    int         m_panelY;
    int         m_panelWidth;
    int         m_panelHeight;
    static const string PREFIX;

public:
    CProPanel();
    ~CProPanel();

    void         Init();
    void         Deinit();
    void         RefreshPanel();
    void         SetPosition(int x, int y);
    void         ToggleMinimize();
    void         SetMinimized(bool minimized);
    bool         IsMinimized() { return m_minimized; }
    int          GetPanelWidth() { return m_panelWidth; }
    int          GetPanelHeight() { return m_minimized ? 30 : m_panelHeight; }

private:
    void         CreateAllObjects();
    void         CreateBackground();
    void         CreateHeader();
    void         CreateAboutSection();
    void         CreateSeparator(string name, int y);
    void         UpdateValues();
    void         CreateLabel(string name, string text, int x, int y, int fontSize, color textColor);
    void         DeleteObjects(string prefix);
};

const string CProPanel::PREFIX = "CPro_Panel_";

//+------------------------------------------------------------------+
//| Constructor                                                       |
//+------------------------------------------------------------------+
CProPanel::CProPanel() {
    m_initialized = false;
    m_minimized = false;
    m_panelX = 0;
    m_panelY = 0;
    m_panelWidth = CPRO_PANEL_WIDTH;
    m_panelHeight = CPRO_PANEL_HEIGHT;
}

//+------------------------------------------------------------------+
//| Destructor                                                        |
//+------------------------------------------------------------------+
CProPanel::~CProPanel() {
    Deinit();
}

//+------------------------------------------------------------------+
//| Init                                                             |
//+------------------------------------------------------------------+
void CProPanel::Init() {
    if(m_initialized) return;
    m_initialized = true;
    CreateAllObjects();
}

//+------------------------------------------------------------------+
//| Deinit                                                           |
//+------------------------------------------------------------------+
void CProPanel::Deinit() {
    DeleteObjects(PREFIX);
    Comment("");
    m_initialized = false;
}

//+------------------------------------------------------------------+
//| SetPosition                                                      |
//+------------------------------------------------------------------+
void CProPanel::SetPosition(int x, int y) {
    m_panelX = x;
    m_panelY = y;
}

//+------------------------------------------------------------------+
//| ToggleMinimize                                                    |
//+------------------------------------------------------------------+
void CProPanel::ToggleMinimize() {
    SetMinimized(!m_minimized);
}

//+------------------------------------------------------------------+
//| SetMinimized                                                      |
//+------------------------------------------------------------------+
void CProPanel::SetMinimized(bool minimized) {
    if(m_minimized == minimized) return;
    m_minimized = minimized;

    if(m_initialized) {
        Deinit();
        Init();
    }
}

//+------------------------------------------------------------------+
//| RefreshPanel                                                     |
//+------------------------------------------------------------------+
void CProPanel::RefreshPanel() {
    if(!m_initialized) return;
    UpdateValues();
}

//+------------------------------------------------------------------+
//| CreateAllObjects                                                  |
//+------------------------------------------------------------------+
void CProPanel::CreateAllObjects() {
    long chartId = ChartID();

    if(m_panelX == 0 && m_panelY == 0) {
        int chartWidth = (int)ChartGetInteger(chartId, CHART_WIDTH_IN_PIXELS);
        m_panelX = chartWidth - m_panelWidth - CPRO_PANEL_MARGIN;
        m_panelY = CPRO_PANEL_MARGIN;
    }

    CreateBackground();
    CreateHeader();
    CreateAboutSection();
}

//+------------------------------------------------------------------+
//| CreateBackground                                                 |
//+------------------------------------------------------------------+
void CProPanel::CreateBackground() {
    long chartId = ChartID();
    string bgName = PREFIX + "Background";

    ObjectDelete(chartId, bgName);

    if(!ObjectCreate(chartId, bgName, OBJ_RECTANGLE_LABEL, 0, 0, 0)) {
        Print("[CProPanel] ERROR: Failed to create background!");
        return;
    }

    ObjectSetInteger(chartId, bgName, OBJPROP_XDISTANCE, m_panelX);
    ObjectSetInteger(chartId, bgName, OBJPROP_YDISTANCE, m_panelY);
    ObjectSetInteger(chartId, bgName, OBJPROP_XSIZE, m_panelWidth);
    ObjectSetInteger(chartId, bgName, OBJPROP_YSIZE, GetPanelHeight());
    ObjectSetInteger(chartId, bgName, OBJPROP_CORNER, CPRO_PANEL_CORNER);
    ObjectSetInteger(chartId, bgName, OBJPROP_BACK, false);
    ObjectSetInteger(chartId, bgName, OBJPROP_BORDER_COLOR, CPRO_COLOR_BORDER);
    ObjectSetInteger(chartId, bgName, OBJPROP_BORDER_TYPE, BORDER_FLAT);
    ObjectSetInteger(chartId, bgName, OBJPROP_BGCOLOR, CPRO_COLOR_PANEL);
}

//+------------------------------------------------------------------+
//| CreateHeader                                                      |
//+------------------------------------------------------------------+
void CProPanel::CreateHeader() {
    long chartId = ChartID();

    string headerBgName = PREFIX + "HeaderBg";
    if(!ObjectCreate(chartId, headerBgName, OBJ_RECTANGLE_LABEL, 0, 0, 0)) {
        return;
    }

    ObjectSetInteger(chartId, headerBgName, OBJPROP_XDISTANCE, m_panelX);
    ObjectSetInteger(chartId, headerBgName, OBJPROP_YDISTANCE, m_panelY);
    ObjectSetInteger(chartId, headerBgName, OBJPROP_XSIZE, m_panelWidth);
    ObjectSetInteger(chartId, headerBgName, OBJPROP_YSIZE, 28);
    ObjectSetInteger(chartId, headerBgName, OBJPROP_CORNER, CPRO_PANEL_CORNER);
    ObjectSetInteger(chartId, headerBgName, OBJPROP_BACK, true);
    ObjectSetInteger(chartId, headerBgName, OBJPROP_BGCOLOR, CPRO_COLOR_BORDER);

    string titleName = PREFIX + "Title";
    if(ObjectCreate(chartId, titleName, OBJ_TEXT, 0, 0, 0)) {
        ObjectSetString(chartId, titleName, OBJPROP_TEXT, CPRO_LABEL_ABOUT_TITLE);
        ObjectSetInteger(chartId, titleName, OBJPROP_XDISTANCE, m_panelX + 10);
        ObjectSetInteger(chartId, titleName, OBJPROP_YDISTANCE, m_panelY + 6);
        ObjectSetInteger(chartId, titleName, OBJPROP_FONTSIZE, 10);
        ObjectSetString(chartId, titleName, OBJPROP_FONT, "Microsoft YaHei");
        ObjectSetInteger(chartId, titleName, OBJPROP_COLOR, CPRO_COLOR_TEXT_PRIMARY);
    }
}

//+------------------------------------------------------------------+
//| CreateAboutSection                                                |
//+------------------------------------------------------------------+
void CProPanel::CreateAboutSection() {
    if(m_minimized) return;

    long chartId = ChartID();
    int currentY = m_panelY + 35;
    int leftMargin = m_panelX + 10;

    CreateLabel(PREFIX + "CompanyName", CPRO_LABEL_COMPANY_NAME, leftMargin, currentY, 10, CPRO_COLOR_PRIMARY);
    currentY += 16;

    CreateLabel(PREFIX + "ProductDesc", CPRO_LABEL_PRODUCT_DESC, leftMargin, currentY, 9, CPRO_COLOR_TEXT_SECONDARY);
    currentY += 18;

    CreateSeparator(PREFIX + "Sep1", currentY);
    currentY += 8;

    CreateLabel(PREFIX + "ProductsLabel", CPRO_LABEL_PRODUCTS, leftMargin, currentY, 9, CPRO_COLOR_TEXT_PRIMARY);
    currentY += 14;

    CreateLabel(PREFIX + "Product1", CPRO_LABEL_PRODUCT_1, leftMargin, currentY, 8, CPRO_COLOR_TEXT_SECONDARY);
    currentY += 12;

    CreateLabel(PREFIX + "Product2", CPRO_LABEL_PRODUCT_2, leftMargin, currentY, 8, CPRO_COLOR_TEXT_SECONDARY);
    currentY += 12;

    CreateLabel(PREFIX + "Product3", CPRO_LABEL_PRODUCT_3, leftMargin, currentY, 8, CPRO_COLOR_TEXT_SECONDARY);
    currentY += 18;

    CreateSeparator(PREFIX + "Sep2", currentY);
    currentY += 8;

    CreateLabel(PREFIX + "Website", CPRO_LABEL_WEBSITE + ": " + CPRO_WEBSITE, leftMargin, currentY, 8, CPRO_COLOR_TEXT_SECONDARY);
    currentY += 12;

    CreateLabel(PREFIX + "WeChatBiz", CPRO_LABEL_WECHAT_BIZ + ": " + CPRO_WEIXIN_BIZ, leftMargin, currentY, 8, CPRO_COLOR_TEXT_SECONDARY);
    currentY += 12;

    CreateLabel(PREFIX + "WeChatSupport", CPRO_LABEL_WECHAT_SUPPORT + ": " + CPRO_WEIXIN_SUPPORT, leftMargin, currentY, 8, CPRO_COLOR_TEXT_SECONDARY);
}

//+------------------------------------------------------------------+
//| CreateSeparator                                                   |
//+------------------------------------------------------------------+
void CProPanel::CreateSeparator(string name, int y) {
    long chartId = ChartID();

    if(ObjectCreate(chartId, name, OBJ_HLINE, 0, 0, 0)) {
        ObjectSetInteger(chartId, name, OBJPROP_XDISTANCE, m_panelX + 10);
        ObjectSetInteger(chartId, name, OBJPROP_YDISTANCE, y);
        ObjectSetInteger(chartId, name, OBJPROP_XSIZE, m_panelWidth - 20);
        ObjectSetInteger(chartId, name, OBJPROP_COLOR, CPRO_COLOR_BORDER);
        ObjectSetInteger(chartId, name, OBJPROP_BACK, true);
    }
}

//+------------------------------------------------------------------+
//| CreateLabel                                                       |
//+------------------------------------------------------------------+
void CProPanel::CreateLabel(string name, string text, int x, int y, int fontSize, color textColor) {
    long chartId = ChartID();

    ObjectDelete(chartId, name);

    if(ObjectCreate(chartId, name, OBJ_TEXT, 0, 0, 0)) {
        ObjectSetString(chartId, name, OBJPROP_TEXT, text);
        ObjectSetInteger(chartId, name, OBJPROP_XDISTANCE, x);
        ObjectSetInteger(chartId, name, OBJPROP_YDISTANCE, y);
        ObjectSetInteger(chartId, name, OBJPROP_FONTSIZE, fontSize);
        ObjectSetString(chartId, name, OBJPROP_FONT, "Microsoft YaHei");
        ObjectSetInteger(chartId, name, OBJPROP_COLOR, textColor);
        ObjectSetInteger(chartId, name, OBJPROP_BACK, true);
    }
}

//+------------------------------------------------------------------+
//| DeleteObjects                                                      |
//+------------------------------------------------------------------+
void CProPanel::DeleteObjects(string prefix) {
    long chartId = ChartID();

    for(int i = 0; i < 50; i++) {
        ObjectDelete(chartId, prefix + IntegerToString(i));
    }

    string objects[] = {
        "Background", "HeaderBg", "Title", "CompanyName",
        "ProductDesc", "ProductsLabel", "Product1", "Product2", "Product3",
        "ContactLabel", "WeChatBiz", "WeChatSupport", "Website"
    };

    for(int i = 0; i < ArraySize(objects); i++) {
        ObjectDelete(chartId, prefix + objects[i]);
        ObjectDelete(chartId, objects[i]);
    }
}

//+------------------------------------------------------------------+
//| UpdateValues                                                       |
//+------------------------------------------------------------------+
void CProPanel::UpdateValues() {
    // Reserved for future statistics updates
}

#endif // CPRO_PANEL_MQH
