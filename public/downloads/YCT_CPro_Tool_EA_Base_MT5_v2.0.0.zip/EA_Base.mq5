//+------------------------------------------------------------------+
//|                                         CPro Tool EA_Base MT5                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include <enums/OrderSide.mqh>
#include /**/ <Trade\Trade.mqh>
#include <enums/DayOfWeek.mqh>
#include <enums/MartingaleLotSizingType.mqh>
#include <enums/StopLimitType.mqh>
#include <enums/PositionSizeType.mqh>
#include <enums/StopLossType.mqh>
#include <enums/TakeProfitType.mqh>
#include <Conditions/TradingTimeCondition.mqh>
#include <Conditions/DisabledCondition.mqh>
#include <Conditions/AndCondition.mqh>
#include <Conditions/ACondition.mqh>
#include <Conditions/NoCondition.mqh>
#include <Conditions/NotCondition.mqh>
#include <Conditions/ActOnSwitchCondition.mqh>
#include <Streams/Interfaces/TIStream.mqh>
#include <MarketEntryStrategy.mqh>
#include <InstrumentInfo.mqh>
#include <TradesIterator.mqh>
#include <TradingCalculator.mqh>
#include <OrdersIterator.mqh>
#include <TradingCommands.mqh>
#include <TrailingController.mqh>
#include <MarketOrderBuilder.mqh>
#include <conditions/PositionLimitHitCondition.mqh>
#include <Actions/EntryAction.mqh>
#include <Actions/MoveNetStopLossAction.mqh>
#include <Actions/MoveNetTakeProfitAction.mqh>
#include <Actions/CreateTrailingAction.mqh>
#include <Actions/CreateMartingaleAction.mqh>
#include <Actions/CloseAllAction.mqh>
#include <TradingController.mqh>
#include <DoCloseOnOppositeStrategy.mqh>
#include <DontCloseOnOppositeStrategy.mqh>
#include <EntryPositionController.mqh>
#include <MoneyManagement/functions.mqh>

#define ACT_ON_SWITCH_CONDITION
#define TAKE_PROFIT_FEATURE
#define STOP_LOSS_FEATURE
#define MARTINGALE_FEATURE
#define ADVANCED_ALERTS
#define USE_MARKET_ORDERS
#define TRADING_TIME_FEATURE
#define WEEKLY_TRADING_TIME_FEATURE
#define WITH_EXIT_LOGIC
#define NET_STOP_LOSS_FEATURE
#define NET_TAKE_PROFIT_FEATURE
#ifndef tradeManager_INSTANCE
#define tradeManager_INSTANCE
CTrade tradeManager;
#endif
enum TradingMode
{
   TradingModeOnBarClose, // Entry on candle close
   TradingModeLive // Entry on tick
};
enum TradingDirection
{
   LongSideOnly, // Long only
   ShortSideOnly, // Short only
   BothSides // Both
};
enum PositionDirection
{
   DirectLogic, // Direct
   ReversalLogic // Reversal
};
enum TrailingType
{
   TrailingDontUse, // No trailing
   TrailingPips, // Use trailing in pips
   TrailingPercent // Use trailing in % of stop
};
input string GeneralSection = ""; // == General ==
input string symbols = "";//交易品种 to 交易. separated by ","
input bool allow_trading = true;//allow 交易时段
input bool BTCAccount = false;//is btc ac数量?
input TradingMode entry_logic = TradingModeOnBarClose;//entry 类型
#ifdef WITH_EXIT_LOGIC
   input TradingMode exit_logic = TradingModeOnBarClose;//exit 类型
#endif
input TradingDirection trading_side = BothSides;//what 交易s should be taken
input double lots_value            = 0.1;//持仓 尺寸
input PositionSizeType lots_type = PositionSizeContract;//持仓 尺寸 类型
input int slippage_points           = 3;//止损ippage, in 点数
input bool close_on_opposite = true;//平仓 on opposite
input string SLSection            = "";//== 停止 亏损/止盈点数 ==
input StopLossType stop_loss_type = SLPips;//停止 亏损 类型
input double stop_loss_value            = 10;//停止 亏损 值
input TrailingType trailing_type = TrailingDontUse;//使用 追踪ing
input double trailing_start = 0;//min 距离 to 订单 to activate the 追踪ing
input double trailing_step = 10;//追踪ing 步进
#ifdef NET_STOP_LOSS_FEATURE
   input string NetStopSection = "";//== net 停止 ==
   input StopLimitType net_stop_loss_type = StopLimitDoNotUse;//net 停止 亏损 类型
   input double net_stop_loss_value = 10;//net 停止 亏损 值
#endif
input TakeProfitType take_profit_type = TPPips;//take 利润 类型
input double take_profit_value           = 10;//take 利润 值
input double take_profit_atr_multiplicator = 1.0;//take 利润 ATR指标 multiplicator
// input StopLimitType breakeven_type = StopLimitPips; // Trigger type for the breakeven
// input double breakeven_value = 10; // Trigger for the breakeven
#ifdef NET_TAKE_PROFIT_FEATURE
   input string NetTakeProfitSection            = "";//== net take 利润 ==
   input StopLimitType net_take_profit_type = StopLimitDoNotUse;//net take 利润 类型
   input double net_take_profit_value = 10;//net take 利润 值
#endif
input string PositionCapSection = "";//== 持仓 cap ==
input bool use_position_cap = true;//使用 持仓 cap?
input int max_positions = 2;//均线x positions
enum MartingaleType
{
   MartingaleDoNotUse, // Do not use
   MartingaleOnLoss // Open another position on loss
};
enum MartingaleStepSizeType
{
   MartingaleStepSizePips, // Pips
   MartingaleStepSizePercent, // %
};
#ifdef MARTINGALE_FEATURE
   input string MartingaleSection = "";//== 均线rtingale 类型 ==
   input MartingaleType martingale_type = MartingaleDoNotUse;//均线rtingale 类型
   input MartingaleLotSizingType martingale_lot_sizing_type = MartingaleLotSizingNo;//马丁格尔 交易量 sizing 类型
   input double martingale_lot_value = 1.5;//matringale 交易量 sizing 值
   MartingaleStepSizeType martingale_step_type = MartingaleStepSizePips; // Step unit
   input double martingale_step = 50;//开仓 均线tringale 持仓 步进
   input int max_longs = 5;//均线x 做多 positions
   input int max_shorts = 5;//均线x 做空 positions
#endif
input string OtherSection            = ""; // == Other ==
input int magic_number        = 42;//魔术号码
input PositionDirection logic_direction = DirectLogic;//logic 类型
#ifdef TRADING_TIME_FEATURE
   input string TradingTimeSection = "In hhmm. You can put several ranges separated by ,";//== 交易时段 time ==
   input string trading_time = "0000-0000";//time 范围 to 交易
   input bool mandatory_closing = false;//均线ndatory closing for non-交易时段 time
#else
   string trading_time = "0000-0000";
   bool mandatory_closing = false;
#endif
#ifdef WEEKLY_TRADING_TIME_FEATURE
   input bool use_weekly_timing = false; // Weekly time
   input DayOfWeek week_start_day = DayOfWeekSunday;//开始 day
   input string week_start_time = "000000";//开始 time in hhmmss for均线t
   input DayOfWeek week_stop_day = DayOfWeekSaturday;//停止 day
   input string week_stop_time = "235959";//停止 time in hhmmss for均线t
#else
   bool use_weekly_timing = false; // Weekly time
   DayOfWeek week_start_day = DayOfWeekSunday; // Start day
   string week_start_time = "000000"; // Start time in hhmmss format
   DayOfWeek week_stop_day = DayOfWeekSaturday; // Stop day
   string week_stop_time = "235959"; // Stop time in hhmmss format
#endif
input bool MandatoryClosing = false;//均线ndatory closing for non-交易时段 time
input bool print_log = false; // Print decisions into the log
input string log_file = "log.csv";//log file 名称
//Signaler v 1.4
input string AlertsSection = ""; // == Alerts ==
input bool     Popup_Alert              = true; // Popup message
input bool     Notification_Alert       = false; // Push notification
input bool     Email_Alert              = false;//e均线il
input bool     Play_Sound               = false; // Play sound on alert
input string   Sound_File               = ""; // Sound file
#ifdef ADVANCED_ALERTS
input bool     Advanced_Alert           = false; // Advanced alert
input string   Advanced_Key             = ""; // Advanced alert key
input string   advanced_Server          = "https://利润robots.com"; // advanced alert server url
input string   Comment2                 = "- You can get a key via @profit_robots_bot Telegram Bot. Visit ProfitRobots.com for discord/other platform keys -";
input string   Comment3                 = "- Allow use of dll in the indicator parameters window -";
input string   Comment4                 = "- Install AdvancedNotificationsLib using ProfitRobots installer -";
// AdvancedNotificationsLib.dll could be downloaded here: http://profitrobots.com/Home/TelegramNotificationsMT4
#import "AdvancedNotificationsLib.dll"
void AdvancedAlert(string key, string text, string instrument, string timeframe);
void AdvancedAlertCustom(string key, string text, string instrument, string timeframe, string url);
#import
#endif
#ifdef ACT_ON_SWITCH_CONDITION
#endif
class EntryStreamData
{
   int refs;
public:
   EntryStreamData(const string symbol, const ENUM_TIMEFRAMES timeframe)
   {
      refs = 1;
      //create common indicators here
   }
   ~EntryStreamData()
   {
      //delete common indicators here
   }
   void AddRef()
   {
      ++refs;
   }
   void Release()
   {
      if (--refs == 0)
      {
         delete &this;
      }
   }
};
class EntryLongCondition : public ACondition
{
   EntryStreamData* data;
public:
   EntryLongCondition(string symbol, ENUM_TIMEFRAMES timeframe, EntryStreamData* data)
      :ACondition(symbol, timeframe)
   {
      this.data = data;
      data.AddRef();
   }
   ~EntryLongCondition()
   {
      data.Release();
   }
   virtual bool IsPass(const int period, const datetime date)
   {
      // TODO: implement
      return false;
   }
};
class EntryShortCondition : public ACondition
{
   EntryStreamData* data;
public:
   EntryShortCondition(string symbol, ENUM_TIMEFRAMES timeframe, EntryStreamData* data)
      :ACondition(symbol, timeframe)
   {
      this.data = data;
      data.AddRef();
   }
   ~EntryShortCondition()
   {
      data.Release();
   }
   virtual bool IsPass(const int period, const datetime date)
   {
      // TODO: implement
      return false;
   }
};
ICondition* CreateLongCondition(string symbol, ENUM_TIMEFRAMES timeframe, EntryStreamData* data)
{
   if (trading_side == ShortSideOnly)
   {
      return (ICondition *)new DisabledCondition();
   }
   AndCondition* condition = new AndCondition();
   condition.Add(new EntryLongCondition(symbol, timeframe, data), false);
   #ifdef ACT_ON_SWITCH_CONDITION
      ActOnSwitchCondition* switchCondition = new ActOnSwitchCondition(symbol, timeframe, (ICondition*) condition);
      condition.Release();
      return switchCondition;
   #else 
      return (ICondition*) condition;
   #endif
}
ICondition* CreateLongFilterCondition(string symbol, ENUM_TIMEFRAMES timeframe, EntryStreamData* data)
{
   if (trading_side == ShortSideOnly)
   {
      return (ICondition *)new DisabledCondition();
   }
   AndCondition* condition = new AndCondition();
   condition.Add(new NoCondition(), false);
   return condition;
}
ICondition* CreateShortCondition(string symbol, ENUM_TIMEFRAMES timeframe, EntryStreamData* data)
{
   if (trading_side == LongSideOnly)
   {
      return (ICondition *)new DisabledCondition();
   }
   AndCondition* condition = new AndCondition();
   condition.Add(new EntryShortCondition(symbol, timeframe, data), false);
   #ifdef ACT_ON_SWITCH_CONDITION
      ActOnSwitchCondition* switchCondition = new ActOnSwitchCondition(symbol, timeframe, (ICondition*) condition);
      condition.Release();
      return switchCondition;
   #else 
      return (ICondition*) condition;
   #endif
}
ICondition* CreateShortFilterCondition(string symbol, ENUM_TIMEFRAMES timeframe, EntryStreamData* data)
{
   if (trading_side == LongSideOnly)
   {
      return (ICondition *)new DisabledCondition();
   }
   AndCondition* condition = new AndCondition();
   condition.Add(new NoCondition(), false);
   return condition;
}
ICondition* CreateExitLongCondition(string symbol, ENUM_TIMEFRAMES timeframe)
{
   AndCondition* condition = new AndCondition();
   condition.Add(new DisabledCondition(), false);
   #ifdef ACT_ON_SWITCH_CONDITION
      ActOnSwitchCondition* switchCondition = new ActOnSwitchCondition(symbol, timeframe, (ICondition*) condition);
      condition.Release();
      return switchCondition;
   #else
      return (ICondition *)condition;
   #endif
}
ICondition* CreateExitShortCondition(string symbol, ENUM_TIMEFRAMES timeframe)
{
   AndCondition* condition = new AndCondition();
   condition.Add(new DisabledCondition(), false);
   #ifdef ACT_ON_SWITCH_CONDITION
      ActOnSwitchCondition* switchCondition = new ActOnSwitchCondition(symbol, timeframe, (ICondition*) condition);
      condition.Release();
      return switchCondition;
   #else
      return (ICondition *)condition;
   #endif
}
#ifdef MARTINGALE_FEATURE
void CreateMartingale(TradingCalculator* tradingCalculator, string symbol, ENUM_TIMEFRAMES timeframe, IEntryStrategy* entryStrategy, 
   OrderHandlers* orderHandlers, ActionOnConditionLogic* actions)
{
   CustomLotsProvider* lots = new CustomLotsProvider();
   IStopLossStrategy* stopLoss = CreateStopLossStrategyForLots(lots, tradingCalculator, symbol, timeframe, true, stop_loss_type, stop_loss_value, 0/*stop_loss_atr_multiplicator*/);
   ITakeProfitStrategy* tp = CreateTakeProfitStrategy(tradingCalculator, symbol, timeframe, true, take_profit_type, take_profit_value, take_profit_atr_multiplicator);
   IMoneyManagementStrategy* longMoneyManagement = new MoneyManagementStrategy(lots, stopLoss, tp);
   IAction* openLongAction = new EntryAction(entryStrategy, BuySide, longMoneyManagement, "", orderHandlers, true);
   stopLoss = CreateStopLossStrategyForLots(lots, tradingCalculator, symbol, timeframe, false, stop_loss_type, stop_loss_value, 0/*stop_loss_atr_multiplicator*/);
   tp = CreateTakeProfitStrategy(tradingCalculator, symbol, timeframe, false, take_profit_type, take_profit_value, take_profit_atr_multiplicator);
   IMoneyManagementStrategy* shortMoneyManagement = new MoneyManagementStrategy(lots, stopLoss, tp);
   IAction* openShortAction = new EntryAction(entryStrategy, SellSide, shortMoneyManagement, "", orderHandlers, true);
   CreateMartingaleAction* martingaleAction = new CreateMartingaleAction(lots, martingale_lot_sizing_type, martingale_lot_value, 
      martingale_step, openLongAction, openShortAction, max_longs, max_shorts, actions, magic_number);
   openLongAction.Release();
   openShortAction.Release();
   martingaleAction.RestoreActions(_Symbol, magic_number);
   orderHandlers.AddOrderAction(martingaleAction);
   martingaleAction.Release();
}
#endif
TradingController* controllers[];
AOrderAction* CreateTrailing(const string symbol, const ENUM_TIMEFRAMES timeframe, ActionOnConditionLogic* actions)
{
   #ifdef STOP_LOSS_FEATURE
      switch (trailing_type)
      {
         case TrailingDontUse:
            return NULL;
      #ifdef INDICATOR_BASED_TRAILING
         case TrailingIndicator:
            return NULL;
      #endif
         case TrailingPips:
            {
               //if (trailing_target_type == TrailingTargetStep)
               {
                  return new CreateTrailingAction(trailing_start, false, trailing_step, actions);
               }
               // TIStream<double>* stream = CreateTrailingStream(symbol, timeframe);
               // AOrderAction* action = new CreateTrailingStreamAction(trailing_start, false, stream, actions);
               // stream.Release();
               // return action;
            }
         // case TrailingATR:
         //    return new CreateATRTrailingAction(symbol, timeframe, trailing_start, trailing_step, actions);
         // case TrailingSLPercent:
         //    {
         //       if (trailing_target_type == TrailingTargetStep)
         //       {
         //          return new CreateTrailingAction(trailing_start, true, trailing_step, actions);
         //       }
         //       TIStream<double>* stream = CreateTrailingStream(symbol, timeframe);
         //       AOrderAction* action = new CreateTrailingStreamAction(trailing_start, true, stream, actions);
         //       stream.Release();
         //       return action;
         //    }
      }
   #endif
   return NULL;
}
TradingController* CreateController(const string symbol, ENUM_TIMEFRAMES timeframe, string &error)
{
   #ifdef TRADING_TIME_FEATURE
      ICondition* tradingTimeCondition = TradingTimeFactory::Create(trading_time, error);
      if (tradingTimeCondition == NULL)
      {
         return NULL;
      }
   #endif
   TradingCalculator* tradingCalculator = TradingCalculator::Create(symbol);
   if (!tradingCalculator.IsLotsValid(lots_value, lots_type, error))
   {
      #ifdef TRADING_TIME_FEATURE
      tradingTimeCondition.Release();
      #endif
      delete tradingCalculator;
      return NULL;
   }
   Signaler* signaler = new Signaler();
   signaler.EnablePopupAlert(Popup_Alert);
   signaler.EnableEmailAlert(Email_Alert);
   signaler.EnableSound(Play_Sound, Sound_File);
   signaler.EnableNotificationAlert(Notification_Alert);
   #ifdef ADVANCED_ALERTS
   signaler.EnableAdvanced(Advanced_Alert, Advanced_Key, advanced_Server);
   #endif
   ActionOnConditionLogic* actions = new ActionOnConditionLogic();
   TradingController* controller = new TradingController(tradingCalculator, timeframe, timeframe, actions, signaler);
   //controller.SetECNBroker(ecn_broker);
   //if (breakeven_type != StopLimitDoNotUse)
   {
      #ifndef USE_NET_BREAKEVEN
         // MoveStopLossOnProfitOrderAction* orderAction = new MoveStopLossOnProfitOrderAction(breakeven_type, breakeven_value, breakeven_level, signaler, actions);
         // controller.AddOrderAction(orderAction);
         // orderAction.Release();
      #endif
   }
   AOrderAction* trailingAction = CreateTrailing(symbol, timeframe, actions);
   if (trailingAction != NULL)
   {
      trailingAction.RestoreActions(_Symbol, magic_number);
      orderHandlers.AddOrderAction(trailingAction);
      trailingAction.Release();
   }
   #ifdef USE_MARKET_ORDERS
      IEntryStrategy* entryStrategy = new MarketEntryStrategy(symbol, magic_number, slippage_points, actions);
   #else
      // AStream *longPrice = new LongEntryStream(symbol, timeframe);
      // AStream *shortPrice = new ShortEntryStream(symbol, timeframe);
      // IEntryStrategy* entryStrategy = new PendingEntryStrategy(symbol, magic_number, slippage_points, longPrice, shortPrice, actions, ecn_broker);
   #endif
   #ifdef MARTINGALE_FEATURE
      switch (martingale_type)
      {
         case MartingaleOnLoss:
            {
               CreateMartingale(tradingCalculator, symbol, timeframe, entryStrategy, orderHandlers, actions);
            }
            break;
      }
   #endif
   EntryStreamData* data = new EntryStreamData(symbol, timeframe);
   AndCondition* longCondition = new AndCondition();
   longCondition.Add(CreateLongCondition(symbol, timeframe, data), false);
   AndCondition* shortCondition = new AndCondition();
   shortCondition.Add(CreateShortCondition(symbol, timeframe, data), false);
   data.Release();
   #ifdef TRADING_TIME_FEATURE
      longCondition.Add(tradingTimeCondition, true);
      shortCondition.Add(tradingTimeCondition, true);
      tradingTimeCondition.Release();
   #endif
   AndCondition* longFilterCondition = new AndCondition();
   longFilterCondition.Add(CreateLongFilterCondition(symbol, timeframe, data), false);
   AndCondition* shortFilterCondition = new AndCondition();
   shortFilterCondition.Add(CreateShortFilterCondition(symbol, timeframe, data), false);
   #ifdef WITH_EXIT_LOGIC
      controller.SetExitLogic(exit_logic);
      ICondition* exitLongCondition = CreateExitLongCondition(symbol, timeframe);
      ICondition* exitShortCondition = CreateExitShortCondition(symbol, timeframe);
   #else
      ICondition* exitLongCondition = new DisabledCondition();
      ICondition* exitShortCondition = new DisabledCondition();
   #endif
   if (use_position_cap)
   {
      ICondition* buyLimitCondition = new PositionLimitHitCondition(BuySide, magic_number, max_positions, max_positions, symbol);
      ICondition* sellLimitCondition = new PositionLimitHitCondition(SellSide, magic_number, max_positions, max_positions, symbol);
      longFilterCondition.Add(new NotCondition(buyLimitCondition), false);
      shortFilterCondition.Add(new NotCondition(sellLimitCondition), false);
      buyLimitCondition.Release();
      sellLimitCondition.Release();
   }
   ICloseOnOppositeStrategy* closeOnOpposite = close_on_opposite 
      ? (ICloseOnOppositeStrategy*)new DoCloseOnOppositeStrategy(slippage_points, magic_number)
      : (ICloseOnOppositeStrategy*)new DontCloseOnOppositeStrategy();
   EntryPositionController* longPosition = new EntryPositionController(BuySide, longCondition, longFilterCondition, 
      closeOnOpposite, signaler, "", "Buy");
   EntryPositionController* shortPosition = new EntryPositionController(SellSide, shortCondition, shortFilterCondition,
      closeOnOpposite, signaler, "", "Sell");
   longCondition.Release();
   shortCondition.Release();
   longFilterCondition.Release();
   shortFilterCondition.Release();
   closeOnOpposite.Release();
   controller.AddLongPosition(longPosition);
   controller.AddShortPosition(shortPosition);
   switch (logic_direction)
   {
      case DirectLogic:
         controller.SetExitLongCondition(exitLongCondition);
         controller.SetExitShortCondition(exitShortCondition);
         break;
      case ReversalLogic:
         controller.SetExitLongCondition(exitShortCondition);
         controller.SetExitShortCondition(exitLongCondition);
         break;
   }
   #ifdef TRADING_TIME_FEATURE
      if (mandatory_closing)
      {
         NotCondition* condition = new NotCondition(tradingTimeCondition);
         IAction* action = new CloseAllAction(magic_number, slippage_points);
         actions.AddActionOnCondition(action, condition);
         action.Release();
         condition.Release();
      }
   #endif
  IMoneyManagementStrategy* longMoneyManagement = CreateMoneyManagementStrategy(tradingCalculator, symbol, timeframe, true, 
      lots_type, lots_value, stop_loss_type, stop_loss_value, 1/*stop_loss_atr_multiplicator*/, take_profit_type, take_profit_value, take_profit_atr_multiplicator);
   IAction* openLongAction = new EntryAction(entryStrategy, BuySide, longMoneyManagement, "", orderHandlers, false);
   longPosition.AddAction(openLongAction);
   openLongAction.Release();
   IMoneyManagementStrategy* shortMoneyManagement = CreateMoneyManagementStrategy(tradingCalculator, symbol, timeframe, false, 
      lots_type, lots_value, stop_loss_type, stop_loss_value, 1/*stop_loss_atr_multiplicator*/, take_profit_type, take_profit_value, take_profit_atr_multiplicator);
   IAction* openShortAction = new EntryAction(entryStrategy, SellSide, shortMoneyManagement, "", orderHandlers, false);
   shortPosition.AddAction(openShortAction);
   openShortAction.Release();
   #ifdef NET_STOP_LOSS_FEATURE
      if (net_stop_loss_type != StopLimitDoNotUse)
      {
         MoveNetStopLossAction* action = new MoveNetStopLossAction(tradingCalculator, net_stop_loss_type, net_stop_loss_value, magic_number);
         #ifdef USE_NET_BREAKEVEN
            if (breakeven_type != StopLimitDoNotUse)
            {
               //TODO: use breakeven_type as well
               action.SetBreakeven(breakeven_value, breakeven_level);
            }
         #endif
         NoCondition* condition = new NoCondition();
         actions.AddActionOnCondition(action, condition);
         action.Release();
      }
   #endif
   #ifdef NET_TAKE_PROFIT_FEATURE
      if (net_take_profit_type != StopLimitDoNotUse)
      {
         IAction* action = new MoveNetTakeProfitAction(tradingCalculator, net_take_profit_type, net_take_profit_value, magic_number);
         NoCondition* condition = new NoCondition();
         actions.AddActionOnCondition(action, condition);
         action.Release();
      }
   #endif
   controller.SetEntryLogic(entry_logic);
   controller.SetEntryStrategy(entryStrategy);
   if (print_log)
   {
      controller.SetPrintLog(log_file);
   }
   return controller;
}
OrderHandlers* orderHandlers;
int OnInit()
{
   CPro_Init();  // CPro营销模块初始化
   orderHandlers = new OrderHandlers();
   string error;
   string sym_arr[];
   if (symbols != "")
   {
      StringSplit(symbols, ',', sym_arr);
   }
   else
   {
      ArrayResize(sym_arr, 1);
      sym_arr[0] = _Symbol;
   }
   int sym_count = ArraySize(sym_arr);
   for (int i = 0; i < sym_count; i++)
   {
      string symbol = sym_arr[i];
      TradingController* controller = CreateController(symbol, (ENUM_TIMEFRAMES)_Period, error);
      if (controller == NULL)
      {
         Print(error);
         return INIT_FAILED;
      }
      int controllersCount = ArraySize(controllers);
      ArrayResize(controllers, controllersCount + 1);
      controllers[controllersCount] = controller;
   }
   return INIT_SUCCEEDED;
}
void OnDeinit(const int reason)
{
   orderHandlers.Clear();
   orderHandlers.Release();
   for (int i = 0; i < ArraySize(controllers); ++i)
   {
      delete controllers[i];
   CPro_Deinit();  // CPro营销模块清理
   }
   int size = ArraySize(controllers);
   ArrayResize(controllers, 0);
}
void OnTick()
{
   for (int i = 0; i < ArraySize(controllers); ++i)
   {
      controllers[i].DoTrading();
   }
}