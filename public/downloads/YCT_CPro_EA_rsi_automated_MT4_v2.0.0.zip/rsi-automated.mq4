//+------------------------------------------------------------------+
//|                                         CPro EA rsi_automated MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

input int MagicNumber=1982;//魔术号码
input double Lots=0.01;//fixed 交易量s
input double StopLoss=50;//fixed 停止 亏损 (in 点数)
input double TakeProfit=150;//fixed take 利润 (in 点数)
input int TrailingStop=25;//追踪止损 停止 (in 点数)
input int Slippage=3;
//+------------------------------------------------------------------+
//|   expert OnTick function                                         |
//+------------------------------------------------------------------+
void OnTick()
  {
   double MyPoint=Point;
   if(Digits==3 || Digits==5) MyPoint=Point*10;
   double TheStopLoss=0;
   double TheTakeProfit=0;
   if(TotalOrdersCount()==0)
     {
      int result=0;
      if((iRSI(NULL,0,14,PRICE_CLOSE,0)<25)) // Here is the open buy condition
        {
         result=OrderSend(Symbol(),OP_BUY,Lots,Ask,Slippage,0,0,"EXAMPLE OF RSI AUTOMATED",MagicNumber,0,Blue);
         if(result>0)
           {
            TheStopLoss=0;
            TheTakeProfit=0;
            if(TakeProfit>0) TheTakeProfit=Ask+TakeProfit*MyPoint;
            if(StopLoss>0) TheStopLoss=Ask-StopLoss*MyPoint;
            int MyOrderSelect=OrderSelect(result,SELECT_BY_TICKET);
            int MyOrderModify=OrderModify(OrderTicket(),OrderOpenPrice(),NormalizeDouble(TheStopLoss,Digits),NormalizeDouble(TheTakeProfit,Digits),0,Green);
           }
        }
      if((iRSI(NULL,0,14,PRICE_CLOSE,0)>75)) // Here is the open Sell condition
        {
         result=OrderSend(Symbol(),OP_SELL,Lots,Bid,Slippage,0,0,"EXAMPLE OF RSI AUTOMATED",MagicNumber,0,Red);
         if(result>0)
           {
            TheStopLoss=0;
            TheTakeProfit=0;
            if(TakeProfit>0) TheTakeProfit=Bid-TakeProfit*MyPoint;
            if(StopLoss>0) TheStopLoss=Bid+StopLoss*MyPoint;
            int MyOrderSelect2=OrderSelect(result,SELECT_BY_TICKET);
            int MyOrderModify2=OrderModify(OrderTicket(),OrderOpenPrice(),NormalizeDouble(TheStopLoss,Digits),NormalizeDouble(TheTakeProfit,Digits),0,Green);
           }
        }
     }
   for(int cnt=0;cnt<OrdersTotal();cnt++)
     {
      int MyOrderSelect22=OrderSelect(cnt,SELECT_BY_POS,MODE_TRADES);
      if(OrderType()<=OP_SELL && 
         OrderSymbol()==Symbol() && 
         OrderMagicNumber()==MagicNumber
         )
        {
         if(OrderType()==OP_BUY)
           {
            if((iRSI(NULL,0,14,PRICE_CLOSE,0)>50)) //here is the close buy condition
              {
               int MyOrderClose=OrderClose(OrderTicket(),OrderLots(),OrderClosePrice(),Slippage,Red);
              }
            if(TrailingStop>0)
              {
               if(Bid-OrderOpenPrice()>MyPoint*TrailingStop)
                 {
                  if(OrderStopLoss()<Bid-MyPoint*TrailingStop)
                    {
                     int MyOrderModify22=OrderModify(OrderTicket(),OrderOpenPrice(),Bid-TrailingStop*MyPoint,OrderTakeProfit(),0,Green);
                    }
                 }
              }
           }
         else
           {
            if((iRSI(NULL,0,14,PRICE_CLOSE,0)<50)) // here is the close sell condition
              {
               int MyOrderClose2=OrderClose(OrderTicket(),OrderLots(),OrderClosePrice(),Slippage,Red);
              }
            if(TrailingStop>0)
              {
               if((OrderOpenPrice()-Ask)>(MyPoint*TrailingStop))
                 {
                  if((OrderStopLoss()>(Ask+MyPoint*TrailingStop)) || (OrderStopLoss()==0))
                    {
                     int MyOrderModify24=OrderModify(OrderTicket(),OrderOpenPrice(),Ask+MyPoint*TrailingStop,OrderTakeProfit(),0,Red);
                    }
                 }
              }
           }
        }
     }
  }
//+------------------------------------------------------------------+
//|   expert TotalOrdersCount function                               |
//+------------------------------------------------------------------+
int TotalOrdersCount()
  {
   int result=0;
   for(int i=0;i<OrdersTotal();i++)
     {
      int MyOrderSelect=OrderSelect(i,SELECT_BY_POS,MODE_TRADES);
      if(OrderMagicNumber()==MagicNumber) result++;
     }
   return (result);
  }
//-------------------------------------------------------------------+
//Bye