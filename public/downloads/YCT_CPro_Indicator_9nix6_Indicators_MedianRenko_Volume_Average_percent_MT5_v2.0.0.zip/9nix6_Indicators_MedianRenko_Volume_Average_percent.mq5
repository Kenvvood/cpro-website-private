//+------------------------------------------------------------------+
//|                                         CPro Indicator 9nix6_Indicators_MedianRenko_Volume_Average_percent MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <AZ-INVEST/CustomBarConfig.mqh>

//--- forward declaration stub for customChartIndicator (provided by CustomBarConfig include)
//--- The CustomBarConfig.mqh header is expected to define a CCustomChartIndicator class.
//--- If the include does not provide it, we declare a minimal stub here.
#ifndef __CUSTOM_CHART_INDICATOR_DEFINED__
#define __CUSTOM_CHART_INDICATOR_DEFINED__
class CCustomChartIndicator
  {
public:
   void              SetGetVolumesFlag() {}
  };
#endif
CCustomChartIndicator customChartIndicator;

//------------------------------------------------------------------
//---
enum enMaTypes
  {
   ma_sma,    // Simple moving average
   ma_ema,    // Exponential moving average
   ma_smma,   // Smoothed MA
   ma_lwma    // Linear weighted MA
  };
//---
enum enVolumeType
  {
   vol_ticks, // Use ticks
   vol_volume // Use real volume
  };
//--- input parameters  
input enVolumeType inpVolumeType      = vol_ticks;//交易量 类型 to 使用
input int          inpAveragePeriod   = 50;//均值 周期
input enMaTypes    inpAverageMethod   = ma_ema;//均值 method
input double       inpBreakoutPercent = 50;//breakout 百分比age
//--- buffers
double  val[],valc[],average[];
//+------------------------------------------------------------------+ 
//| Custom indicator initialization function                         | 
//+------------------------------------------------------------------+ 
void OnInit()
  {
//---- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,val,INDICATOR_DATA);
   SetIndexBuffer(1,valc,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(2,average,INDICATOR_DATA);
   string _avgNames[]={"SMA","EMA","SMMA","LWMA"};
   IndicatorSetString(INDICATOR_SHORTNAME,"Volume "+_avgNames[inpAverageMethod]+" average percent ("+(string)inpAveragePeriod+")");
   customChartIndicator.SetGetVolumesFlag();
  }
//+------------