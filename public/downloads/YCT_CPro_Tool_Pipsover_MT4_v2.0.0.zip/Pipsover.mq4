//+------------------------------------------------------------------+
//|                                         CPro Tool Pipsover MT4                           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
// 
extern double lots = 0.1;
// 
extern double stoploss = 70;
// 
extern double takeprofit = 140;
//        
extern double openlevel = 55;
//        
extern double closelevel = 90;
//   
static int prevtime = 0;
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
   // ,    
   if (Time[0] == prevtime) return(0);
   prevtime = Time[0];
//---- 
   // 20  
   double ma = iMA(NULL, 0, 20, 0, MODE_SMA, PRICE_CLOSE, 0);
   //    
   double ch = iCustom(NULL, 0, "Chaikin", 0, 0, 1);
   //   
   if (OrdersTotal() < 1) {
      int res = 0;
      //         
      //   
      // 
      if (Close[1] > Open[1] && Low[1] < ma && ch < -openlevel) {
         res=OrderSend(Symbol(), OP_BUY, lots ,Ask, 3, Ask - stoploss * Point, Bid + takeprofit * Point, "Pipsover", 888, 0, Blue);
         return(0);
      }
      //         
      //   
      // 
      if (Close[1] < Open[1] && High[1] > ma &&  ch > openlevel) {
         res=OrderSend(Symbol(), OP_SELL, lots ,Bid, 3, Bid + stoploss * Point, Ask - takeprofit * Point, "Pipsover", 888, 0, Red);
         return(0);
      }
   } else { //   .    ?
      //     
      if (OrdersTotal() > 1) return(0);
      OrderSelect(0, SELECT_BY_POS, MODE_TRADES);
      //   ,   
      if (OrderType() == OP_BUY  && Close[1] < Open[1] && High[1] > ma &&  ch > closelevel) {
         res=OrderSend(Symbol(), OP_SELL, lots ,Bid, 3, Bid + stoploss * Point, Ask - takeprofit * Point, "Pipsover", 888, 0, Red);
         return(0);
      }
      //   ,   
      if (OrderType() == OP_SELL && Close[1] > Open[1] && Low[1] < ma && ch < -closelevel) {
         res=OrderSend(Symbol(), OP_BUY, lots ,Ask, 3, Ask - stoploss * Point, Bid + takeprofit * Point, "Pipsover", 888, 0, Blue);
         return(0);
      }
   }
//----    
   return(0);
  }
//+------------------------------------------------------------------+