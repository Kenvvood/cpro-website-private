//+------------------------------------------------------------------+
//|                                         CPro Indicator Double_MA_Cross MT5               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot FastLine
//--- plot SloeLine
//--- plot Long
//--- plot Short
//--- input Fast iMA parameters
input string             CommandFM            = "=====Fast_MA Paramater=====";
input ENUM_TIMEFRAMES    FastMA_timeframe     = 0;
input int                FastMA_period        = 9;
input int                FastMA_shift         = 0;
input ENUM_MA_METHOD     FastMA_method        = 0;
input ENUM_APPLIED_PRICE FastMA_applied_price = PRICE_CLOSE;
//--- input Slow iMA parameters
input string             CommandSM            = "=====Slow_MA Paramater=====";
input ENUM_TIMEFRAMES    SlowMA_timeframe     = 0;
input int                SlowMA_period        = 36;
input int                SlowMA_shift         = 0;
input ENUM_MA_METHOD     SlowMA_method        = 0;
input ENUM_APPLIED_PRICE SlowMA_applied_price = PRICE_CLOSE;
//--- indicator buffers
double         FastLineBuffer[];
double         SlowLineBuffer[];
double         LinearBuffer1[];
double         LinearBuffer2[];
double         LinearXBuffer1[];
double         LinearXBuffer2[];
int FastShift;
int SlowShift;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,FastLineBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,SlowLineBuffer,INDICATOR_DATA);
   SetIndexBuffer(2,LinearBuffer1 ,INDICATOR_DATA);
   SetIndexBuffer(3,LinearBuffer2 ,INDICATOR_DATA);
   SetIndexBuffer(4,LinearXBuffer1,INDICATOR_DATA);
   SetIndexBuffer(5,LinearXBuffer2,INDICATOR_DATA);
   FastShift=iMA(NULL,FastMA_timeframe,FastMA_period,FastMA_shift,FastMA_method,FastMA_applied_price);
   SlowShift=iMA(NULL,SlowMA_timeframe,SlowMA_period,SlowMA_shift,SlowMA_method,SlowMA_applied_price);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
//---
   double Fast[];
   if(CopyBuffer(FastShift,0,0,rates_total,Fast)<=0)
      return(0);
   double Slow[];
   if(CopyBuffer(SlowShift,0,0,rates_total,Slow)<=0)
      return(0);
   int start=100;
   if(prev_calculated>0)
      start=prev_calculated-1;
   for(int i=start; i<rates_total; i++)
      {
       FastLineBuffer[i]=Fast[i];
       SlowLineBuffer[i]=Slow[i];
       if(FastLineBuffer[i]>=SlowLineBuffer[i])
         {
          LinearBuffer1[i]=Fast[i];
          LinearBuffer2[i]=Slow[i];
         }
       else 
         {
          LinearXBuffer1[i]=Slow[i];
          LinearXBuffer2[i]=Fast[i];
         }
       }
//--- return value of prev_calculated for next call
   return(rates_total);
  }