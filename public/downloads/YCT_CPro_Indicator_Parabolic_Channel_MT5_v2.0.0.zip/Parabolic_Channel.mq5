//+------------------------------------------------------------------+
//|                                         CPro Indicator Parabolic_Channel MT5             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- labels
//--- input parameters
input double InpSARStep   =0.02;//步进
input double InpSARMaximum=0.2;//均线ximum
input bool   InpShowLabel =true;//show 价格 of 级别
//--- indicator buffers
double ExtUpperBuffer[];
double ExtParabolicBuffer[];
double ExtLowerBuffer[];
//--- indicator handle
int    ExtParabolicHandle;
//--- unique prefix for indicator objects
string ExtPrefixUniq;
//--- current chart scale
long   ExtChartScale=2;
//--- price labels should not be shown on the built-in VPS
bool   ExtShowLabel=false;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- if the indicator is running on the built-in VPS, price labels should not be shown
   CPro_Init();  // CPro营销模块初始化
   if(!TerminalInfoInteger(TERMINAL_VPS))
      ExtShowLabel=InpShowLabel; 
//--- define buffers
   SetIndexBuffer(0, ExtUpperBuffer);
   SetIndexBuffer(1, ExtParabolicBuffer);
   SetIndexBuffer(2, ExtLowerBuffer);
   PlotIndexSetInteger(1,PLOT_ARROW,159);
//--- indicator name
   IndicatorSetString(INDICATOR_SHORTNAME, "Parabolic Channel");
//--- number of digits of indicator value
   IndicatorSetInteger(INDICATOR_DIGITS, _Digits);
//--- create indicators
   ExtParabolicHandle=iSAR(NULL,0,InpSARStep,InpSARMaximum);
//--- prepare prefix for objects
   string number=StringFormat("%I64d", GetTickCount64());
   ExtPrefixUniq=StringSubstr(number, StringLen(number)-4);
   ExtPrefixUniq=ExtPrefixUniq+"_PS";
   Print("Indicator \"Parabolic Channels\" started, prefix=", ExtPrefixUniq);
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
//--- write Parabolic SAR indicator values to the buffer
   if(CopyBuffer(ExtParabolicHandle, 0, 0, rates_total, ExtParabolicBuffer)<0)
      return(0);
//--- start calculations from the bar preceding the last one
   int start=prev_calculated-2;
//--- if this is the first calculation of the indicator
   if(prev_calculated==0)
     {
      start=1;
      ArrayFill(ExtUpperBuffer,0,rates_total,0);
      ArrayFill(ExtLowerBuffer,0,rates_total,0);
      ExtUpperBuffer[start-1]=close[start-1];
      ExtLowerBuffer[start-1]=open[start-1];
     }
   for(int i=start; i<rates_total; i++)
     {
      ExtUpperBuffer[i]=ExtUpperBuffer[i-1];
      ExtLowerBuffer[i]=ExtLowerBuffer[i-1];
      //--- check if the parabolic has jumped down
      if(close[i]>ExtParabolicBuffer[i] && close[i-1]<ExtParabolicBuffer[i-1])
         ExtLowerBuffer[i]=ExtParabolicBuffer[i];
      //--- check if the parabolic has jumped up
      if(close[i]<ExtParabolicBuffer[i] && close[i-1]>ExtParabolicBuffer[i-1])
         ExtUpperBuffer[i]=ExtParabolicBuffer[i];
     }
//--- draw labels on levels
   if(ExtShowLabel)
     {
      ShowPriceLevels(time[rates_total-1], rates_total-1);
      ChartRedraw();
     }     
//--- succesfully calculated
   return(rates_total);
  }
//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//--- delete all our graphical objects after use
   Print("Indicator \"Parabolic Channel\" stopped, delete all objects with prefix=", ExtPrefixUniq);
   ObjectsDeleteAll(0, ExtPrefixUniq, 0, OBJ_ARROW_RIGHT_PRICE);
   ChartRedraw(0);
  }  
//+------------------------------------------------------------------+
//| Handles CHARTEVENT_CHART_CHANGE to track chart window updates    |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long& lparam, const double& dparam, const string& sparam)
  {
   if(id==CHARTEVENT_CHART_CHANGE)
      if(!ChartGetInteger(0, CHART_SCALE, 0, ExtChartScale))
        {
         //--- output an error message to the Experts journal
         Print(__FUNCTION__+", ChartGetInteger(CHART_SCALE) failed, error = ", GetLastError());
        }
//---
  }  
//+------------------------------------------------------------------+
//|  Show prices' levels                                             |
//+------------------------------------------------------------------+
void ShowPriceLevels(datetime time, int last_index)
  {
   ShowRightPrice(ExtPrefixUniq+"_Upper", time, ExtUpperBuffer[last_index], clrRoyalBlue);
   ShowRightPrice(ExtPrefixUniq+"_Parabolic", time, ExtParabolicBuffer[last_index], clrDeepSkyBlue);
   ShowRightPrice(ExtPrefixUniq+"_Lower", time, ExtLowerBuffer[last_index], clrDarkOrange);
  }  
//+------------------------------------------------------------------+
//| Create or Update "Right Price Label" object                      |
//+------------------------------------------------------------------+
bool ShowRightPrice(const string name, datetime time, double price, color clr)
  {
   if(!ObjectCreate(0, name, OBJ_ARROW_RIGHT_PRICE, 0, time, price))
     {
      ObjectMove(0, name, 0, time, price);
      return(false);
     }
//--- adjust label size based on chart scale
   int width=ExtChartScale>1 ? 2:1;  // if chart scale > 1, then label size = 2
   ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, name, OBJPROP_STYLE, STYLE_SOLID);
   ObjectSetInteger(0, name, OBJPROP_WIDTH, width);
   ObjectSetInteger(0, name, OBJPROP_BACK, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, name, OBJPROP_SELECTED, false);
   ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   ObjectSetInteger(0, name, OBJPROP_ZORDER, 0);
   return(true);
  }   
//+------------------------------------------------------------------+