//+------------------------------------------------------------------+
//|                                         CPro Tool auto_stop7takeprofit MT4               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

input double StopLoss =500;
input double TakeProfit =500;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
   for(int j=0;j<OrdersTotal();j++)
     {
      if(OrderSelect(j,SELECT_BY_POS,MODE_TRADES)==false) break;
      if(OrderSymbol()!=Symbol() || OrderCloseTime()!=0) continue;
        {
         //--- long position is opened
            if(OrderType()==OP_BUY && OrderStopLoss()==0)
            //--- check for trailing stop
           { if(OrderStopLoss()==OrderOpenPrice()-StopLoss*Point) break;
              else
                    {
                     //--- modify order and exit
                     if(!OrderModify(OrderTicket(),OrderOpenPrice(),OrderOpenPrice()-StopLoss*Point,OrderTakeProfit(),0,Green))
                        Print("OrderModify error ",GetLastError());
                    // return;
                    }
            }     
             if(OrderType()==OP_BUY && OrderTakeProfit()==0)
            //--- check for trailing stop
           { if(OrderTakeProfit()==OrderOpenPrice()+TakeProfit*Point) break;
              else
                    {
                     //--- modify order and exit
                     if(!OrderModify(OrderTicket(),OrderOpenPrice(),OrderStopLoss(),OrderOpenPrice()+TakeProfit*Point,0,Green))
                        Print("OrderModify error ",GetLastError());
                    // return;
                    }
            }     
         if(OrderType()==OP_SELL && OrderStopLoss()==0)   
            //--- check for trailing stop
          {  if(OrderStopLoss()==OrderOpenPrice()+StopLoss*Point) break;
            else 
                    {
                     //--- modify order and exit
                     if(!OrderModify(OrderTicket(),OrderOpenPrice(),OrderOpenPrice()+StopLoss*Point,OrderTakeProfit(),0,Red))
                        Print("OrderModify error ",GetLastError());
                     //return;
                    }
           }         
            if(OrderType()==OP_SELL && OrderTakeProfit()==0)   
            //--- check for trailing stop
          {  if(OrderTakeProfit()==OrderOpenPrice()-TakeProfit*Point) break;
            else 
                    {
                     //--- modify order and exit
                     if(!OrderModify(OrderTicket(),OrderOpenPrice(),OrderStopLoss(),OrderOpenPrice()-TakeProfit*Point,0,Red))
                        Print("OrderModify error ",GetLastError());
                    // return;
                    }
           }       
        }
     } 
     Sleep(1000);
  }
//+------------------------------------------------------------------+