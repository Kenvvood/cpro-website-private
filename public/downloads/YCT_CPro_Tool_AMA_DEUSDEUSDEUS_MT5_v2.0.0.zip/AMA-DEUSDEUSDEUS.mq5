//+------------------------------------------------------------------+
//|                                         CPro Tool AMA_DEUSDEUSDEUS MT5                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <trade/trade.mqh>

CTrade trade;
//-------------------------------------------BASIC TEST IF CONCEPT WORKS -------------
input double TrigPDif = 0.00005;
input double SLDif = 0.001;
input double TPDif = 0.001;
input double LotS = 1.0;
input int ExpiryTime = 120;
//bool OrderinAction;
double bid1 = 0;
double bid0 = 0; 
double accountbalancebeginning;
double accountprofit;
int OnInit(){
   CPro_Init();  // CPro营销模块初始化
   accountbalancebeginning = AccountInfoDouble(ACCOUNT_BALANCE);
   //OrderinAction = false;
   return(INIT_SUCCEEDED);
  }
void OnTick(){
   //GET RED AMA VALUES
   double AMAPriceArray[];
   int AMADefinition = iAMA (_Symbol,_Period,5,2,30,0,PRICE_CLOSE);
   ArraySetAsSeries(AMAPriceArray,true);
   //AMA DEF, one line, current candle, 3 candles, store result
   CopyBuffer(AMADefinition,0,0,3,AMAPriceArray);
   double AMACurrentValue = NormalizeDouble(AMAPriceArray[0],6);
   Comment("AMA-Value ",AMACurrentValue); 
   //GET PRICE VALUES
   MqlRates CurrentPriceArray[];
   int copied = CopyRates(_Symbol,PERIOD_CURRENT,0,3,CurrentPriceArray);
   ArraySetAsSeries(CurrentPriceArray, true);
   //SET THE ORDER
   bid1 = bid0;
   bid0 = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);
   if(bid0 <= AMAPriceArray[0] && bid1 > AMAPriceArray[1] && PositionsTotal() == 0 && OrdersTotal() == 0/*&& OrderinAction == false*/){
      double TrigP = bid0 - TrigPDif;
      double TP = TrigP - TPDif;
      double SL = TrigP + SLDif;
      datetime OrderExpTime = TimeCurrent() + ExpiryTime;
      trade.SellStop(LotS,TrigP,_Symbol,SL,TP,ORDER_TIME_SPECIFIED,OrderExpTime);
      //OrderinAction = true;
   }
   /*/DELETE ORDER
   if(bid0 >= AMAPriceArray[0] - TrigPDif && OrderinAction == true){
      ulong Positionticket = PositionGetTicket(0);
      trade.OrderDelete(Positionticket);
   }*/
   // DISPLAY OF VALUES ON CHART 
   double accountbalance = AccountInfoDouble(ACCOUNT_BALANCE);
   double accountequity = AccountInfoDouble(ACCOUNT_EQUITY);
   accountprofit = accountequity - accountbalancebeginning;
   accountprofit = NormalizeDouble(accountprofit,2);  
   Comment("\nServertime: ", TimeCurrent(),
           "\nCurrenttime: ",TimeCurrent(),
           "\nProfit: ",accountprofit,
           "\nEquity: ",accountequity);
  }