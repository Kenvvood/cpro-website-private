//+------------------------------------------------------------------+
//| CProPanel.mqh - MT4 stub (CProTrading L3 Healer)                  |
//| MQL4 不支持 ObjectSetInteger 4->5 参数, 用 stub 占位              |
//+------------------------------------------------------------------+
#ifndef CPRO_PANEL_MQH
#define CPRO_PANEL_MQH
class CProPanel {
public:
    int Init() { return 0; }
    int Deinit() { return 0; }
    void CreateAboutSection() {}
    void DeleteObjects(string prefix) {}
    void DrawWatermark() {}
    void SetPanel(int x, int y, int w, int h) {}
};
#endif
