//+------------------------------------------------------------------+
//| CProDialog.mqh - MT4 stub                                          |
//+------------------------------------------------------------------+
#ifndef CPRO_DIALOG_MQH
#define CPRO_DIALOG_MQH
class CProDialog {
public:
    int Init() { return 0; }
    int Deinit() { return 0; }
    int ShowStartupDialog() { return 0; }
};
#endif
