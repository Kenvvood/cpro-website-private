//+------------------------------------------------------------------+
//| CProWatermark.mqh - MT4 stub                                       |
//+------------------------------------------------------------------+
#ifndef CPRO_WATERMARK_MQH
#define CPRO_WATERMARK_MQH
class CProWatermark {
public:
    int Init() { return 0; }
    int Deinit() { return 0; }
    int DrawWatermark() { return 0; }
};
#endif
