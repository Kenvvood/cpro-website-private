//+------------------------------------------------------------------+
//| CPro.mqh - MT4 stub (CProTrading L3 Healer)                       |
//+------------------------------------------------------------------+
#ifndef CPRO_MQH
#define CPRO_MQH
#include <CPro\CProConfig.mqh>
class CProDialog;
class CProPanel;
class CProWatermark;
#include <CPro\CProDialog.mqh>
#include <CPro\CProPanel.mqh>
#include <CPro\CProWatermark.mqh>
#endif
