//+------------------------------------------------------------------+
//| CProConfig.mqh - MT4 stub                                         |
//+------------------------------------------------------------------+
#ifndef CPRO_CONFIG_MQH
#define CPRO_CONFIG_MQH
#define CPRO_PANEL_CORNER 0
#define CPRO_COLOR_PANEL 0
#define CPRO_COLOR_BORDER 0
#define CPRO_COLOR_TEXT_PRIMARY 0
#define CPRO_LABEL_ABOUT_TITLE ""
#endif
