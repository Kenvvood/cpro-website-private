//+------------------------------------------------------------------+
//|                                         CPro EA DCA_Gold_Grid MT5                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//+------------------------------------------------------------------+
//| Input parameters                                                 |
//+------------------------------------------------------------------+
input group "===Trading Parameters==="
input double   InpLotSize = 0.01;//交易量 尺寸 (in 交易量s)
input double   InpStartPrice = 3300.0;//开始 价格 for 网格
input int      InpGridStepPoints = 300;//网格 步进 in 点数
input int      InpLinesUp = 150;//编号 of lines upwards
input int      InpLinesDown = 10;//编号 of lines downwards
input bool     InpAutoTrading = true;//启用 auto 交易时段
input int      InpMagicNumber = 12345;//魔术号码
input int      InpSlippage = 3;//止损ippage in 点数
input bool     InpEnableAlerts = false;//启用 价格 alerts
input bool     InpUseStopLoss = false;//启用 停止 亏损
input int      InpStopLossPoints = 500;//停止 亏损 in 点数
input group "===Grid Display Options==="
input bool     InpShowGridLines = true;//show 网格 lines
input color    InpGridColor = clrBlue;//网格 lines 颜色
input color    InpBuySignalColor = clrGreen;//买入 信号 颜色
input color    InpTakeProfitColor = clrRed;//take 利润 颜色
input bool     InpShowTradedLabels = true;//show 交易d labels
input bool     InpShowTPLabels = true;//show take 利润 labels
input int      InpGridLabelFontSize = 10;//网格 labels font 尺寸
input group "===Panel Options==="
input bool     InpShowInfoPanel = true;        // Show Info Panel
input color    InpPanelBackgroundColor = clrWhite;//panel background 颜色
input color    InpPanelBorderColor = clrBlack;//panel border 颜色
input color    InpPanelTextColor = clrBlack;//panel text 颜色
input color    InpPanelValueColor = clrBlue;//panel 值 颜色
input int      InpPanelFontSize = 18;//panel font 尺寸
input int      InpPanelWidth = 300;//panel 宽度
input int      InpPanelHeight = 160;//panel 高度
input bool     InpShowEquityInstead = false;//show 净值 (余额 + 利润)
// Panel position options
enum ENUM_PANEL_POSITION
{
   POSITION_TOP_LEFT,      // Top Left
   POSITION_TOP_RIGHT,     // Top Right
   POSITION_BOTTOM_LEFT,   // Bottom Left
   POSITION_BOTTOM_RIGHT   // Bottom Right
};
input ENUM_PANEL_POSITION InpPanelPosition = POSITION_TOP_LEFT;//panel 持仓
//+------------------------------------------------------------------+
//| CGoldGridExpert class                                            |
//+------------------------------------------------------------------+
class CGoldGridExpert
{
private:
   // Member variables
   double            m_gridPrices[];
   bool              m_gridLevelTraded[];
   int               m_totalLines;
   double            m_pointValue;
   datetime          m_lastTradeTime;
   bool              m_gridCalculated;
   int               m_panelX;
   int               m_panelY;
   double            m_contractSize;
   // Trading parameters
   double            m_lotSize;
   double            m_startPrice;
   int               m_gridStepPoints;
   int               m_linesUp;
   int               m_linesDown;
   bool              m_autoTrading;
   int               m_magicNumber;
   int               m_slippage;
   bool              m_enableAlerts;
   bool              m_useStopLoss;
   int               m_stopLossPoints;
   // Display options
   bool              m_showGridLines;
   color             m_gridColor;
   color             m_buySignalColor;
   color             m_takeProfitColor;
   bool              m_showTradedLabels;
   bool              m_showTPLabels;
   int               m_gridLabelFontSize;
   // Panel options
   bool              m_showInfoPanel;
   color             m_panelBackgroundColor;
   color             m_panelBorderColor;
   color             m_panelTextColor;
   color             m_panelValueColor;
   int               m_panelFontSize;
   int               m_panelWidth;
   int               m_panelHeight;
   bool              m_showEquityInstead;
   ENUM_PANEL_POSITION m_panelPosition;
public:
   //+------------------------------------------------------------------+
   //| Constructor                                                      |
   //+------------------------------------------------------------------+
   CGoldGridExpert() :
      m_lotSize(InpLotSize),
      m_startPrice(InpStartPrice),
      m_gridStepPoints(InpGridStepPoints),
      m_linesUp(InpLinesUp),
      m_linesDown(InpLinesDown),
      m_autoTrading(InpAutoTrading),
      m_magicNumber(InpMagicNumber),
      m_slippage(InpSlippage),
      m_enableAlerts(InpEnableAlerts),
      m_useStopLoss(InpUseStopLoss),
      m_stopLossPoints(InpStopLossPoints),
      m_showGridLines(InpShowGridLines),
      m_gridColor(InpGridColor),
      m_buySignalColor(InpBuySignalColor),
      m_takeProfitColor(InpTakeProfitColor),
      m_showTradedLabels(InpShowTradedLabels),
      m_showTPLabels(InpShowTPLabels),
      m_gridLabelFontSize(InpGridLabelFontSize),
      m_showInfoPanel(InpShowInfoPanel),
      m_panelBackgroundColor(InpPanelBackgroundColor),
      m_panelBorderColor(InpPanelBorderColor),
      m_panelTextColor(InpPanelTextColor),
      m_panelValueColor(InpPanelValueColor),
      m_panelFontSize(InpPanelFontSize),
      m_panelWidth(InpPanelWidth),
      m_panelHeight(InpPanelHeight),
      m_showEquityInstead(InpShowEquityInstead),
      m_panelPosition(InpPanelPosition),
      m_pointValue(0.01),
      m_totalLines(0),
      m_lastTradeTime(0),
      m_gridCalculated(false),
      m_panelX(10),
      m_panelY(20),
      m_contractSize(0)
   {
   }
   //+------------------------------------------------------------------+
   //| Destructor                                                       |
   //+------------------------------------------------------------------+
   ~CGoldGridExpert()
   {
      DeleteObjects();
      if(m_showInfoPanel) DeleteInfoPanel();
      Print("Gold Grid EA deinitialized");
   }
   //+------------------------------------------------------------------+
   //| Initialization method                                            |
   //+------------------------------------------------------------------+
   int Init()
   {
      m_pointValue = 0.01;
      m_totalLines = m_linesUp + m_linesDown + 1;
      ArrayResize(m_gridPrices, m_totalLines);
      ArrayResize(m_gridLevelTraded, m_totalLines);
      ArrayInitialize(m_gridLevelTraded, false);
      // Get contract size for the symbol
      m_contractSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_CONTRACT_SIZE);
      Print("Contract size for ", _Symbol, ": ", m_contractSize);
      CalculateGridPrices();
      if(m_showGridLines) DrawGridLines();
      CalculatePanelPosition();
      if(m_showInfoPanel) CreateInfoPanel();
      m_gridCalculated = true;
      CheckExistingPositions();
      Print("Gold Grid EA initialized. Start Price: ", m_startPrice);
      Print("Grid Step: ", m_gridStepPoints, " points (", DoubleToString(m_gridStepPoints * m_pointValue, 2), " USD)");
      Print("Total Grid Lines: ", m_totalLines);
      Print("Lot Size: ", m_lotSize, " lots (", m_lotSize * m_contractSize, " ounces)");
      return(INIT_SUCCEEDED);
   }
   //+------------------------------------------------------------------+
   //| Deinitialization method                                          |
   //+------------------------------------------------------------------+
   void Deinit(const int reason)
   {
      DeleteObjects();
      if(m_showInfoPanel) DeleteInfoPanel();
      Print("Gold Grid EA deinitialized");
   }
   //+------------------------------------------------------------------+
   //| Tick processing method                                           |
   //+------------------------------------------------------------------+
   void OnTick()
   {
      if(!m_gridCalculated) return;
      static datetime lastCheck = 0;
      datetime currentTime = TimeCurrent();
      // Check for signals every tick on 1-minute chart
      if(Period() == PERIOD_M1)
      {
         CheckForSignals();
         // Update traded status of grid levels
         UpdateGridLevelStatus();
      }
      // Update info panel on every tick
      if(m_showInfoPanel) UpdateInfoPanel();
   }
   //+------------------------------------------------------------------+
   //| Chart event handler                                              |
   //+------------------------------------------------------------------+
   void OnChartEvent(const int id,
                     const long &lparam,
                     const double &dparam,
                     const string &sparam)
   {
      if(id == CHARTEVENT_CHART_CHANGE)
      {
         // Recalculate panel position if chart size changes
         CalculatePanelPosition();
         // Update panel position if shown
         if(m_showInfoPanel)
         {
            ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_XDISTANCE, m_panelX);
            ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_YDISTANCE, m_panelY);
            // Update all label positions
            int lineSpacing = m_panelFontSize + 5;
            int startY = m_panelY + 5;
            // Update headers
            ObjectSetInteger(0, "LabelHeader", OBJPROP_XDISTANCE, m_panelX + 5);
            ObjectSetInteger(0, "LabelHeader", OBJPROP_YDISTANCE, startY);
            ObjectSetInteger(0, "ValueHeader", OBJPROP_XDISTANCE, m_panelX + m_panelWidth - 5);
            ObjectSetInteger(0, "ValueHeader", OBJPROP_YDISTANCE, startY);
            // Update separator line
            ObjectSetInteger(0, "SeparatorLine", OBJPROP_XDISTANCE, m_panelX);
            ObjectSetInteger(0, "SeparatorLine", OBJPROP_YDISTANCE, startY + lineSpacing - 2);
            ObjectSetInteger(0, "SeparatorLine", OBJPROP_XSIZE, m_panelWidth);
            // Update labels
            ObjectSetInteger(0, "LotSize_Label", OBJPROP_XDISTANCE, m_panelX + 5);
            ObjectSetInteger(0, "LotSize_Label", OBJPROP_YDISTANCE, startY + lineSpacing);
            ObjectSetInteger(0, "OpenTrades_Label", OBJPROP_XDISTANCE, m_panelX + 5);
            ObjectSetInteger(0, "OpenTrades_Label", OBJPROP_YDISTANCE, startY + lineSpacing * 2);
            ObjectSetInteger(0, "Balance_Label", OBJPROP_XDISTANCE, m_panelX + 5);
            ObjectSetInteger(0, "Balance_Label", OBJPROP_YDISTANCE, startY + lineSpacing * 3);
            ObjectSetInteger(0, "FreeMargin_Label", OBJPROP_XDISTANCE, m_panelX + 5);
            ObjectSetInteger(0, "FreeMargin_Label", OBJPROP_YDISTANCE, startY + lineSpacing * 4);
            ObjectSetInteger(0, "TotalProfit_Label", OBJPROP_XDISTANCE, m_panelX + 5);
            ObjectSetInteger(0, "TotalProfit_Label", OBJPROP_YDISTANCE, startY + lineSpacing * 5);
            // Update values
            ObjectSetInteger(0, "LotSize_Value", OBJPROP_XDISTANCE, m_panelX + m_panelWidth - 5);
            ObjectSetInteger(0, "LotSize_Value", OBJPROP_YDISTANCE, startY + lineSpacing);
            ObjectSetInteger(0, "OpenTrades_Value", OBJPROP_XDISTANCE, m_panelX + m_panelWidth - 5);
            ObjectSetInteger(0, "OpenTrades_Value", OBJPROP_YDISTANCE, startY + lineSpacing * 2);
            ObjectSetInteger(0, "Balance_Value", OBJPROP_XDISTANCE, m_panelX + m_panelWidth - 5);
            ObjectSetInteger(0, "Balance_Value", OBJPROP_YDISTANCE, startY + lineSpacing * 3);
            ObjectSetInteger(0, "FreeMargin_Value", OBJPROP_XDISTANCE, m_panelX + m_panelWidth - 5);
            ObjectSetInteger(0, "FreeMargin_Value", OBJPROP_YDISTANCE, startY + lineSpacing * 4);
            ObjectSetInteger(0, "TotalProfit_Value", OBJPROP_XDISTANCE, m_panelX + m_panelWidth - 5);
            ObjectSetInteger(0, "TotalProfit_Value", OBJPROP_YDISTANCE, startY + lineSpacing * 5);
         }
         if(m_showGridLines) DrawGridLines();
      }
   }
private:
   //+------------------------------------------------------------------+
   //| Calculate panel position based on selection                      |
   //+------------------------------------------------------------------+
   void CalculatePanelPosition()
   {
      int chartWidth = (int)ChartGetInteger(0, CHART_WIDTH_IN_PIXELS);
      int chartHeight = (int)ChartGetInteger(0, CHART_HEIGHT_IN_PIXELS);
      switch(m_panelPosition)
      {
         case POSITION_TOP_LEFT:
            m_panelX = 10;
            m_panelY = 20;
            break;
         case POSITION_TOP_RIGHT:
            m_panelX = chartWidth - m_panelWidth - 10;
            m_panelY = 20;
            break;
         case POSITION_BOTTOM_LEFT:
            m_panelX = 10;
            m_panelY = chartHeight - m_panelHeight - 20;
            break;
         case POSITION_BOTTOM_RIGHT:
            m_panelX = chartWidth - m_panelWidth - 10;
            m_panelY = chartHeight - m_panelHeight - 20;
            break;
      }
   }
   //+------------------------------------------------------------------+
   //| Check for existing positions and mark grid levels as traded      |
   //+------------------------------------------------------------------+
   void CheckExistingPositions()
   {
      for(int i = 0; i < PositionsTotal(); i++)
      {
         if(PositionGetSymbol(i) == _Symbol && PositionGetInteger(POSITION_MAGIC) == m_magicNumber)
         {
            double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
            // Find which grid level this position corresponds to
            for(int j = 0; j < m_totalLines; j++)
            {
               double tolerance = (m_gridStepPoints * m_pointValue) * 0.1;
               if(MathAbs(openPrice - m_gridPrices[j]) <= tolerance)
               {
                  m_gridLevelTraded[j] = true;
                  Print("Existing position found at grid level: ", DoubleToString(m_gridPrices[j], 2));
                  break;
               }
            }
         }
      }
   }
   //+------------------------------------------------------------------+
   //| Update grid level status based on open positions                 |
   //+------------------------------------------------------------------+
   void UpdateGridLevelStatus()
   {
      // Reset all grid level status
      ArrayInitialize(m_gridLevelTraded, false);
      // Mark grid levels that have open positions
      for(int i = 0; i < PositionsTotal(); i++)
      {
         if(PositionGetSymbol(i) == _Symbol && PositionGetInteger(POSITION_MAGIC) == m_magicNumber)
         {
            double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
            // Find which grid level this position corresponds to
            for(int j = 0; j < m_totalLines; j++)
            {
               double tolerance = (m_gridStepPoints * m_pointValue) * 0.1;
               if(MathAbs(openPrice - m_gridPrices[j]) <= tolerance)
               {
                  m_gridLevelTraded[j] = true;
                  break;
               }
            }
         }
      }
   }
   //+------------------------------------------------------------------+
   //| Calculate grid prices based on points                            |
   //+------------------------------------------------------------------+
   void CalculateGridPrices()
   {
      // Calculate center line (start price)
      m_gridPrices[m_linesDown] = NormalizePrice(m_startPrice);
      // Calculate upward lines
      for(int i = 1; i <= m_linesUp; i++)
      {
         m_gridPrices[m_linesDown + i] = NormalizePrice(m_startPrice + (m_gridStepPoints * m_pointValue * i));
      }
      // Calculate downward lines
      for(int i = 1; i <= m_linesDown; i++)
      {
         m_gridPrices[m_linesDown - i] = NormalizePrice(m_startPrice - (m_gridStepPoints * m_pointValue * i));
      }
   }
   //+------------------------------------------------------------------+
   //| Normalize price to 2 decimal places for Gold                     |
   //+------------------------------------------------------------------+
   double NormalizePrice(double price)
   {
      return NormalizeDouble(price, 2);
   }
   //+------------------------------------------------------------------+
   //| Normalize volume according to symbol specifications              |
   //+------------------------------------------------------------------+
   double NormalizeVolume(double volume)
   {
      double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
      double minVolume = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
      double maxVolume = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
      volume = MathRound(volume / step) * step;
      volume = MathMax(volume, minVolume);
      volume = MathMin(volume, maxVolume);
      return volume;
   }
   //+------------------------------------------------------------------+
   //| Draw grid lines on chart                                         |
   //+------------------------------------------------------------------+
   void DrawGridLines()
   {
      DeleteObjects();
      if(!m_showGridLines) return;
      for(int i = 0; i < m_totalLines; i++)
      {
         string lineName = "GridLine_" + IntegerToString(i);
         color lineColor = m_gridColor;
         string text = "";
         // Center line (start price)
         if(i == m_linesDown)
         {
            lineColor = clrYellow;
            text = "Start: " + DoubleToString(m_gridPrices[i], 2);
         }
         // Buy signal lines (all lines)
         else
         {
            // Change color if this grid level already has a trade
            if(m_gridLevelTraded[i])
            {
               lineColor = clrGray;
               if(m_showTradedLabels)
                  text = "Traded: " + DoubleToString(m_gridPrices[i], 2);
            }
            else
            {
               lineColor = m_buySignalColor;
               text = "Buy: " + DoubleToString(m_gridPrices[i], 2);
            }
            // Add take profit line label for the line above
            if(i < m_totalLines - 1 && m_showTPLabels)
            {
               string tpText = "TP: " + DoubleToString(m_gridPrices[i+1], 2);
               CreateTextLabel(lineName + "_TP", m_gridPrices[i] + (m_gridStepPoints * m_pointValue * 0.1), m_takeProfitColor, tpText);
            }
         }
         CreateHorizontalLine(lineName, m_gridPrices[i], lineColor, text, i == m_linesDown);
      }
   }
   //+------------------------------------------------------------------+
   //| Create horizontal line object with label                         |
   //+------------------------------------------------------------------+
   void CreateHorizontalLine(string name, double price, color clr, string text = "", bool isCenter = false)
   {
      // Create the horizontal line
      ObjectCreate(0, name, OBJ_HLINE, 0, 0, price);
      ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
      ObjectSetInteger(0, name, OBJPROP_STYLE, isCenter ? STYLE_SOLID : STYLE_DASH);
      ObjectSetInteger(0, name, OBJPROP_WIDTH, isCenter ? 2 : 1);
      ObjectSetInteger(0, name, OBJPROP_BACK, true);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      // Create text label if provided
      if(text != "")
      {
         string labelName = name + "_Label";
         ObjectCreate(0, labelName, OBJ_TEXT, 0, TimeCurrent(), price);
         ObjectSetString(0, labelName, OBJPROP_TEXT, text);
         ObjectSetInteger(0, labelName, OBJPROP_COLOR, clr);
         ObjectSetInteger(0, labelName, OBJPROP_ANCHOR, ANCHOR_LEFT_UPPER);
         ObjectSetInteger(0, labelName, OBJPROP_BACK, true);
         ObjectSetInteger(0, labelName, OBJPROP_SELECTABLE, false);
         ObjectSetInteger(0, labelName, OBJPROP_FONTSIZE, m_gridLabelFontSize);
         // Make sure the label is visible
         ObjectSetInteger(0, labelName, OBJPROP_ZORDER, 0);
      }
   }
   //+------------------------------------------------------------------+
   //| Create text label                                                |
   //+------------------------------------------------------------------+
   void CreateTextLabel(string name, double price, color clr, string text)
   {
      ObjectCreate(0, name, OBJ_TEXT, 0, TimeCurrent(), price);
      ObjectSetString(0, name, OBJPROP_TEXT, text);
      ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, ANCHOR_LEFT_UPPER);
      ObjectSetInteger(0, name, OBJPROP_BACK, true);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, m_gridLabelFontSize);
      // Make sure the label is visible
      ObjectSetInteger(0, name, OBJPROP_ZORDER, 0);
   }
   //+------------------------------------------------------------------+
   //| Delete all objects                                               |
   //+------------------------------------------------------------------+
   void DeleteObjects()
   {
      for(int i = ObjectsTotal(0) - 1; i >= 0; i--)
      {
         string name = ObjectName(0, i);
         if(StringFind(name, "GridLine_") == 0 || StringFind(name, "TPLabel_") == 0)
         {
            ObjectDelete(0, name);
         }
      }
   }
   //+------------------------------------------------------------------+
   //| Check for trading signals                                        |
   //+------------------------------------------------------------------+
   void CheckForSignals()
   {
      double currentBid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
      // Check for buy signals at all grid lines
      for(int i = 0; i < m_totalLines; i++)
      {
         // Use a tolerance of 0.5% of the grid step
         double tolerance = (m_gridStepPoints * m_pointValue) * 0.005;
         if(MathAbs(currentBid - m_gridPrices[i]) <= tolerance)
         {
            // Check if this grid level already has an open trade
            if(!m_gridLevelTraded[i] && i < m_totalLines - 1)
            {
               if(m_autoTrading && (TimeCurrent() - m_lastTradeTime) > 60)
               {
                  // Take profit is the next grid line above
                  if(ExecuteBuyOrder(m_gridPrices[i], m_gridPrices[i + 1]))
                  {
                     // Mark this grid level as traded
                     m_gridLevelTraded[i] = true;
                     // Update the grid display
                     if(m_showGridLines) DrawGridLines();
                  }
               }
               if(m_enableAlerts)
               {
                  Alert("BUY SIGNAL at: ", DoubleToString(m_gridPrices[i], 2),
                        " | TP: ", DoubleToString(m_gridPrices[i + 1], 2),
                        " | Time: ", TimeToString(TimeCurrent()));
               }
               break;
            }
         }
      }
   }
   //+------------------------------------------------------------------+
   //| Execute buy order                                                |
   //+------------------------------------------------------------------+
   bool ExecuteBuyOrder(double entryPrice, double takeProfitPrice)
   {
      MqlTradeRequest request;
      MqlTradeResult result;
      ZeroMemory(request);
      ZeroMemory(result);
      takeProfitPrice = NormalizePrice(takeProfitPrice);
      entryPrice = NormalizePrice(entryPrice);
      // Calculate stop loss if enabled
      double stopLossPrice = 0.0;
      if(m_useStopLoss)
      {
         stopLossPrice = NormalizePrice(entryPrice - (m_stopLossPoints * m_pointValue));
      }
      // Normalize volume according to symbol specifications
      double volume = NormalizeVolume(m_lotSize);
      request.action = TRADE_ACTION_DEAL;
      request.symbol = _Symbol;
      request.volume = volume;
      request.type = ORDER_TYPE_BUY;  // Corrected: removed extra parenthesis
      request.price = NormalizePrice(SymbolInfoDouble(_Symbol, SYMBOL_ASK));
      request.sl = stopLossPrice; // Set stop loss if enabled, otherwise 0.0
      request.tp = takeProfitPrice;
      request.deviation = m_slippage;
      request.magic = m_magicNumber;
      request.comment = "Gold Grid Buy at " + DoubleToString(entryPrice, 2);
      if(OrderSend(request, result))
      {
         Print("Buy order executed. Ticket: ", result.order, 
               " Volume: ", DoubleToString(volume, 2), " lots (", DoubleToString(volume * m_contractSize, 2), " ounces)",
               " Price: ", DoubleToString(result.price, 2),
               " SL: ", m_useStopLoss ? DoubleToString(stopLossPrice, 2) : "None",
               " TP: ", DoubleToString(takeProfitPrice, 2));
         m_lastTradeTime = TimeCurrent();
         return true;
      }
      else
      {
         Print("Order send failed. Error: ", GetLastError());
         return false;
      }
   }
   //+------------------------------------------------------------------+
   //| Create information panel with tabular layout                     |
   //+------------------------------------------------------------------+
   void CreateInfoPanel()
   {
      if(!m_showInfoPanel) return;
      // Calculate line spacing based on font size
      int lineSpacing = m_panelFontSize + 5;
      // Background rectangle
      ObjectCreate(0, "InfoPanel_BG", OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_XDISTANCE, m_panelX);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_YDISTANCE, m_panelY);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_XSIZE, m_panelWidth);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_YSIZE, m_panelHeight);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_BGCOLOR, m_panelBackgroundColor);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_BORDER_TYPE, BORDER_FLAT);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_BORDER_COLOR, m_panelBorderColor);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_BACK, false);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, "InfoPanel_BG", OBJPROP_HIDDEN, true);
      // Calculate positions for tabular layout
      int labelX = m_panelX + 5;
      int valueX = m_panelX + m_panelWidth - 5;
      int startY = m_panelY + 5;
      // Create column headers
      CreateInfoLabel("LabelHeader", labelX, startY, "Parameter", m_panelTextColor, ANCHOR_LEFT_UPPER);
      CreateInfoLabel("ValueHeader", valueX, startY, "Value", m_panelTextColor, ANCHOR_RIGHT_UPPER);
      // Create separator line
      ObjectCreate(0, "SeparatorLine", OBJ_HLINE, 0, 0, 0);
      ObjectSetInteger(0, "SeparatorLine", OBJPROP_XDISTANCE, m_panelX);
      ObjectSetInteger(0, "SeparatorLine", OBJPROP_YDISTANCE, startY + lineSpacing - 2);
      ObjectSetInteger(0, "SeparatorLine", OBJPROP_XSIZE, m_panelWidth);
      ObjectSetInteger(0, "SeparatorLine", OBJPROP_COLOR, m_panelBorderColor);
      ObjectSetInteger(0, "SeparatorLine", OBJPROP_STYLE, STYLE_SOLID);
      ObjectSetInteger(0, "SeparatorLine", OBJPROP_BACK, false);
      ObjectSetInteger(0, "SeparatorLine", OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, "SeparatorLine", OBJPROP_HIDDEN, true);
      // Create static labels (left column)
      CreateInfoLabel("LotSize_Label", labelX, startY + lineSpacing, "Lot Size (lots)", m_panelTextColor, ANCHOR_LEFT_UPPER);
      CreateInfoLabel("OpenTrades_Label", labelX, startY + lineSpacing * 2, "Open Trades", m_panelTextColor, ANCHOR_LEFT_UPPER);
      if(m_showEquityInstead)
         CreateInfoLabel("Balance_Label", labelX, startY + lineSpacing * 3, "Equity", m_panelTextColor, ANCHOR_LEFT_UPPER);
      else
         CreateInfoLabel("Balance_Label", labelX, startY + lineSpacing * 3, "Balance", m_panelTextColor, ANCHOR_LEFT_UPPER);
      CreateInfoLabel("FreeMargin_Label", labelX, startY + lineSpacing * 4, "Free Margin", m_panelTextColor, ANCHOR_LEFT_UPPER);
      CreateInfoLabel("TotalProfit_Label", labelX, startY + lineSpacing * 5, "Total Profit", m_panelTextColor, ANCHOR_LEFT_UPPER);
      // Create dynamic value labels (right column)
      CreateInfoLabel("LotSize_Value", valueX, startY + lineSpacing, DoubleToString(m_lotSize, 2), m_panelValueColor, ANCHOR_RIGHT_UPPER);
      CreateInfoLabel("OpenTrades_Value", valueX, startY + lineSpacing * 2, "0", m_panelValueColor, ANCHOR_RIGHT_UPPER);
      CreateInfoLabel("Balance_Value", valueX, startY + lineSpacing * 3, DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE), 2), m_panelValueColor, ANCHOR_RIGHT_UPPER);
      CreateInfoLabel("FreeMargin_Value", valueX, startY + lineSpacing * 4, DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2), m_panelValueColor, ANCHOR_RIGHT_UPPER);
      CreateInfoLabel("TotalProfit_Value", valueX, startY + lineSpacing * 5, "0.00", m_panelValueColor, ANCHOR_RIGHT_UPPER);
   }
   //+------------------------------------------------------------------+
   //| Create info label with anchor option                             |
   //+------------------------------------------------------------------+
   void CreateInfoLabel(string name, int x, int y, string text, color clr, int anchor = ANCHOR_LEFT_UPPER)
   {
      ObjectCreate(0, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(0, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(0, name, OBJPROP_YDISTANCE, y);
      ObjectSetInteger(0, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetString(0, name, OBJPROP_TEXT, text);
      ObjectSetInteger(0, name, OBJPROP_COLOR, clr);
      ObjectSetInteger(0, name, OBJPROP_FONTSIZE, m_panelFontSize);
      ObjectSetInteger(0, name, OBJPROP_ANCHOR, anchor);
      ObjectSetInteger(0, name, OBJPROP_SELECTABLE, false);
      ObjectSetInteger(0, name, OBJPROP_HIDDEN, true);
   }
   //+------------------------------------------------------------------+
   //| Update information panel                                         |
   //+------------------------------------------------------------------+
   void UpdateInfoPanel()
   {
      if(!m_showInfoPanel) return;
      int openTrades = 0;
      double totalProfit = 0.0;
      // Count open trades and calculate total profit
      for(int i = 0; i < PositionsTotal(); i++)
      {
         if(PositionGetSymbol(i) == _Symbol && PositionGetInteger(POSITION_MAGIC) == m_magicNumber)
         {
            openTrades++;
            totalProfit += PositionGetDouble(POSITION_PROFIT);
         }
      }
      // Calculate equity if needed
      double balance = AccountInfoDouble(ACCOUNT_BALANCE);
      double equity = balance + totalProfit;
      // Update values
      ObjectSetString(0, "OpenTrades_Value", OBJPROP_TEXT, IntegerToString(openTrades));
      if(m_showEquityInstead)
         ObjectSetString(0, "Balance_Value", OBJPROP_TEXT, DoubleToString(equity, 2));
      else
         ObjectSetString(0, "Balance_Value", OBJPROP_TEXT, DoubleToString(balance, 2));
      ObjectSetString(0, "FreeMargin_Value", OBJPROP_TEXT, DoubleToString(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2));
      ObjectSetString(0, "TotalProfit_Value", OBJPROP_TEXT, DoubleToString(totalProfit, 2));
      // Color code profit (green/red)
      color profitColor = totalProfit >= 0 ? clrGreen : clrRed;
      ObjectSetInteger(0, "TotalProfit_Value", OBJPROP_COLOR, profitColor);
   }
   //+------------------------------------------------------------------+
   //| Delete information panel                                         |
   //+------------------------------------------------------------------+
   void DeleteInfoPanel()
   {
      string names[] = {
         "InfoPanel_BG", "SeparatorLine",
         "LabelHeader", "ValueHeader",
         "LotSize_Label", "OpenTrades_Label", "Balance_Label", "FreeMargin_Label", "TotalProfit_Label",
         "LotSize_Value", "OpenTrades_Value", "Balance_Value", "FreeMargin_Value", "TotalProfit_Value"
      };
      for(int i = 0; i < ArraySize(names); i++)
      {
         ObjectDelete(0, names[i]);
      }
   }
};
//+------------------------------------------------------------------+
//| Global expert object                                             |
//+------------------------------------------------------------------+
CGoldGridExpert Expert;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   CPro_Init();  // CPro营销模块初始化
   return Expert.Init();
}
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   Expert.Deinit(reason);
   CPro_Deinit();  // CPro营销模块清理
}
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
   Expert.OnTick();
}
//+------------------------------------------------------------------+
//| Chart event handler                                              |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,
                  const long &lparam,
                  const double &dparam,
                  const string &sparam)
{
   Expert.OnChartEvent(id, lparam, dparam, sparam);
}
//+-----------------------------------------------------------------+