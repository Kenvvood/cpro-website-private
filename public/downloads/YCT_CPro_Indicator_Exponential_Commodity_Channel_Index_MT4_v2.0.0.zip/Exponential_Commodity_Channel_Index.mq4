//+------------------------------------------------------------------+
//|                                         CPro Indicator Exponential_Commodity_Channel_Index MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//---------------------------------------------------------------------------------------------------------------------
//--- Setup
   // Define number of buffers and plots
      #define MPlots    1
      #define MBuffers  3
      #ifdef __MQL4__
      #else
      #endif
   // Display properties for plots
   // Display levels for plots
//--- Parameter settings
   input double                  i_dbAveragingPeriod     = 14;//均值加仓 周期
   input double                  i_dbAdjustmentConstant  = 0.015;          // Adjustment constant
   #ifdef __MQL4__
      input ENUM_APPLIED_PRICE   i_ePriceApplied         = PRICE_TYPICAL;//applied 价格
   #endif
//--- Macro definitions
   // Define OnCalculate loop sequencing macros
      #define MOnCalcPrevTest ( prev_calculated < 1 || prev_calculated > rates_total )
      #ifdef __MQL4__   // for MQL4 (as series)
         #define MOnCalcNext(  _index          ) ( _index--             )
         #define MOnCalcBack(  _index, _offset ) ( _index + _offset     )
         #define MOnCalcCheck( _index          ) ( _index >= 0          )
         #define MOnCalcValid( _index          ) ( _index < rates_total )
         #define MOnCalcStart \
            ( rates_total - ( MOnCalcPrevTest ? 1 : prev_calculated ) )
      #else             // for MQL5 (as non-series)
         #define MOnCalcNext(  _index          ) ( _index++             )
         #define MOnCalcBack(  _index, _offset ) ( _index - _offset     )
         #define MOnCalcCheck( _index          ) ( _index < rates_total )
         #define MOnCalcValid( _index          ) ( _index >= 0          )
         #define MOnCalcStart \
            ( prev_calculated > 0 ? prev_calculated - 1 : 0 )
      #endif
//--- Indicator name (used in plot label / indicator_labelX as macro)
      #define MName "Exponential Commodity Channel Index"
//--- Indicator buffers
   #ifdef __MQL4__
      double                     m_dblPrices[];
      double                     m_dblBuffer[];
      double                     m_dblBufferColor[];
   #else
      double                     m_dblPrices[];
      double                     m_dblBuffer[];
      double                     m_dblBufferColor[];
   #endif
//+------------------------------------------------------------------+
//| Custom indicator initialization function                          |
//+------------------------------------------------------------------+
int OnInit()
{
   #ifdef __MQL4__
      //--- MQL4: label is declared via #property (see below) and via PlotIndexSetString-equivalent fallback
      //--- Set plot label explicitly to avoid undeclared identifier at runtime
      string indicator_label1 = MName;
   #else
      //--- MQL5: use PlotIndexSetString
      PlotIndexSetString(0, PLOT_LABEL, MName);
      #define indicator_label1 MName
   #endif

   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                        |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   CPro_Deinit();
}

//+------------------------------------------------------------------+
//| Custom indicator iteration function                               |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   CPro_Init();
   return(rates_total);
}