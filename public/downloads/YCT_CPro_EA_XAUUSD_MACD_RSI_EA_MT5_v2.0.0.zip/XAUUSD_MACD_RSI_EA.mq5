//+------------------------------------------------------------------+
//|                                         CPro EA XAUUSD_MACD_RSI_EA MT5                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


// Trading Parameters
input double FixedLotSize = 0.1;//fixed 交易量 尺寸
input int StopLossPips = 50;//停止 亏损 in 点值s
input int TakeProfitPips = 100;//take 利润 in 点值s
input int MagicNumber = 201125;//ea 魔术号码
// MACD Parameters
input int FastMA = 12;//快速 moving 均值
input int SlowMA = 26;//止损ow moving 均值
input int SignalMA = 9;//信号 line 均线
input ENUM_APPLIED_PRICE MacdPrice = PRICE_CLOSE;//均线cd applied 价格
// RSI Parameters
input int RSIPeriod = 14;//RSI 周期
input ENUM_APPLIED_PRICE RsiPrice = PRICE_CLOSE;//RSI指标 applied 价格
// Indicator handles
int macdHandle;
int rsiHandle;
//+------------------------------------------------------------------+
void OnInit()
{
    // Create MACD indicator
   CPro_Init();  // CPro营销模块初始化
    macdHandle = iMACD(Symbol(), Period(), FastMA, SlowMA, SignalMA, MacdPrice);
    if(macdHandle == INVALID_HANDLE)
    {
        Print("Failed to create MACD handle");
        return;
    }
    // Create RSI indicator
    rsiHandle = iRSI(Symbol(), Period(), RSIPeriod, RsiPrice);
    if(rsiHandle == INVALID_HANDLE)
    {
        Print("Failed to create RSI handle");
        return;
    }
    Print("XAUUSD MACD RSI Bot Started Successfully");
}
//+------------------------------------------------------------------+
void OnTick()
{
    // Get MACD values
    double macdMain[2];
    double macdSignal[2];
    if(CopyBuffer(macdHandle, 0, 0, 2, macdMain) < 0 || 
       CopyBuffer(macdHandle, 1, 0, 2, macdSignal) < 0)
    {
        Print("Error copying MACD data");
        return;
    }
    // Get RSI value
    double rsiValue[2];
    if(CopyBuffer(rsiHandle, 0, 0, 2, rsiValue) < 0)
    {
        Print("Error copying RSI data");
        return;
    }
    // Get current price information
    double ask = SymbolInfoDouble(Symbol(), SYMBOL_ASK);
    double bid = SymbolInfoDouble(Symbol(), SYMBOL_BID);
    // Only one trade at a time
    if(CountOrders() > 0) return;
    // BUY SIGNAL: MACD crosses above signal line
    if(macdMain[1] <= macdSignal[1] && macdMain[0] > macdSignal[0] && rsiValue[0] < 50)
    {
        OpenBuyOrder(ask, bid, FixedLotSize);
    }
    // SELL SIGNAL: MACD crosses below signal line
    if(macdMain[1] >= macdSignal[1] && macdMain[0] < macdSignal[0] && rsiValue[0] > 50)
    {
        OpenSellOrder(ask, bid, FixedLotSize);
    }
}
//+------------------------------------------------------------------+
int CountOrders()
{
    int count = 0;
    for(int i = PositionsTotal() - 1; i >= 0; i--)
    {
        if(PositionSelectByTicket(PositionGetTicket(i)))
        {
            if(PositionGetInteger(POSITION_MAGIC) == MagicNumber && 
               PositionGetString(POSITION_SYMBOL) == Symbol())
                count++;
        }
    }
    return count;
}
//+------------------------------------------------------------------+
void OpenBuyOrder(double ask, double bid, double volume)
{
    double sl = bid - (StopLossPips * Point());
    double tp = ask + (TakeProfitPips * Point());
    MqlTradeRequest request = {};
    request.action = TRADE_ACTION_DEAL;
    request.symbol = Symbol();
    request.volume = volume;
    request.type = ORDER_TYPE_BUY;
    request.price = ask;
    request.sl = sl;
    request.tp = tp;
    request.magic = MagicNumber;
    request.comment = "XAUUSD MACD RSI Buy";
    MqlTradeResult result = {};
    if(OrderSend(request, result))
    {
        Print("Buy order opened. Ticket: ", result.order, " Price: ", ask);
    }
    else
    {
        Print("Buy order failed. Error: ", GetLastError());
    }
}
//+------------------------------------------------------------------+
void OpenSellOrder(double ask, double bid, double volume)
{
    double sl = ask + (StopLossPips * Point());
    double tp = bid - (TakeProfitPips * Point());
    MqlTradeRequest request = {};
    request.action = TRADE_ACTION_DEAL;
    request.symbol = Symbol();
    request.volume = volume;
    request.type = ORDER_TYPE_SELL;
    request.price = bid;
    request.sl = sl;
    request.tp = tp;
    request.magic = MagicNumber;
    request.comment = "XAUUSD MACD RSI Sell";
    MqlTradeResult result = {};
    if(OrderSend(request, result))
    {
        Print("Sell order opened. Ticket: ", result.order, " Price: ", bid);
    }
    else
    {
        Print("Sell order failed. Error: ", GetLastError());
    }
}
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   CPro_Deinit();  // CPro营销模块清理
    // Release indicator handles
    if(macdHandle != INVALID_HANDLE)
        IndicatorRelease(macdHandle);
    if(rsiHandle != INVALID_HANDLE)
        IndicatorRelease(rsiHandle);
    Print("XAUUSD MACD RSI Bot Stopped");
}
//+------------------------------------------------------------------+