//+------------------------------------------------------------------+
//|                                         CPro Tool TlgBot MT5                             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include "Reciber.mqh"

//+------------------------------------------------------------------+
//| Include                                                          |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
input long InpChartIdPadre = -1;
input double InpKey = 0.00;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
#resource "sys_prompt.txt" as const string g_system_prompt
//+------------------------------------------------------------------+
//| Global variables                                                 |
//+------------------------------------------------------------------+
CChatTelegramBaseFully bot(g_system_prompt);
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
 {
//--- create timer
   CPro_Init();  // CPro营销模块初始化
  if(!bot.Init(InpChartIdPadre, InpKey))
   {
    FastLog(FUNCION_ACTUAL, FATAL_ERROR_TEXT, "Fallo al setear parametros");
    return INIT_PARAMETERS_INCORRECT;
   }
//---
//f(bot.GetMe() != 0)
// {
//  Print("Fallo");
//  return INIT_PARAMETERS_INCORRECT;
// }
//---
  EventSetTimer(1);
//---
  return(INIT_SUCCEEDED);
 }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
 {
   CPro_Deinit();  // CPro营销模块清理
//--- destroy timer
  EventKillTimer();
 }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
 {
//---
 }
//+------------------------------------------------------------------+
//| Timer function                                                   |
//+------------------------------------------------------------------+
void OnTimer()
 {
  bot.OnTimerEvent();
 }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnChartEvent(const int32_t id, const long& lparam, const double& dparam, const string& sparam)
 {
  bot.ChartEvent(id, lparam, dparam, sparam);
 }
//+------------------------------------------------------------------+