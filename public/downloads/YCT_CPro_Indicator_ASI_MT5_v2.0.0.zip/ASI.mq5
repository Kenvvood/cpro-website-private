//+------------------------------------------------------------------+
//|                                         CPro Indicator ASI MT5                           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- input parameter
input double InpT=300.0;//t (均线ximum 价格 changing)
//--- indicator buffers
double       ExtASIBuffer[];
double       ExtSIBuffer[];
double       ExtTRBuffer[];
double       ExtTpoints,ExtT;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
void OnInit()
  {
//--- check for input value
   CPro_Init();  // CPro营销模块初始化
   if(MathAbs(InpT)>1e-7)
      ExtT=InpT;
   else
     {
      ExtT=300.0;
      PrintFormat("Input parameter T has wrong value. Indicator will use T = %f.",ExtT);
     }
//--- define buffers
   SetIndexBuffer(0,ExtASIBuffer);
   SetIndexBuffer(1,ExtSIBuffer,INDICATOR_CALCULATIONS);
   SetIndexBuffer(2,ExtTRBuffer,INDICATOR_CALCULATIONS);
//--- draw begin settings
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,1);
//--- number of digits of indicator value
   IndicatorSetInteger(INDICATOR_DIGITS,2);
//--- calculate ExtTpoints value
   if(_Point>1e-7)
      ExtTpoints=ExtT*_Point;
   else
      ExtTpoints=ExtT*MathPow(10,-_Digits);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(rates_total<2)
      return(0);
//--- start calculation
   int pos=prev_calculated-1;
//--- correct position, when it's first iteration
   if(pos<=0)
     {
      pos=1;
      ExtASIBuffer[0]=0.0;
      ExtSIBuffer[0]=0.0;
      ExtTRBuffer[0]=high[0]-low[0];
     }
//--- main cycle
   for(int i=pos; i<rates_total && !IsStopped(); i++)
     {
      //--- get some data
      double dPrevClose=close[i-1];
      double dPrevOpen=open[i-1];
      double dClose=close[i];
      double dHigh=high[i];
      double dLow=low[i];
      //--- fill TR buffer
      ExtTRBuffer[i]=MathMax(dHigh,dPrevClose)-MathMin(dLow,dPrevClose);
      double ER=0.0;
      if(!(dPrevClose>=dLow && dPrevClose<=dHigh))
        {
         if(dPrevClose>dHigh)
            ER=MathAbs(dHigh-dPrevClose);
         if(dPrevClose<dLow)
            ER=MathAbs(dLow-dPrevClose);
        }
      double K=MathMax(MathAbs(dHigh-dPrevClose),MathAbs(dLow-dPrevClose));
      double SH=MathAbs(dPrevClose-dPrevOpen);
      double R=ExtTRBuffer[i]-0.5*ER+0.25*SH;
      //--- calculate SI value
      if(R==0.0 || ExtTpoints==0.0)
         ExtSIBuffer[i]=0.0;
      else
         ExtSIBuffer[i]=50*(dClose-dPrevClose+0.5*(dClose-open[i])+0.25*(dPrevClose-dPrevOpen))*(K/ExtTpoints)/R;
      //--- write down ASI buffer value
      ExtASIBuffer[i]=ExtASIBuffer[i-1]+ExtSIBuffer[i];
     }
//--- OnCalculate done. Return new prev_calculated.
   return(rates_total);
  }
//+------------------------------------------------------------------+