//+------------------------------------------------------------------+
//|                                         CPro Tool SimpleTrade MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int stop = 120;
extern double lots = 1;
int slippage = 3;
datetime curTime;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
if((Time[0]!=curTime))
{   
   curTime=Time[0];
   if(OrdersTotal()==0)
   {
     if(Open[0]>Open[3])  OrderSend(Symbol(),OP_BUY,lots,Ask,slippage,Ask-stop*Point,0);    
     if(Open[0]<=Open[3])   OrderSend(Symbol(),OP_SELL,lots,Bid,slippage,Bid+stop*Point,0); 
   }
   else
   {
     OrderSelect(0,SELECT_BY_POS);
     if(OrderType()==OP_BUY)
       OrderClose(OrderTicket(),OrderLots(),Bid,3);
     if(OrderType()==OP_SELL)
       OrderClose(OrderTicket(),OrderLots(),Ask,3);
     if(Open[0]>Open[3])  OrderSend(Symbol(),OP_BUY,lots,Ask,slippage,Ask-stop*Point,0);    
     if(Open[0]<=Open[3])   OrderSend(Symbol(),OP_SELL,lots,Bid,slippage,Bid+stop*Point,0); 
   }
}
//----
   return(0);
  }
//+------------------------------------------------------------------+