//+------------------------------------------------------------------+
//|                                         CPro Tool ordermanager MT4                       |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern bool ManageAllSymbol = false;
extern bool UseStopLoss = true;
extern double StopLossPercent = 0.02;
extern bool UseTakeProfit = true;
extern double TakeProfitPercent = 0.06;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   EventSetTimer(1);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
   EventKillTimer();
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---      
  }
//+------------------------------------------------------------------+
void OnTimer()
{
   if(!IsTradeAllowed()) return;
   double profit;   
   double percent ,risk;
   bool reponse = false;
   int cmd = 0;
   double price;
   for(int i = OrdersTotal()-1; i>=0; i--)
   {
      if( OrderSelect( i, SELECT_BY_POS, MODE_TRADES ) == false ) break;
      if(!ManageAllSymbol && OrderSymbol()!= Symbol())break;
      RefreshRates();
      profit = OrderProfit();
      cmd = OrderType();
      bool close = false;
      price = (cmd == OP_BUY) ? MarketInfo(OrderSymbol(),MODE_ASK) : MarketInfo(OrderSymbol(),MODE_BID);
      if(profit < 0)
      {
         double tempProfit =  MathAbs(profit);
         risk = tempProfit / AccountBalance();
         if(UseStopLoss && risk > StopLossPercent)
         {
            close = true;
         }
      }
      else if(profit > 0)
      {
         risk = profit / AccountBalance();
         if(UseTakeProfit && risk >= TakeProfitPercent)
         {
            close = true;   
         }
      }
      if(close) reponse = OrderClose(OrderTicket(),OrderLots(),price,3,0);
   }
}