//+------------------------------------------------------------------+
//|                                         CPro Tool Wipeout MT4                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern string    Product="Wipeout v1";
extern double    CloseAllWhenProfitIs=300;
extern int       Slippage=5;
extern string    MoreAvailableAt="www.FxAutomated.com";
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int start()
  {
//----
int StopMultd;
 int digits=MarketInfo("EURUSD",MODE_DIGITS);
if(digits==5){StopMultd=10;} else{StopMultd=1;}
int Slip=Slippage*StopMultd;
double CurrentProfit=NormalizeDouble(AccountEquity()-AccountBalance(),Digits);
if(CurrentProfit>=CloseAllWhenProfitIs){ // start check
 if(OrdersTotal()>0){
  for(int i=1; i<=OrdersTotal(); i++)          // Cycle searching in orders
     {
      if (OrderSelect(i-1,SELECT_BY_POS)==true) // If the next is available
        {
           if(OrderType()==OP_BUY){OrderClose(OrderTicket(),OrderLots(),Bid,Slip,CLR_NONE);}
           if(OrderType()==OP_SELL){OrderClose(OrderTicket(),OrderLots(),Ask,Slip,CLR_NONE);}
           int Error=GetLastError();
           if(Error>0){
           if(Error==2){Alert("Common error.");}
           if(Error==146){Alert("Trading subsystem is busy. Retrying."); Sleep(500); RefreshRates();}
           }
        }
     }
 }
}// start check   
//----
   return(0);
  }
//+------------------------------------------------------------------+