//+------------------------------------------------------------------+
//|                                         CPro Tool firstfriday MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

datetime lastTime = 0; // Variable to store the time of the last detected candle
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   lastTime = iTime(Symbol(),PERIOD_D1,0);
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
   datetime currentTime = iTime(NULL, PERIOD_D1, 0); // Get the time of the current candle
   if(IsFirstFriday() && currentTime != lastTime)
     {
      Print("This is Friday of The First Week of The Month");
      lastTime = currentTime; // Update the lastTime to the current candle time
     }
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool IsFirstFriday()
  {
// Get the current day of the week (0=Sunday, 1=Monday, ..., 5=Friday, 6=Saturday)
   int dayOfWeek = TimeDayOfWeek(TimeCurrent());
// Get the current day of the month
   int dayOfMonth = TimeDay(TimeCurrent());
// Check if today is Friday
   if(dayOfWeek == 5)
     {
      // Check if the day of the month is between 1 and 7
      if(dayOfMonth >= 1 && dayOfMonth <= 7)
        {
         return(true);
        }
     }
   return(false);
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+