//+------------------------------------------------------------------+
//|                                         CPro Tool MacdPatternTraderv01 MT4               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

/*
Original description strategies:
http://www.unfx.ru/strategies_to_trade/strategies_134.php
         10 , 
         : letters@fortrader.ru
http://www.fortrader.ru/arhiv.php
A detailed description of the parameters adviser available issue of the journal dated Iune 10, 
suggestions and feedback we will be glad to see in our e-mail: letters@fortrader.ru
http://www.fortrader.ru/arhiv.php
Looking for an interpreter for the English version of the magazine on partnership.
*/
extern int stoplossbars = 6;
extern int takeprofitbars = 20;
extern int otstup = 10; 
extern int lowema=5;
extern int fastema=13;
extern double maxur=0.0045;
extern double minur=-0.0045;
extern string x=" MA:";
extern  int perema1=7;
extern  int perema2=21;
extern  int persma3=98;
extern  int perema4=365;
extern double Lots=1;
int buy,sell;int nummodb,nummods;int flaglot;
int start()
  {   
      AOPattern(lowema,fastema,maxur,minur);
      ActivePosManager(perema1,perema2,persma3,perema4);
   return(0);
  }
int aop_maxur,aop_minur,aop_oksell,aop_okbuy;
int AOPattern(double FastEMA,double SlowEMA,double maxur,double minur)
{
   // 
   double macdcurr =iMACD(NULL,0,FastEMA,SlowEMA,1,PRICE_CLOSE,MODE_MAIN,1);
   double macdlast =iMACD(NULL,0,FastEMA,SlowEMA,1,PRICE_CLOSE,MODE_MAIN,2);
   double macdlast3 =iMACD(NULL,0,FastEMA,SlowEMA,1,PRICE_CLOSE,MODE_MAIN,3);
   if(macdcurr>maxur){aop_maxur=1;}
   if(macdcurr<0){aop_maxur=0;}
   if(macdcurr<maxur && macdcurr<macdlast && macdlast>macdlast3 && aop_maxur==1 && macdcurr>0 && macdlast3<maxur)
   { 
   aop_oksell=1;
   }
   if(aop_oksell==1 )
   {
      OrderSend(Symbol(),OP_SELL,Lots,Bid,3,StopLoss(0),TakeProfit(0),"FORTRADER.RU",16385,0,Red);
      aop_oksell=0;
      aop_maxur=0;
      nummods=0;
      flaglot=0;
   }
   if(macdcurr<minur){aop_minur=1;}
   if(macdcurr>0){aop_minur=0;}
   if(macdcurr>minur && macdcurr<0 && macdcurr>macdlast && macdlast<macdlast3 && aop_minur==1 && macdlast3>minur )
   { 
   aop_okbuy=1;
   }
   if(aop_okbuy==1 )
   {
       OrderSend(Symbol(),OP_BUY,Lots,Ask,3,StopLoss(1),TakeProfit(1),"FORTRADER.RU",16385,0,Red);
      aop_okbuy=0;
      aop_minur=0;
      nummodb=0;
      flaglot=0;
   }
}
double StopLoss(int type)
{double stoploss;
if(type==0)
{
  stoploss=High[iHighest(NULL,0,MODE_HIGH,stoplossbars,1)]+otstup*Point;
 return(stoploss);
}
if(type==1)
{
  stoploss=Low[iLowest(NULL,0,MODE_LOW,stoplossbars,1)]-otstup*Point;
 return(stoploss);
}
}
double TakeProfit(int type)
{ int x=0,stop=0;double takeprofit;
  if(type==0)
   {
   while(stop==0)
         {
           takeprofit =Low[iLowest(NULL,0,MODE_LOW,takeprofitbars,x)];
          if(takeprofit>Low[iLowest(NULL,0,MODE_LOW,takeprofitbars,x+takeprofitbars)])
            {
            takeprofit =Low[iLowest(NULL,0,MODE_LOW,takeprofitbars,x+takeprofitbars)];
            x=x+takeprofitbars;
            }
          else
            {
             stop=1;return(takeprofit);
            }
         }
   }
   if(type==1)
   {
   while(stop==0)
         {
           takeprofit =High[iHighest(NULL,0,MODE_HIGH,takeprofitbars,x)];
          if(takeprofit<High[iHighest(NULL,0,MODE_HIGH,takeprofitbars,x+takeprofitbars)])
            {
            takeprofit =High[iHighest(NULL,0,MODE_HIGH,takeprofitbars,x+takeprofitbars)];
            x=x+takeprofitbars;
            }
          else
            {
             stop=1;return(takeprofit);
            }
         }
   }
}
int  ActivePosManager(int perema1, int perema2, int persma3, int perema4)
{
   double ema1 =iMA(NULL,0,perema1,0,MODE_EMA,PRICE_CLOSE,1);
    double ema2 =iMA(NULL,0,perema2,0,MODE_EMA,PRICE_CLOSE,1);
     double sma1 =iMA(NULL,0,persma3,0,MODE_SMA,PRICE_CLOSE,1);
      double ema3 =iMA(NULL,0,perema4,0,MODE_EMA,PRICE_CLOSE,1);
   for( int i=0;i<OrdersTotal();i++)
      {
              OrderSelect(i, SELECT_BY_POS, MODE_TRADES);
              if(OrderType()==OP_BUY && OrderProfit()>5 && Close[1]>ema2 && nummodb==0)
              {  
                 OrderClose(OrderTicket(),NormalizeDouble(OrderLots()/3,2),Bid,3,Violet); 
                 nummodb++;
              }
                 if(OrderType()==OP_BUY && OrderProfit()>5 && High[1]>(sma1+ema3)/2 && nummodb==1)
              {  
                 OrderClose(OrderTicket(),NormalizeDouble(OrderLots()/2,2),Bid,3,Violet); 
                 nummodb++;
              }
                if(OrderType()==OP_SELL && OrderProfit()>5 && Close[1]<ema2 && nummods==0)
              {  
                 OrderClose(OrderTicket(),NormalizeDouble(OrderLots()/3,2),Ask,3,Violet); 
                 nummods++;
              }
                   if(OrderType()==OP_SELL && OrderProfit()>5 && Low[1]<(sma1+ema3)/2 && nummods==1)
              {  
                 OrderClose(OrderTicket(),NormalizeDouble(OrderLots()/2,2),Ask,3,Violet); 
                 nummods++;
              }
      }
}