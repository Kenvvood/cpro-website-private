//+------------------------------------------------------------------+
//|                                         CPro Tool RAVIiAO MT4                            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int       per1=12;
extern int       per2=72;
extern double       uroven=0.3;
extern int tp=50;
extern int sl=50;
extern double lot=0.1;
double q1,q2,slb,sls,tpb,tps,ac1,ac2,ac0;
bool New_Bar;
int kup, prod, order;
int start()
  {
if (OrdersTotal()==1)
return;
New_Bar=false ;
Fun_New_Bar();  //                                                
if (New_Bar==false) 
return;
//___________________________________________________________________
q1= iCustom (NULL,0,"Ravi",per1,per2,0,1) ; 
q2= iCustom (NULL,0,"Ravi",per1,per2,0,2) ; 
ac1=iAC(NULL, 0 ,1);
ac2 =iAC(NULL, 0 ,2);
ac0 =iAC(NULL, 0 ,0);
//____________________________________________________________________
slb=Bid-sl*Point ; sls=Ask+sl*Point; tpb= Bid+tp*Point; tps= Ask-tp*Point;
//____________________________________________________________________
if   (   ac1>ac2 && ac2>0 && q1>q2 && q1> uroven )                                    
   {
       order =  OrderSend ( Symbol(), 0, lot, Ask, 3,slb,tpb );
   }
if (  ac1<ac2 && ac2<0 &&  q1<q2 && q1< -uroven   )                                      
   {
       order =  OrderSend ( Symbol(), 1, lot, Bid, 3,sls,tps);
   }
   return(0);
  }
//+------------------------------------------------------------------+
void Fun_New_Bar()
{
 static datetime New_Time=0;
 New_Bar=false;
 if(New_Time!=Time[0])
       {
        New_Time=Time[0];
        New_Bar=true; 
       }
}
//______________________________________________________