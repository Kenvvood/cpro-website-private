//+------------------------------------------------------------------+
//|                                         CPro Indicator LinearRegressionCandles MT5       |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input int LrLen = 11; // Linear Regression Length
input int SmaLen = 7;//信号 length
double B1[];
double B2[];
double B3[];
double B4[];
double C[];
double S[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, B1, INDICATOR_DATA);
    SetIndexBuffer(1, B2, INDICATOR_DATA);
    SetIndexBuffer(2, B3, INDICATOR_DATA);
    SetIndexBuffer(3, B4, INDICATOR_DATA);
    SetIndexBuffer(4, C, INDICATOR_COLOR_INDEX);
    SetIndexBuffer(5, S, INDICATOR_DATA);
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    int limit = rates_total - prev_calculated;
    if (prev_calculated == 0) {
        ArrayInitialize(B1, 0);
        ArrayInitialize(B2, 0);
        ArrayInitialize(B3, 0);
        ArrayInitialize(B4, 0);
        ArrayInitialize(C, 0);
        ArrayInitialize(S, 0);
        limit = rates_total - MathMax(LrLen, SmaLen) - 1;
    }
    if (rates_total <= MathMax(LrLen, SmaLen) + 1) return(0);
    ArraySetAsSeries(open, true);
    ArraySetAsSeries(high, true);
    ArraySetAsSeries(low, true);
    ArraySetAsSeries(close, true);
    ArraySetAsSeries(B1, true);
    ArraySetAsSeries(B2, true);
    ArraySetAsSeries(B3, true);
    ArraySetAsSeries(B4, true);
    ArraySetAsSeries(C, true);
    ArraySetAsSeries(S, true);
    for (int i = limit; i >= 0 && !IsStopped(); i--) {
        B1[i] = LRMA(i, LrLen, open);
        B2[i] = LRMA(i, LrLen, high);
        B3[i] = LRMA(i, LrLen, low);
        B4[i] = LRMA(i, LrLen, close);
        C[i] = B4[i] < B1[i] ? 0 : 1;
    }
    for (int i = limit; i >= 0 && !IsStopped(); i--) {
        double sum = 0;
        for (int j = i; j < i + SmaLen; j++)
            sum += B4[j];
        S[i] = sum / SmaLen;
    }
    return(rates_total);
}
//+------------------------------------------------------------------+
//| Calculate LRMA                                                   |
//+------------------------------------------------------------------+
double LRMA(const int pos, const int period, const double &price[]) {
    double res = 0;
    double tmpS = 0, tmpW = 0, wsum = 0;;
    for (int i = 0; i < period; i++) {
        tmpS += price[pos + i];
        tmpW += price[pos + i] * (period - i);
        wsum += (period - i);
    }
    tmpS /= period;
    tmpW /= wsum;
    res = 3.0 * tmpW - 2.0 * tmpS;
    return res;
}
//+------------------------------------------------------------------+