//+------------------------------------------------------------------+
//|                                         CPro Tool risk MT4                               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern double risk = 10;
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
   int trade, cnt, cnt2, ticket;
   int total=OrdersTotal();
   double OpenLots=0;
//----
    for(cnt=0;cnt<total;cnt++)
     {
      OrderSelect(cnt,SELECT_BY_POS,MODE_TRADES);
      if(OrderType()==OP_SELL || OrderType()==OP_BUY)
        {
         OpenLots += OrderLots();
        }
     }
//----
   double Lots=NormalizeDouble(AccountBalance()/1000,1);
   double raznica = MathMod(Lots,MarketInfo(Symbol(),MODE_LOTSTEP));
   if(raznica>0.1){Lots-=raznica;}
   double Lots2=NormalizeDouble(Lots*risk/100.0,1);
   if(raznica>0.1){Lots2-=raznica;}
   double Lots3=MathAbs(Lots2)-MathAbs(OpenLots);
   if(Lots3<0 && Lots3>(raznica*(-1))){Lots3=0;}
   int i,ks;
   double op,ou;
   for(i=0;i<HistoryTotal();i++)
     {
      if(OrderSelect(i,SELECT_BY_POS,MODE_HISTORY))
        {
         if(OrderType()==OP_BUY || OrderType()==OP_SELL)
           {
            if(OrderProfit()>0)
              {
               op+=OrderProfit();
              }
               else
              {
               ou+=OrderProfit();
              }
            op+=OrderSwap();
            ks++;
           }
        }
     }
   double totalprofit=NormalizeDouble(op+ou,2);
   double totalprofitpersent=NormalizeDouble(100/(AccountBalance()-totalprofit)*totalprofit,2);
   Comment(": ",Lots,"   : ",Lots2,"   : ",OpenLots,"    : ",Lots3,"\n",": ",risk,"%   : ",AccountProfit()," (",NormalizeDouble(100/AccountBalance()*AccountProfit(),2),"%)    : ",totalprofit," (",totalprofitpersent,"%)");
   return(0);
  }
//+------------------------------------------------------------------+