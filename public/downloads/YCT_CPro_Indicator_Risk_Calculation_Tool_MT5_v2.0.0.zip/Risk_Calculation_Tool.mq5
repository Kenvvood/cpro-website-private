//+------------------------------------------------------------------+
//|                                         CPro Indicator Risk_Calculation_Tool MT5         |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


enum PositionType{
    buy, // Buy
    sell // Sell
};
input double lotSize = 1.0;//交易 交易量 (交易量 尺寸)
input PositionType posType = buy;//持仓 类型
double virtSL[];
double balance;
double maxLoss;
double bid, ask;
double BidAsk;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0, virtSL, INDICATOR_DATA);
   bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);  
   ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   balance = AccountInfoDouble(ACCOUNT_BALANCE);   
   ArraySetAsSeries(virtSL, true);
   Comment("Click on the chart at the desired stop loss level...");
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   balance = AccountInfoDouble(ACCOUNT_BALANCE); // updated now on every recalculation
   bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   posType == buy ? BidAsk = ask : bid;
   return(rates_total);
  }
void OnChartEvent(const int id,
                  const long &lparam,
                  const double &dparam,
                  const string &sparam){                
   if (id == CHARTEVENT_CLICK){
         int all_bars = Bars(_Symbol, _Period);
         for(int x = 10; x >= 0; x--){
            virtSL[x] = GetMouseY(dparam);  
         }     
         for(int x = 11; x < all_bars; x++){
            virtSL[x] = EMPTY_VALUE;  
         }     
         double virtualStopLossPoints = MathAbs(BidAsk - GetMouseY(dparam))/_Point;
         maxLoss = MaxLossCalc(lotSize, virtualStopLossPoints);    
         string calculation = 
         ".:: Position Risk Calculator ::."
         + "\n\n"
         + "Lot size: " + DoubleToString(lotSize, 2)
         + "\n"
         + "Stop loss points: " + DoubleToString(virtualStopLossPoints, 2)
         + "\n\n"
         + "Risking:"
         + "\n"
         + DoubleToString(virtualStopLossPoints > 0 ? maxLoss : balance, 2) + " " 
         + AccountInfoString(ACCOUNT_CURRENCY) + " "
         + "(" + DoubleToString(virtualStopLossPoints > 0 ? (maxLoss/balance) * 100 : 100, 2) + "%" + ")";
         Comment(calculation);             
         ChartNavigate(0, CHART_END);      
    }
}
double GetMouseY(const double &dparam){
        long chartHeightInPixels = ChartGetInteger(0, CHART_HEIGHT_IN_PIXELS);
        double priceRange = ChartGetDouble(0, CHART_PRICE_MAX) - ChartGetDouble(0, CHART_PRICE_MIN);
        double pixelsPerPrice = chartHeightInPixels / priceRange;
        double mouseYValue = ChartGetDouble(0, CHART_PRICE_MAX) - dparam / pixelsPerPrice;
        return mouseYValue;
}
//+------------------------------------------------------------------+
//|     Calculating monetary risk based on lot size and stop loss    |
//|                                                                  |
//+------------------------------------------------------------------+
double MaxLossCalc(double lot, double sl_points) {
   // Get tick value for the current symbol (value per pip in the account currency per 1 lot)
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double stopLossValue = sl_points * tickValue;
   maxLoss = lot * stopLossValue;
   return maxLoss;  // Return the max loss in monetary terms
}
void OnDeinit(const int reason){
   Comment("");
   CPro_Deinit();  // CPro营销模块清理
}