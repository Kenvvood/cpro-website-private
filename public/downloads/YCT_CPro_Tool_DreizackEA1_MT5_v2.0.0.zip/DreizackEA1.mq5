//+------------------------------------------------------------------+
//|                                         CPro Tool DreizackEA1 MT5                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//+------------------------------------------------------------------+
//| Inputs                               |
//+------------------------------------------------------------------+
input group "=== General Settings ==="
static input long InpMagicnumber = 123145;        //magic number
static input double InpLotSize     = 0.01;        // lot size
input ENUM_TIMEFRAMES InpTimeframe = PERIOD_M5;//时间框架
input int InpTakeProfit = 400;//take 利润 in 点数 0=off
input int InpStopLoss = 200;//停止 亏损   in 点数 0=off
input int InpTradingTimeStart = 8;//交易时段 time 开始
input int InpTradingTimeStop = 16;//交易时段 time 停止
input group "=== Indicator Settings ==="
input int InpSlowEMA = 100;//止损ow ema 周期
input int InpMidEMA  = 50;//mid ema 周期
input int InpFastEMA = 25;//快速 ema 周期
input int InpTriggerPeriod = 5;//均线x candle between 信号 and trigger
input int InpDistance = 20;//difference between e均线s
int OnInit(){
   CPro_Init();  // CPro营销模块初始化
   if(!CheckInputs()){return INIT_PARAMETERS_INCORRECT;}
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
  }
bool CheckInputs(){
   if(InpMagicnumber<=0){
      Alert("wrong input: magicnumber <= 0");
      return false;
   }
   if(InpLotSize<=0){
      Alert("wrong input: lot size <= 0");
      return false;
   }
   if(InpStopLoss<0){
      Alert("wrong input: stoploss < 0");
      return false;
   }
   if(InpTakeProfit<0){
      Alert("wrong input: take profit < 0");
      return false;
   }
   if(InpTradingTimeStart<0 && InpTradingTimeStart > 24 ){
      Alert("wrong input: time start < 0 and >24");
      return false;
   }
   if(InpTradingTimeStop<0 && InpTradingTimeStart > 24){
      Alert("wrong input: time start < 0 and >24");
      return false;
   }
   return true;
}