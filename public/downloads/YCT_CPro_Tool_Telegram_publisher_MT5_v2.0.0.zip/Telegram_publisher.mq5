//+------------------------------------------------------------------+
//|                                         CPro Tool Telegram_publisher MT5                 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


string botToken = "1072805610:AAEUeJJZ-mMr_7-2erUOuC6MVuyC1Fdr6QE";
string channelName = "Trading Signals"; // Channel or Group name
datetime start_time;
datetime previous_date;
input int height = 768;//[高度 of the snapshot taken]
input int width = 1280;//[宽度 of the snapshot taken]
struct TelegramMessage
  {
   long              MessageId;
   string            Text;
   datetime          TimestampGMT;
  };
#import "Telegram Connector MT5.ex5"
bool TelegramInit(const string botToken, const long channelId);
bool TelegramInit(const string botToken, const string channelName);
void TelegramGetUpdates(TelegramMessage& messages[]);
string BuildReplyMarkup(const string keyboard, const bool resize = false,const bool selective = true);
string BuildReplyKeyboardHide();
bool TelegramSendText(const string text, const bool htmlMode = false, const string replyMarkup = NULL);
bool TelegramSendPhoto(const string path, const string title, const bool useCommonFlag = false, const int timeout = 10000);
#import
int current_positions;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   if(!TelegramInit(botToken, channelName))
     {
      return INIT_FAILED;
     }
   start_time = TimeCurrent();
   previous_date = TimeCurrent();
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//--- destroy timer
   EventKillTimer();
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
// bool snap_shot_sent = false;
   datetime current_previous_date = previous_date;
   HistorySelect(start_time,TimeCurrent());
   current_positions =HistoryDealsTotal();
//Print(current_positions);
   int i =0;
   while(i<current_positions)
     {
      //Print("Current_Previous_Date: ", current_previous_date);
      //PositionSelect(PositionGetTicket(i));
      ulong ticket = HistoryDealGetTicket(i);
      //Print(ticket);
      while(ticket == 0)
        {
         Sleep(100);
         Print("Retrying to get ticket...");
         HistorySelect(start_time,TimeCurrent());
         current_positions = HistoryDealsTotal();
         //int new_positions = HistoryDealsTotal();
         ticket = HistoryDealGetTicket(i);
         Print("Ticket: ",ticket);
        }
      datetime newdate  = (datetime)HistoryDealGetInteger(ticket,DEAL_TIME);
      if(HistoryDealGetString(ticket, DEAL_SYMBOL)!=_Symbol)
        {
         i++;
         continue;
        }
      //Print("NewDate: ",newdate);
      if(current_previous_date < newdate)
        {
         Print("New Position was Open with ticket ", ticket," and date ",newdate);
         SendSnapshot(ticket);
         previous_date = newdate;
        }
      //bool y = PositionSelect(OrderGetTicket(i));
      //Print(PositionGetTicket(i));
      i++;
     }
  }
//+------------------------------------------------------------------+
//| Timer function                                                   |
//+------------------------------------------------------------------+
void OnTimer()
  {
//---
  }
//+------------------------------------------------------------------+
void SendSnapshot(ulong ticket)
  {
   string filename = "tmp.png";
   ulong position_id = HistoryDealGetInteger(ticket,DEAL_POSITION_ID);
   int CHwidth = (int)ChartGetInteger(0, CHART_WIDTH_IN_PIXELS);
//Print("Chwidth: ",CHwidth);
//Print("scale: ",ChartGetInteger(0,CHART_SCALE));
   string type = "Bought";
   string endSentence = "";
   if(HistoryDealGetInteger(ticket,DEAL_TYPE) == 1)
     {
      type = "Sold";
     }
   string entry = "Opening position";
   if(HistoryDealGetInteger(ticket,DEAL_ENTRY) == DEAL_ENTRY_IN)
     {
      //Print("taking screenshot");
      ChartScreenShot(0, filename, width, height);
     }
   else
      if(HistoryDealGetInteger(ticket,DEAL_ENTRY) == DEAL_ENTRY_OUT)
        {
         entry = "Closing position";
         HistorySelectByPosition(position_id);
         int total_deals = HistoryDealsTotal();
         double open_price = 0;
         datetime open_date = 0;
         //Print("Total deals:",total_deals);
         for(int i = 0; i < total_deals; i++)
           {
            ulong current_ticket = HistoryDealGetTicket(i);
            //Print(HistoryDealGetInteger(current_ticket,DEAL_ENTRY));
            if(current_ticket!=ticket)
              {
               open_price = HistoryDealGetDouble(current_ticket,DEAL_PRICE);
               open_date = (datetime)HistoryDealGetInteger(current_ticket,DEAL_TIME);
               //Print("OpenPrice: ", open_price);
              }
           }
         endSentence = "\n ";
         if(HistoryDealGetInteger(ticket,DEAL_TYPE) == DEAL_TYPE_SELL)
           {
            endSentence += "Profit: " + DoubleToString(MathRound((HistoryDealGetDouble(ticket, DEAL_PRICE) - open_price) / _Point)/10,1)+ " pips";
           }
         else
            if(HistoryDealGetInteger(ticket,DEAL_TYPE) == DEAL_TYPE_BUY)
              {
               endSentence += "Profit: " +DoubleToString(MathRound((open_price-HistoryDealGetDouble(ticket, DEAL_PRICE)) / _Point)/10,1) + " pips";
              }
         ScaleSnapShot(open_date);
         ChartScreenShot(0, filename, width, height);
         ChartSetSymbolPeriod(0,NULL,PERIOD_M15);
         ChartScaleSet(5,0);
        }
      else
         if(HistoryDealGetInteger(ticket,DEAL_ENTRY) == 2)
           {
            entry = "Reversing position";
           }
   int digits = _Digits;
//Print(digits);
   double volume = HistoryDealGetDouble(ticket,DEAL_VOLUME);
   double price = HistoryDealGetDouble(ticket,DEAL_PRICE);
   string title = entry +"\n" +HistoryDealGetString(ticket,DEAL_SYMBOL) + ": " + type + " at " + DoubleToString(price,digits) + endSentence;
   StringReplace(title, "PERIOD_", "");
   TelegramSendPhoto(filename, title);
   FileDelete(filename);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool ChartScaleSet(const long value,const long chart_ID=0)
  {
//--- reset the error value
   ResetLastError();
//--- set property value
   if(!ChartSetInteger(chart_ID,CHART_SCALE,0,value))
     {
      //--- display the error message in Experts journal
      Print(__FUNCTION__+", Error Code = ",GetLastError());
      return(false);
     }
//--- successful execution
   return(true);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ScaleSnapShot(datetime someDate)
  {
//someDate -= 30*24*60*60;
   ENUM_TIMEFRAMES period[] = {PERIOD_M15,PERIOD_M30,PERIOD_H1};
   int i = 1;
   int scale = 4;
   int  bar = iBarShift(NULL,0,someDate,false);
   long bars_count = ChartGetInteger(0,CHART_VISIBLE_BARS);
   long first_bar = ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
   while(first_bar < bar)
     {
      if(scale == -1)
         break;
      bars_count = ChartGetInteger(0,CHART_VISIBLE_BARS);
      first_bar = ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
      //if(i > 2)
      //  {
         Print("Changing Scale to ",scale);
         long tmp_bar = bars_count-1;
         ChartSetInteger(0,CHART_SCALE,scale);
         first_bar = ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
         while(tmp_bar == first_bar)
           {
            Sleep(100);
            first_bar = ChartGetInteger(0,CHART_FIRST_VISIBLE_BAR);
            //Print("tmp_bar: ",tmp_bar,"|| bar: ", first_bar);
           }
         scale --;
     //   }
     /*
      else
        {
         //Print("Changing Period to ",period[i]);
         ChartSetSymbolPeriod(0,NULL,period[i]);
         bar /= 2;
         //Print("bar: ", bar);
         i++;
        }
        */
     }
  }
//+------------------------------------------------------------------+