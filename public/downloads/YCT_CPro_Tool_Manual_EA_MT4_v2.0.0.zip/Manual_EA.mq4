//+------------------------------------------------------------------+
//|                                         CPro Tool Manual_EA MT4                          |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern int       Kperiod=5;
extern int       Dperiod=3;
extern int       slowPeriod=3;
extern int       UpLevel=90;
extern int       DownLevel=10;
extern int       StopLoss=100;
extern int       TakeProfit=100;
extern double    Lots=0.1;
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
   int res=-1;
//----
   double prevValue = iStochastic(Symbol(),0,Kperiod,Dperiod,slowPeriod,MODE_SMA,0,MODE_SIGNAL,2);
   double currValue = iStochastic(Symbol(),0,Kperiod,Dperiod,slowPeriod,MODE_SMA,0,MODE_SIGNAL,1);
   int i,type;
   double SL,TP;
   if (currValue>DownLevel && prevValue<DownLevel) res=OP_BUY;
   if (currValue<UpLevel && prevValue>UpLevel) res=OP_SELL;
   if (res==OP_BUY) //  ,  
      {
      if (OrdersTotal()>0)
         {
         for (i=OrdersTotal()-1; i>=0;i--)
            {
            if (OrderSelect(i,SELECT_BY_POS))
               {
               if (OrderType()==OP_SELL) OrderClose(OrderTicket(),OrderLots(),Ask,3);
               }
            }
         }
      if (StopLoss!=0)    SL=Bid-StopLoss*Point;   else SL=0;         
      if (TakeProfit!=0)  TP=Bid+TakeProfit*Point; else TP=0;         
      OrderSend(Symbol(),OP_BUY,Lots,Ask,3,SL,TP);
      }
   if (res==OP_SELL) //  ,  
      {
      if (OrdersTotal()>0)
         {
         for (i=OrdersTotal()-1; i>=0;i--)
            {
            if (OrderSelect(i,SELECT_BY_POS))
               {
               if (OrderType()==OP_BUY) OrderClose(OrderTicket(),OrderLots(),Bid,3);
               }
            }
         }   
      if (StopLoss!=0)    SL=Ask+StopLoss*Point;   else SL=0;         
      if (TakeProfit!=0)  TP=Ask-TakeProfit*Point; else TP=0;         
      OrderSend(Symbol(),OP_SELL,Lots,Bid,3,SL,TP);
      }
//----
   return(0);
  }
//+------------------------------------------------------------------+