//+------------------------------------------------------------------+
//|                                         CPro Indicator 9nix6_Indicators_MedianRenko_RangeDetector MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <AZ-INVEST/CustomBarConfig.mqh>

// Stub for missing function
int customChartIndicator() { return 0; }

input string Text = "Renko";
input color Font_Color = DodgerBlue;
input int Font_Size = 11;
input bool Font_Bold = true;
input int Left_Right = 125;
input int Up_Down = 150;
input ENUM_BASE_CORNER Corner = CORNER_RIGHT_LOWER;
string The_Font;
double Pointz;
string name_rnk;
string Renko_Range;
bool   isFirstRun;
long   chartId;
//
//
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   Pointz=_Point;
// 1, 3 & 5 digits pricing
   if(_Point==0.1) Pointz=1;
   if((_Point==0.00001) || (_Point==0.001)) Pointz*=10;
   if(Font_Bold==true)
     {
      The_Font="Arial Bold";
     }
   else
     {
      The_Font="Arial";
     }
   name_rnk = "RNK";
   isFirstRun = true;
   chartId = ChartID();
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Deinit                  
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ObjectDelete(chartId, name_rnk);
   CPro_Deinit();  // CPro营销模块清理
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function