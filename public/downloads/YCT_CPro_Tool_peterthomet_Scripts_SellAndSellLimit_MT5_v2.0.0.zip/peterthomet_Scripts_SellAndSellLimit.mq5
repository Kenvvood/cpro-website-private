//+------------------------------------------------------------------+
//|                                         CPro Tool peterthomet_Scripts_SellAndSellLimit MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <Trade\Trade.mqh>

input int NumberOfOrders=1;//数量 of orders to 开仓
input double EntryPrice=0;//entry 价格 for 卖出 限价 (overrules drag and drop 价格)
input double RiskPercent=1;//风险 百分比 money management
input double Lots=0;//----- or 交易量 尺寸
input int LotSizeDigits=2;//交易量 尺寸 fractional 小数位
input double StopLoss=100;//停止 亏损 点数
input double StopLossPrice=0;//----- or 停止 亏损 价格
input double TakeProfit=100;//take 利润 点数
input double TakeProfitPrice=0;//----- or take 利润 价格
input string OrderComment="Sell Script";//add this 备注 to orders
void OnStart()
{
   CTrade trade;
   MqlTick last;
   SymbolInfoTick(Symbol(),last);
   double selectedprice=ChartPriceOnDropped();
   if(EntryPrice>0&&EntryPrice>last.bid)
      selectedprice=EntryPrice;
   double entryprice=selectedprice;
   if(entryprice==0||last.bid>selectedprice)
      entryprice=last.bid;
   double slprice=StopLossPrice;
   if(StopLoss>0)
      slprice=entryprice+(StopLoss*Point());
   double tpprice=TakeProfitPrice;
   if(TakeProfit>0)
      tpprice=entryprice-(TakeProfit*Point());
   double volume=Lots;
   if(RiskPercent>0&&slprice>0)
      volume=AccountInfoDouble(ACCOUNT_BALANCE)*(RiskPercent/100)/((slprice-entryprice)/Point())/(SymbolInfoDouble(Symbol(),SYMBOL_TRADE_TICK_VALUE));
   volume=NormalizeDouble(volume,LotSizeDigits);
   if(volume>0)
   {
      for(int i=0;i<NumberOfOrders;i++)
      {
         if(last.bid<selectedprice&&selectedprice>0)
            trade.SellLimit(volume,selectedprice,NULL,slprice,tpprice,0,0,OrderComment);
         else
            trade.Sell(volume,NULL,0,slprice,tpprice,OrderComment);
      }
   }
}