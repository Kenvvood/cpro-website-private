//+------------------------------------------------------------------+
//|                                         CPro Tool peterthomet_Scripts_Modify_All_TP_SL MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <Trade\Trade.mqh>
#include <Trade\OrderInfo.mqh>
#include <Trade\PositionInfo.mqh>

input double TakeProfit=0;//take 利润 (价格)
input double StopLoss=0;//停止 亏损 (价格)
void OnStart()
{
   double inputtp=NormalizeDouble(TakeProfit,_Digits);
   double inputsl=NormalizeDouble(StopLoss,_Digits);
   MqlTick last;
   SymbolInfoTick(Symbol(),last);
   for(int i=OrdersTotal()-1;i>=0;i--)
   {
      COrderInfo oi;
      oi.SelectByIndex(i);
      if(oi.Symbol()==Symbol())
      {
         double tp=inputtp;
         double sl=inputsl;
         if(tp<=0)
            tp=oi.TakeProfit();
         if(sl<=0)
            sl=oi.StopLoss();
         if(oi.OrderType()==ORDER_TYPE_BUY_LIMIT||oi.OrderType()==ORDER_TYPE_BUY_STOP)
         {
            if(tp<=oi.PriceOpen())
               tp=oi.TakeProfit();
            if(sl>=oi.PriceOpen())
               sl=oi.StopLoss();
         }
         if(oi.OrderType()==ORDER_TYPE_SELL_LIMIT||oi.OrderType()==ORDER_TYPE_SELL_STOP)
         {
            if(tp>=oi.PriceOpen())
               tp=oi.TakeProfit();
            if(sl<=oi.PriceOpen())
               sl=oi.StopLoss();
         }
         if(tp!=oi.TakeProfit()||sl!=oi.StopLoss())
            Modify(oi.Ticket(),tp,sl,&oi);
      }
   }
   for(int i=PositionsTotal()-1;i>=0;i--)
   {
      CPositionInfo pi;
      pi.SelectByIndex(i);
      if(pi.Symbol()==Symbol())
      {
         double tp=inputtp;
         double sl=inputsl;
         if(tp<=0)
            tp=pi.TakeProfit();
         if(sl<=0)
            sl=pi.StopLoss();
         if(pi.PositionType()==POSITION_TYPE_BUY)
         {
            if(tp<last.bid)
               tp=pi.TakeProfit();
            if(sl>last.bid)
               sl=pi.StopLoss();
         }
         if(pi.PositionType()==POSITION_TYPE_SELL)
         {
            if(tp>last.ask)
               tp=pi.TakeProfit();
            if(sl<last.ask)
               sl=pi.StopLoss();
         }
         if(tp!=pi.TakeProfit()||sl!=pi.StopLoss())
            Modify(pi.Ticket(),tp,sl,NULL);
      }
   }
}
void Modify(long ticket, double tp, double sl, COrderInfo *oi=NULL)
{
   CTrade trade;
   ResetLastError();
   bool success=false;
   int retry=0;
   while(!success && !IsStopped() && retry<5)
   {
      if(oi!=NULL)
         success=trade.OrderModify(ticket,oi.PriceOpen(),sl,tp,oi.TypeTime(),oi.TimeExpiration(),oi.PriceStopLimit());
      else
         success=trade.PositionModify(ticket,sl,tp);
      if(!success)
      {
         Print("Error modifying orders, #"+IntegerToString(GetLastError()));
         Sleep(500);
         retry++;
      }
   }
}