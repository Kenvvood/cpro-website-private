//+------------------------------------------------------------------+
//|                                         CPro Tool Badorders MT4                          |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//----
double asdf;
double ticket, t2;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//---- 
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//---- 
   //This section closes any positions opened on the last tick
   OrderSelect(1,SELECT_BY_POS);
   OrderClose(OrderTicket(),1,Bid,8,Red);
   ticket=OrderSend(Symbol(),OP_BUYSTOP,1,Bid+100*Point,3,0,0,"asdfasdf",16384,0,Green);
   t2=OrderSelect(ticket,SELECT_BY_TICKET);
   OrderModify(OrderTicket(),Bid-100*Point,0,0,0,Green);
   //OrderClose(OrderTicket(),1,Bid,8,Red);
   //OrderSend(Symbol(),OP_BUYSTOP,1,Bid-100*Point,3,0,0,"asdfasdf",16384,0,Green);
//----
   return(0);
  }
//+------------------------------------------------------------------+