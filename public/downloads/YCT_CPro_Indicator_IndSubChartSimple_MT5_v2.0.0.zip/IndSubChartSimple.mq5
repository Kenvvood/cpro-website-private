//+------------------------------------------------------------------+
//|                                         CPro Indicator IndSubChartSimple MT5             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <PRTF.mqh>
#include "..\..\Include\QuoteRefresh.mqh"

//+------------------------------------------------------------------+
//| Stub for QuoteRefresh if not defined in include                   |
//+------------------------------------------------------------------+
#ifndef QUOTE_REFRESH_DEFINED
#define QUOTE_REFRESH_DEFINED
void QuoteRefresh(string sym) {}
#endif

// inputs
input string SubSymbol = "";//品种
input ENUM_CHART_MODE Mode = CHART_CANDLES;
// globals
string symbol;
// Buffers: OHLC
double open[];
double high[];
double low[];
double close[];
//+------------------------------------------------------------------+
//| Single buffer setup                                              |
//+------------------------------------------------------------------+
void InitBuffer(const int index, double &buffer[],
   const ENUM_INDEXBUFFER_TYPE style = INDICATOR_DATA,
   const bool asSeries = false)
{
   SetIndexBuffer(index, buffer, style);
   ArraySetAsSeries(buffer, asSeries);
}
//+------------------------------------------------------------------+
//| Group of buffers setup                                           |
//+------------------------------------------------------------------+
string InitBuffers(const ENUM_CHART_MODE m)
{
   string title;
   if(m == CHART_LINE)
   {
      InitBuffer(0, close, INDICATOR_DATA, true);
      // hide all other buffers unneeded for line drawing
      InitBuffer(1, high, INDICATOR_CALCULATIONS, true);
      InitBuffer(2, low, INDICATOR_CALCULATIONS, true);
      InitBuffer(3, open, INDICATOR_CALCULATIONS, true);
      title = symbol + " Close";
   }
   else
   {
      InitBuffer(0, open, INDICATOR_DATA, true);
      InitBuffer(1, high, INDICATOR_DATA, true);
      InitBuffer(2, low, INDICATOR_DATA, true);
      InitBuffer(3, close, INDICATOR_DATA, true);
      title = symbol + " OHLC";
   }
   return title;
}
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
   //--- Determine symbol
   if(SubSymbol != "")
      symbol = SubSymbol;
   else
      symbol = Symbol();
   
   //--- Refresh quote for the symbol (sub-symbol may be different)
   QuoteRefresh(symbol);
   
   //--- Initialize buffers based on chart mode
   string title = InitBuffers(Mode);
   IndicatorSetString(INDICATOR_SHORTNAME, title);
   
   //--- Initialize marketing module
   CPro_Init();
   
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open_arr[],
                const double &high_arr[],
                const double &low_arr[],
                const double &close_arr[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   //--- Refresh quote data for the sub-symbol
   QuoteRefresh(symbol);
   
   //--- Copy price data from the sub-symbol
   int copied = CopyOpen(symbol, 0, 0, rates_total, open);
   if(copied <= 0) return(0);
   copied = CopyHigh(symbol, 0, 0, rates_total, high);
   if(copied <= 0) return(0);
   copied = CopyLow(symbol, 0, 0, rates_total, low);
   if(copied <= 0) return(0);
   copied = CopyClose(symbol, 0, 0, rates_total, close);
   if(copied <= 0) return(0);
   
   //--- Calculate from where to start
   int limit = rates_total - prev_calculated;
   if(prev_calculated == 0) limit = rates_total;
   if(limit > rates_total) limit = rates_total;
   
   //--- Fill indicator buffers
   for(int i = limit - 1; i >= 0; i--)
   {
      // Data already in OHLC buffers via CopyOpen/High/Low/Close
   }
   
   return(rates_total);
}
//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   CPro_Deinit();
}
//+------------------------------------------------------------------+
//| ChartEvent function                                              |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,
                  const long &lparam,
                  const double &dparam,
                  const string &sparam)
{
   // Handle marketing module events if needed
}