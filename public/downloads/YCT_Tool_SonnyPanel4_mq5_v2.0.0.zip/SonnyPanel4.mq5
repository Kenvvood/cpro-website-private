
//+------------------------------------------------------------------+
//|                 YCT Tool SonnyPanel4_mq5                           |
//|                         城诺科技                            |
//|                         WeChat: Lookee333                        |
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                  SonnyPanel2.mq5 |
//|                                  Copyright 2024, MetaQuotes Ltd. |
//|                                             https://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "Copyright 2024, MetaQuotes Ltd."
#property link      "https://www.mql5.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                           Brand Panel                             |
//+------------------------------------------------------------------+
#include <mq5\Marketing.mqh>

// 品牌面板将在 OnInit() 中通过 InitMarketing() 初始化
// 品牌面板将在 OnDeinit() 中通过 DeinitMarketing() 清理

#include <Trade\PositionInfo.mqh>
#include <Trade\Trade.mqh>
#include "..\includes\CalculateBreakeven.mqh"
#include "..\includes\OrderManager.mqh"

#include"..\\Includes\\BreakEvenResult.mqh"
#include <Controls\Button.mqh>
#include <Controls\Edit.mqh>
#include <Controls\CheckBox.mqh>

CTrade trade;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
#define BTN_BUY_NAME "Btn Buy"
#define BTN_SELL_NAME "Btn Sell"
#define BTN_CLOSEALL_NAME "Btn CloseAll"
#define EDIT_VOLUME "Edit Volume"

datetime Last_Candle_Open_Time=0;
CButton btnBuy;
CButton btnSell;
CButton btnCloseAll;
CEdit CEditMagic;
CButton btnMagicUp;
CButton btnMagicDown;
CButton TrailStartDown;
CButton TrailStartUp;
CButton TrailStepDown;
CButton TrailStepUp;

CEdit CEditLotsize;
CButton btnLotsizeDown;
CButton btnLotsizeUp;


CButton btnHedge;
CButton btnCloseMagic;

CEdit CEditProfit;
CButton btnProfitUp;
CButton btnProfitDown;
CEdit TrailStart;
CEdit TrailStep;

CEdit CEditLotsizeToClose;
CButton btnLotsizeToCloseUp;
CButton btnLotsizeToCloseDown;
CButton btnMoveUpDown;

CCheckBox         CheckStopForToday;
CCheckBox         CheckRecover;


input int iMax1=2;
input int iMax2=5;
OrderManager orderManager(iMax1,iMax2);
long Magic=1;
input bool iUseIndicator=true;
int autolot=700;
double buyat=-2;
double closeat=40;
input double iLotsizeToClose=0.01;// lotsize toclose/0.01
input double iprofitTarget=0.17;// profitargeet 0.07
input double iTrailStop=0.1;//trailstop 0.02
input double iTrailStep=0.03;//trailstep0.007
input double iLotsize=0.01;//0.01
input double iStopOut=3000;
input double iTotalLossProfit=30;
input double TotalLossProfit1=30;
input double iLossProfit=-3;
input double iLossProfit1=-0.5;
input bool iSlave =false;


double LossProfit;
double TotalLossProfit;
double Lotsize;
double ProfitTaget;
double LotsizeToClose;
double TotalLossProfit11;
bool PanelUp=true;
int MA_handle;
int MA_handle1;
int MA_handle2;
int MA_handle3;
int MA_handle4;
int x=20;
bool process=true;

int w=50;
int h=20;
int d=30;
ulong TicketList[100] = {0};
double Step[100] = {0};

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
datetime lasthedge;
MqlDateTime SDateTime,SToday;
long oldmagic=1;
double start;
double step;
int factor=0;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnInit()
  {
   Magic=1;
   start=iTrailStop;
   step=iTrailStep;
   Lotsize=iLotsize;
   ProfitTaget=iprofitTarget;
   LotsizeToClose=iLotsizeToClose;
   TotalLossProfit=iTotalLossProfit;
   LossProfit=iLossProfit;
   
   if(iUseIndicator)
     {
      MA_handle=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_total",true,true);
      MA_handle2=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_totalBuy",true,false);
      MA_handle3=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_totalSell",false,true);
      MA_handle4=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_totalMagic",Magic,LotsizeToClose,ProfitTaget);
      MA_handle1=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\candlecountdown");
     }


   ObjectsDeleteAll(0,0,-1);
//---


   TimeToStruct(TimeCurrent(),SDateTime);

   SDateTime.hour=0;
   SDateTime.min=0;
   SDateTime.sec=0;
   datetime  from_date=StructToTime(SDateTime);     // From date

   SDateTime.hour=23;
   SDateTime.min=59;
   SDateTime.sec=59;

   datetime  to_date=StructToTime(SDateTime);     // To date

   lasthedge=TimeCurrent()-60*60*23*2;

   btnBuy.Create(0,BTN_BUY_NAME,0,x+w,h,x+2*w,h+d);
   btnBuy.Text("Buy");
   btnBuy.Color(clrWhite);
   btnBuy.ColorBackground(clrGreen);

   btnSell.Create(0,BTN_SELL_NAME,0,x,h,x+w,h+d);
   btnSell.Text("Sell");
   btnSell.Color(clrWhite);
   btnSell.ColorBackground(clrRed);

   btnCloseAll.Create(0,BTN_CLOSEALL_NAME,0,x+2*w,h,x+3*w,h+d);
   btnCloseAll.Text("CloseAll");
   btnCloseAll.Color(clrWhite);
   btnCloseAll.ColorBackground(clrPurple);

   CEditMagic.Create(0,"Edit Magic",0,x+10,h+d,x+40,h+2*d);
   CEditMagic.Text("1");
   btnMagicUp.Create(0,"Magic Up",0,x,h+d,x+10,h+2*d);
   btnMagicUp.Text("+");
   btnMagicDown.Create(0,"Magic down",0,x+40,h+d,x+50,h+2*d);
   btnMagicDown.Text("-");

   CEditLotsize.Create(0,"Edit Lotsize",0,x+w+10,h+d,x+w+40,h+2*d);
   CEditLotsize.Text(Lotsize);
   btnLotsizeUp.Create(0,"Lotsize Up",0,x+w,h+d,x+w+10,h+2*d);
   btnLotsizeUp.Text("+");
   btnLotsizeDown.Create(0,"Lotsize Down",0,x+w+40,h+d,x+w+50,h+2*d);
   btnLotsizeDown.Text("-");

   CEditProfit.Create(0,"Profit",0,x+2*w+10,h+d,x+2*w+40,h+2*d);
   CEditProfit.Text(ProfitTaget);
   CEditProfit.ColorBackground(clrLightGreen);
   CEditProfit.ReadOnly();


   btnProfitUp.Create(0,"Profit Up",0,x+2*w,h+d,x+2*w+10,h+2*d);
   btnProfitUp.Text("+");
   btnProfitDown.Create(0,"Profit Down",0,x+2*w+40,h+d,x+2*w+50,h+2*d);
   btnProfitDown.Text("-");


   btnHedge.Create(0,"Hedge",0,x,h+2*d,x+w,h+3*d);
   btnHedge.Text("Hedge");
   btnHedge.Color(clrWhite);
   btnHedge.ColorBackground(clrRed);
   btnCloseMagic.Create(0,"Close Magic",0,x+w,h+2*d,x+2*w,h+3*d);
   btnCloseMagic.Text("ClsMagic");

   btnCloseMagic.Color(clrWhite);
   btnCloseMagic.ColorBackground(clrPurple);

   CEditLotsizeToClose.Create(0,"Edit LotsizeToClose",0,x+2*w+10,h+2*d,x+2*w+40,h+3*d);
   CEditLotsizeToClose.Text(LotsizeToClose);
   btnLotsizeToCloseUp.Create(0,"LotsizeToClose Up",0,x+2*w,h+2*d,x+2*w+10,h+3*d);
   btnLotsizeToCloseDown.Text("-");
   btnLotsizeToCloseDown.Create(0,"LotsizeToClose Down",0,x+2*w+40,h+2*d,x+2*w+50,h+3*d);
   btnLotsizeToCloseUp.Text("+");

   TrailStartUp.Create(0,"TrailUp",0,x,h+3*d,x+10,h+4*d);
   TrailStartUp.Text("+");
   TrailStart.Create(0,"TrailStart",0,x+10,h+3*d,x+40,h+4*d);
   TrailStart.Text(start);
   TrailStartDown.Create(0,"TrailDown",0,x+40,h+3*d,x+50,h+4*d);
   TrailStartDown.Text("-");

   TrailStep.Create(0,"TrailStep",0,x+w+10,h+3*d,x+w+40,h+4*d);
   TrailStep.Text(step);
   TrailStepUp.Create(0,"StepUp",0,x+w,h+3*d,x+w+10,h+4*d);
   TrailStepUp.Text("+");
   TrailStepDown.Create(0,"StepDown",0,x+w+40,h+3*d,x+w+50,h+4*d);
   TrailStepDown.Text("-");

   btnMoveUpDown.Create(0,"Move Panel",0,x+2*w,h+3*d,x+3*w,h+4*d);
   btnMoveUpDown.Text("--");
   CheckRecover.Create(0,"CRecover",0,x,h+4*d,x+w,h+5*d);
   CheckRecover.Text("Recover");
   CheckStopForToday.Create(0,"CStop",0,x+w, h+4*d,x+2*w,h+5*d);
   CheckStopForToday.Text("StopToday");


//--- create application dialog


//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void MovePanelUp()
  {

   ObjectSetInteger(0, BTN_BUY_NAME, OBJPROP_YDISTANCE, x);

   ObjectSetInteger(0, BTN_SELL_NAME, OBJPROP_YDISTANCE, x);
   ObjectSetInteger(0,BTN_CLOSEALL_NAME,OBJPROP_YDISTANCE,x);
   ObjectSetInteger(0,"Edit Magic",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Magic Up",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Magic down",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Profit",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Profit Up",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Profit Down",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Edit Lotsize",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Lotsize Up",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Lotsize Down",OBJPROP_YDISTANCE,x+d);
   ObjectSetInteger(0,"Hedge",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"Close Magic",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"Edit LotsizeToClose",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"LotsizeToClose Up",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"LotsizeToClose Down",OBJPROP_YDISTANCE,x+2*d);
   ObjectSetInteger(0,"Move Panel",OBJPROP_YDISTANCE,x+3*d);
   ObjectSetInteger(0,"TrailUp",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"TrailStart",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"TrailDown",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"TrailStep",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"StepUp",OBJPROP_YDISTANCE,h+3*d);
   ObjectSetInteger(0,"StepDown",OBJPROP_YDISTANCE,h+3*d);


  }
void MovePanelDown()

  {

   long result1=0;
   int dis=120;
   ChartGetInteger(0,CHART_HEIGHT_IN_PIXELS,0,result1);

   ObjectSetInteger(0, BTN_BUY_NAME, OBJPROP_YDISTANCE, result1-dis);
   ObjectSetInteger(0, BTN_SELL_NAME, OBJPROP_YDISTANCE, result1-dis);
   ObjectSetInteger(0,BTN_CLOSEALL_NAME,OBJPROP_YDISTANCE,result1-dis);
   ObjectSetInteger(0,"Edit Magic",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Magic Up",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Magic down",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Profit",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Profit Up",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Profit Down",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Edit Lotsize",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Lotsize Up",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Lotsize Down",OBJPROP_YDISTANCE,result1-dis+d);
   ObjectSetInteger(0,"Hedge",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"Close Magic",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"Edit LotsizeToClose",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"LotsizeToClose Up",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"LotsizeToClose Down",OBJPROP_YDISTANCE,result1-dis+2*d);
   ObjectSetInteger(0,"Move Panel",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"TrailUp",OBJPROP_YDISTANCE,result1-dis+3*d);

   ObjectSetInteger(0,"TrailStart",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"TrailDown",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"TrailStep",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"StepUp",OBJPROP_YDISTANCE,result1-dis+3*d);
   ObjectSetInteger(0,"StepDown",OBJPROP_YDISTANCE,result1-dis+3*d);
  }


//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
   ObjectsDeleteAll(0,0,-1);

  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnChartEvent(const int id,
                  const long &lparam,
                  const double &dparam,
                  const string &sparam)

  {
   if(!MQLInfoInteger(MQL_TESTER))
     {
      ButtonHandler();

     }

  }



//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ReadParameters()
  {
   Magic=StringToInteger(ObjectGetString(0,"Edit Magic",OBJPROP_TEXT));
   Lotsize=StringToDouble(ObjectGetString(0,"Edit Lotsize",OBJPROP_TEXT));
  }


//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnTick()
  {
   static datetime dtBarCurrent  = WRONG_VALUE;
   datetime dtBarPrevious = dtBarCurrent;
   dtBarCurrent  = iTime(_Symbol,PERIOD_M1, 0);
   bool     bNewBarEvent  = (dtBarCurrent != dtBarPrevious);






   if(MQLInfoInteger(MQL_TESTER))
     {
      ButtonHandler();
      ObjectSetInteger(0, "Edit Magic", OBJPROP_READONLY, 1);
      ObjectSetInteger(0, "Edit Lotsize", OBJPROP_READONLY, 1);

      ObjectSetInteger(0, "Edit LotsizeToClose", OBJPROP_READONLY, 1);


     }
//  SetAutolot();
//OrderList();
// CheckForTrail();
//trailing stop
//  MqlDateTime rightNow;
// TimeCurrent(rightNow);

   if(bNewBarEvent)
     {
      // Detect if this is the first tick received and handle it.
      /* For example, when it is first attached to a chart and
         the bar is somewhere in the middle of its progress and
         it's not actually the start of a new bar. */
      if(dtBarPrevious == WRONG_VALUE)
        {
         // Do something on first tick or middle of bar ...
        }
      else
        {
         if(orderManager.PositionTotalOnThis()==0) //&& GetSpread(_Symbol)<1.6)
           {
            //&&  rightNow.hour>8 && rightNow.hour<22)&& !CheckStopForToday.Checked()
            //CheckRecover.Checked(false);

            Magic=1;
            start=iTrailStop;
            step=iTrailStep;
            Lotsize=iLotsize;
            ProfitTaget=iprofitTarget;
            LotsizeToClose=iLotsizeToClose;
            TotalLossProfit=iTotalLossProfit;
            LossProfit=iLossProfit;
            oldmagic=1;
            TotalLossProfit11=TotalLossProfit1;
            orderManager.recoveryOrdersBuy=0;
            orderManager.recoveryOrdersSell=0;

            ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(iLotsize));
            ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));

            ObjectSetString(0, "Edit LotsizeToClose",OBJPROP_TEXT, DoubleToString(iLotsizeToClose));
            orderManager.FirstOrder(Magic,Lotsize);


           }

         orderManager.TrailTrades(Magic,true,true,ProfitTaget,LotsizeToClose,ProfitTaget,step,start);
         if(AccountInfoDouble(ACCOUNT_PROFIT)<-iStopOut)
           {
            orderManager.CloseAll();
            Magic=1;
            start=iTrailStop;
            step=iTrailStep;
            Lotsize=iLotsize;
            ProfitTaget=iprofitTarget;
            LotsizeToClose=iLotsizeToClose;
            TotalLossProfit=iTotalLossProfit;
            TotalLossProfit11=TotalLossProfit1;
            LossProfit=iLossProfit;
            oldmagic=1;

            orderManager.recoveryOrdersBuy=0;
            orderManager.recoveryOrdersSell=0;
            lasthedge=TimeCurrent()-60*60*24;
            ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(iLotsize));
            ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));
            ObjectSetString(0, "Edit LotsizeToClose",OBJPROP_TEXT, DoubleToString(iLotsizeToClose));
            //
           }
         //NormalizeDouble(iLossProfit*Lotsize/0.01,3)
         if(orderManager.RelativeProfitOnMagic2(Magic,Lotsize,LossProfit,LotsizeToClose,lasthedge,false,false)<-(Magic==1?TotalLossProfit11:TotalLossProfit))
           {
            if(AccountInfoDouble(ACCOUNT_PROFIT)<-40)
              {
               int y;
               y=1;
              }
            //ckStopForToday.Checked(true);
            // CheckRecover.Checked(false);
            int direction;
            double result;
            // result=orderManager.RelativeProfitOnMagic2(Magic,Lotsize,NormalizeDouble(iLossProfit*Lotsize/0.01,3),LotsizeToClose,lasthedge,false,false);
            direction= orderManager.HedgePositions(Magic);

            Magic=Magic+1;
            TotalLossProfit11=TotalLossProfit1*Magic;
            TotalLossProfit=(Magic<20 ? Magic: 20)*iTotalLossProfit;
            LossProfit=(Magic<20? Magic: 20)*iLossProfit;

            Lotsize=(Magic<20? Magic: 20)*iLotsize;// NormalizeDouble(Lotsize*1.6,2);;
            LotsizeToClose=NormalizeDouble(iLotsizeToClose*(Magic<20? Magic: 20),2);
            ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));
            ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(Lotsize));
            ObjectSetString(0,"Edit LotsizeToClose",OBJPROP_TEXT,DoubleToString(LotsizeToClose));

            TimeToStruct(TimeCurrent(),SToday);
            TimeToStruct(lasthedge,SDateTime);

            if(Magic==2)
               process=true;

            if(Magic>2 && ((lasthedge+60*60*24) <TimeCurrent()))
               process=true;
            if(process)
              {
               lasthedge=TimeCurrent();
               if(direction==1)
                 {
                  orderManager.PlaceOrder(POSITION_TYPE_BUY,Lotsize,Magic,Magic);
                  orderManager.PlaceOrder(POSITION_TYPE_BUY,Lotsize,Magic,Magic);
                  orderManager.PlaceOrder(POSITION_TYPE_BUY,Lotsize,Magic,Magic);
                  orderManager.PlaceOrder(POSITION_TYPE_BUY,Lotsize,Magic,Magic);
                 }
               if(direction==0)
                 {
                  orderManager.PlaceOrder(POSITION_TYPE_SELL,Lotsize,Magic,Magic);
                  orderManager.PlaceOrder(POSITION_TYPE_SELL,Lotsize,Magic,Magic);
                  orderManager.PlaceOrder(POSITION_TYPE_SELL,Lotsize,Magic,Magic);
                  orderManager.PlaceOrder(POSITION_TYPE_SELL,Lotsize,Magic,Magic);
                 }
              }
           }

         if((lasthedge+60*60*24)<TimeCurrent())
            process=true;
         if((lasthedge+60*60*24)>TimeCurrent())
            process=false;

         orderManager.RelativeProfitOnMagic(Magic,Lotsize,LossProfit,LotsizeToClose,lasthedge,process,true);

        }
     }



  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
void SetAutolot()
  {
   double balance=AccountInfoDouble(ACCOUNT_BALANCE);
   int intfactor;
   intfactor=(int)MathFloor(NormalizeDouble(balance/autolot,1));
   if(intfactor==0)
      intfactor=1;
   if(intfactor>SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX)/SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN))
      intfactor=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX)/SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN);

   if(intfactor>=factor)
      factor=intfactor;


   ProfitTaget=iprofitTarget*factor;
   start=factor*iTrailStop;
   step=factor*iTrailStep;
   Lotsize=factor*0.1;


  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void DetectConfig()
  {
   int magicHigh=orderManager.GetHighestMagic();
   TotalLossProfit=(magicHigh<20 ? magicHigh: 20)*iTotalLossProfit;
   LossProfit=(magicHigh<20? magicHigh: 20)*iLossProfit;

   Lotsize=(magicHigh<20? magicHigh: 20)*iLotsize;// NormalizeDouble(Lotsize*1.6,2);;
   LotsizeToClose=NormalizeDouble(iLotsizeToClose*(magicHigh<20? magicHigh: 20),2);
   ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(magicHigh));
   ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(Lotsize));
   ObjectSetString(0,"Edit LotsizeToClose",OBJPROP_TEXT,DoubleToString(LotsizeToClose));
  }

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ButtonHandler()
  {

   double oldprofittarge=ProfitTaget;
   double oldlotstoclose=LotsizeToClose;



   if(TrailStartUp.Pressed())
     {
      start=start+iTrailStop;
      ObjectSetString(0,"TrailStart",OBJPROP_TEXT,DoubleToString(start,1));
      TrailStartUp.Pressed(false);
     }

   if(TrailStartDown.Pressed())
     {
      if(start > 0)
         start=start-iTrailStop;
      ObjectSetString(0,"TrailStart",OBJPROP_TEXT,DoubleToString(start,1));
      TrailStartDown.Pressed(false);
     }

   if(TrailStepUp.Pressed())
     {
      step=step+iTrailStep;
      ObjectSetString(0,"TrailStep",OBJPROP_TEXT,DoubleToString(step,1));
      TrailStepUp.Pressed(false);
     }

   if(TrailStepDown.Pressed())
     {
      if(step > 0)
         step=step-iTrailStep;
      ObjectSetString(0,"TrailStep",OBJPROP_TEXT,DoubleToString(step,1));
      TrailStepDown.Pressed(false);
     }

   if(btnMagicUp.Pressed())
     {
      oldmagic=Magic;
      Magic=Magic+1;
      ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));

      btnMagicUp.Pressed(false);
     }

   if(btnMagicDown.Pressed())
     {
      Magic=Magic-1;
      ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));
      btnMagicDown.Pressed(false);
     }

   if(btnBuy.Pressed())
     {
      orderManager.PlaceOrder(POSITION_TYPE_BUY, Lotsize, Magic,NULL);
      btnBuy.Pressed(false);
     }

   if(btnSell.Pressed())
     {
      orderManager.PlaceOrder(POSITION_TYPE_SELL, Lotsize, Magic,NULL);
      btnSell.Pressed(false);
     }
   if(btnCloseAll.Pressed())
     {
      orderManager.CloseTrades(0,true,true,0);
      btnCloseAll.Pressed(false);
     }
   if(btnLotsizeDown.Pressed())
     {
      Lotsize=Lotsize-iLotsize;
      if(Lotsize<DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN)))
         Lotsize=DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
      ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(Lotsize));
      btnLotsizeDown.Pressed(false);
     }

   if(btnLotsizeUp.Pressed())
     {
      Lotsize=Lotsize+iLotsize;

      ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(Lotsize));

      btnLotsizeUp.Pressed(false);
     }


   if(btnLotsizeToCloseDown.Pressed())
     {
      LotsizeToClose=LotsizeToClose-iLotsizeToClose;
      if(LotsizeToClose<DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN)))
         LotsizeToClose=DoubleToString(SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
      ObjectSetString(0,"Edit LotsizeToClose",OBJPROP_TEXT,DoubleToString(LotsizeToClose));

      btnLotsizeToCloseDown.Pressed(false);

     }

   if(btnLotsizeToCloseUp.Pressed())
     {
      LotsizeToClose=LotsizeToClose+iLotsizeToClose;

      ObjectSetString(0,"Edit LotsizeToClose",OBJPROP_TEXT,DoubleToString(LotsizeToClose));

      btnLotsizeToCloseUp.Pressed(false);
     }

   if(btnProfitUp.Pressed())
     {
      ProfitTaget=ProfitTaget+iprofitTarget;

      ObjectSetString(0,"Profit",OBJPROP_TEXT,DoubleToString(ProfitTaget));

      btnProfitUp.Pressed(false);
     }
   if(btnProfitDown.Pressed())
     {
      ProfitTaget=ProfitTaget-iprofitTarget;

      ObjectSetString(0,"Profit",OBJPROP_TEXT,DoubleToString(ProfitTaget));

      btnProfitDown.Pressed(false);
     }

   if(btnCloseMagic.Pressed())
     {
      orderManager.CloseTrades(Magic,true,true,0,LotsizeToClose);

      btnCloseMagic.Pressed(false);
     }
   if(btnHedge.Pressed())
     {
        {

         //ckStopForToday.Checked(true);
         // CheckRecover.Checked(false);
         int direction;
         double result;
         // result=orderManager.RelativeProfitOnMagic2(Magic,Lotsize,NormalizeDouble(iLossProfit*Lotsize/0.01,3),LotsizeToClose,lasthedge,false,false);
         direction= orderManager.HedgePositions(Magic);

         Magic=Magic+1;
         TotalLossProfit=(Magic<20 ? Magic: 20)*iTotalLossProfit;
         LossProfit=(Magic<20? Magic: 20)*iLossProfit/2;

         Lotsize=(Magic<20? Magic: 20)*iLotsize;// NormalizeDouble(Lotsize*1.6,2);;
         LotsizeToClose=NormalizeDouble(iLotsizeToClose*(Magic<20? Magic: 20),2);
         ObjectSetString(0,"Edit Magic",OBJPROP_TEXT,IntegerToString(Magic));
         ObjectSetString(0,"Edit Lotsize",OBJPROP_TEXT,DoubleToString(Lotsize));
         ObjectSetString(0,"Edit LotsizeToClose",OBJPROP_TEXT,DoubleToString(LotsizeToClose));
         if(direction==1)
           {
            orderManager.PlaceOrder(POSITION_TYPE_BUY,Lotsize,Magic,Magic);
            orderManager.PlaceOrder(POSITION_TYPE_BUY,Lotsize,Magic,Magic);
           }
         if(direction==0)
           {
            orderManager.PlaceOrder(POSITION_TYPE_SELL,Lotsize,Magic,Magic);
            orderManager.PlaceOrder(POSITION_TYPE_SELL,Lotsize,Magic,Magic);
           }
         lasthedge=TimeCurrent();
        }




     }
   if(Magic==0)
     {
      IndicatorRelease(MA_handle4);
     }
   if(((oldlotstoclose!=LotsizeToClose)||(oldmagic!=Magic)|| (oldprofittarge!=ProfitTaget)) && Magic!=0)
     {
      if(iUseIndicator)
        {
         IndicatorRelease(MA_handle4);
         MA_handle4=iCustom(NULL,0,"..\\indicators\\shared projects\\sonnypanel\\ea\\average_price_totalMagic",Magic,LotsizeToClose,ProfitTaget);
        }
      oldmagic=Magic;
     }

   if(btnMoveUpDown.Pressed())
     {
      if(PanelUp==true)
        {

         MovePanelDown();
         PanelUp=false;
        }
      else
        {
         MovePanelUp();
         PanelUp=true;


        }
      btnMoveUpDown.Pressed(false);
     }
   ChartRedraw(0);

  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double GetSpread(string symbol)
  {
// Get the Ask price
   double ask = SymbolInfoDouble(symbol, SYMBOL_ASK);

// Get the Bid price
   double bid = SymbolInfoDouble(symbol, SYMBOL_BID);

// Calculate the spread
   double spread = ask - bid;

   return spread;
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OrderList()
  {
   for(int i=PositionsTotal()-1; i>=0; i--)
     {
      ulong PositionTicket = PositionGetTicket(i);
      if(PositionGetString(POSITION_SYMBOL) == _Symbol)
        {
         if(!InArray(PositionTicket))
            Save(PositionTicket);
        }
     }
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void Save(ulong t)
  {
   for(int i=0;i<ArraySize(TicketList);i++)
     {
      if(TicketList[i] == 0)
        {
         TicketList[i] = t;
         break;
        }
     }
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
bool InArray(ulong t)
  {
   for(int i=0;i<ArraySize(TicketList);i++)
     {
      if(TicketList[i] == t)
         return true;
     }
   return false;
  }
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CheckForTrail()
  {
   double p = 0;


   for(int i=0;i<ArraySize(TicketList);i++)
     {
      if(TicketList[i] != 0)
        {
         if(PositionSelectByTicket(TicketList[i]))
           {
            p = PositionGetDouble(POSITION_PROFIT);
            if(p >= start && p-step > Step[i])
               Step[i] = p-step;
            else
              {
               if(Step[i] != 0 && p <= Step[i])
                  trade.PositionClose(TicketList[i]);
              }
           }
         else
           {
            Step[i] = 0;
            TicketList[i] = 0;
           }
        }
     }
  }
//+------------------------------------------------------------------+
