//+------------------------------------------------------------------+
//|                                         CPro Indicator AtrChannel MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot Label1
//#property indicator_label1  "Label1"
//--- plot Label2
//#property indicator_label2  "Label2"
//--- indicator buffers
double         Label1Buffer[];
double         Label2Buffer[];
input int indicatorPeriod = 14;//indicator 周期
input int multiplier=1;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//---- name for DataWindow and indicator subwindow label
   CPro_Init();  // CPro营销模块初始化
   IndicatorShortName(StringFormat("ATR(%i) Channel",indicatorPeriod));
//--- indicator buffers mapping
   SetIndexBuffer(0,Label1Buffer);
   SetIndexLabel(0,"ATR high");
   SetIndexBuffer(1,Label2Buffer);
   SetIndexLabel(1,"ATR low");
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int start()
  {
   int i=Bars-IndicatorCounted()-1;
   double Atr=0;
   double Midpoint=0;
   while(i>=0)
     {
      Atr = (iATR(Symbol(),Period(),indicatorPeriod,i)*multiplier)/2;
      Midpoint=Open[i];
      Label1Buffer[i]=Midpoint + Atr;
      Label2Buffer[i]=Midpoint - Atr;
      i--;
     }
   return (0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int deinit()
  {
   return(0);
  }
//+------------------------------------------------------------------+