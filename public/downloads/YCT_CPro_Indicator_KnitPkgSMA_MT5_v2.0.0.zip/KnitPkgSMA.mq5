//+------------------------------------------------------------------+
//|                                         CPro Indicator KnitPkgSMA MT5                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include "../knitpkg/build/BuildInfo.mqh"
#include "../knitpkg/flat/KnitPkgSMA_flat.mqh"

//---
//--- input parametrs
input int     InpSMAPeriod=10;//周期
//--- indicator buffers
double         SMABuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,SMABuffer,INDICATOR_DATA);
//--- set index labels
   PlotIndexSetString(0,PLOT_LABEL,"KnitPkg SMA("+string(InpSMAPeriod)+")");
//--- indicator name
   IndicatorSetString(INDICATOR_SHORTNAME,"KnitPkg SMA");
//--- indexes draw begin settings
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,InpSMAPeriod);
//--- number of digits of indicator value
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);  
//---
   ArraySetAsSeries(SMABuffer, true); 
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int32_t rates_total,
                const int32_t prev_calculated,
                const int32_t begin,
                const double &price[])
  {
//---
   if (rates_total < InpSMAPeriod)
      return(0);
   if (prev_calculated >= rates_total)
      return rates_total;
   douglasrechia::TimeSeriesArray<double> priceArray(price, prev_calculated - InpSMAPeriod - 1, rates_total-1, false);
   // The following loop recalculates the SMA for the most recent bars.
   // This is necessary because the current bar's data can change with each tick
   // until its formation is complete. The `shiftStart` variable determines
   // the initial index for recalculation, ensuring that the SMA is accurately
   // updated for the latest bar and any preceding bars affected by recent data changes.
   int shiftStart = rates_total-prev_calculated;
   if (shiftStart >= rates_total)
      shiftStart--;
   for (int shift=shiftStart; shift >= 0 && !IsStopped(); shift--)
   {
      SMABuffer[shift] = douglasrechia::SMA(priceArray, InpSMAPeriod, shift);
   }
   return(rates_total);
  }
//+------------------------------------------------------------------+