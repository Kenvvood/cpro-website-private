//+------------------------------------------------------------------+
//|                                         CPro Tool 1h_4h_1d MT4                           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//----
extern int MagicNumber=0;
extern bool SignalMail=False;
extern bool EachTickMode=True;
extern double Lots=3.0;
extern int Slippage=3;
extern bool StopLossMode=True;
extern int StopLoss=75;
extern bool TakeProfitMode=True;
extern int TakeProfit=150;
extern bool TrailingStopMode=True;
extern int TrailingStop=30;
//----
#define SIGNAL_NONE 0
#define SIGNAL_BUY   1
#define SIGNAL_SELL  2
#define SIGNAL_CLOSEBUY 3
#define SIGNAL_CLOSESELL 4
//----
int BarCount;
int Current;
bool TickCheck=False;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
  int init() 
  {
   BarCount=Bars;
   if (EachTickMode) Current=0; else Current=1;
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
  int deinit() 
  {
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
  int start() 
  {
   int Order=SIGNAL_NONE;
   int Total, Ticket;
   double StopLossLevel, TakeProfitLevel;
//----
   if (EachTickMode && Bars!=BarCount) TickCheck=False;
   Total=OrdersTotal();
   Order=SIGNAL_NONE;
   //+------------------------------------------------------------------+
   //| Variable Begin                                                   |
   //+------------------------------------------------------------------+
   double Var1=iMA(NULL, PERIOD_M1, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var2=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var3=iMA(NULL, PERIOD_M1, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var4=iMA(NULL, PERIOD_M1, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var5=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var6=iMA(NULL, PERIOD_M5, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var7=iMA(NULL, PERIOD_M5, 8, +3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var8=iMA(NULL, PERIOD_M5, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var9=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var10=iMA(NULL, PERIOD_M30, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var11=iMA(NULL, PERIOD_M30, 8, +3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Var12=iMA(NULL, PERIOD_M30, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy1_1=iMA(NULL, PERIOD_M1, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy1_2=iMA(NULL, PERIOD_M1, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy2_1=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy2_2=iMA(NULL, PERIOD_M1, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy3_1=iMA(NULL, PERIOD_M1, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy3_2=iMA(NULL, PERIOD_M1, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy4_1=iMA(NULL, PERIOD_M1, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy4_2=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy5_1=iMA(NULL, PERIOD_M1, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy5_2=iMA(NULL, PERIOD_M1, 8, +3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy6_1=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy6_2=iMA(NULL, PERIOD_M1, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy7_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy7_2=iMA(NULL, PERIOD_M5, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy8_1=iMA(NULL, PERIOD_M5, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy8_2=iMA(NULL, PERIOD_M5, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy9_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy9_2=iMA(NULL, PERIOD_M5, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy10_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy10_2=iMA(NULL, PERIOD_M5, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy11_1=iMA(NULL, PERIOD_M5, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy11_2=iMA(NULL, PERIOD_M5, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy12_1=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy12_2=iMA(NULL, PERIOD_M30, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy13_1=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy13_2=iMA(NULL, PERIOD_M30, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy14_1=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy14_2=iMA(NULL, PERIOD_M30, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy15_1=iMA(NULL, PERIOD_M30, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Buy15_2=iMA(NULL, PERIOD_M30, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell1_1=iMA(NULL, PERIOD_M1, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell1_2=iMA(NULL, PERIOD_M1, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell2_1=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell2_2=iMA(NULL, PERIOD_M1, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell3_1=iMA(NULL, PERIOD_M1, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell3_2=iMA(NULL, PERIOD_M1, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell4_1=iMA(NULL, PERIOD_M1, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell4_2=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell5_1=iMA(NULL, PERIOD_M1, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell5_2=iMA(NULL, PERIOD_M1, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell6_1=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell6_2=iMA(NULL, PERIOD_M1, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell7_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell7_2=iMA(NULL, PERIOD_M5, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell8_1=iMA(NULL, PERIOD_M5, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell8_2=iMA(NULL, PERIOD_M5, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell9_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell9_2=iMA(NULL, PERIOD_M5, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell10_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell10_2=iMA(NULL, PERIOD_M5, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell11_1=iMA(NULL, PERIOD_M5, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell11_2=iMA(NULL, PERIOD_M5, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell12_1=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell12_2=iMA(NULL, PERIOD_M30, 64, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell13_1=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell13_2=iMA(NULL, PERIOD_M30, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell14_1=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell14_2=iMA(NULL, PERIOD_M30, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell15_1=iMA(NULL, PERIOD_M30, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double Sell15_2=iMA(NULL, PERIOD_M30, 8, 3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseBuy1_1=iMA(NULL, PERIOD_M1, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseBuy1_2=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseBuy2_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseBuy2_2=iMA(NULL, PERIOD_M30, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseBuy3_1=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseBuy3_2=iMA(NULL, PERIOD_M30, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseSell1_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseSell1_2=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseSell2_1=iMA(NULL, PERIOD_M5, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseSell2_2=iMA(NULL, PERIOD_M1, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseSell3_1=iMA(NULL, PERIOD_M30, 8, -3, MODE_EMA, PRICE_CLOSE, Current + 0);
   double CloseSell3_2=iMA(NULL, PERIOD_M5, 8, 0, MODE_EMA, PRICE_CLOSE, Current + 0);
   //+------------------------------------------------------------------+
   //| Variable End                                                     |
   //+------------------------------------------------------------------+
   //Check position
   bool IsTrade=False;
//----
     for(int i=0; i < Total; i ++) 
     {
      OrderSelect(i, SELECT_BY_POS, MODE_TRADES);
        if(OrderType()<=OP_SELL &&  OrderSymbol()==Symbol()) 
        {
         IsTrade=True;
           if(OrderType()==OP_BUY) 
           {
            //Close
            //+------------------------------------------------------------------+
            //| Signal Begin(Exit Buy)                                           |
            //+------------------------------------------------------------------+
            if (CloseBuy1_1<=CloseBuy1_2 && CloseBuy2_1<=CloseBuy2_2 && CloseBuy3_1<=CloseBuy3_2) Order=SIGNAL_CLOSEBUY;
            //+------------------------------------------------------------------+
            //| Signal End(Exit Buy)                                             |
            //+------------------------------------------------------------------+
              if (Order==SIGNAL_CLOSEBUY && ((EachTickMode && !TickCheck) || (!EachTickMode && (Bars!=BarCount)))) 
              {
               OrderClose(OrderTicket(), OrderLots(), Bid, Slippage, MediumSeaGreen);
               if (SignalMail) SendMail("[Signal Alert]", "[" + Symbol() + "] " + DoubleToStr(Bid, Digits) + " Close Buy");
               if (!EachTickMode) BarCount=Bars;
               IsTrade=False;
               continue;
              }
            //Trailing stop
              if(TrailingStopMode && TrailingStop > 0) 
              {
                 if(Bid - OrderOpenPrice() > Point * TrailingStop) 
                 {
                    if(OrderStopLoss() < Bid - Point * TrailingStop) 
                    {
                     OrderModify(OrderTicket(), OrderOpenPrice(), Bid - Point * TrailingStop, OrderTakeProfit(), 0, MediumSeaGreen);
                     if (!EachTickMode) BarCount=Bars;
                     continue;
                    }
                 }
              }
            }
             else 
            {
            //Close
            //+------------------------------------------------------------------+
            //| Signal Begin(Exit Sell)                                          |
            //+------------------------------------------------------------------+
            if (CloseSell1_1>=CloseSell1_2 && CloseSell2_1>=CloseSell2_2 && CloseSell3_1>=CloseSell3_2) Order=SIGNAL_CLOSESELL;
            //+------------------------------------------------------------------+
            //| Signal End(Exit Sell)                                            |
            //+------------------------------------------------------------------+
              if (Order==SIGNAL_CLOSESELL && ((EachTickMode && !TickCheck) || (!EachTickMode && (Bars!=BarCount)))) 
              {
               OrderClose(OrderTicket(), OrderLots(), Ask, Slippage, DarkOrange);
               if (SignalMail) SendMail("[Signal Alert]", "[" + Symbol() + "] " + DoubleToStr(Ask, Digits) + " Close Sell");
               if (!EachTickMode) BarCount=Bars;
               IsTrade=False;
               continue;
              }
            //Trailing stop
              if(TrailingStopMode && TrailingStop > 0) 
              {
                 if((OrderOpenPrice() - Ask) > (Point * TrailingStop)) 
                 {
                    if((OrderStopLoss() > (Ask + Point * TrailingStop)) || (OrderStopLoss()==0)) 
                    {
                     OrderModify(OrderTicket(), OrderOpenPrice(), Ask + Point * TrailingStop, OrderTakeProfit(), 0, DarkOrange);
                     if (!EachTickMode) BarCount=Bars;
                     continue;
                    }
                 }
              }
           }
        }
     }
   //+------------------------------------------------------------------+
   //| Signal Begin(Entry)                                              |
   //+------------------------------------------------------------------+
   if (Buy1_1>=Buy1_2 && Buy2_1>=Buy2_2 && Buy3_1>=Buy3_2 && Buy4_1>=Buy4_2 && Buy5_1>=Buy5_2 && Buy6_1>=Buy6_2 && Buy7_1>=Buy7_2 && Buy8_1>=Buy8_2 && Buy9_1>=Buy9_2 && Buy10_1==Buy10_2 && Buy11_1>=Buy11_2 && Buy12_1>=Buy12_2 && Buy13_1>=Buy13_2 && Buy14_1>=Buy14_2 && Buy15_1>=Buy15_2) Order=SIGNAL_BUY;
   if (Sell1_1<=Sell1_2 && Sell2_1<=Sell2_2 && Sell3_1<=Sell3_2 && Sell4_1<=Sell4_2 && Sell5_1<=Sell5_2 && Sell6_1<=Sell6_2 && Sell7_1<=Sell7_2 && Sell8_1<=Sell8_2 && Sell9_1<=Sell9_2 && Sell10_1<=Sell10_2 && Sell11_1<=Sell11_2 && Sell12_1<=Sell12_2 && Sell13_1<=Sell13_2 && Sell14_1<=Sell14_2 && Sell15_1<=Sell15_2) Order=SIGNAL_SELL;
   //+------------------------------------------------------------------+
   //| Signal End                                                       |
   //+------------------------------------------------------------------+
   //Buy
     if (Order==SIGNAL_BUY && ((EachTickMode && !TickCheck) || (!EachTickMode && (Bars!=BarCount)))) 
     {
        if(!IsTrade) 
        {
         //Check free margin
           if (AccountFreeMargin() < (1000 * Lots)) 
           {
            Print("We have no money. Free Margin = ", AccountFreeMargin());
            return(0);
           }
         if (StopLossMode) StopLossLevel=Ask - StopLoss * Point; else StopLossLevel=0.0;
         if (TakeProfitMode) TakeProfitLevel=Ask + TakeProfit * Point; else TakeProfitLevel=0.0;
//----
         Ticket=OrderSend(Symbol(), OP_BUY, Lots, Ask, Slippage, StopLossLevel, TakeProfitLevel, "Buy(#" + MagicNumber + ")", MagicNumber, 0, DodgerBlue);
           if(Ticket > 0) 
           {
              if (OrderSelect(Ticket, SELECT_BY_TICKET, MODE_TRADES)) 
              {
               Print("BUY order opened : ", OrderOpenPrice());
               if (SignalMail) SendMail("[Signal Alert]", "[" + Symbol() + "] " + DoubleToStr(Ask, Digits) + " Open Buy");
               }
                else 
               {
               Print("Error opening BUY order : ", GetLastError());
              }
           }
         if (EachTickMode) TickCheck=True;
         if (!EachTickMode) BarCount=Bars;
         return(0);
        }
     }
   //Sell
     if (Order==SIGNAL_SELL && ((EachTickMode && !TickCheck) || (!EachTickMode && (Bars!=BarCount)))) 
     {
        if(!IsTrade) 
        {
         //Check free margin
           if (AccountFreeMargin() < (1000 * Lots)) 
           {
            Print("We have no money. Free Margin = ", AccountFreeMargin());
            return(0);
           }
         if (StopLossMode) StopLossLevel=Bid + StopLoss * Point; else StopLossLevel=0.0;
         if (TakeProfitMode) TakeProfitLevel=Bid - TakeProfit * Point; else TakeProfitLevel=0.0;
//----
         Ticket=OrderSend(Symbol(), OP_SELL, Lots, Bid, Slippage, StopLossLevel, TakeProfitLevel, "Sell(#" + MagicNumber + ")", MagicNumber, 0, DeepPink);
           if(Ticket > 0) 
           {
              if (OrderSelect(Ticket, SELECT_BY_TICKET, MODE_TRADES)) 
              {
               Print("SELL order opened : ", OrderOpenPrice());
               if (SignalMail) SendMail("[Signal Alert]", "[" + Symbol() + "] " + DoubleToStr(Bid, Digits) + " Open Sell");
               }
                else 
               {
               Print("Error opening SELL order : ", GetLastError());
              }
           }
         if (EachTickMode) TickCheck=True;
         if (!EachTickMode) BarCount=Bars;
         return(0);
        }
     }
   if (!EachTickMode) BarCount=Bars;
//----
   return(0);
  }
//+------------------------------------------------------------------+