//+------------------------------------------------------------------+
//|                                         CPro Tool 3_lccfpgubwykd__www_forex_instruments_info MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//----
extern double lStopLoss=17;
extern double sStopLoss=40;
extern double lTrailingStop=88;
extern double sTrailingStop=76;
extern double Lots=0.1;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
  int start()
  {
   int cnt, ticket;
     if(Bars<100)
     {
      Print("bars less than 100");
      return(0);
     }
     if(lStopLoss<10)
     {
      Print("StopLoss less than 10");
      return(0);
     }
     if(sStopLoss<10)
     {
      Print("StopLoss less than 10");
      return(0);
     }
   double diMACD0=iMACD(NULL,60,22,27,9,PRICE_CLOSE,MODE_MAIN,0);
   double diMACD1=iMACD(NULL,60,22,27,9,PRICE_CLOSE,MODE_MAIN,1);
   double diMACD2=iMACD(NULL,60,22,27,9,PRICE_CLOSE,MODE_MAIN,0);
   double diStochastic3=iStochastic
   (NULL,15,5,3,11,MODE_EMA,PRICE_CLOSE,MODE_MAIN,0);
   double d4=(26);
   double diStochastic5=iStochastic
   (NULL,15,5,3,11,MODE_EMA,PRICE_CLOSE,MODE_MAIN,0);
   double diStochastic6=iStochastic
   (NULL,15,5,3,11,MODE_EMA,PRICE_CLOSE,MODE_MAIN,1);
   double diClose7=iClose(NULL,1,0);
   double diHigh8=iHigh(NULL,1,1);
   double diMACD9=iMACD(NULL,60,19,77,9,PRICE_CLOSE,MODE_MAIN,0);
   double diMACD10=iMACD(NULL,60,19,77,9,PRICE_CLOSE,MODE_MAIN,1);
   double diMACD11=iMACD(NULL,60,19,77,9,PRICE_CLOSE,MODE_MAIN,1);
   double diStochastic12=iStochastic(NULL,15,9,3,19,MODE_EMA,PRICE_CLOSE,MODE_MAIN,0);
   double d13=(70);
   double diClose14=iClose(NULL,1,0);
   double diLow15=iLow(NULL,1,1);
//----
   int total=OrdersTotal();
     if(total<1)
     {
        if(AccountFreeMargin()<(1000*Lots))
        {
         Print("We have no money. Free Margin = ", AccountFreeMargin());
         return(0);
        }
        if ((diMACD0>diMACD1 && diMACD2<0 && diStochastic3<d4 && diStochastic5>diStochastic6 && diClose7>diHigh8))
        {
         ticket=OrderSend(Symbol(),OP_BUY,Lots,Ask,3,Ask-lStopLoss*Point,0, "gordago simple",16384,0,Green);
           if(ticket>0)
           {
            if(OrderSelect(ticket,SELECT_BY_TICKET,MODE_TRADES))
               Print("BUY order opened : ",OrderOpenPrice());
           }
         else Print("Error opening BUY order : ",GetLastError());
         return(0);
        }
        if ((diMACD9<diMACD10 && diMACD11>0 && diStochastic12>d13 && diClose14<diLow15))
        {
         ticket=OrderSend(Symbol(),OP_SELL,Lots,Bid,3,Bid+sStopLoss*Point,0,"gordagosample",16384,0,Red);
           if(ticket>0) 
           {
            if(OrderSelect(ticket,SELECT_BY_TICKET,MODE_TRADES))
               Print("SELL order opened : ",OrderOpenPrice());
           }
         else Print("Error opening SELL order : ",GetLastError());
         return(0);
        }
     }
     for(cnt=0;cnt<total;cnt++) 
     {
      OrderSelect(cnt, SELECT_BY_POS, MODE_TRADES);
        if(OrderType()<=OP_SELL && OrderSymbol()==Symbol()) 
        {
           if(OrderType()==OP_BUY)
           {
              if(lTrailingStop>0) 
              {
                 if(Bid-OrderOpenPrice()>Point*lTrailingStop) 
                 {
                    if(OrderStopLoss()<Bid-Point*lTrailingStop) 
                    {
                     OrderModify(OrderTicket(),OrderOpenPrice(),Bid-Point*lTrailingStop,OrderTakeProfit(),0,Green);
                     return(0);
                    }
                 }
              }
            }
            else
            {
              if(sTrailingStop>0) 
              {
                 if((OrderOpenPrice()-Ask)>(Point*sTrailingStop)) 
                 {
                  if((OrderStopLoss()>(Ask+Point*sTrailingStop)) ||
                      (OrderStopLoss()==0)) 
                      {
                     OrderModify(OrderTicket(),OrderOpenPrice(),Ask+Point*sTrailingStop,OrderTakeProfit(),0,Red);
                     return(0);
                    }
                 }
              }
           }
        }
     }
  }
//+------------------------------------------------------------------+