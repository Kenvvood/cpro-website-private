//+------------------------------------------------------------------+
//|                                         CPro Tool tickvalue MT5                          |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input double   InpDividentValue  =  10;//divid结束 值
input double   InpDivisorValue   =  3;//divisor 值
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
//---
   CPro_Init();  // CPro营销模块初始化
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
printf("tickvalue");
printf(SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE));
printf("ticksize");
printf(SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE));
printf("digits");
printf(Digits());
   //- get the real remainder of the division of the numbers entered in the inputs
   double res=MathMod(InpDividentValue,InpDivisorValue);
//--- print the result in the journal
   PrintFormat("Real remainder when dividing %.2f by %.2f = %.2f",InpDividentValue,InpDivisorValue,res);
   printf (SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX)/SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN));
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+