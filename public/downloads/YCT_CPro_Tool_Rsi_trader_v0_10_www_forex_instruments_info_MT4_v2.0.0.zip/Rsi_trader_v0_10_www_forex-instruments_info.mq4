//+------------------------------------------------------------------+
//|                                         CPro Tool Rsi_trader_v0_10_www_forex_instruments_info MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//            \\|//             +-+-+-+-+-+-+-+-+-+-+-+             \\|// 
//           ( o o )            |T|r|a|d|e|r|S|e|v|e|n|            ( o o )
//    ~~~~oOOo~(_)~oOOo~~~~     +-+-+-+-+-+-+-+-+-+-+-+     ~~~~oOOo~(_)~oOOo~~~~
// Run on EUR/USD H1 
// At a certain time a small breakout often occurs.
//----------------------- HISTORY
// v0.10 Initial release.
//----------------------- TODO
// Test other pairs and timeframes.
// Trailing stop
extern int RSIPeriod=14;
extern int Short_price_MA_periods=9;
extern int Long_price_MA_periods=45;
extern int Short_RSI_MA_periods=9;
extern int Long_RSI_MA_periods=45;
extern double Lots=1;
extern int Slippage=3;
//----------------------- MAIN PROGRAM LOOP
//+------------------------------------------------------------------+
//| Relative Strength Index                                          |
//+------------------------------------------------------------------+
int start()
  {
   int arraysize=200;
   double RSI[];
   double RSI_SMA[];
   ArrayResize(RSI,arraysize);
   ArrayResize(RSI_SMA,arraysize);
   ArraySetAsSeries(RSI,true);
//----
   for(int i3=arraysize-1;i3>=0;i3--)
      RSI[i3]=iRSI(NULL,0,RSIPeriod,PRICE_CLOSE,i3);
   for(i3=arraysize-1;i3>=0;i3--)
      RSI_SMA[i3]=iMAOnArray(RSI,0,Short_RSI_MA_periods,0,MODE_SMA,i3);
   double RSI9 =RSI_SMA[1];
//----
   for(i3=arraysize-1;i3>=0;i3--)
      RSI[i3]=iRSI(NULL,0,RSIPeriod,PRICE_CLOSE,i3);
   for(i3=arraysize-1;i3>=0;i3--)
      RSI_SMA[i3]=iMAOnArray(RSI,0,Long_RSI_MA_periods,0,MODE_SMA,i3);
   double RSI45 =RSI_SMA[1];
   double Price45=iMA(NULL,0, Long_price_MA_periods ,0,MODE_LWMA,PRICE_CLOSE,1);
   double Price9 =iMA(NULL,0, Short_price_MA_periods,0,MODE_SMA,PRICE_CLOSE,1);
//----
   bool Long=false;
   bool Short=false;
   bool Sideways=false;
   if(Price9>Price45 && RSI9>RSI45) Long=true;
   if(Price9<Price45 && RSI9<RSI45) Short=true;
   if(Price9>Price45 && RSI9<RSI45) Sideways=true;
   if(Price9<Price45 && RSI9>RSI45) Sideways=true;
   if(Long==true  && OrdersTotal()==0)
     {
      OrderSend(Symbol(),OP_BUY ,Lots,Ask,Slippage,Ask/3,Ask*3,0,0,Blue);
     }
   if(Short==true && OrdersTotal()==0)
     {
      OrderSend(Symbol(),OP_SELL,Lots,Bid,Slippage,Bid*3,Bid/3,0,0,Red);
     }
   if(Sideways==true  && OrdersTotal()!=0)
     {
      OrderSelect(0, SELECT_BY_POS, MODE_TRADES);
      Comment("Sideways detected");
      if(OrderType()==OP_BUY) OrderClose(OrderTicket(),1,Ask,3,Red);
      if(OrderType()==OP_SELL) OrderClose(OrderTicket(),1,Bid,3,Red);
     }
  }
//+------------------------------------------------------------------+