//+------------------------------------------------------------------+
//|                                         CPro Tool CopierOnePosition MT4                  |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


input bool Start = true;
input int Timer = 5000;
input bool   ssl = false;
input string url="localhost";
int Refresh = Timer;  
string apiurl;
void OnInit()
{
   CPro_Init();  // CPro营销模块初始化
 if(Refresh < 5000){ Refresh = 5000; }
 EventSetMillisecondTimer(Refresh);       
   // api url http or https(ssl)
   if(ssl){
      apiurl = "https://" + url + "/api.php"; 
   }
   if(!ssl){
      apiurl = "http://" + url + "/api.php"; 
   }  
}//end
void OnTimer(void)
  {
   if(!Start){ Print("On EA first!"); return;  }   
   char post[];
   char result[];
   string headers;
   int res;   
   string send = "";
   string positions = "";   
   string historyall = "";
   int orders=OrdersTotal();
   for(int i=0;i<orders;i++)
     {
     if(!OrderSelect(i,SELECT_BY_POS,MODE_TRADES)){
     Print("Orders error ",GetLastError());
     break;
     }
         if(OrderType() <= OP_SELL){   
            positions = OrderOpenTime() + ";" + OrderTicket() + ";" + OrderOpenPrice() + ";" + OrderSymbol() + ";" + OrderLots() + ";" + OrderType() + ";" + OrderStopLoss() + ";" + OrderTakeProfit() + ";" + OrderProfit() + ";" + AccountNumber() +"|";
         }
     }
   int ii, hTotal;
   hTotal= OrdersHistoryTotal();
   for(ii=0;ii<hTotal;ii++)
     {
      if(OrderSelect(ii,SELECT_BY_POS,MODE_HISTORY)==false)
        {
         Print("History Error ",GetLastError());
         break;
        }
      if(OrderType()<=OP_SELL)
        {
         historyall = historyall + OrderOpenTime() + ";" + OrderTicket() + ";" + OrderOpenPrice() + ";" + OrderSymbol() + ";" + OrderLots() + ";" + OrderType() + ";" + OrderStopLoss() + ";" + OrderTakeProfit() + ";" + OrderCloseTime() + ";" + OrderClosePrice() + ";" + OrderProfit() + ";" + AccountNumber() +"|";
        }// if end
    }
      send = 
      "&accountid=" +AccountNumber() + 
      "&time=" + TimeCurrent() + 
      "&positions=" + positions +
      "&historyall=" + historyall +
      "&balance=" + AccountBalance() +
      "&equity=" + AccountEquity()+"&end=0";
      Print("Master send: ",send);
      StringToCharArray(send,post);
      ResetLastError();
      res=WebRequest("POST",apiurl,NULL,NULL,50,post,ArraySize(post),result,headers);
      if(res==-1)
        {
         Print("Error code =",GetLastError());
         Print("Add address '"+apiurl+"' in Expert Advisors tab of the Options window","Error",MB_ICONINFORMATION);
        }
      else
        {
         Print("Server response:",CharArrayToString(result,0));
        }      
}//end
//+------------------------------------------------------------------+