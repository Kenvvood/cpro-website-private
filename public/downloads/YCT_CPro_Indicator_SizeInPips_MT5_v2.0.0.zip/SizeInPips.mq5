//+------------------------------------------------------------------+
//|                                         CPro Indicator SizeInPips MT5                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot settings for the histogram
//--- plot settings for the SMA line
input int period = 22;//sma 周期
input double howMuchBig = 10; // How much bigger from ARTR? (in %)
//--- indicator buffers
double CandleSizeBuffer[];
double SMABuffer[];
double OptimumBuffer[];
//--- OnInit function
int OnInit()
{
    //--- Bind the buffers to the indicator
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer(0, CandleSizeBuffer, INDICATOR_DATA);
    SetIndexBuffer(1, SMABuffer, INDICATOR_DATA);
    SetIndexBuffer(2, OptimumBuffer, INDICATOR_DATA);
    // Set Short indicator name
   IndicatorSetString(INDICATOR_SHORTNAME, "Size-In-Pips : ");
    // Set dynamic label for SMA line
   PlotIndexSetString(1,PLOT_LABEL,"SMA("+period+")");
    // Set dynamic label for Optimum
   PlotIndexSetString(2,PLOT_LABEL,"Optimum ("+howMuchBig+"%)");
    //--- Set digits for the indicator
    IndicatorSetInteger(INDICATOR_DIGITS, _Digits);
    return(INIT_SUCCEEDED);
}
//--- OnCalculate function
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
    //--- Ensure rates_total is valid
    if (rates_total <= 0)
        return(0);
    //--- Start calculation from the last calculated bar
    int start = prev_calculated > 0 ? prev_calculated - 1 : 0;
    //--- Calculate the candle size in pips
    for (int i = start; i < rates_total; i++)
    {
        CandleSizeBuffer[i] = NormalizeDouble((high[i] - low[i]) / (_Point), 2);
    }
    //--- Calculate the SMA(period) on the CandleSizeBuffer
    for (int i = start; i < rates_total; i++)
    {
        if (i >= period - 1)
        {
            double sum = 0.0;
            for (int j = 0; j < period; j++)
            {
                sum += CandleSizeBuffer[i - j];
            }
            SMABuffer[i] = NormalizeDouble(sum / period, 2);
        }
        else
        {
            SMABuffer[i] = 0.0; // Not enough data for SMA
        }
    }
    //--- Calculate the Optimum buffer
    for (int i = start; i < rates_total; i++)
    {
        OptimumBuffer[i] = CalculateOptimum(CandleSizeBuffer[i], SMABuffer[i]);
    }
    return(rates_total);
}
//--- Function to calculate Optimum value
int CalculateOptimum(double candleSize, double smaValue)
{
    if (smaValue == 0.0)
        return 0;
    if (candleSize > smaValue * ( 1 + (howMuchBig / 100)))
        return 1;
    return 0;
}