//+------------------------------------------------------------------+
//|                                         CPro Tool Code3 MT5                              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include "..\\Utils\\MetricSaver.mqh"

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
// https://www.mql5.com/en/code/48116  (convertido a EA)
//--- input parameters
input color             InpColorToUP   =  clrLime;//颜色 of the 间隙 up
input color             InpColorToDN   =  clrDeepPink;//颜色 of the 间隙 down
input int maxbars = 300;//how 均线ny K线数 to look back
string prefix;
double price;
datetime lastBarTime = 0;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit() {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   CMetricsSave::Start(FILE_CODE3);
   prefix=MQLInfoString(MQL_PROGRAM_NAME)+"_";
//---
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
   ObjectsDeleteAll(0,prefix);
   ChartRedraw();
   CMetricsSave::Destroy();
   CPro_Deinit();  // CPro营销模块清理
}
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick() {
//---
   datetime currentBarTime = iTime(_Symbol, PERIOD_CURRENT, 0);
   if(lastBarTime == currentBarTime)
      return;
   lastBarTime = currentBarTime;
   MqlRates rates[];
   int copied = CopyRates(_Symbol, PERIOD_CURRENT, 0, maxbars + 10, rates);
   if(copied < 4) return;
   datetime time[];
   double open[];
   double high[];
   double low[];
   double close[];
   ArrayResize(time, copied);
   ArrayResize(open, copied);
   ArrayResize(high, copied);
   ArrayResize(low, copied);
   ArrayResize(close, copied);
   for(int i = 0; i < copied; i++)
     {
      time[i] = rates[i].time;
      open[i] = rates[i].open;
      high[i] = rates[i].high;
      low[i] = rates[i].low;
      close[i] = rates[i].close;
     }
   int rates_total = copied;
   price = close[0];
   ArraySetAsSeries(open,true);
   ArraySetAsSeries(high,true);
   ArraySetAsSeries(low,true);
   ArraySetAsSeries(close,true);
   ArraySetAsSeries(time,true);
   for(int i=maxbars; i>=0 && !IsStopped(); i--) {
      if(low[i]-high[i+2]>=Point()) {
         double up=fmin(high[i],low[i]);
         double dn=fmax(high[i+2],low[i+2]);
         DrawArea(i,up,dn,time,InpColorToUP,1);
      }
      if(low[i+2]-high[i]>=Point()) {
         double up=fmin(high[i+2],low[i+2]);
         double dn=fmax(high[i],low[i]);
         DrawArea(i,up,dn,time,InpColorToDN,0);
      }
   }
}
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void DrawArea(const int index, const double price_up,const double price_dn,const datetime &time[],const color color_area,const char dir) {
   string name=prefix+(dir>0 ? "up_" : "dn_")+TimeToString(time[index]);
   if(ObjectFind(0,name)<0 )
      ObjectCreate(0,name,OBJ_RECTANGLE,0,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
   ObjectSetInteger(0,name,OBJPROP_FILL,true);
   ObjectSetInteger(0,name,OBJPROP_BACK,true);
   ObjectSetString(0,name,OBJPROP_TOOLTIP,"\n");
//---
   ObjectSetInteger(0,name,OBJPROP_COLOR,color_area);
   ObjectSetInteger(0,name,OBJPROP_TIME,0,time[index+2]);
   ObjectSetInteger(0,name,OBJPROP_TIME,1,time[index]);
   ObjectSetDouble(0,name,OBJPROP_PRICE,0,price_up);
   ObjectSetDouble(0,name,OBJPROP_PRICE,1,price_dn);
}
//+------------------------------------------------------------------+