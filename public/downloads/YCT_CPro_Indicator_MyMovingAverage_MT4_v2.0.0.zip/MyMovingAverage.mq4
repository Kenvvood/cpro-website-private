//+------------------------------------------------------------------+
//|                                         CPro Indicator MyMovingAverage MT4               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


//+------------------------------------------------------------------+
//| Global Variables                                                                 |
//+------------------------------------------------------------------+
double                              MainBuffer[];
input int                           MAPeriod = 14;
input int                           MAShift  = 0;
input ENUM_MA_METHOD                MAMethod = MODE_SMA;
input ENUM_APPLIED_PRICE            MAPrice  = PRICE_CLOSE;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
/********************************************************************
   OnInit()
   Initializes Indicator globaal Variables
********************************************************************/
int OnInit()
  {
   CPro_Init();  // CPro营销模块初始化
   IndicatorBuffers( 1 );                    // We have only one indicator
   IndicatorDigits( Digits );                // Digits showwhen visualizing indicator value.
   SetIndexStyle( 0, DRAW_LINE );            // MA shown as a simple line
   SetIndexBuffer( 0, MainBuffer );          // Associate buffer to index.
   SetIndexShift( 0, MAShift );              // Apply user shift
   SetIndexLabel( 0, "MyMovingAverage" );    // Index Label
   ArrayInitialize( MainBuffer ,0);          // Initializes the array
                                             // Check that input parameter is valid
   if(MAPeriod<=0)
     {
      Print("Wrong input parameter MAPeriod");
      return INIT_FAILED;
     }
   return INIT_SUCCEEDED;
  }
//+------------------------------------------------------------------+
//| OnCalculate()                                                    |
//| Indicator Iteration function                                     |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   int i,Start;
// If there are not enough rates,
// i.e less than desired period, we just return. 
   if(rates_total<=MAPeriod)
     {
      return 0;
     }
// We don't use data as series
   ArraySetAsSeries(MainBuffer,false);
   ArraySetAsSeries(close,false);
   if(prev_calculated==0)
     {
      // Calculates first visible value.
      double FirstValue=0;
      Start= MAPeriod;
      for(i=0; i<Start; i++)
        {
         FirstValue+=close[i];
        }
      FirstValue/=MAPeriod;
      MainBuffer[Start-1]=FirstValue;
     }
   else
     {
      Start=prev_calculated-1;
     }
   for(i=Start; i<rates_total && !IsStopped(); i++)
     {
      MainBuffer[i]=MainBuffer[i-1]+(close[i]-close[i-MAPeriod])/MAPeriod;
     }
// Return number of calculated rates.
   return(rates_total);
  }
//+------------------------------------------------------------------+