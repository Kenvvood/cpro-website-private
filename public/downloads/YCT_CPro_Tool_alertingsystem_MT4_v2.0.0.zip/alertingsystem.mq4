//+------------------------------------------------------------------+
//|                                         CPro Tool alertingsystem MT4                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

input double   HigherPrice;
input double   LowerPrice;
string slineid1 = "lineid1";
string slineid2 = "lineid2";
int counter = 0;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
   if (counter==0) {
      ObjectCreate(NULL, slineid1,OBJ_HLINE,0,0,HigherPrice);  //Create Hline of the vlineid1 with price HigherPrice
      ObjectCreate(NULL, slineid2,OBJ_HLINE,0,0,LowerPrice);   //Create Hline of the vlineid1 with price LowerPrice
      ObjectSetInteger(NULL,slineid1,OBJPROP_COLOR,C'38,166,154');   //color the vline of the vlineid
      ObjectSetInteger(NULL,slineid2,OBJPROP_COLOR,C'239,83,80');   //color the vline of the vlineid
      ObjectSetInteger(NULL, slineid1,OBJPROP_SELECTABLE,true);
      ObjectSetInteger(NULL, slineid2,OBJPROP_SELECTABLE,true);
      counter++;
   }
   double val1 = ObjectGetDouble(NULL,slineid1,OBJPROP_PRICE);
   double val2 = ObjectGetDouble(NULL,slineid2,OBJPROP_PRICE);
   ObjectSetDouble(NULL,slineid1,OBJPROP_PRICE,val1);
   ObjectSetDouble(NULL,slineid2,OBJPROP_PRICE,val2);
	if (SymbolInfoDouble(_Symbol,SYMBOL_BID) >= ObjectGetDouble(NULL,slineid1,OBJPROP_PRICE) && ObjectGetDouble(NULL,slineid1,OBJPROP_PRICE)>0.0) {
		PlaySound("alert.wav");
	}
	if (SymbolInfoDouble(_Symbol,SYMBOL_ASK) <= ObjectGetDouble(NULL,slineid2,OBJPROP_PRICE) && ObjectGetDouble(NULL,slineid2,OBJPROP_PRICE)>0.0) {
		PlaySound("alert.wav");
	}
  }
//+------------------------------------------------------------------+