//+------------------------------------------------------------------+
//|                                         CPro EA FINAL_ZONES MT4                          |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

input ENUM_TIMEFRAMES timeframe = PERIOD_H4;
input int recentBarsToCheck = 10;
datetime lastCheckedTime = 0;
int zoneID = 0;
double zoneHighs[100];
double zoneLows[100];
datetime zoneTimes[100];
bool zoneIsReversed[100];
string zoneTypes[100];
//+------------------------------------------------------------------+
int OnInit() {
   return INIT_SUCCEEDED;
}
void OnDeinit(const int reason) {
   for (int i = 0; i < zoneID; i++) {
      ObjectDelete(0, "ZoneHigh_" + IntegerToString(i));
      ObjectDelete(0, "ZoneLow_" + IntegerToString(i));
   }
}
void OnTick() {
//    if (Period() != timeframe) return;
   datetime currentTime = iTime(NULL, timeframe, 0);
   if (currentTime == lastCheckedTime) return;
   lastCheckedTime = currentTime;
   DetectRecentZones();
   HandleReversals();
}
void DetectRecentZones() {
   for (int i = 1; i < 1 + recentBarsToCheck; i++) {  // 🔄 FIXED: was i = 2
      if (IsRegularBuy(i))       { CreateZone("Buy", i+1); break; }
      if (IsIrregularBuy(i))     { CreateZone("Buy", i+1); break; }
      if (IsRegularSell(i))      { CreateZone("Sell", i+1); break; }
      if (IsIrregularSell(i))    { CreateZone("Sell", i+1); break; }
   }
}
void CreateZone(string type, int index) {
   double high = iHigh(NULL, timeframe, index);
   double low = iLow(NULL, timeframe, index);
   datetime startTime = iTime(NULL, timeframe, index);
   datetime endTime = TimeCurrent();
   string nameHigh = "ZoneHigh_" + IntegerToString(zoneID);
   string nameLow  = "ZoneLow_"  + IntegerToString(zoneID);
   int zoneColor = (type == "Buy") ? Lime : Red;
   ObjectCreate(nameHigh, OBJ_TREND, 0, startTime, high, endTime, high);
   ObjectSet(nameHigh, OBJPROP_COLOR, zoneColor);
   ObjectSet(nameHigh, OBJPROP_STYLE, STYLE_DASH);
   ObjectSet(nameHigh, OBJPROP_WIDTH, 1);
   ObjectCreate(nameLow, OBJ_TREND, 0, startTime, low, endTime, low);
   ObjectSet(nameLow, OBJPROP_COLOR, zoneColor);
   ObjectSet(nameLow, OBJPROP_STYLE, STYLE_DASH);
   ObjectSet(nameLow, OBJPROP_WIDTH, 1);
   zoneHighs[zoneID] = high;
   zoneLows[zoneID] = low;
   zoneTimes[zoneID] = startTime;
   zoneIsReversed[zoneID] = false;
   zoneTypes[zoneID] = type;
   zoneID++;
}
void HandleReversals() {
   for (int i = 0; i < zoneID; i++) {
      if (zoneHighs[i] == 0 && zoneLows[i] == 0) continue;
      double high = zoneHighs[i];
      double low  = zoneLows[i];
      string type = zoneTypes[i];
      bool reversed = zoneIsReversed[i];
      if (!reversed) {
         if (type == "Buy" && Close[1] < low) {
            zoneIsReversed[i] = true;
            zoneTypes[i] = "ReversalSell";
            UpdateZoneStyle(i, Red, STYLE_SOLID);
         }
         else if (type == "Sell" && Close[1] > high) {
            zoneIsReversed[i] = true;
            zoneTypes[i] = "ReversalBuy";
            UpdateZoneStyle(i, Lime, STYLE_SOLID);
         }
      }
      else {
         if ((zoneTypes[i] == "ReversalSell" && Close[1] > high) ||
             (zoneTypes[i] == "ReversalBuy" && Close[1] < low)) {
            ObjectDelete("ZoneHigh_" + IntegerToString(i));
            ObjectDelete("ZoneLow_" + IntegerToString(i));
            zoneHighs[i] = 0;
            zoneLows[i] = 0;
         }
      }
   }
}
void UpdateZoneStyle(int id, int newColor, int newStyle) {
   string nameHigh = "ZoneHigh_" + IntegerToString(id);
   string nameLow  = "ZoneLow_" + IntegerToString(id);
   ObjectSet(nameHigh, OBJPROP_COLOR, newColor);
   ObjectSet(nameHigh, OBJPROP_STYLE, newStyle);
   ObjectSet(nameLow, OBJPROP_COLOR, newColor);
   ObjectSet(nameLow, OBJPROP_STYLE, newStyle);
}
//+------------------------------------------------------------------+
//| Pattern Detectors                                                |
//+------------------------------------------------------------------+
bool IsRegularBuy(int i) {
   if (iOpen(NULL, timeframe, i+1) > iClose(NULL, timeframe, i+1))
   if (iOpen(NULL, timeframe, i) < iClose(NULL, timeframe, i))
   if (iClose(NULL, timeframe, i) > iHigh(NULL, timeframe, i+1))
      return true;
   return false;
}
bool IsIrregularBuy(int i) {
   if (iOpen(NULL, timeframe, i+1) > iClose(NULL, timeframe, i+1)) {
      int bullishCount = 0;
      for (int j = i; j >= 1; j--) {
         if (iOpen(NULL, timeframe, j) < iClose(NULL, timeframe, j)) {
            bullishCount++;
            if (bullishCount >= 2 && iClose(NULL, timeframe, j) > iHigh(NULL, timeframe, i+1))
               return true;
         } else break;
      }
   }
   return false;
}
bool IsRegularSell(int i) {
   if (iOpen(NULL, timeframe, i+1) < iClose(NULL, timeframe, i+1))
   if (iOpen(NULL, timeframe, i) > iClose(NULL, timeframe, i))
   if (iClose(NULL, timeframe, i) < iLow(NULL, timeframe, i+1))
      return true;
   return false;
}
bool IsIrregularSell(int i) {
   if (iOpen(NULL, timeframe, i+1) < iClose(NULL, timeframe, i+1)) {
      int bearishCount = 0;
      for (int j = i; j >= 1; j--) {
         if (iOpen(NULL, timeframe, j) > iClose(NULL, timeframe, j)) {
            bearishCount++;
            if (bearishCount >= 2 && iClose(NULL, timeframe, j) < iLow(NULL, timeframe, i+1))
               return true;
         } else break;
      }
   }
   return false;
}