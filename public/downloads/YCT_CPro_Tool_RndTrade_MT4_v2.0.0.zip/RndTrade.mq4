//+------------------------------------------------------------------+
//|                                         CPro Tool RndTrade MT4                           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#define NUM_BUY  20050611
#define NUM_SELL  20050612
int ticket;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
if(OrdersTotal() == 0)
{
   checkForOpen();
}
else
{
   checkForClose();
}
//----
   return(0);
  }
//+------------------------------------------------------------------+
//|                                        |
//+------------------------------------------------------------------+
void checkForOpen()
{
int a = 0;
MathSrand(TimeLocal());
  //  10 .
  for(int i=0;i<10;i++ )
    if(i==5)
    {
      a = MathRand();
      if(a > 16383.5)
      {
      //  
        ticket = OrderSend(Symbol(),OP_BUY,1,Ask,3,0,0,"TestDrawSell",NUM_BUY);
        if (ticket == -1) Alert("    ");
      }
      else
      {
      // 
        ticket = OrderSend(Symbol(),OP_SELL,1,Bid,3,0,0,"TestDrawBuy",NUM_SELL);
        if (ticket == -1) Alert("    ");
      }
    }
    else
    {
      a = MathRand();
    } 
}
//+------------------------------------------------------------------+
//|                                         |
//+------------------------------------------------------------------+
void checkForClose()
{
  if(OrderSelect(0, SELECT_BY_POS)==true)
  {
    if( (OrderOpenTime()+14400) < TimeLocal() )
       if(OrderClose(OrderTicket(),1,Ask,3) == false)
          Print("   ");
  }
  else
  {
    Print("OrderSelect()   - ",GetLastError());
  }
}
//+------------------------------------------------------------------+