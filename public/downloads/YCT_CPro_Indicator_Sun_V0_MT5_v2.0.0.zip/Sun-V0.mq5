//+------------------------------------------------------------------+
//|                                         CPro Indicator Sun_V0 MT5                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//---
input color    i_ColorLong=clrBlue;//farbe 做多
input color    i_ColorShort=clrRed;//farbe 做空
input int      i_DrawBegin=5;                                           // Anfang aussetzen
input string   i_Name0="Kreis";//名称n der sonnenwerte0
input ushort   i_ArrowCode0=159;                                        // ArrowCode0
input int      i_ArrowWidth0=5;//arrow 宽度0
input int      i_ArrowShift0=6;//arrow偏移0
input string   i_Name1="Sonne";//名称n der sonnenwerte1
input ushort   i_ArrowCode1=82;                                         // ArrowCode1
input int      i_ArrowWidth1=5;//arrow 宽度1
input int      i_ArrowShift1=6;//arrow偏移1
//---
int         i_Handle_MA_H;
int         i_Handle_MA_L;
//---
double      i_KreisHigh=0;
double      i_KreisHighLast=0;
double      i_KreisLow=0;
double      i_KreisLowLast=0;
double      i_SunHigh=0;
double      i_SunHighLast=0;
double      i_SunLow=0;
//---
double      i_Buffer_Kreis_Oben[];
double      i_Buffer_Kreis_Oben_Color[];
double      i_Buffer_Kreis_Unten[];
double      i_Buffer_Kreis_Unten_Color[];
double      i_Buffer_Sun_Oben[];
double      i_Buffer_Sun_Oben_Color[];
double      i_Buffer_Sun_Unten[];
double      i_Buffer_Sun_Unten_Color[];
double      i_Buffer_MA_H[];
double      i_Buffer_MA_L[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
//---
   CPro_Init();  // CPro营销模块初始化
   i_Handle_MA_H=iMA(Symbol(),PERIOD_CURRENT,5,0,MODE_SMMA,PRICE_HIGH);
   i_Handle_MA_L=iMA(Symbol(),PERIOD_CURRENT,5,0,MODE_SMMA,PRICE_LOW);
   if(i_Handle_MA_H==INVALID_HANDLE || i_Handle_MA_L==INVALID_HANDLE)
      {
         Print("Indicator handle error");
         return(INIT_FAILED);
      }
//--- indicator buffers mapping
   SetIndexBuffer(0,i_Buffer_Kreis_Oben,INDICATOR_DATA);
   SetIndexBuffer(1,i_Buffer_Kreis_Oben_Color,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(2,i_Buffer_Kreis_Unten,INDICATOR_DATA);
   SetIndexBuffer(3,i_Buffer_Kreis_Unten_Color,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(4,i_Buffer_Sun_Oben,INDICATOR_DATA);
   SetIndexBuffer(5,i_Buffer_Sun_Oben_Color,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(6,i_Buffer_Sun_Unten,INDICATOR_DATA);
   SetIndexBuffer(7,i_Buffer_Sun_Unten_Color,INDICATOR_COLOR_INDEX);
   SetIndexBuffer(8,i_Buffer_MA_H,INDICATOR_DATA);
   SetIndexBuffer(9,i_Buffer_MA_L,INDICATOR_DATA);
//---
   PlotIndexSetInteger(0,PLOT_DRAW_TYPE,DRAW_COLOR_ARROW);
   PlotIndexSetInteger(0,PLOT_ARROW,i_ArrowCode0);
   PlotIndexSetInteger(0,PLOT_ARROW_SHIFT,i_ArrowShift0*-1);
   //PlotIndexSetInteger(0,PLOT_SHIFT,0);
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,i_DrawBegin);
   PlotIndexSetInteger(0,PLOT_COLOR_INDEXES,2);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,0,i_ColorLong);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,1,i_ColorShort);
   PlotIndexSetInteger(0,PLOT_LINE_WIDTH,i_ArrowWidth0);
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,0.0);
   PlotIndexSetString(0,PLOT_LABEL,i_Name0+" Oben");
//---
   PlotIndexSetInteger(1,PLOT_DRAW_TYPE,DRAW_COLOR_ARROW);
   PlotIndexSetInteger(1,PLOT_ARROW,i_ArrowCode0);
   PlotIndexSetInteger(1,PLOT_ARROW_SHIFT,i_ArrowShift0);
   //PlotIndexSetInteger(1,PLOT_SHIFT,0);
   PlotIndexSetInteger(1,PLOT_DRAW_BEGIN,i_DrawBegin);
   PlotIndexSetInteger(1,PLOT_COLOR_INDEXES,3);
   PlotIndexSetInteger(1,PLOT_LINE_COLOR,0,i_ColorLong);
   PlotIndexSetInteger(1,PLOT_LINE_COLOR,1,i_ColorShort);
   PlotIndexSetInteger(1,PLOT_LINE_WIDTH,i_ArrowWidth0);
   PlotIndexSetDouble(1,PLOT_EMPTY_VALUE,0.0);
   PlotIndexSetString(1,PLOT_LABEL,i_Name0+" Unten");
//---
   PlotIndexSetInteger(2,PLOT_DRAW_TYPE,DRAW_COLOR_ARROW);
   PlotIndexSetInteger(2,PLOT_ARROW,i_ArrowCode1);
   PlotIndexSetInteger(2,PLOT_ARROW_SHIFT,i_ArrowShift1*-1);
   //PlotIndexSetInteger(2,PLOT_SHIFT,0);
   PlotIndexSetInteger(2,PLOT_DRAW_BEGIN,i_DrawBegin);
   PlotIndexSetInteger(2,PLOT_COLOR_INDEXES,3);
   PlotIndexSetInteger(2,PLOT_LINE_COLOR,0,i_ColorLong);
   PlotIndexSetInteger(2,PLOT_LINE_COLOR,1,i_ColorShort);
   PlotIndexSetInteger(2,PLOT_LINE_WIDTH,i_ArrowWidth1);
   PlotIndexSetDouble(2,PLOT_EMPTY_VALUE,0.0);
   PlotIndexSetString(2,PLOT_LABEL,i_Name1+" Oben");
//---
   PlotIndexSetInteger(3,PLOT_DRAW_TYPE,DRAW_COLOR_ARROW);
   PlotIndexSetInteger(3,PLOT_ARROW,i_ArrowCode1);
   PlotIndexSetInteger(3,PLOT_ARROW_SHIFT,i_ArrowShift1);
   //PlotIndexSetInteger(3,PLOT_SHIFT,0);
   PlotIndexSetInteger(3,PLOT_DRAW_BEGIN,i_DrawBegin);
   PlotIndexSetInteger(3,PLOT_COLOR_INDEXES,3);
   PlotIndexSetInteger(3,PLOT_LINE_COLOR,0,i_ColorLong);
   PlotIndexSetInteger(3,PLOT_LINE_COLOR,1,i_ColorShort);
   PlotIndexSetInteger(3,PLOT_LINE_WIDTH,i_ArrowWidth1);
   PlotIndexSetDouble(3,PLOT_EMPTY_VALUE,0.0);
   PlotIndexSetString(3,PLOT_LABEL,i_Name1+" Unten");
//---
   PlotIndexSetString(4,PLOT_LABEL,"MA High");
   PlotIndexSetString(5,PLOT_LABEL,"MA Low");
//---
   IndicatorSetString(INDICATOR_SHORTNAME,"TF Sun");
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);
//---
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   CPro_Deinit();  // CPro营销模块清理
//---
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
//---
   int i=prev_calculated;
//---
   CopyBuffer(i_Handle_MA_H,0,0,BarsCalculated(i_Handle_MA_H),i_Buffer_MA_H);
   CopyBuffer(i_Handle_MA_L,0,0,BarsCalculated(i_Handle_MA_L),i_Buffer_MA_L);
//---
   for(i; i<rates_total && !IsStopped(); i++)
      {
         //i_Buffer_Kreis_Oben[i]=high[i];
         //i_Buffer_Kreis_Oben_Color[i]=0;
         //i_Buffer_Kreis_Unten[i]=low[i];
         //i_Buffer_Kreis_Unten_Color[i]=0;
         //i_Buffer_Sun_Oben[i]=high[i];
         //i_Buffer_Sun_Oben_Color[i]=0;
         //i_Buffer_Sun_Unten[i]=low[i];
         //i_Buffer_Sun_Unten_Color[i]=0;
      }
//--- return value of prev_calculated for next call
   return(rates_total);
}
//+------------------------------------------------------------------+