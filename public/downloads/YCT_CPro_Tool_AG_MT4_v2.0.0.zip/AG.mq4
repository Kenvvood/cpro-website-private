//+------------------------------------------------------------------+
//|                                         CPro Tool AG MT4                                 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern double     Lots=     1;
extern double     F_EMA=   15;
extern double     S_EMA=   18;
extern double     SMA=     30;
extern double     ORDER=   10;
extern int        chk=      0;
//+------------------------------------------------------------------+
//|          expert start making money - sometimes                   |
//+------------------------------------------------------------------+
int start()
  {
   int  ticket, total;
   double SAR,SA;
   SAR=iMACD(Symbol(),0,F_EMA,S_EMA,SMA,PRICE_WEIGHTED,MODE_MAIN,1);
   SA=iMACD(Symbol(),0,F_EMA,S_EMA,SMA,PRICE_WEIGHTED,MODE_SIGNAL,1);
   double SAR1,SA1;
   SAR1=iMACD(Symbol(),0,S_EMA*2,F_EMA*2,SMA*2,PRICE_WEIGHTED,MODE_MAIN,1);
   SA1=iMACD(Symbol(),0,S_EMA*2,F_EMA*2,SMA*2,PRICE_WEIGHTED,MODE_SIGNAL,1);
   total=OrdersTotal();
   if(total<ORDER)
     {
      if(AccountFreeMargin()<(1000*Lots))
        {
         Print("NO MONEY = ", AccountFreeMargin());
         return(0);
        }
        {
         chk=1;
         Print("OK OK OK OK OK!");
        }
      if(chk==1)
        {
//------------------ OPEN SEEL ---------------------//
      if((SAR<SA)&&(SA>0)&&(SAR1<SA1)&&(SA1>0))
           {
            ticket=OrderSend(Symbol(),OP_SELL,Lots,Bid,3,0,0,
            "SAR position:",16385,0,Red);
            if(ticket<1)
              {
               if(OrderSelect(ticket,SELECT_BY_TICKET,MODE_TRADES)==False)
                  Print("OPEN SELL ORDER :  ",OrderOpenPrice());
              }
            else
              {
               Print("-----ERROR-----  opening SEEL order : ",GetLastError());
               return(0);
              }
           }
//------------------ OPEN BUY ---------------------//
         if((SAR>SA)&&(SA<0)&&(SAR1>SA1)&&(SA1<0))
           {
            ticket=OrderSend(Symbol(),OP_BUY,Lots,Ask,3,0,0,
            "SAR position:",16385,0,Blue);
            if(ticket<1)
              {
               if(OrderSelect(ticket,SELECT_BY_TICKET,MODE_TRADES)==False)
                  Print("OPEN BUY ORDER ",OrderOpenPrice());
              }
            else
              {
               Print("-----ERROR-----  opening BUY order : ",GetLastError());
               return(0);
              }
           }
        }
      return(0);
     }
 //------------------ CLOSE BUY ---------------------//
     {
      OrderSelect(SELECT_BY_POS, MODE_TRADES);
         if(OrderType()==OP_BUY && OrderSymbol()==Symbol()) 
            if((SAR1<SA1)&&(SA>0))
              {
               OrderClose(OrderTicket(),OrderLots(),Bid,3,Black); // OUT
               return(0); 
 //------------------ CLOSE SELL --------------------//       
              }
        OrderSelect(SELECT_BY_POS, MODE_TRADES);
          if(OrderType()==OP_SELL && OrderSymbol()==Symbol())
           if((SAR1>SA1)&&(SA<0))
              {
               OrderClose(OrderTicket(),OrderLots(),Ask,3,White); // OUT
               return(0);
              }
           }
  return(0);
  }
//+-------------------- GAME OWER --------------------------------+