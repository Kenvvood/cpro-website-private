//+------------------------------------------------------------------+
//|                                         CPro Tool SP_Victor_Template_Trailing_v2 MT5     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


  #include<Trade/Trade.mqh>

//+------------------------------------------------------------------+
//|                  Input Variables                                 |
//+------------------------------------------------------------------+
  input group "Copyright 2024, www.SingularityPartners.ch "
  input double IL = 0.1;//il initial 交易量
  input double SL = 0.05;//止损 停止 亏损 as 百分比 of 余额
  //input double TP = 0.03; // TP Take Profit as Percent of Balance
  input double TPP = 1000;//止盈p take 利润 in 点数
  input double SLP = 2600;//止损p 停止 亏损 in 点数
  input group "EXTRA Inputs"
  input int MAX_POSITION = 1;//均线x positions allowed to be openened
  //Include Files
  CTrade trade; //Trade Class
  // Variables Definitions
  bool signal;
  bool CS; // Close Shorts
  bool CL; // Close Longs
  int LT; // Counter of Long Trades
  int ST; // Counter of Short Trades
  int T; // Counter of Total Trades
  int L; // Code Line
  // Current prices
  double ask;
  double bid;
  // Account information
  double balance;
  double equity;
  double profit;
  // Trailing
  double trailingValue;
  bool readyToBuy;
  bool buyed;
  bool readyToSell;
  // Dashboard info
  input group "Dashboard"
  input int maxLines = 14;
  input double trailingLimit = 50;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
   int OnInit() {
   CPro_Init();  // CPro营销模块初始化
      return(INIT_SUCCEEDED);
   }
//+------------------------------------------------------------------+
//|                  Expert Tester Function                          |
//+------------------------------------------------------------------+
// This function is to calculate CUSTOM CRITERIA for OPTIMIZATION. 
   // The modified code calculates the relative drawdown (RDD) and ... (UR) for optimization purposes in a trading expert advisor. 
   // It uses the TesterStatistics function to retrieve relevant statistics from the backtesting results. 
   // The UR is calculated as the ratio of the sum of profit and initial deposit 
   // to a denominator based on the initial deposit, RDD, and a constant factor. 
   // The UR and RDD are then concatenated into a string and converted back to a double for return.
   double OnTester() {  
         // Calculate REALTIVE DRAWDOWN
         double RDD = TesterStatistics(STAT_EQUITY_DDREL_PERCENT); 
         // Calculate NUMERATOS as the SUM of PROFIT and INITIAL DEPOSIT
         double numerator = TesterStatistics(STAT_PROFIT) + TesterStatistics(STAT_INITIAL_DEPOSIT);
         // Calculate denominator based on initial deposit, RDD and a constant factor
         int month = 5;
         double denominator = TesterStatistics(STAT_INITIAL_DEPOSIT) * month/12 * RDD * 0.01; 
         // Calculate UR as the ratio of Numerator and Denominator
         double UR = numerator / denominator;
         // Convert UR and RDD to strings and concatenate them
         string concatenatedString = DoubleToString(UR, 0) + "." + DoubleToString(RDD, 0); 
         // Convert the concatenated string back to double and return
         return StringToDouble(concatenatedString);
   }
//+------------------------------------------------------------------+
//|                  Expert Tick Function                            |
//+------------------------------------------------------------------+
// Special event handler that is called every time a new quote is received for the symbol the Expert Advisor (EA).
// It's triggered EVERY TIME THE PRICE CHANGES (a new "tick" is received).
   void OnTick() {
      // Update current prices and account information
      UpdateInformation();
      // Count current trades
      CountTrades();
      // Calculate Signal
      CalculateSignal();
      // Update Trailing Information
      if (PositionsTotal() > 0){
        UpdateTrailingValue();
        CheckTrailingValue();
        DrawTrailingLine();
      }
      // Attempt to open long and short positions
      OpenLongs();
      //OpenShorts();
      // Attempt to close long and short positions
      CloseLongs();
      //CloseShorts();
      // Print dashboard information
      PrintDashboard();
   }
//+------------------------------------------------------------------+
//|                  Longs Shorts Counter                            | 
//+------------------------------------------------------------------+
// Function to count operations
   void CountTrades() {
      // Initializes the long (LT), short (ST), and total (T) counters to 0
      LT=0; ST=0; T=0;
      // Go through all open positions
      for(int i = 0; i < PositionsTotal(); i++)
      {
         // Get the ticket for the position
         ulong ticket = PositionGetTicket(i);
         // Select the position by its ticket
         PositionSelectByTicket(ticket);
         // If the position is long (buy)
         if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
         {
               // Increment the long operations counter
               LT ++;
         }
         // If the position is short (sell)
         else if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_SELL)
         {
               // Increment the short operations counter
               ST ++;
         }
         // Updates the total trade counter by adding the long and short trades
         T=(LT+ST);   
      }
   }
//+------------------------------------------------------------------+
//|                  Sensing                                         |
//+------------------------------------------------------------------+
  void CalculateSignal() {
    if (ask >= 2550 && PositionsTotal() < MAX_POSITION) {
        readyToBuy = true;
    }
  }
//+------------------------------------------------------------------+
//|                  Control                                         |
//+------------------------------------------------------------------+
   // Function to verify and activate the stop loss
   void CheckTrailingValue() {
    readyToSell = trailingValue > ask;
   }
//+------------------------------------------------------------------+
//|                  ACTUATION                                       |
//+------------------------------------------------------------------+
   //+------------------------------------------------------------------+
   //|                  TRAILING                                        | 
   //+------------------------------------------------------------------+
   // Function to update trailing value
   void UpdateTrailingValue() {
    if ( trailingValue < (ask - trailingLimit)) {
      trailingValue = ask -trailingLimit;
    }
   }
   void DrawTrailingLine() {
    // Trailing name... 
    string trailingName = "TrailingName";
    // Delete the old support line if it exists
    ObjectDelete(_Symbol, trailingName);
    // Get the time of the current bar
    datetime currentBarTime = iTime(_Symbol, _Period, 0);
    // Create a horizontal line at the support level
    ObjectCreate(_Symbol, trailingName, OBJ_HLINE, 0, currentBarTime, trailingValue);
    // Set the properties of the support line
    ObjectSetInteger(0, trailingName, OBJPROP_COLOR, C'255,147,69');
    ObjectSetInteger(0, trailingName, OBJPROP_WIDTH, 2);
   }
//+------------------------------------------------------------------+
//|                  OPENING LONGS                                   |
//+------------------------------------------------------------------+
// Function to open long positions
   void OpenLongs() {
    if(readyToBuy && PositionsTotal() < MAX_POSITION) {
      // Open a long position with no TP and SL
      trade.Buy(IL, NULL, ask, 0, 0, NULL);
      L = __LINE__; // Save the current line of code
      // Print a message indicating that a long position has been opened
      Print("\n Se ha abierto una posición larga \n");
      readyToBuy = false;
    }
  }
//+------------------------------------------------------------------+
//|                  CLOSING LONGS                                   |
//+------------------------------------------------------------------+
// Function to close long positions
   void CloseLongs() {
      // If the stop loss has been activated for long positions (CL == 1)
      if(readyToSell)
      {
         // Go through all open positions
         for(int i=PositionsTotal()-1;i>=0; i--)
         {
               // Get the ticket for the position
               ulong ticket=PositionGetTicket(i);
               PositionSelectByTicket(ticket);
               // If the position is long
               if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
               {   
                  // Close the position
                  trade.PositionClose(ticket); 
               }
         }
         // Disable stop loss for long positions
         CL=0;
         L=__LINE__; // Save the current line of code
         // Prints a message indicating that the closing of long positions has been confirmed
         Print("CL=1 CONFIRMED. L:",__LINE__);
      }
   }
//+------------------------------------------------------------------+
//|                  DASHBOARD                                       |
//+------------------------------------------------------------------+
// Custom Dashboard
   void PrintDashboard() {
    // Split the commentText into lines
    string commentText = GetComment();
    string lines[];
    StringSplit(commentText, '\n', lines);
    SetBackgroundLabel(ArraySize(lines));
    SetTextLabel(lines);
   }
   string GetComment(){
      return "\n" +
      "© Singularity Partners 2024" + "\n" +
      "CODE LINE:  " + L + "\n" +
      "\n" +
      "------- ACCOUNT ----------------\n" +
      "Balance:   " + StringFormat("%9.0f", balance) + "\n" +
      "Equity:       " + StringFormat("%9.0f", equity) + "\n" +
      "Profit:         " + StringFormat("%9.0f", profit) + "\n" +
      "----------------------------------------\n"
      "\n" +
      "------- USEFULL -----------------\n" +
      "LT: " + LT + " ST: " + ST + " T:" + PositionsTotal() + "\n" +
      "CL: " + CL + " CS: " + CS + "\n" +
      "----------------------------------------\n"
      "\n" +
      "------- SIGNAL -------------------\n" +
      "Buy:    " + readyToBuy + "\n" +
      "Sell:    " + readyToSell + "\n" +
      "Done:    " + buyed + "\n" +
      "--------------------------------------\n"
      "\n" +
      "------- TICKET ------------------\n" +
      AllTicketToString() +
      "-------------------------------------\n"
      "\n" +
      "\n" +
      "\n" +
      "------- TRAILING ---------------\n" +
      "VALUE: " + trailingValue + "\n" +
      "ASK: " + ask + "\n" +
      "-------------------------------------\n"
      ;
   }
   string AllTicketToString() {
      if (PositionsTotal() == 0) return "\nNO OPEN POSITIONS\n\n";
      string result = "";
      for(int i = 0; i < PositionsTotal(); i++){
         ulong ticket = PositionGetTicket(i);
         PositionSelectByTicket(ticket);
         // Get the profit of the position
         double ticketProfit = PositionGetDouble(POSITION_PROFIT);
         // Calculate the time the position has been open in seconds
         ulong openTimeInSeconds = TimeCurrent() - PositionGetInteger(POSITION_TIME);
         // Calculate the remaining time before the position is closed
         // ulong remainingTime = 12000 - openTimeInSeconds;
         result += StringFormat("Ticket: %5d\nProfit: %6s\nOpen Time : %8d(s)\n", 
                        ticket, ticketProfit < 0 ? "- " + DoubleToString(MathAbs(ticketProfit) , 2) : "+ " + DoubleToString(ticketProfit , 2) , 
                        openTimeInSeconds);                      
      }
      return result;
   }
   void SetBackgroundLabel(int lenght){
      // Create a single rectangle for all lines
      string allLinesRectObjName = "RectangleAllLines";
      int row = lenght / maxLines;
      // Create the rectangle
      if (ObjectCreate(0, allLinesRectObjName, OBJ_RECTANGLE_LABEL, 0, 0, 0)) {
      // Set the rectangle's coordinates
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_CORNER, CORNER_LEFT_UPPER);
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_XDISTANCE, 10);
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_YDISTANCE, 20);  // Start from the top
         // Set the rectangle's size
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_XSIZE, 200 + 200 * row);  // Adjust the width as needed
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_YSIZE, 20 * maxLines);  // Height is line height times number of lines
         // Set the rectangle's color
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_COLOR, clrBlack);  // Change clrBlack to your desired color
         // Set the rectangle's background color
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_BGCOLOR, clrBlack);  // Change clrBlack to your desired color
         // Set the rectangle's z-order to be below the labels
         ObjectSetInteger(0, allLinesRectObjName, OBJPROP_ZORDER, 0);
      } else {
         Print("Failed to create rectangle. Error code: ", GetLastError());
      }
   }
   void SetTextLabel(string &lines[]){
      // Create a label for each line
      for (int i = 0; i < ArraySize(lines); i++) {
        string lineObjName = "DashBoardLabel" + IntegerToString(i);
        // Calculate the column and row for this label
        int column = i / maxLines;
        int row = i % maxLines;
        // Create the label
        if (ObjectCreate(0, lineObjName, OBJ_LABEL, 0, 0, 0)) {
            // Set the label's coordinates
            ObjectSetInteger(0, lineObjName, OBJPROP_CORNER, CORNER_LEFT_UPPER);
            ObjectSetInteger(0, lineObjName, OBJPROP_XDISTANCE, 10 + column * 200);  // Adjust the X distance for each column
            ObjectSetInteger(0, lineObjName, OBJPROP_YDISTANCE, 20 + row * 20);  // Adjust the Y distance for each row
            // Set the label's text
            ObjectSetString(0, lineObjName, OBJPROP_TEXT, "      " + lines[i]);
            // Set the label's color
            color labelColor = C'0,255,191';
            if (StringFind(lines[i], "-------") == 0) {
              labelColor = C'255,165,0';
            }
            ObjectSetInteger(0, lineObjName, OBJPROP_COLOR, labelColor);  
            // Set the label's font size
            ObjectSetInteger(0, lineObjName, OBJPROP_FONTSIZE, 7); 
            // Set the label's z-order to be above the black square (ZORDER == 0)
            ObjectSetInteger(0, lineObjName, OBJPROP_ZORDER, 1);
        } else {
            Print("Failed to create label. Error code: ", GetLastError());
        }
      }
   }
//+------------------------------------------------------------------+
//|                  EXTRA FUNCTION                                  |
//+------------------------------------------------------------------+
// Minors functions
   void UpdateInformation()
      {
         // Get current prices
         ask = GetAsk();
         bid = GetBid();
         // Get account information
         balance = GetBalance();
         equity = GetEquity();
         profit = GetProfit();
      }
   double GetAsk() 
      {
         return NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_ASK),_Digits);
      }
   double GetBid() 
      {
         return NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);
      }
   double GetBalance() 
      {
         return NormalizeDouble(AccountInfoDouble(ACCOUNT_BALANCE),0);
      }
   double GetEquity() 
      {
         return NormalizeDouble(AccountInfoDouble(ACCOUNT_EQUITY),0);
      }
   double GetProfit() 
   {
      return NormalizeDouble(AccountInfoDouble(ACCOUNT_PROFIT),0);
   }