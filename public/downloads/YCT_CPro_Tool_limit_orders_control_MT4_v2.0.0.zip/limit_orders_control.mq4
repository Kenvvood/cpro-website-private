//+------------------------------------------------------------------+
//|                                         CPro Tool limit_orders_control MT4               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#include <stderror.mqh>
#include <stdlib.mqh>

input int MagicNumber=0;
input bool WriteComments=true;
static bool work=true;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
   work=true;
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
   int countOrders=0;
   if(OrdersTotal()>0)
     {
      for(int c=0; c<OrdersTotal(); c++)
        {
         if(OrderSelect(c,SELECT_BY_POS))
           {
            if(OrderMagicNumber()==MagicNumber && OrderSymbol()==Symbol())
              {
               if(OrderType()==OP_BUYLIMIT || OrderType()==OP_BUYSTOP || OrderType()==OP_SELLLIMIT || OrderType()==OP_SELLSTOP)
                 {
                  countOrders++;
                 }
              }
           }
        }
     }
   string txt="";
   if(WriteComments)
     {
      txt=txt+"We have "+(string)countOrders+" open orders\n";
      if(work)
        {
         txt=txt+"Limit Orders Control - work\n";
           }else{
         txt=txt+"Limit Orders Control - STOPPED\n";
        }
      Comment(txt);
     }
   if(!work){ return; }
   if(countOrders<2)
     {
      DeleteOrders();
     }
   if(countOrders<1)
     {
      work=false;
      Alert("Limit Orders Control - Stopped ",_Symbol);
     }
  }
//+------------------------------------------------------------------+
void DeleteOrders()
  {
   int t;
   if(IsTradeAllowed())
     {
      for(int c=0; c<=OrdersTotal();c++)
        {
         if(OrderSelect(c,SELECT_BY_POS,MODE_TRADES))
            if(OrderSymbol()==Symbol() && OrderMagicNumber()==MagicNumber)//
              {
               if(OrderType()==OP_BUYLIMIT || OrderType()==OP_BUYSTOP || OrderType()==OP_SELLLIMIT || OrderType()==OP_SELLSTOP)
                 {
                  for(t=0; t<=5; t++)
                    {
                     RefreshRates();
                     int ticket=OrderDelete(OrderTicket(),clrRed);
                     int e=GetLastError();
                     if(e==0)
                       {
                        break;
                          }else{
                        Print("Try ",c+1," delete orders, error : ",ErrorDescription(e));
                        Sleep(100);
                       }
                    }
                 }
              }
        }
     }
   return;
  }
//+------------------------------------------------------------------+