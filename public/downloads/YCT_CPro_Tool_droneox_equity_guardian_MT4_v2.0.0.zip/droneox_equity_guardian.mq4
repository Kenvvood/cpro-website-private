//+------------------------------------------------------------------+
//|                                         CPro Tool droneox_equity_guardian MT4            |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#include <WinUser32.mqh>

extern string EAName="Equity Guardian";
extern string Copyright="Droneox";
extern bool CloseOrder=TRUE; //Close All Order
extern bool disableexpert=TRUE; //Disable Expert Advisor
extern double EquityTarget=999999; //Equity Take Profit (USD)
extern double EquityStop=0; //Equity Stop Loss (USD)
//+------------------------------------------------------------------+
//| check live trading and dll                                       |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(!IsTradeAllowed() && !IsDllsAllowed())
     {
      Alert("Please Allow Live Trading and DLL Import");
      return(1);
     }
   else if(!IsTradeAllowed())
     {
      Alert("Please Allow Live Trading");
      return(1);
     }
   else if(!IsDllsAllowed())
     {
      Alert("Please Allow DLL Import");
      return(1);
     }
   else
     {
      return(0);
     }
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int start()
  {
   double equity=AccountEquity();
   double accbalance=AccountBalance();
   int total=OrdersTotal();
   if(IsExpertEnabled())
     {
      if(equity<=EquityStop)
        {
         if(total!=0 && CloseOrder==TRUE)
           {
            CloseAllTrade();
           }
         if(disableexpert)
           {
            DisableEA();
           }
         Print("Equity Guardian reach equity stop level");
        }
      if(equity>=EquityTarget)
        {
         if(total!=0 && CloseOrder==TRUE)
           {
            CloseAllTrade();
           }
         if(disableexpert)
           {
            DisableEA();
           }
         Print("Equity Guardian reach equity Target level");
        }
     }
   return(0);
  }
//disable autotrading
void DisableEA() 
  {
   keybd_event(17,0,0,0);
   keybd_event(69,0,0,0);
   keybd_event(69,0,2,0);
   keybd_event(17,0,2,0);
  }
//close all open trade
int CloseAllTrade() 
  {
   int total=OrdersTotal();
   int t;
   int cnt=0;
   for(cnt=0; cnt<=total; cnt++)
     {
      bool s=OrderSelect(0,SELECT_BY_POS,MODE_TRADES);
      if(OrderType()==OP_BUY)
         t=OrderClose(OrderTicket(),OrderLots(),MarketInfo(OrderSymbol(),MODE_BID),5,Violet);
      if(OrderType()==OP_SELL)
         t=OrderClose(OrderTicket(),OrderLots(),MarketInfo(OrderSymbol(),MODE_ASK),5,Violet);
      if(OrderType()>OP_SELL) //pending orders
         t=OrderDelete(OrderTicket());
     }
   return(0);
  }
//+------------------------------------------------------------------+