//+------------------------------------------------------------------+
//|                                         CPro Indicator KijunSenEnvelope MT5              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input int Kijun_Sen_Period = 100;//kijun sen 周期
input int Envelope_Deviation = 230;//envelope 偏移量
input int ShiftKijun = 0;//偏移
double Kijun_Buffer_1[];
double Kijun_Buffer_2[];
double Kijun_Buffer_3[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    int begin = Kijun_Sen_Period + ShiftKijun - 1;
    SetIndexBuffer(0, Kijun_Buffer_1);
    PlotIndexSetInteger(0, PLOT_DRAW_BEGIN, begin);
    PlotIndexSetInteger(0, PLOT_SHIFT, ShiftKijun);
    SetIndexBuffer(1, Kijun_Buffer_2);
    PlotIndexSetInteger(1, PLOT_DRAW_BEGIN, begin);
    PlotIndexSetInteger(1, PLOT_SHIFT, ShiftKijun);
    SetIndexBuffer(2, Kijun_Buffer_3);
    PlotIndexSetInteger(2, PLOT_DRAW_BEGIN, begin);
    PlotIndexSetInteger(2, PLOT_SHIFT, ShiftKijun);
    return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
    ArraySetAsSeries(high, true);
    ArraySetAsSeries(low, true);
    ArraySetAsSeries(Kijun_Buffer_1, true);
    ArraySetAsSeries(Kijun_Buffer_2, true);
    ArraySetAsSeries(Kijun_Buffer_3, true);
    int Bars = rates_total;
    int counted_bars = prev_calculated;
    int i, k;
    double highx, lowx, pricex;
    if (Bars <= Kijun_Sen_Period) return (0);
    if (counted_bars < 1) {
        for (i = 1; i <= Kijun_Sen_Period; i++)
            Kijun_Buffer_1[Bars - i] = 0;
        Kijun_Buffer_2[Bars - i] = 0;
        Kijun_Buffer_3[Bars - i] = 0;
    }
    i = Bars - Kijun_Sen_Period;
    if (counted_bars > Kijun_Sen_Period) i = Bars - counted_bars - 1;
    while (i >= 0) {
        highx = high[i];
        lowx = low[i];
        k = i - 1 + Kijun_Sen_Period;
        while (k >= i) {
            pricex = high[k];
            if (highx < pricex) highx = pricex;
            pricex = low[k];
            if (lowx > pricex) lowx = pricex;
            k--;
        }
        Kijun_Buffer_1[i + ShiftKijun] = ((highx + lowx) / 2) + Envelope_Deviation * _Point;
        Kijun_Buffer_2[i + ShiftKijun] = ((highx + lowx) / 2);
        Kijun_Buffer_3[i + ShiftKijun] = ((highx + lowx) / 2) - Envelope_Deviation * _Point;
        i--;
    }
    i = ShiftKijun - 1;
    return(rates_total);
}
//+------------------------------------------------------------------+