//+------------------------------------------------------------------+
//|                                         CPro Tool analyzehistory MT4                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

#define  Sunday   0     // as returned by TimeDayOfWeek()
#define  Friday   5     // as returned by TimeDayOfWeek()
input  uint    MinGapInBars               = 10;                                                 // minimum gap detected (in number of bars)
// print starting date on initialization
int OnInit() 
{        
   Print("History starts from ",TimeToStr(Time[0],TIME_DATE));
   return(INIT_SUCCEEDED);
}
// scan history looking for gaps
void OnTick(void)
{  
   if(Time[0]-Time[1]>MinGapInBars*60*Period())                                                 // gap detected
      if(TimeDayOfWeek(Time[0]) != Sunday  ||  TimeDayOfWeek(Time[1]) != Friday)                // gap not due to the weekend
         Print("gap from ",TimeToStr(Time[1])," to ",TimeToStr(Time[0]));            
}
// print ending date on deinitialization
void OnDeinit(const int reason) 
{
   Print("History ends on ",TimeToStr(Time[0],TIME_DATE));
   return;
}