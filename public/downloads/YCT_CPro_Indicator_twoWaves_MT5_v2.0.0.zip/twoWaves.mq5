//+------------------------------------------------------------------+
//|                                         CPro Indicator twoWaves MT5                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- plot wave1high
//--- plot wave1low
//--- plot wave2high
//--- plot wave2low
//--- indicator buffers
double         wave1highBuffer[];
double         wave1lowBuffer[];
double         wave2highBuffer[];
double         wave2lowBuffer[];
//--- input parameters
input ENUM_TIMEFRAMES TF = PERIOD_CURRENT;
//--- global variables
int pos;
double w1High;
double w1Low;
double p_w2High;//potential wave two high
double w2High;
double p_w2Low;//potential wave two low
double w2Low;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,wave1highBuffer,INDICATOR_DATA);
   SetIndexBuffer(1,wave1lowBuffer,INDICATOR_DATA);
   SetIndexBuffer(2,wave2highBuffer,INDICATOR_DATA);
   SetIndexBuffer(3,wave2lowBuffer,INDICATOR_DATA);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
//---
   pos = prev_calculated -1;
   if(pos < 3){
      pos = 3;
   }
   for(int i=pos; i<rates_total; i++){
      //wave one high
      if(close[i-2] > open[i-2] && close[i-1] < open[i-1]){
         p_w2Low = low[i-1]; //reset potential wave two low
         if(high[i-2] > high[i-1]) w1High = high[i-2];
         else w1High = high[i-1];
      }
      //wave one low
      if(close[i-2] < open[i-2] && close[i-1] > open[i-1]){
         p_w2High = high[i-1]; //reset potential wave two low
         if(low[i-2] < low[i-1]) w1Low = low[i-2];
         else w1Low = low[i-1];
      }
      //wave two high
      if(high[i-1] > p_w2High) p_w2High = high[i-1];
      if(close[i-1] < w1Low && close[i-2] > w1Low){
         w2High = p_w2High;
      }
      //wave two low
      if(low[i-1] < p_w2Low) p_w2Low = low[i-1];
      if(close[i-1] > w1High && close[i-2] < w1High){
         w2Low = p_w2Low;
      }
      //pass the values to the indicator buffers
      wave1highBuffer[i] = w1High;
      wave1lowBuffer[i] = w1Low;
      wave2highBuffer[i] = w2High;
      wave2lowBuffer[i] = w2Low;
   }
//--- return value of prev_calculated for next call
   return(rates_total);
  }
//+------------------------------------------------------------------+