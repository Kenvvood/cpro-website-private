//+------------------------------------------------------------------+
//|                                         CPro EA OnTimer MT5                              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//---
input int shift=0;
//---
ulong MagicNumber=12;
//---
int TakeProfitDist=25, StopLossDist=25;
//---
static bool was_position=false;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- create timer
   CPro_Init();  // CPro营销模块初始化
   EventSetTimer(1);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   CPro_Deinit();  // CPro营销模块清理
//--- destroy timer
   EventKillTimer();
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
  }
//+------------------------------------------------------------------+
//| Timer function                                                   |
//+------------------------------------------------------------------+
void OnTimer()
  {
//---
   MqlTick tick_array[];
//---
   ulong start_time=iTime(_Symbol,PERIOD_M1,0);
//---
   int copied_ticks=CopyTicks(_Symbol,tick_array,COPY_TICKS_ALL,start_time);
//---
   static int last_size=0;
//---
   for(int i=last_size; i<ArraySize(tick_array); i++)
     {
      //---
      last_size++;
      //---
      bool buy_tick=((tick_array[i].flags&TICK_FLAG_BUY)==TICK_FLAG_BUY+25);
      bool sell_tick=((tick_array[i].flags&TICK_FLAG_SELL)==TICK_FLAG_SELL+25);
      //---
      string buyorsell="";
      //---
      if(buy_tick&&isbearish(shift))
        {
         if(!IsPosition() && OrderCount()==0)
           {
            //---
            double filledbuyPrice;
            //---
            bool buyordersend_mkt=BuyOrderMarket(filledbuyPrice);
            //---
            if(!buyordersend_mkt)
              {
               //---
               Print("Error has occured!!");
              }
            else
              {
               //---
               double filled_buy_price=filledbuyPrice;
               //---
               double tp_price_buy=filled_buy_price+TakeProfitDist*_Point;
               //---
               bool tp_send_buy=SendTakeProfitLong(tp_price_buy);
               //---
               if(!tp_send_buy)
                 {
                  //---
                  Print("Send Take Profit function failed Long!!!");
                 }
               else
                 {
                  //---
                  double sl_price_buy=filled_buy_price-StopLossDist*_Point;
                  //---
                  if(!SendStopLossLong(sl_price_buy))
                    {
                     //---
                     Print("Send Stop Loss function failed!!!");
                    }
                  else
                    {
                     //---
                     Print("Send StopLoss function sucessfully executed");
                     //---
                     Print("All orders have been sucessfully executed.... we are now waiting for sl or tp trigger....");
                     //---
                     was_position=true;
                    }
                 }
              }
           }
         //---
         break;
         buyorsell="buy";
        }
      //---
      if(sell_tick&&isbullish(shift))
        {
         if(!IsPosition() && OrderCount()==0)
           {
            //---
            double filledsellPrice;
            //---
            bool sellordersend_mkt=SellOrderMarket(filledsellPrice);
            //---
            if(!sellordersend_mkt)
              {
               //---
               Print("Error has occured!!");
              }
            else
              {
               //---
               double filled_sell_price=filledsellPrice;
               //---
               double tp_price_sell=NormalizeDouble(filled_sell_price-TakeProfitDist*_Point,_Digits);
               //---
               bool tp_send_sell=SendTakeProfitShort(tp_price_sell);
               //---
               if(!tp_send_sell)
                 {
                  //---
                  Print("Send TakeProfit function failed Short!!!");
                 }
               else
                 {
                  //---
                  double sl_price_sell=filled_sell_price+StopLossDist*_Point;
                  //---
                  if(!SendStopLossShort(sl_price_sell))
                    {
                     //---
                     Print("Send StopLoss function failed!!!");
                    }
                  else
                    {
                     //---
                     Print("Send StopLoss function sucessfully executed");
                     //---
                     Print("All orders have been sucessfully executed.... we are now waiting for sl or tp trigger....");
                     //---
                     was_position=true;
                    }
                 }
              }
           }
         //---
         break;
        }
     }
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| isbullish                                                        |
//+------------------------------------------------------------------+
bool isbullish(int shift)
  {
//---
   double close=(iClose(_Symbol,PERIOD_CURRENT,shift));
//---
   double open=(iOpen(_Symbol,PERIOD_CURRENT,shift));
//---
   if(close>open)
     {
      return(true);
     }
   else
     {
      return(false);
     }
//---
  }
//+------------------------------------------------------------------+
//| isbearish                                                        |
//+------------------------------------------------------------------+
bool isbearish(int shift)
  {
//---
   double close=(iClose(_Symbol,PERIOD_CURRENT,shift));
//---
   double open=(iOpen(_Symbol,PERIOD_CURRENT,shift));
//---
   if(close<open)
     {
      return(true);
     }
   else
     {
      return(false);
     }
//---
  }
//+------------------------------------------------------------------+
//| IsNewBar                                                         |
//+------------------------------------------------------------------+
bool IsNewBar()
  {
//---
   datetime time_now=iTime(_Symbol,PERIOD_CURRENT,0);
//---
   static datetime last_time=0;
//---
   if(time_now!=last_time)
     {
      //---
      last_time=time_now;
      //---
      return(true);
     }
   else
     {
      return(false);
     }
//---
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| BuyOrderMarket                                                   |
//+------------------------------------------------------------------+
bool BuyOrderMarket(double &filled_buy_price)
  {
//---
   MqlTradeRequest trade_request;
//---
   MqlTradeResult trade_result;
//---
   ZeroMemory(trade_request);
//---
   trade_request.action=TRADE_ACTION_DEAL;
//---
   trade_request.magic=MagicNumber;
//---
   trade_request.symbol=_Symbol;
//---
   trade_request.volume=1;
//---
   trade_request.price=SymbolInfoDouble(_Symbol,SYMBOL_ASK);
//---
   trade_request.type=ORDER_TYPE_BUY;
//---
   trade_request.type_filling=ORDER_FILLING_RETURN;
//---
   trade_request.comment="My super EA";
//---
   bool ordersend_result=OrderSend(trade_request,trade_result);
//---
   if(!ordersend_result)
     {
      //---
      Print("Order send Market failed, error code=",trade_result.retcode);
      //---
      return(false);
     }
   else
     {
      //---
      Print("Order send Market sucessfully done @",trade_result.price);
      //---
      filled_buy_price=trade_result.price;
      //---
      return(true);
     }
//---
  }
//+------------------------------------------------------------------+
//| SendTakeProfitLong                                               |
//+------------------------------------------------------------------+
bool SendTakeProfitLong(double tp_price_long)
  {
//---
   MqlTradeRequest trade_request_tp;
//---
   MqlTradeResult trade_result_tp;
//---
   ZeroMemory(trade_request_tp);
//---
   trade_request_tp.action=TRADE_ACTION_PENDING;
//---
   trade_request_tp.magic=MagicNumber;
//---
   trade_request_tp.symbol=_Symbol;
//---
   trade_request_tp.volume=1;
//---
   trade_request_tp.price=tp_price_long;
//---
   trade_request_tp.type=ORDER_TYPE_SELL_LIMIT;
//---
   trade_request_tp.type_filling=ORDER_FILLING_RETURN;
//---
   trade_request_tp.type_time=ORDER_TIME_DAY;
//---
   bool ordersend_result_tp=OrderSend(trade_request_tp,trade_result_tp);
//---
   if(!ordersend_result_tp)
     {
      //---
      Print("Error has occured!! Error code=",trade_result_tp.retcode);
      //---
      return(false);
     }
   else
     {
      //---
      Print("Take Profit Order was sucessfully filled... @",trade_result_tp.price);
      //---
      return(true);
     }
//---
  }
//+------------------------------------------------------------------+
//| SendStopLossLong                                                 |
//+------------------------------------------------------------------+
bool SendStopLossLong(double sl_price_long)
  {
//---
   MqlTradeRequest trade_request_sl;
//---
   MqlTradeResult trade_result_sl;
//---
   ZeroMemory(trade_request_sl);
//---
   trade_request_sl.action=TRADE_ACTION_PENDING;
//---
   trade_request_sl.magic=MagicNumber;
//---
   trade_request_sl.symbol=_Symbol;
//---
   trade_request_sl.volume=1;
//---
   trade_request_sl.price=sl_price_long;
//---
   trade_request_sl.type=ORDER_TYPE_SELL_STOP;
//---
   trade_request_sl.type_filling=ORDER_FILLING_RETURN;
//---
   trade_request_sl.type_time=ORDER_TIME_DAY;
//---
   bool ordersend_result_sl=OrderSend(trade_request_sl,trade_result_sl);
//---
   if(!ordersend_result_sl)
     {
      //---
      Print("Error has occured!! Error code=",trade_result_sl.retcode);
      //---
      return(false);
     }
   else
     {
      //---
      Print("Stop Loss Order was sucessfully filled... @",trade_result_sl.price);
      //---
      return(true);
     }
//---
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| SellOrderMarket                                                  |
//+------------------------------------------------------------------+
bool SellOrderMarket(double &filled_sell_price)
  {
//---
   MqlTradeRequest trade_request;
//---
   MqlTradeResult trade_result;
//---
   ZeroMemory(trade_request);
//---
   trade_request.action=TRADE_ACTION_DEAL;
//---
   trade_request.magic=MagicNumber;
//---
   trade_request.symbol=_Symbol;
//---
   trade_request.volume=1;
//---
   trade_request.price=SymbolInfoDouble(_Symbol,SYMBOL_BID);
//---
   trade_request.type=ORDER_TYPE_SELL;
//---
   trade_request.type_filling=ORDER_FILLING_RETURN;
//---
   trade_request.comment="My super EA";
//---
   bool ordersend_result=OrderSend(trade_request,trade_result);
//---
   if(!ordersend_result)
     {
      //---
      Print("Order send Market failed, error code=",trade_result.retcode);
      //---
      return(false);
     }
   else
     {
      //---
      Print("Order send Market sucessfully done @",trade_result.price);
      //---
      filled_sell_price=trade_result.price;
      //---
      return(true);
     }
//---
  }
//+------------------------------------------------------------------+
//| SendTakeProfitShort                                              |
//+------------------------------------------------------------------+
bool SendTakeProfitShort(double tp_price_short)
  {
//---
   MqlTradeRequest trade_request_tp;
//---
   MqlTradeResult trade_result_tp;
//---
   ZeroMemory(trade_request_tp);
//---
   trade_request_tp.action=TRADE_ACTION_PENDING;
//---
   trade_request_tp.magic=MagicNumber;
//---
   trade_request_tp.symbol=_Symbol;
//---
   trade_request_tp.volume=1;
//---
   trade_request_tp.price=tp_price_short;
//---
   trade_request_tp.type=ORDER_TYPE_BUY_LIMIT;
//---
   trade_request_tp.type_filling=ORDER_FILLING_RETURN;
//---
   trade_request_tp.type_time=ORDER_TIME_DAY;
//---
   bool ordersend_result_tp=OrderSend(trade_request_tp,trade_result_tp);
//---
   if(!ordersend_result_tp)
     {
      //---
      Print("Error has occured!! Error code=",trade_result_tp.retcode);
      //---
      return(false);
     }
   else
     {
      //---
      Print("Take Profit Order was sucessfully filled... @",trade_result_tp.price);
      //---
      return(true);
     }
//---
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| SendStopLossShort                                                |
//+------------------------------------------------------------------+
bool SendStopLossShort(double sl_price_short)
  {
//---
   MqlTradeRequest trade_request_sl;
//---
   MqlTradeResult trade_result_sl;
//---
   ZeroMemory(trade_request_sl);
//---
   trade_request_sl.action=TRADE_ACTION_PENDING;
//---
   trade_request_sl.magic=MagicNumber;
//---
   trade_request_sl.symbol=_Symbol;
//---
   trade_request_sl.volume=1;
//---
   trade_request_sl.price=sl_price_short;
//---
   trade_request_sl.type=ORDER_TYPE_BUY_STOP;
//---
   trade_request_sl.type_filling=ORDER_FILLING_RETURN;
//---
   trade_request_sl.type_time=ORDER_TIME_DAY;
//---
   bool ordersend_result_sl=OrderSend(trade_request_sl,trade_result_sl);
//---
   if(!ordersend_result_sl)
     {
      //---
      Print("Error has occured!! Error code=",trade_result_sl.retcode);
      //---
      return(false);
     }
   else
     {
      //---
      Print("Stop LossOrder was sucessfully filled... @",trade_result_sl.price);
      //---
      return(true);
     }
//---
  }
//+------------------------------------------------------------------+
//| IsPosition                                                       |
//+------------------------------------------------------------------+
bool IsPosition()
  {
//---
   bool result=false;
//---
   for(int i=0; i<PositionsTotal(); i++)
     {
      //---
      ulong ticket=PositionGetTicket(i);
      //---
      if(!PositionSelectByTicket(ticket))
         continue;
      //---
      if(PositionGetString(POSITION_SYMBOL)!=_Symbol)
         continue;
      //---
      if(PositionGetInteger(POSITION_MAGIC)!=MagicNumber)
         continue;
      //---
      result=true;
      //---
      break;
     }
//---
   return(result);
  }
//+------------------------------------------------------------------+
//| OrderCount                                                       |
//+------------------------------------------------------------------+
int OrderCount()
  {
//---
   int result=0;
//---
   for(int i=0; i<OrdersTotal(); i++)
     {
      //---
      ulong ticket=OrderGetTicket(i);
      //---
      if(!OrderSelect(ticket))
         continue;
      //---
      if(OrderGetString(ORDER_SYMBOL)!=_Symbol)
         continue;
      //---
      if(OrderGetInteger(ORDER_MAGIC)!=MagicNumber)
         continue;
      //---
      result++;
     }
//---
   return(result);
  }
//+------------------------------------------------------------------+
//| OrdersMonitioring                                                |
//+------------------------------------------------------------------+
void OrdersMonitioring()
  {
//---
   if(!IsPosition())
     {
      //---
      if(was_position)
        {
         //---
         if(OrderCount()>0)
           {
            //---
            OrdersDeleteAll();
            //---
            was_position=false;
           }
        }
     }
//---
  }
//+------------------------------------------------------------------+
//| OrdersDeleteAll                                                  |
//+------------------------------------------------------------------+
void OrdersDeleteAll()
  {
//---
   for(int i=0 ; i<OrdersTotal(); i++)
     {
      //---
      ulong ticket=OrderGetTicket(i);
      //---
      if(!OrderSelect(ticket))
         continue;
      //---
      if(OrderGetString(ORDER_SYMBOL)!=_Symbol)
         continue;
      //---
      if(OrderGetInteger(ORDER_MAGIC)!=MagicNumber)
         continue;
      //---
      MqlTradeRequest trade_request_delete;
      //---
      MqlTradeResult trade_result_delete;
      //---
      ZeroMemory(trade_request_delete);
      //---
      trade_request_delete.action=TRADE_ACTION_REMOVE;
      //---
      trade_request_delete.symbol=_Symbol;
      //---
      trade_request_delete.order=ticket;
      //---
      bool ordersend_result_delete=OrderSend(trade_request_delete,trade_result_delete);
      //---
      if(!ordersend_result_delete)
        {
         //---
         Print("Error has occured!! Error code=",trade_result_delete.retcode);
         //---
         //return(false);
        }
      else
        {
         //---
         Print("Order was sucessfully deleted... @",trade_result_delete.price);
         //---
         //return(true);
        }
     }
//---
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+