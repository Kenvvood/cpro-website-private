//+------------------------------------------------------------------+
//|                                         CPro EA hpcs_fastslowmacrosssover_mt4_v01_we MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

input string is_start = "HH:MM" ;
input string is_stop = "HH:MM" ;
input int ii_takeprofit = 10;
input int ii_stoploss = 10;
input int ii_lots = 1;
input int ii_fastMAPeriod = 14;   // Fast Moving Average Period
input int ii_slowMAPeriod = 21;   // Slow Moving Average Period
datetime gdt_TimeCurrent = Time[1];
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
   datetime ldt_StartTime = StringToTime(is_start);
   datetime ldt_StopTime = StringToTime(is_stop);
   if(TimeCurrent()>ldt_StartTime && TimeCurrent()<ldt_StopTime)
     {
      double ld_buysignal = iCustom(_Symbol,PERIOD_CURRENT,"_HPCS_FastSlowMACrossover_MT4_Indi_V01_WE",ii_fastMAPeriod,ii_slowMAPeriod,0,0);
      double ld_Sellsignal = iCustom(_Symbol,PERIOD_CURRENT,"_HPCS_FastSlowMACrossover_MT4_Indi_V01_WE",ii_fastMAPeriod,ii_slowMAPeriod,1,0);
      int li_Factor = 0;
      if(Digits == 5 || Digits == 3)
        { li_Factor = 10; }
      double ld_TakeProfitBuy = Ask + ii_takeprofit*Point()*li_Factor;
      double ld_StopLossBuy = Ask - ii_takeprofit*Point()*li_Factor;
      if(ld_StopLossBuy > (Bid - MarketInfo(_Symbol,MODE_STOPLEVEL)*Point()))
        {
         ld_StopLossBuy = Bid - (MarketInfo(_Symbol,MODE_STOPLEVEL)*Point());
        }
      if(ld_buysignal != EMPTY_VALUE)
        {
         if(gdt_TimeCurrent != Time[0])
           {
            int li_TicketBuy = OrderSend(_Symbol,OP_BUY,ii_lots,Ask,10,ld_StopLossBuy,ld_TakeProfitBuy,NULL,1212);
            if(li_TicketBuy < 0)
              {
               Print("Order Not Generated",GetLastError());
              }
            gdt_TimeCurrent = Time[0];
           }
        }
      double ld_TakeProfitSell = Bid - ii_takeprofit*Point()*li_Factor;
      double ld_StopLossSell = Bid + ii_takeprofit*Point()*li_Factor;
      if(ld_StopLossSell < (Ask + MarketInfo(_Symbol,MODE_STOPLEVEL)*Point()))
        {
         ld_StopLossSell = Ask + (MarketInfo(_Symbol,MODE_STOPLEVEL)*Point());
        }
      if(ld_Sellsignal != EMPTY_VALUE)
        {
         if(gdt_TimeCurrent != Time[0])
           {
            int li_TicketSell = OrderSend(_Symbol,OP_SELL,ii_lots,Bid,10,ld_StopLossSell,ld_TakeProfitSell,NULL,1122);
            if(li_TicketSell < 0)
              {
               Print("Order Not Generated",GetLastError());
              }
            gdt_TimeCurrent = Time[0];
           }
        }
     }
     else
     {
         Print("Market Not Operating");
     }
  }
//+------------------------------------------------------------------+