//+------------------------------------------------------------------+
//|                                         CPro Tool AMadeusGoogleVersion MT5               |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <trade/trade.mqh>

CTrade trade;
//-------------------------------------------OVEROPTIMIZED VERSION 5 AFTER 2. TESTING -------------
//Added Dynamic Lotsizing
input double TrigPDif = 0.00005;
input double DesiredProfitPerc = 20;
input int ExpiryTime = 120;
input double RuleMinimumTPSLValue = 0.0001;
input double PufferDistance = 0.0001;
input double WhiteYellowProtRange = 0.00001;
input bool SWhiteProtection = true;
input double StaticLots = 1.0;
input bool DynamicLotsCalc = false;
//AUSSTEHEND input double TPSLFactor = 1.0;
input string Opentime = "04:30:00";
input string CloseTime = "23:45:";
long TickVolumes[];
double bid0 = 0; 
double accountbalancebeginning;
double accountprofit;
double Lostrades = 0;
double Wintrades = 0;
double AllWinRatio = 0;
//DYNAMIC LOT CALCULATION
double CalcLots(double riskPercent, double SLDistance){
   double ticksize = SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   double tickvalue = SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_VALUE);
   double Lotstep = SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP);
   if(ticksize == 0 || tickvalue == 0 || Lotstep == 0){
      Print(__FUNCTION__,"Lotsize cannot be calculated1");
      return 0;}
   double riskMoney = AccountInfoDouble(ACCOUNT_BALANCE) * riskPercent /100;
   double MoneyperLotstep = (SLDistance / ticksize) * tickvalue * Lotstep;
   if(MoneyperLotstep == 0){
      Print(__FUNCTION__,"Lotsize cannot be calculated2","\n  SLDistance: ",SLDistance,"  ticksize: ",ticksize,
                                                         "\n  tickvalue: ",tickvalue,"  Lotstep: ",Lotstep,"\n  SLDistance: ",riskMoney);
      return 0;}
   double lots = MathFloor(riskMoney / MoneyperLotstep) * Lotstep;
   return lots;  
}
int OnInit(){
   CPro_Init();  // CPro营销模块初始化
   accountbalancebeginning = AccountInfoDouble(ACCOUNT_BALANCE);
   //OrderinAction = false;
   return(INIT_SUCCEEDED);
  }
void OnTick(){
   //DETERMINING TIMEFRAME
   datetime opentimenow = StringToTime(Opentime);
   datetime closetimenow = StringToTime(CloseTime);
   datetime currenttime = TimeCurrent();
   if(currenttime > opentimenow && currenttime < closetimenow){
      //GET YELLWOW AMA VALUES
      double YellAMAPriceArray[];
      int YellAMADefinition = iAMA (_Symbol,_Period,2,5,1,0,PRICE_CLOSE);
      ArraySetAsSeries(YellAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(YellAMADefinition,0,0,10,YellAMAPriceArray);
      double YellAMACurrentValue = NormalizeDouble(YellAMAPriceArray[0],6);
      //GET WHITE AMA VALUES
      double WhiteAMAPriceArray[];
      int WhiteAMADefinition = iAMA (_Symbol,_Period,2,5,1,1,PRICE_CLOSE);
      ArraySetAsSeries(WhiteAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(WhiteAMADefinition,0,0,10,WhiteAMAPriceArray);
      double WhiteAMACurrentValue = NormalizeDouble(WhiteAMAPriceArray[0],6);
      //GET SWHITE AMA VALUES
      double SWhiteAMAPriceArray[];
      int SWhiteAMADefinition = iAMA (_Symbol,_Period,2,5,1,2,PRICE_CLOSE);
      ArraySetAsSeries(SWhiteAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(SWhiteAMADefinition,0,0,10,SWhiteAMAPriceArray);
      double SWhiteAMACurrentValue = NormalizeDouble(SWhiteAMAPriceArray[0],6);
      //GET RED AMA VALUES
      double RedAMAPriceArray[];
      int RedAMADefinition = iAMA (_Symbol,_Period,5,2,30,0,PRICE_CLOSE);
      ArraySetAsSeries(RedAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(RedAMADefinition,0,0,10,RedAMAPriceArray);
      double RedAMACurrentValue = NormalizeDouble(RedAMAPriceArray[0],6);
      //GET ORANGE AMA VALUES
      double OrangeAMAPriceArray[];
      int OrangeAMADefinition = iAMA (_Symbol,_Period,5,2,30,1,PRICE_CLOSE);
      ArraySetAsSeries(OrangeAMAPriceArray,true);
      //AMA DEF, one line, current candle, 3 candles, store result
      CopyBuffer(OrangeAMADefinition,0,0,10,OrangeAMAPriceArray);
      double OrangeAMACurrentValue = NormalizeDouble(OrangeAMAPriceArray[0],6);
      //SET THE ORDER
      bid0 = NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),_Digits);
      double PufferPrice = RedAMACurrentValue + PufferDistance;
      double InvalidStopProhibitorline = RuleMinimumTPSLValue + PufferDistance + RedAMACurrentValue;
      double iLow1 = iLow(_Symbol,PERIOD_CURRENT,1);
      double iLow2 = iLow(_Symbol,PERIOD_CURRENT,2);
      double TrigP = bid0 - TrigPDif;
      double TP = RedAMACurrentValue;
      double SL = bid0 + (bid0 - RedAMACurrentValue);
      datetime OrderExpTime = TimeCurrent() + ExpiryTime;
      if(SWhiteProtection == false){SWhiteAMACurrentValue = 5;}
      if( iLow1 > OrangeAMACurrentValue + PufferDistance && iLow2 > OrangeAMACurrentValue + PufferDistance){
         if(WhiteAMACurrentValue - WhiteYellowProtRange > YellAMACurrentValue &&
            YellAMACurrentValue > SymbolInfoDouble(_Symbol,SYMBOL_BID) &&
            YellAMACurrentValue > PufferPrice &&
            SWhiteAMACurrentValue > WhiteAMACurrentValue &&
            TrigP > InvalidStopProhibitorline && 
            PositionsTotal() == 0 && 
            OrdersTotal() == 0){
            //CALC LOTS
            double Lots = 0;
            if(DynamicLotsCalc){
               double SLDistance = SL - bid0;
               Lots = CalcLots(DesiredProfitPerc,SLDistance);
            }else{Lots = StaticLots;}
            trade.SellStop(Lots,TrigP,_Symbol,SL,TP,ORDER_TIME_SPECIFIED,OrderExpTime);
            Print(//"\nPinkAMA-Value ",PinkAMACurrentValue,
                 "\nYellAMA-Value ",YellAMACurrentValue,
                 "\nWhiteAMA-Value ",WhiteAMACurrentValue,
                 "\nRedAMA-Value ",RedAMACurrentValue,
                 "\nOrangeAMA-Value ",OrangeAMACurrentValue,
                 "\niLow 1: ",iLow1,
                 "\niLow2",iLow2,
                 "\nBid ",bid0);
         }
      }
      // DISPLAY OF VALUES ON CHART
      double accountequity = AccountInfoDouble(ACCOUNT_EQUITY);
      accountprofit = accountequity - accountbalancebeginning;
      accountprofit = NormalizeDouble(accountprofit,2);  
      Comment("\nServertime: ", TimeCurrent(),
              "\nCurrenttime: ",TimeCurrent(),
              "\nProfit: ",accountprofit,
              "\nEquity: ",accountequity,
              //"\nPinkAMA-Value ",PinkAMACurrentValue,
              "\nYellAMA-Value ",YellAMACurrentValue,
              "\nWhiteAMA-Value ",WhiteAMACurrentValue,
              "\nRedAMA-Value ",RedAMACurrentValue,
              "\nOrangeAMA-Value ",OrangeAMACurrentValue,
              "\niLow 1: ",iLow1,
              "\niLow2",iLow2,
              "\nBid ",bid0);
   }//END TIMEFRAME
  }//END ONTICK
void OnDeinit(const int reason){
   Lostrades = TesterStatistics(STAT_LOSS_TRADES);
   Wintrades = TesterStatistics(STAT_PROFIT_TRADES);
   if(Lostrades + Wintrades > 0){
      AllWinRatio = NormalizeDouble(Wintrades / (Wintrades + Lostrades),2);
   }else{AllWinRatio = 0;}
   Print("Verlorene Trades:  ",Lostrades,
         "\nGewonnenen Trades: ",Wintrades,
         "\nGewinnrate:________",AllWinRatio);
   CPro_Deinit();  // CPro营销模块清理
}
double OnTester(){
   Lostrades = TesterStatistics(STAT_LOSS_TRADES);
   Wintrades = TesterStatistics(STAT_PROFIT_TRADES);
   if(Lostrades + Wintrades > 0){
      AllWinRatio = NormalizeDouble(Wintrades / (Wintrades + Lostrades),2);
   }else{AllWinRatio = 0;}
   return(AllWinRatio);
}