//+------------------------------------------------------------------+
//|                                         CPro EA VR_Heads_or_Tails MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}


// --- Input parameters (configurable by user) ---
input double  iStartLots    = 0.01;//initial 交易 交易量 (交易量 尺寸)
input int     iTakeProfit   = 450;//take 利润 距离 in 点数
input int     iStopLoss     = 390;//停止 亏损 距离 in 点数
input int     iMagicNumber  = 227;//unique identifier for this ea's 交易s
input int     iSlippage     = 30;//maximum allowed 止损ippage in 点数
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
// ---
   CPro_Init();  // CPro营销模块初始化
   MathSrand(GetTickCount());                         // Seed the random number generator with current system time
// ---
   return(INIT_SUCCEEDED);                            // Return success code to terminal
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
// --- Count open positions managed by this EA ---
   int total = OrdersTotal(), b = 0, s = 0;     // total = number of all orders, b = buy count, s = sell count
// Loop through all existing orders
   for(int i = 0; i < total; i++)
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)) // Select order by position index from open trades
         if(OrderSymbol() == _Symbol)              // Check if order is for current symbol
            if(OrderMagicNumber() == iMagicNumber) // Check if order belongs to this EA (by magic number)
              {
               if(OrderType() == OP_BUY)           // If it's a buy order
                  b++;                             // Increment buy counter
               if(OrderType() == OP_SELL)          // If it's a sell order
                  s++;                             // Increment sell counter
              }
   int ticket = -1;  // Variable to store order ticket number
   if(CheckVolumeValue(iStartLots)) // Checking the trading volume
      // If no open positions exist for this EA (b+s=0)
      if((b + s) == 0)
         // Randomly decide trade direction (like flipping a coin)
         if(MathRand() % 2 == 0)                     // If random number is even -> BUY
           {
            // Send BUY order with specified parameters
            ticket = OrderSend(Symbol(),OP_BUY,iStartLots,Ask,iSlippage,
                               Ask - iStopLoss * _Point,       // Stop Loss price (current Ask minus SL distance)
                               Ask + iTakeProfit * _Point,     // Take Profit price (current Ask plus TP distance)
                               "VR Heads or Tails",            // Order comment
                               iMagicNumber,0,clrBlue);        // Magic number, expiration, blue arrow color
            // Check if order was successfully placed
            if(ticket<0)
               Print("OrderSend failed with an error #",GetLastError());  // Print error if failed
            else
               Print("The OrderSend function has been completed successfully");  // Success message
           }
         else  // If random number is odd -> SELL
           {
            // Send SELL order with specified parameters
            ticket = OrderSend(Symbol(),OP_SELL,iStartLots,Bid,iSlippage,
                               Bid + iStopLoss * _Point,       // Stop Loss price (current Bid plus SL distance)
                               Bid - iTakeProfit * _Point,     // Take Profit price (current Bid minus TP distance)
                               "VR Heads or Tails",            // Order comment
                               iMagicNumber,0,clrRed);         // Magic number, expiration, red arrow color
            // Check if order was successfully placed
            if(ticket<0)
               Print("OrderSend failed with an error #",GetLastError());  // Print error if failed
            else
               Print("The OrderSend function has been completed successfully");  // Success message
           }
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)  // Called when EA is removed from chart
  {
   CPro_Deinit();  // CPro营销模块清理
// No cleanup operations needed in this EA
  }
//+------------------------------------------------------------------+
//|  Checks order volume for correctness                            |
//+------------------------------------------------------------------+
bool CheckVolumeValue(double volume)
  {
//--- minimum allowed volume for trading operations
   double min_volume=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MIN);
   if(volume<min_volume)
      return(false);
//--- maximum allowed volume for trading operations
   double max_volume=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_MAX);
   if(volume>max_volume)
      return(false);
//--- get minimum volume increment step
   double volume_step=SymbolInfoDouble(Symbol(),SYMBOL_VOLUME_STEP);
   int ratio=(int)MathRound(volume/volume_step);
   if(MathAbs(ratio*volume_step-volume)>0.0000001)
      return(false);
   return(true);
  }
//+------------------------------------------------------------------+