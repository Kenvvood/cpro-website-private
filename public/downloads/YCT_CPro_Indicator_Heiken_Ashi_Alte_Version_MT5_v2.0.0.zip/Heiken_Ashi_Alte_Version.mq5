//+------------------------------------------------------------------+
//|                                         CPro Indicator Heiken_Ashi_Alte_Version MT5      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//#property strict
//#property indicator_separate_window
//#property indicator_type1 DRAW_HISTOGRAM
//#property indicator_type2 DRAW_HISTOGRAM
//#property indicator_type3 DRAW_HISTOGRAM
//#property indicator_type4 DRAW_HISTOGRAM
//#property indicator_label1 "Low/High"
//#property indicator_label2 "High/low"
//#property indicator_label3 "Open"
//#property indicator_label4 "Close"
//#property indicator_color1 clrRed
//#property indicator_color2 clrBlue
//#property indicator_color3 clrRed
//#property indicator_color4 clrBlue
//#property indicator_width1 1
//#property indicator_width2 0
//#property indicator_width3 3
//#property indicator_width4 4
//---
input color ExtColor1 = clrRed;    // Shadow of bear candlestick
input color ExtColor2 = clrBlue;  // Shadow of bull candlestick
input color ExtColor3 = clrRed;    // Bear candlestick body
input color ExtColor4 = clrBlue;  // Bull candlestick body
string tfsymbol;
//--- buffers
double ExtLowHighBuffer[];
double ExtHighLowBuffer[];
double ExtOpenBuffer[];
double ExtCloseBuffer[];
double ExtColorBuffer[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//|------------------------------------------------------------------|
void OnInit(void)
{
   //IndicatorShortName("Heiken Ashi");
   //IndicatorDigits(Digits);
   CPro_Init();  // CPro营销模块初始化
   IndicatorSetString(INDICATOR_SHORTNAME,"Heiken Ashi");
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);
//--- indicator lines
   //SetIndexBuffer(0,ExtHighLowBuffer);
   //SetIndexBuffer(1,ExtLowHighBuffer);
   //SetIndexBuffer(2,ExtOpenBuffer);
   //SetIndexBuffer(3,ExtCloseBuffer);
   //SetIndexStyle(0,DRAW_HISTOGRAM,0,1,ExtColor1);
   //SetIndexBuffer(0,ExtLowHighBuffer);
   //SetIndexStyle(1,DRAW_HISTOGRAM,0,1,ExtColor2);
   //SetIndexBuffer(1,ExtHighLowBuffer);
   //SetIndexStyle(2,DRAW_HISTOGRAM,0,3,ExtColor3);
   //SetIndexBuffer(2,ExtOpenBuffer);
   //SetIndexStyle(3,DRAW_HISTOGRAM,0,3,ExtColor4);
   //SetIndexBuffer(3,ExtCloseBuffer);
//---
   //SetIndexLabel(0,"Low/High");
   //SetIndexLabel(1,"High/Low");
   //SetIndexLabel(2,"Open");
   //SetIndexLabel(3,"Close");
   //SetIndexDrawBegin(0,10);
   //SetIndexDrawBegin(1,10);
   //SetIndexDrawBegin(2,10);
   //SetIndexDrawBegin(3,10);
   PlotIndexSetInteger(0,PLOT_DRAW_TYPE,DRAW_COLOR_CANDLES);
   //PlotIndexSetInteger(0,PLOT_LINE_STYLE,STYLE_SOLID);
   //PlotIndexSetInteger(0,PLOT_SHIFT,0   );
   PlotIndexSetInteger(0,PLOT_SHOW_DATA,true);//--- if show indicator data in DataWindow
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,5);
   PlotIndexSetInteger(0,PLOT_LINE_WIDTH,1);
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,0.0);
   PlotIndexSetInteger(0,PLOT_COLOR_INDEXES,ExtColor1);
   //tfsymbol=Symbol();
   //PlotIndexSetString(0,PLOT_LABEL,"Low/High");
   //PlotIndexSetInteger(1,PLOT_DRAW_TYPE,DRAW_HISTOGRAM2);
   //PlotIndexSetInteger(1,PLOT_LINE_STYLE,STYLE_SOLID);
   //PlotIndexSetInteger(1,PLOT_SHIFT,0);
   //PlotIndexSetInteger(1,PLOT_SHOW_DATA,true);//--- if show indicator data in DataWindow
   //PlotIndexSetInteger(1,PLOT_DRAW_BEGIN,5);
   //PlotIndexSetInteger(1,PLOT_LINE_WIDTH,1);
   //PlotIndexSetDouble(1,PLOT_EMPTY_VALUE,0.0);
   //PlotIndexSetInteger(1,PLOT_COLOR_INDEXES,ExtColor2);
   //PlotIndexSetString(1,PLOT_LABEL,"High/low");
   //PlotIndexSetInteger(2,PLOT_DRAW_TYPE,DRAW_HISTOGRAM2);
   //PlotIndexSetInteger(2,PLOT_LINE_STYLE,STYLE_SOLID);
   //PlotIndexSetInteger(2,PLOT_SHIFT,5);
   //PlotIndexSetInteger(2,PLOT_SHOW_DATA,true);//--- if show indicator data in DataWindow
   //PlotIndexSetInteger(2,PLOT_DRAW_BEGIN,5);
   //PlotIndexSetInteger(2,PLOT_LINE_WIDTH,4);
   //PlotIndexSetDouble(2,PLOT_EMPTY_VALUE,0.0);
   //PlotIndexSetInteger(2,PLOT_COLOR_INDEXES,ExtColor3);
   //PlotIndexSetString(2,PLOT_LABEL,"Open");
   //PlotIndexSetInteger(3,PLOT_DRAW_TYPE,DRAW_HISTOGRAM2);
   //PlotIndexSetInteger(3,PLOT_LINE_STYLE,STYLE_SOLID);
   //PlotIndexSetInteger(3,PLOT_SHIFT,5);
   //PlotIndexSetInteger(3,PLOT_SHOW_DATA,true);//--- if show indicator data in DataWindow
   //PlotIndexSetInteger(3,PLOT_DRAW_BEGIN,5);
   //PlotIndexSetInteger(3,PLOT_LINE_WIDTH,4);
   //PlotIndexSetDouble(3,PLOT_EMPTY_VALUE,0.0);
   //PlotIndexSetInteger(3,PLOT_COLOR_INDEXES,ExtColor4);
   //PlotIndexSetString(3,PLOT_LABEL,"Close");
//--- indicator buffers mapping
   SetIndexBuffer(0,ExtLowHighBuffer);
   SetIndexBuffer(1,ExtHighLowBuffer);
   SetIndexBuffer(2,ExtOpenBuffer);
   SetIndexBuffer(3,ExtCloseBuffer);
   SetIndexBuffer(4,ExtColorBuffer);
//--- initialization done
}
//+------------------------------------------------------------------+
//| Heiken Ashi                                                      |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   int    i,pos;
   double haOpen,haHigh,haLow,haClose;
//---
   if(rates_total<=10)
      return(0);
//--- counting from 0 to rates_total
   ArraySetAsSeries(ExtLowHighBuffer,false);
   ArraySetAsSeries(ExtHighLowBuffer,false);
   ArraySetAsSeries(ExtOpenBuffer,false);
   ArraySetAsSeries(ExtCloseBuffer,false);
   ArraySetAsSeries(open,false);
   ArraySetAsSeries(high,false);
   ArraySetAsSeries(low,false);
   ArraySetAsSeries(close,false);
//--- preliminary calculation
   if(prev_calculated>1)
      pos=prev_calculated-1;
   else
      {
         //--- set first candle
         if(open[0]<close[0])
            {
               ExtLowHighBuffer[0]=low[0];
               ExtHighLowBuffer[0]=high[0];
            }
         else
            {
               ExtLowHighBuffer[0]=high[0];
               ExtHighLowBuffer[0]=low[0];
            }
         ExtOpenBuffer[0]=open[0];
         ExtCloseBuffer[0]=close[0];
         //---
         pos=1;
      }
//--- main loop of calculations
   for(i=pos; i<rates_total; i++)
      {
         haOpen=(ExtOpenBuffer[i-1]+ExtCloseBuffer[i-1])/2;
         haClose=(open[i]+high[i]+low[i]+close[i])/4;
         haHigh=MathMax(high[i],MathMax(haOpen,haClose));
         haLow=MathMin(low[i],MathMin(haOpen,haClose));
         if(haOpen<haClose)
            {
               ExtLowHighBuffer[i]=haLow;
               ExtHighLowBuffer[i]=haHigh;
            }
         else
            {
               ExtLowHighBuffer[i]=haHigh;
               ExtHighLowBuffer[i]=haLow;
            }
         ExtOpenBuffer[i]=haOpen;
         ExtCloseBuffer[i]=haClose;
      }
//--- done
   return(rates_total);
}
//+------------------------------------------------------------------+