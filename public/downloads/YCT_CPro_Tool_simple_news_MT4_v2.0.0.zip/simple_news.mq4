//+------------------------------------------------------------------+
//|                                         CPro Tool simple_news MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

input datetime news_time=D'2015.11.06 14:30';
input int
deals=3,       //amount of deals
delta=50,      //step between them (in pips)
distance=300,  //distance from current price
sl=150,        //stop loss from current price
trail=200,     //trail sl (in pips)
tp=900,        //take profit from order price
slip=50,       //tolerance for trail
magic=220;     //magic number
input double
lot=0.01;      //lot size
//+------------------------------------------------------------------+
//|Main function                                                     |
//+------------------------------------------------------------------+
void start()
  {
//set pending orders before the news
   if(TimeCurrent()<(int)news_time && TimeCurrent()>(int)news_time-5*60 && !PendingExcist()) SetPending();
//delete pending orders which were not started
   if(TimeCurrent()>(int)news_time+10*60) DeletePending();
   Comment(news_time," ",TimeCurrent());
//trail stop loss if orders in the market 
   if(InMarket() && trail!=0)
     {
      for(int i=0; i<OrdersTotal(); i++)
        {
         if(OrderSelect(i,SELECT_BY_POS)==false) continue;
         if(OrderSymbol()==Symbol() && OrderMagicNumber()==magic && OrderType()<2)
           {
            if(OrderType()==OP_BUY)
              {
               if(OrderStopLoss()<Bid-trail*Point && OrderStopLoss()<Bid-trail*Point-slip*Point) if(OrderModify(OrderTicket(),OrderOpenPrice(),Bid-trail*Point,OrderTakeProfit(),0)==false) continue;
              }
            else if(OrderType()==OP_SELL)
              {
               if(OrderStopLoss()>Ask+trail*Point && OrderStopLoss()>Ask+trail*Point+slip*Point) if(OrderModify(OrderTicket(),OrderOpenPrice(),Ask+trail*Point,OrderTakeProfit(),0)==false) continue;
              }
           }
        }
     }
  }
//+------------------------------------------------------------------+
//|Check if pending orders run into the market                       |
//+------------------------------------------------------------------+
bool InMarket()
  {
   for(int i=0; i<OrdersTotal(); i++)
     {
      if(OrderSelect(i,SELECT_BY_POS)==false) continue;
      if(OrderSymbol()==Symbol() && OrderMagicNumber()==magic && OrderType()<2) return(true);
     }
   return(false);
  }
//+------------------------------------------------------------------+
//|Set pending orders                                                |
//+------------------------------------------------------------------+
void SetPending()
  {
   for(int i=0; i<deals; i++)
     {
      double price,sl_=0,tp_=0;
      price=Ask+distance*Point;
      if(sl!=0) sl_=Ask-sl*Point;
      if(tp!=0) tp_=price+tp*Point;
      if(OrderSend(Symbol(),OP_BUYSTOP,lot,price+i*delta*Point,slip,sl_,tp_,"",magic)==false) continue;
      price=Bid-distance*Point;
      if(sl!=0) sl_=Bid+sl*Point;
      if(tp!=0) tp_=price-tp*Point;
      if(OrderSend(Symbol(),OP_SELLSTOP,lot,price-i*delta*Point,slip,sl_,tp_,"",magic)==false) continue;
     }
  }
//+------------------------------------------------------------------+
//|Delete pending orders                                             |
//+------------------------------------------------------------------+
void DeletePending()
  {
   for(int i=0; i<OrdersTotal(); i++)
     {
      if(OrderSelect(i,SELECT_BY_POS)==false) continue;
      if(OrderSymbol()==Symbol() && OrderMagicNumber()==magic && OrderType()>1) if(OrderDelete(OrderTicket())==false) continue;
     }
  }
//+------------------------------------------------------------------+
//|Check if pending orders were set                                  |
//+------------------------------------------------------------------+ 
bool PendingExcist()
  {
   for(int i=0; i<OrdersTotal(); i++)
     {
      if(OrderSelect(i,SELECT_BY_POS)==false) continue;
      if(OrderSymbol()==Symbol() && OrderMagicNumber()==magic && OrderType()>1) return(true);
     }
   return(false);
  }
//+------------------------------------------------------------------+
//|Initialisation function                                           |
//+------------------------------------------------------------------+  
void init()
  {
  }
//+------------------------------------------------------------------+
//|Deinitialisation function                                         |
//+------------------------------------------------------------------+
void deinit()
  {
   Comment("");
  }
//+------------------------------------------------------------------+