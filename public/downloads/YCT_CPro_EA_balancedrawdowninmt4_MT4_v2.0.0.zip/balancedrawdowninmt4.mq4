//+------------------------------------------------------------------+
//|                                         CPro EA balancedrawdowninmt4 MT4                 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
input bool ENABLE_MAGIC_NUMBER= true; // Enable Magic Number(For manual trades set false)
input int  MAGIC_NUMBER_INPUT =  20131111; // Magic Number
input double START_BALANCE =1000; // Start Balance
input double LOTS = 0.01;
input double STOPLOSS =300;
input double TAKEPROFIT =400;
int MAGIC_NUMBER;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
   if(ENABLE_MAGIC_NUMBER)
      MAGIC_NUMBER = MAGIC_NUMBER_INPUT;
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
   if(OrdersTotal()==0){
     int res= OrderSend(Symbol(),OP_BUY,LOTS,Ask,3,Ask-STOPLOSS*Point(),Ask+STOPLOSS*Point(),"",MAGIC_NUMBER,0,clrGreen);
   }
   Comment("Current Drawdown "+DoubleToStr(DrawDown(Symbol()),2));
  }
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//|              CALCULATES THE DRAWDOWN                             |
//+------------------------------------------------------------------+
double DrawDown(string symbol)
  {
   double maxBalance=START_BALANCE;
   double currentBalance=START_BALANCE;
   // FINDING THE MAXIMUM BALANCE SO FAR AND THE TOTAL BALANCE
   for(int i =0; i <OrdersHistoryTotal(); i++)
     {
      // If the order cannot be selected, throw and log an error.
      if(OrderSelect(i, SELECT_BY_POS, MODE_HISTORY)  && OrderSymbol()==symbol && ((ENABLE_MAGIC_NUMBER && OrderMagicNumber()==MAGIC_NUMBER) || !ENABLE_MAGIC_NUMBER))
        {
         currentBalance+= OrderProfit();
         if(currentBalance>maxBalance)
            maxBalance=currentBalance;
        }
     }
   double currentProfit =TotalCurrentProfit(symbol);
   currentBalance+= currentProfit;
   double drawdown= ((maxBalance-currentBalance)*100)/(maxBalance);
   return drawdown;
  }
//+------------------------------------------------------------------+
//|                   GET CURRENT TOTAL PROFIT OF A SYMBOL                   |
//+------------------------------------------------------------------+
double TotalCurrentProfit(string symbol)
  {
   double profit=0;
   for(int i=0; i<OrdersTotal(); i++)
     {
      if(OrderSelect(i,SELECT_BY_POS,MODE_TRADES)&& ((ENABLE_MAGIC_NUMBER && OrderMagicNumber()==MAGIC_NUMBER) || !ENABLE_MAGIC_NUMBER) && OrderSymbol()==symbol)
         profit+=OrderProfit();
     }
   return profit;
  }
//+------------------------------------------------------------------+