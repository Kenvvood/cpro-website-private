//+------------------------------------------------------------------+
//|                                         CPro Tool 3sma_www_forex_instruments_info MT4    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern int       SMA1=9;
extern int       SMA2=14;
extern int       SMA3=29;
extern double    lots=0.1;
extern int       SMAspread=0;
extern int       StopLoss=0;
extern int       Slippage=4;
double   ma1,ma2,ma3;
int      i, buys, sells;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
   //get moving average info
   ma1=iMA(Symbol(),0,SMA1,1,MODE_SMA,PRICE_CLOSE,0);
   ma2=iMA(NULL,0,SMA2,1,MODE_SMA,PRICE_CLOSE,0);
   ma3=iMA(NULL,0,SMA3,1,MODE_SMA,PRICE_CLOSE,0);
   //check for open orders first 
   if (OrdersTotal()>0)
     {
      buys=0;
      sells=0;
      for(i=0;i<OrdersTotal();i++)
        {
         OrderSelect(i,SELECT_BY_POS);
         if (OrderSymbol()==Symbol())
           {
            if (OrderType()== OP_BUY)
              {
               if (ma1 < ma2) OrderClose(OrderTicket(),OrderLots(),Bid,Slippage,Orange);
               else buys++;
              }
            if (OrderType()== OP_SELL)
              {
               if (ma1 > ma2) OrderClose(OrderTicket(),OrderLots(),Ask,Slippage,Yellow);
               else sells++;
              }
           }
        }
     }
   if (ma1>(ma2+SMAspread*Point) && ma2 > (ma3+SMAspread*Point) && buys==0)
     {
      Print("Buy condition");
   OrderSend(Symbol(),OP_BUY,lots,Ask,Slippage,0/*(Ask-StopLoss*Point)*/,0,"3SMA",123,0,Green);
     }
   if (ma1<(ma2-SMAspread*Point) && ma2 < (ma3-SMAspread*Point) && sells ==0)
     {
      Print ("Sell condition");
   OrderSend(Symbol(),OP_SELL,lots,Bid,Slippage,0/*(Bid+StopLoss*Point)*/,0,"3SMA",123,0,Red);
     }
//----
   return(0);
  }
//+------------------------------------------------------------------+