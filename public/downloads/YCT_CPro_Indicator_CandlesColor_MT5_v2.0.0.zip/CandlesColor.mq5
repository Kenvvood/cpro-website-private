//+------------------------------------------------------------------+
//|                                         CPro Indicator CandlesColor MT5                  |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input color ColorBarUp=clrNONE;
input color ColorBarDown=clrNONE;
double _open[],_high[],_low[],_close[];
double _color[];
int OnInit()
{
   CPro_Init();  // CPro营销模块初始化
   PlotIndexSetInteger(0,PLOT_DRAW_TYPE,DRAW_COLOR_CANDLES);
   SetIndexBuffer(0,_open,INDICATOR_DATA);
   SetIndexBuffer(1,_high,INDICATOR_DATA);
   SetIndexBuffer(2,_low,INDICATOR_DATA);
   SetIndexBuffer(3,_close,INDICATOR_DATA);
   SetIndexBuffer(4,_color,INDICATOR_COLOR_INDEX);
   PlotIndexSetInteger(0,PLOT_COLOR_INDEXES,2);
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,NULL);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,0,ColorBarUp);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,1,ColorBarDown);
   if(PlotIndexGetInteger(0,PLOT_LINE_COLOR,0)==-1)
   {
      int cb=(int)ChartGetInteger(0,CHART_COLOR_CANDLE_BULL);
      int red=cb%256;
      int green=((cb-(cb%256))/256)%256;
      int blue=cb>>16;
      red=MathMin(red+50,255);
      green=MathMin(green+50,255);
      blue=MathMin(blue+50,255);
      PlotIndexSetInteger(0,PLOT_LINE_COLOR,0,(blue<<16)+(green<<8)+(red));
   }
   if(PlotIndexGetInteger(0,PLOT_LINE_COLOR,1)==-1)
   {
      int cb=(int)ChartGetInteger(0,CHART_COLOR_CANDLE_BEAR);
      int red=cb%256;
      int green=((cb-(cb%256))/256)%256;
      int blue=cb>>16;
      red=MathMin(red+50,255);
      green=MathMin(green+50,255);
      blue=MathMin(blue+50,255);
      PlotIndexSetInteger(0,PLOT_LINE_COLOR,1,(blue<<16)+(green<<8)+(red));
   }
   return(0);
}
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   MqlDateTime t;
   for(int i=prev_calculated;i<=rates_total-1;i++)
   {
      _open[i]=NULL;
      _high[i]=NULL;
      _low[i]=NULL;
      _close[i]=NULL;
      datetime candle_time=time[i];
      TimeToStruct(time[i],t);
      if((t.min>=45 && t.min<50) || (t.min>=15 && t.min<20))
      {
         _open[i]=open[i];
         _high[i]=high[i];
         _low[i]=low[i];
         _close[i]=close[i];
         _color[i]=0;
         if(open[i]>=close[i])
            _color[i]=1;
      }
   }
   return(rates_total-1);
}
void OnChartEvent(const int id, const long& lparam, const double& dparam, const string& sparam)
{
   if(id-CHARTEVENT_CUSTOM==3333)
   {
      if(lparam==0)
         PlotIndexSetInteger(0,PLOT_DRAW_TYPE,DRAW_NONE);
      if(lparam==1)
         PlotIndexSetInteger(0,PLOT_DRAW_TYPE,DRAW_COLOR_CANDLES);
   }
}