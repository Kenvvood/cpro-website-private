//+------------------------------------------------------------------+
//|                                         CPro Tool Sample MT5                             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <Expert\Expert.mqh>
#include <Expert\Signal\SignalMA.mqh>
#include <Expert\Signal\SignalStoch.mqh>
#include <Expert\Signal\SignalITF.mqh>
#include <Expert\Trailing\TrailingNone.mqh>
#include <Expert\Money\MoneyFixedLot.mqh>

//+------------------------------------------------------------------+
//| Include                                                          |
//+------------------------------------------------------------------+
//--- available signals
//--- available trailing
//--- available money management
//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
//--- inputs for expert
input string             Expert_Title             ="Sample";//document 名称
ulong                    Expert_MagicNumber       =17414;       //
bool                     Expert_EveryTick         =false;       //
//--- inputs for main signal
input int                Signal_ThresholdOpen     =10;//信号 threshold 值 to 开仓 [0...100]
input int                Signal_ThresholdClose    =10;//信号 threshold 值 to 平仓 [0...100]
input double             Signal_PriceLevel        =0.0;//价格 级别 to execute a 成交
input double             Signal_StopLevel         =50.0;//停止 亏损 级别 (in 点数)
input double             Signal_TakeLevel         =50.0;//take 利润 级别 (in 点数)
input int                Signal_Expiration        =4;//expiration of 挂单 orders (in K线数)
input int                Signal_0_MA_PeriodMA     =31;//moving 均值(31,0,...) 周期 of 均值加仓
input int                Signal_0_MA_Shift        =0;//moving 均值(31,0,...) time 偏移
input ENUM_MA_METHOD     Signal_0_MA_Method       =MODE_EMA;//moving 均值(31,0,...) method of 均值加仓
input ENUM_APPLIED_PRICE Signal_0_MA_Applied      =PRICE_CLOSE;//moving 均值(31,0,...) 价格s series
input double             Signal_0_MA_Weight       =1.0;//moving 均值(31,0,...) weight [0...1.0]
input int                Signal_0_Stoch_PeriodK   =8;//随机指标(8,3,3,...) k-周期
input int                Signal_0_Stoch_PeriodD   =3;//随机指标(8,3,3,...) d-周期
input int                Signal_0_Stoch_PeriodSlow=3;//随机指标(8,3,3,...) 周期 of 止损owing
input ENUM_STO_PRICE     Signal_0_Stoch_Applied   =STO_LOWHIGH;//随机指标(8,3,3,...) prices to apply to
input double             Signal_0_Stoch_Weight    =1.0;//随机指标(8,3,3,...) weight [0...1.0]
input int                Signal_1_MA_PeriodMA     =24;//moving 均值(24,0,...) h1 周期 of 均值加仓
input int                Signal_1_MA_Shift        =0;//moving 均值(24,0,...) h1 time 偏移
input ENUM_MA_METHOD     Signal_1_MA_Method       =MODE_SMA;//moving 均值(24,0,...) h1 method of 均值加仓
input ENUM_APPLIED_PRICE Signal_1_MA_Applied      =PRICE_CLOSE;//moving 均值(24,0,...) h1 价格s series
input double             Signal_1_MA_Weight       =1.0;//moving 均值(24,0,...) h1 weight [0...1.0]
input int                Signal_1_Stoch_PeriodK   =8;//随机指标(8,3,3,...) h4 k-周期
input int                Signal_1_Stoch_PeriodD   =3;//随机指标(8,3,3,...) h4 d-周期
input int                Signal_1_Stoch_PeriodSlow=3;//随机指标(8,3,3,...) h4 周期 of 止损owing
input ENUM_STO_PRICE     Signal_1_Stoch_Applied   =STO_LOWHIGH;//随机指标(8,3,3,...) h4 prices to apply to
input double             Signal_1_Stoch_Weight    =1.0;//随机指标(8,3,3,...) h4 weight [0...1.0]
input int                Signal_ITF_GoodHourOfDay =-1;//intradaytimefilter(-1,0,-1,...) good 小时
input int                Signal_ITF_BadHoursOfDay =0;//intradaytimefilter(-1,0,-1,...) bad hours (bit-均线p)
input int                Signal_ITF_GoodDayOfWeek =-1;          // IntradayTimeFilter(-1,0,-1,...) Good day of week
input int                Signal_ITF_BadDaysOfWeek =0;//intradaytimefilter(-1,0,-1,...) bad days of week (bit-均线p)
input double             Signal_ITF_Weight        =1.0;         // IntradayTimeFilter(-1,0,-1,...) Weight [0...1.0]
//--- inputs for money
input double             Money_FixLot_Lots        =0.1;//固定交易量
//+------------------------------------------------------------------+
//| Global expert object                                             |
//+------------------------------------------------------------------+
CExpert ExtExpert;
//+------------------------------------------------------------------+
//| Initialization function of the expert                            |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- Initializing expert
   CPro_Init();  // CPro营销模块初始化
   if(!ExtExpert.Init("EURUSDc", PERIOD_M10, Expert_EveryTick, Expert_MagicNumber))
     {
      //--- failed
      printf(__FUNCTION__+": error initializing expert");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
//--- Creating signal
   CExpertSignal *signal=new CExpertSignal;
   if(signal==NULL)
     {
      //--- failed
      printf(__FUNCTION__+": error creating signal");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
//---
   ExtExpert.InitSignal(signal);
   signal.ThresholdOpen(Signal_ThresholdOpen);
   signal.ThresholdClose(Signal_ThresholdClose);
   signal.PriceLevel(Signal_PriceLevel);
   signal.StopLevel(Signal_StopLevel);
   signal.TakeLevel(Signal_TakeLevel);
   signal.Expiration(Signal_Expiration);
//--- Creating filter CSignalMA
   CSignalMA *filter0=new CSignalMA;
   if(filter0==NULL)
     {
      //--- failed
      printf(__FUNCTION__+": error creating filter0");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
   signal.AddFilter(filter0);
//--- Set filter parameters
   filter0.PeriodMA(Signal_0_MA_PeriodMA);
   filter0.Shift(Signal_0_MA_Shift);
   filter0.Method(Signal_0_MA_Method);
   filter0.Applied(Signal_0_MA_Applied);
   filter0.Weight(Signal_0_MA_Weight);
//--- Creating filter CSignalStoch
   CSignalStoch *filter1=new CSignalStoch;
   if(filter1==NULL)
     {
      //--- failed
      printf(__FUNCTION__+": error creating filter1");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
   signal.AddFilter(filter1);
//--- Set filter parameters
   filter1.PeriodK(Signal_0_Stoch_PeriodK);
   filter1.PeriodD(Signal_0_Stoch_PeriodD);
   filter1.PeriodSlow(Signal_0_Stoch_PeriodSlow);
   filter1.Applied(Signal_0_Stoch_Applied);
   filter1.Weight(Signal_0_Stoch_Weight);
//--- Creating filter CSignalMA
   CSignalMA *filter2=new CSignalMA;
   if(filter2==NULL)
     {
      //--- failed
      printf(__FUNCTION__+": error creating filter2");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
   signal.AddFilter(filter2);
//--- Set filter parameters
   filter2.Period(PERIOD_H1);
   filter2.PeriodMA(Signal_1_MA_PeriodMA);
   filter2.Shift(Signal_1_MA_Shift);
   filter2.Method(Signal_1_MA_Method);
   filter2.Applied(Signal_1_MA_Applied);
   filter2.Weight(Signal_1_MA_Weight);
//--- Creating filter CSignalStoch
   CSignalStoch *filter3=new CSignalStoch;
   if(filter3==NULL)
     {
      //--- failed
      printf(__FUNCTION__+": error creating filter3");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
   signal.AddFilter(filter3);
//--- Set filter parameters
   filter3.Period(PERIOD_H4);
   filter3.PeriodK(Signal_1_Stoch_PeriodK);
   filter3.PeriodD(Signal_1_Stoch_PeriodD);
   filter3.PeriodSlow(Signal_1_Stoch_PeriodSlow);
   filter3.Applied(Signal_1_Stoch_Applied);
   filter3.Weight(Signal_1_Stoch_Weight);
//--- Creating filter CSignalITF
   CSignalITF *filter4=new CSignalITF;
   if(filter4==NULL)
     {
      //--- failed
      printf(__FUNCTION__+": error creating filter4");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
   signal.AddFilter(filter4);
//--- Set filter parameters
   filter4.GoodHourOfDay(Signal_ITF_GoodHourOfDay);
   filter4.BadHoursOfDay(Signal_ITF_BadHoursOfDay);
   filter4.GoodDayOfWeek(Signal_ITF_GoodDayOfWeek);
   filter4.BadDaysOfWeek(Signal_ITF_BadDaysOfWeek);
   filter4.Weight(Signal_ITF_Weight);
//--- Creation of trailing object
   CTrailingNone *trailing=new CTrailingNone;
   if(trailing==NULL)
     {
      //--- failed
      printf(__FUNCTION__+": error creating trailing");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
//--- Add trailing to expert (will be deleted automatically))
   if(!ExtExpert.InitTrailing(trailing))
     {
      //--- failed
      printf(__FUNCTION__+": error initializing trailing");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
//--- Set trailing parameters
//--- Creation of money object
   CMoneyFixedLot *money=new CMoneyFixedLot;
   if(money==NULL)
     {
      //--- failed
      printf(__FUNCTION__+": error creating money");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
//--- Add money to expert (will be deleted automatically))
   if(!ExtExpert.InitMoney(money))
     {
      //--- failed
      printf(__FUNCTION__+": error initializing money");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
//--- Set money parameters
   money.Lots(Money_FixLot_Lots);
//--- Check all trading objects parameters
   if(!ExtExpert.ValidationSettings())
     {
      //--- failed
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
//--- Tuning of all necessary indicators
   if(!ExtExpert.InitIndicators())
     {
      //--- failed
      printf(__FUNCTION__+": error initializing indicators");
      ExtExpert.Deinit();
      return(INIT_FAILED);
     }
//--- ok
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Deinitialization function of the expert                          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   ExtExpert.Deinit();
   CPro_Deinit();  // CPro营销模块清理
  }
//+------------------------------------------------------------------+
//| "Tick" event handler function                                    |
//+------------------------------------------------------------------+
void OnTick()
  {
   ExtExpert.OnTick();
  }
//+------------------------------------------------------------------+
//| "Trade" event handler function                                   |
//+------------------------------------------------------------------+
void OnTrade()
  {
   ExtExpert.OnTrade();
  }
//+------------------------------------------------------------------+
//| "Timer" event handler function                                   |
//+------------------------------------------------------------------+
void OnTimer()
  {
   ExtExpert.OnTimer();
  }
//+------------------------------------------------------------------+