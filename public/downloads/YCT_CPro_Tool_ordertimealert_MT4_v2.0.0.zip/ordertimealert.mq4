//+------------------------------------------------------------------+
//|                                         CPro Tool ordertimealert MT4                     |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//|                                              |
//+------------------------------------------------------------------+
string globGVName="PTA_lastOrderTicket";
//+------------------------------------------------------------------+
//|                                                  |
//+------------------------------------------------------------------+
input int inpNum = 10;                    //   ()  
input int inpTimerFreqSec = 1;            //   (), 
input int inpMagic = 0;                   //     (0 -  )
input string inpSymbol = "";              //    ( -  )
input bool inpUsePrint = true;            //   
input string inpSoundName = "Alert2.wav"; //   - 
//+------------------------------------------------------------------+
//|                                      |
//+------------------------------------------------------------------+
int OnInit()
  {
//---   
   EventSetTimer(inpTimerFreqSec);
//---    
   if(!GlobalVariableCheck(globGVName ) )     //     
      GlobalVariableSet( globGVName,0 );      //  
   return( INIT_SUCCEEDED );
  }
//+------------------------------------------------------------------+
//|  -                                                  |
//+------------------------------------------------------------------+
void OnTimer()
  {
   int total = OrdersTotal();                  //   
   if(total <= 0 ) return;                     //     - 
   int oType;                                   //  
   int oTicket;                                 //  
   datetime oTime;                              //   
   datetime currentTime;                        //  
   int lastOrderTicket=int(GlobalVariableGet(globGVName));      //    ""  ( )
   for(int i=total-1; i>=0; i--) //    
     {
      if(OrderSelect(i,SELECT_BY_POS)) //   
        {
         if(inpSymbol=="" || inpSymbol==OrderSymbol()) //   ,      
           {
            oType = OrderType();                                    //   
            if( oType == OP_BUY || oType == OP_SELL )               //    (/)
              {
               if(inpMagic==0 || inpMagic==OrderMagicNumber())//   ,      
                 {
                  oTime=OrderOpenTime();                           //    
                  currentTime= TimeCurrent();                      //   
                  oTicket = OrderTicket();                         //   
                  if( currentTime - oTime >= inpNum && lastOrderTicket < oTicket )     //        inpNum . ..
                    {                                                                  // ..     
                     if( inpUsePrint )                                                 //      
                        Print(_Symbol+": c    #",OrderTicket(),"    ",inpNum," !");
                     if(!PlaySound(inpSoundName)) //     -   
                        Print("!   "+inpSoundName+"  !   .     /Sounds");
                     GlobalVariableSet(globGVName,oTicket);      //     
                     break;                                      //     
                    }
                  else if(lastOrderTicket>=oTicket) break;      //     - 
                 }
              }
           }
        }
      else                                     //     -     
      Print(" #",_LastError,"!  #",i," c  #",OrderTicket(),"  !");
     }
  }
//+------------------------------------------------------------------+
//|                                    |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) //  
  {
   if(reason == REASON_REMOVE ||       //      ..
      reason == REASON_ACCOUNT ||      // ..  . /.    ..
      reason == REASON_TEMPLATE )      // ..   
     {
      //---    
      GlobalVariableDel(globGVName);
     }
//---    
   EventKillTimer();
  }
//+------------------------------------------------------------------+