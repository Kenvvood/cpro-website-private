//+------------------------------------------------------------------+
//|                                         CPro Tool Billy_expert MT4                       |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int    TrailingStop   = 30;
extern int    StopLoss       = 0;
extern int    TakeProfit     = 12;
extern double Lots           = 0.01;
extern int    magicnumber    = 777;
extern int    MaxOrders      = 1;
extern int    Periods        = 1;
extern int    Periods2       = 5;
int prevtime;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
   int i=0;  
   int total = OrdersTotal();   
      int balance=AccountBalance()/500;
   double lot=balance*0.1;
   for(i = 0; i <= total; i++) 
     {
      if(TrailingStop>0)  
       {                 
       OrderSelect(i, SELECT_BY_POS, MODE_TRADES);
}
      }
 double M_0, M_1,               //  MAIN  0  1 
        S_0, S_1,               //  SIGNAL  0  1
        M_0a,M_1a,
        S_0a,S_1a;
bool BuyOp=false;
//--------------------------------------------------------------------
                                  //    ..
   M_0 = iStochastic(NULL,Periods,5,3,3,MODE_SMA,0,MODE_MAIN,  0);// 0 
   M_1 = iStochastic(NULL,Periods,5,3,3,MODE_SMA,0,MODE_MAIN,  1);// 1 
   S_0 = iStochastic(NULL,Periods,5,3,3,MODE_SMA,0,MODE_SIGNAL,0);// 0 
   S_1 = iStochastic(NULL,Periods,5,3,3,MODE_SMA,0,MODE_SIGNAL,1);// 1 
   M_0a = iStochastic(NULL,Periods2,5,3,3,MODE_SMA,0,MODE_MAIN,  0);// 0 
   M_1a = iStochastic(NULL,Periods2,5,3,3,MODE_SMA,0,MODE_MAIN,  1);// 1 
   S_0a = iStochastic(NULL,Periods2,5,3,3,MODE_SMA,0,MODE_SIGNAL,0);// 0 
   S_1a = iStochastic(NULL,Periods2,5,3,3,MODE_SMA,0,MODE_SIGNAL,1);// 1 
//--------------------------------------------------------------------
if (High[0]<High[1]&&High[1]<High[2]&&High[2]<High[3]&&Open[0]<Open[1]&&Open[1]<Open[2]&&Open[2]<Open[3]) BuyOp=true;
   if(Time[0] == prevtime) 
       return(0);
   prevtime = Time[0];
   if(!IsTradeAllowed()) 
     {
       prevtime = Time[1];
       return(0);
     }
//----
    if (total < MaxOrders || MaxOrders == 0)
     {   
       if(BuyOp)
        { 
          if( M_1 > S_1 && M_0 > S_0 )   //   
          {
                   if( M_1a > S_1a && M_0a > S_0a )   //   
{
           OrderSend(Symbol(),OP_BUY,lot,Ask,3,Bid-(StopLoss*Point),Ask+(TakeProfit*Point),"OpenTiks_Buy",magicnumber,0,Green);
          }
        }
        }
        }
//----
   return(0);
  } 
//+------------------------------------------------------------------+