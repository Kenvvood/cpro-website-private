//+------------------------------------------------------------------+
//|                                         CPro Tool Hanger_Scaled_ProfitAttempt MT5        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include<Trade\Trade.mqh>
#include <Expert\Trailing\TrailingNone.mqh>
#include <Expert\Money\MoneyFixedLot.mqh>

//+------------------------------------------------------------------+
//| Include                                                          |
//+------------------------------------------------------------------+
  // include the file Trade.mqh
// Create an instance of Ctrade
CTrade trade;
//--- available trailing
//--- available money management
//+------------------------------------------------------------------+
//| Inputs                                                           |
//+------------------------------------------------------------------+
//--- inputs for main signal
input double             Signal_TakeLevel     =210.0;//take 利润 级别 (in 点数)
input double             Price_Trigger        =160.0;//价格 trigger
input int                Balance_Range         =2.0;//余额 trigger
input int                Max_Positions_Total   =7.0;//均线x positions to be held
input double             Gain_Percentage        =1.25;//gain 百分比 in 净值 before 平仓 all
//--- inputs for money
input double             Money_FixLot_Percent =1.0;//百分比
input double             Money_FixLot_Lots    =0.10;//固定交易量
//+------------------------------------------------------------------+
//| Global expert object                                             |
//+------------------------------------------------------------------+
//CExpert ExtExpert;
//+------------------------------------------------------------------+
//| Initialization function of the expert                            |
//+------------------------------------------------------------------+
void OnTick()
{
   // Get the ask & bid price
   double Ask=NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_ASK),4);
   double Bid=NormalizeDouble(SymbolInfoDouble(_Symbol,SYMBOL_BID),4);  
      //Get the Account Balance
   double Balance=AccountInfoDouble(ACCOUNT_BALANCE);
   //Get the Account Equity
   double Equity=AccountInfoDouble(ACCOUNT_EQUITY);  
   //Get the Account Margin Free
  double Free_Margin=AccountInfoDouble(ACCOUNT_MARGIN_FREE); 
  //Get the Account Margin
  double Account_Margin=AccountInfoDouble(ACCOUNT_MARGIN);
  //Get total positions
  int Total_Positions=PositionsTotal();
  // Calculate the deposit load
  double Deposit_Load = Account_Margin/Equity;
  //Create an equity starting point
 static double Base_Equity=0;
  if (PositionsTotal()==0)
  {
  Base_Equity=Equity;
  }
      //Create an Array for prices
      MqlRates PriceInformation[];
      // Sort it from current candle to oldest candle
      ArraySetAsSeries(PriceInformation,true);
   //Copy price data into the array ------ old text that was in place of 50 --- Bars(Symbol(),Period())
      int Data=CopyRates(Symbol(),_Period,0,10,PriceInformation);
 //ORDER HISTORY PROFIT TUTORIAL START
   uint   TotalNumberOfDeals=HistoryDealsTotal();
   ulong  TicketNumber=0;
   long   OrderType, DealEntry;
   double OrderProfit=0;
   string MySymbol="";
   string PositionDirection="";
   string MyResult="";
 static  double open_price=0;
   //get the history
   HistorySelect(0,TimeCurrent());
   //go through all the deals
   for(uint i=0; i<TotalNumberOfDeals;i++)
   {
      //we look for a ticket number  -- use an if statement, because if there are no open positions this avoids an error
      if((TicketNumber=HistoryDealGetTicket(i))>0)
         {
         //Get the profit
         OrderProfit=HistoryDealGetDouble(TicketNumber,DEAL_PROFIT);
         // get the type
         OrderType = HistoryDealGetInteger(TicketNumber,DEAL_TYPE);
         //get the currency pair
         MySymbol=HistoryDealGetString(TicketNumber,DEAL_SYMBOL);
         //get the deal entry type to check for close types
         DealEntry=HistoryDealGetInteger(TicketNumber,DEAL_ENTRY);
         open_price=HistoryDealGetDouble(TicketNumber,DEAL_PRICE);
      //+++++++++++++++SET THE BASE PRICE +++++++++++++++++++++++++++
   double             BasePrice=open_price;        
         //If the currency pair fits
         if (MySymbol==_Symbol)
         //if it is a buy or a sell order
         if(OrderType==ORDER_TYPE_BUY || OrderType==ORDER_TYPE_SELL)
         //if the order was closed
         if (DealEntry==1)
         {
            // set sell order type if close type was buy
            if (OrderType==ORDER_TYPE_BUY)
            PositionDirection="SELL-TRADE";
            //set buy order type if close type was sell
            if (OrderType==ORDER_TYPE_SELL)
            PositionDirection="BUY-TRADE";
        //    MyResult = "Profit:"+OrderProfit+ "Ticket:" +TicketNumber+ "Position Direction:"+PositionDirection;  
  //ORDER HISTORY PROFIT TUTORIAL END
 }
   }
      }
     if(PositionsTotal()<1)
     {
      trade.Buy(Money_FixLot_Percent,NULL,Ask,NULL,(Ask+Signal_TakeLevel*_Point),NULL);
         }
      //check all open positions for the current symbol +++++++++++++++++++++++++++++CHANGED i=PositionsTotal ()-1; i>=0
      for(int i=PositionsTotal()-1; i>=0; i--) // count all currency pair positions
      {
         string symbol=PositionGetSymbol(i); // get position symbol
            if(_Symbol==symbol) // if chart symbol equals position symbol
               // get the ticket number
               ulong PositionTicket=PositionGetInteger(POSITION_TICKET);   
               //get the current Stop Loss
               double CurrentStopLoss=PositionGetDouble(POSITION_SL);
                              //get the open price
           //    double open_price=PositionGetDouble(POSITION_PRICE_OPEN);
            //   datetime open_start_time=PositionGetDouble(POSITION_TIME_MSC);
            }
    //   if(PositionsTotal()>=1)
    //   if(Bid<=open_price-Price_Trigger*_Point)
     //          trade.Sell(Money_FixLot_Lots,NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL);
      if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
         if(Ask>=open_price+Price_Trigger*_Point)
            if(PositionsTotal()<=Max_Positions_Total)
              // {trade.BuyStop(Money_FixLot_Lots,open_price+Price_Trigger*_Point,_Symbol,NULL,Signal_TakeLevel*_Point,ORDER_TIME_GTC,0,NULL); }
                  trade.Sell((Money_FixLot_Percent),NULL,Bid,(Ask+Signal_TakeLevel*_Point),0,NULL);       
       if(PositionsTotal()>=1&& (OrdersTotal()+PositionsTotal())==PositionsTotal())
         if(Bid<=open_price-Price_Trigger*_Point)
            if(PositionsTotal()<=Max_Positions_Total)
              // {trade.BuyStop(Money_FixLot_Lots,open_price+Price_Trigger*_Point,_Symbol,NULL,Signal_TakeLevel*_Point,ORDER_TIME_GTC,0,NULL); }+++++(Bid-100*_Point)
                  trade.Buy((Money_FixLot_Percent),NULL,Ask,(Bid-Signal_TakeLevel*_Point),999999999,NULL);
      //  (Ask+Signal_TakeLevel*_Point) ++++++++  (Bid-Signal_TakeLevel*_Point)
      //++++++++++++++Balancing Trades+++++++
      //Buy & Sell Counter Variables
  int Buy_Position_Counter=0;
  int Sell_Position_Counter=0;    
    // count down until there are no positions left
   for(int i=PositionsTotal()-1; i>=0; i--) // go through all positions
   {
         //Get the ticket number for the current position
         int ticket=PositionGetTicket(i);
 //        
         // Get the positon direction
         int PositionDirection=PositionGetInteger(POSITION_TYPE);
         //if it is a buy position
         if (PositionDirection==POSITION_TYPE_BUY)
         //close the current position add to buy counter here
               // add 1 to the candleCounter
      Buy_Position_Counter=Buy_Position_Counter+1;
               //if it is a buy position
         if (PositionDirection==POSITION_TYPE_SELL)
         //close the current position add to buy counter here
               // add 1 to the candleCounter
      Sell_Position_Counter=Sell_Position_Counter+1;
   }//End for loop
      // Pull the counters into the logic for buying/selling here
  if((Buy_Position_Counter-Sell_Position_Counter)>=Balance_Range)
             trade.Sell((Money_FixLot_Percent*Total_Positions*2),NULL,Bid,0,(Bid-Signal_TakeLevel*_Point),NULL);
  if((Sell_Position_Counter-Buy_Position_Counter)>=Balance_Range)
              trade.Buy((Money_FixLot_Percent*Total_Positions*2),NULL,Ask,0,(Ask+Signal_TakeLevel*_Point),NULL);  
      //if we have a profit, close all positions "if the equity is above the balance, that means we made a profit"  +++++++  Equity>=Balance)Free_Margin<=0 || 
   if (Equity>=Base_Equity*Gain_Percentage || Equity<=Base_Equity*0)
         {
            CloseAllPositions();
         }
}
// EXTERNAL CLOSE FUNCTION 
void CloseAllPositions()
   {
   // from the number of positions count down to zero
   for(int i=PositionsTotal()-1; i>=0; i--) //look at all positions
   {
      // get the ticket number for the current position
      int ticket=PositionGetTicket(i);
      // close the current postion
      trade.PositionClose(ticket);
   }   // End the for loop
 } // CloseAllPositions end
double DynamicVolume(){ return(0.0); };