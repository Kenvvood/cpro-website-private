//+------------------------------------------------------------------+
//|                                         CPro Indicator Decision_Candles_Colored MT5      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


input double dcpercent = 50;//decision candle body/范围 百分比
double buff0[];
double buff1[];
double buff2[];
double buff3[];
double buff4[];
double buff5[];
double buff6[];
double buff7[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   IndicatorSetString(INDICATOR_SHORTNAME, "DCandles");
   SetIndexBuffer(0, buff0, INDICATOR_DATA);
   SetIndexBuffer(1, buff1, INDICATOR_DATA);
   SetIndexBuffer(2, buff2, INDICATOR_DATA);
   SetIndexBuffer(3, buff3, INDICATOR_DATA);
   SetIndexBuffer(4, buff4, INDICATOR_DATA);
   SetIndexBuffer(5, buff5, INDICATOR_DATA);
   SetIndexBuffer(6, buff6, INDICATOR_DATA);
   SetIndexBuffer(7, buff7, INDICATOR_DATA);
   for(int in = 0; in < 8; in++)PlotIndexSetInteger(in, PLOT_SHOW_DATA, false);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
//---
   int start = prev_calculated;
   if(start >= rates_total)start = rates_total - 1;
   if(start < 0)start = 0;
   for(int i = start; i < rates_total; i++)
     {
      buff0[i] = EMPTY_VALUE;
      buff1[i] = EMPTY_VALUE;
      buff2[i] = EMPTY_VALUE;
      buff3[i] = EMPTY_VALUE;
      buff4[i] = EMPTY_VALUE;
      buff5[i] = EMPTY_VALUE;
      buff6[i] = EMPTY_VALUE;
      buff7[i] = EMPTY_VALUE;
      bool DC = (high[i] - low[i]) * dcpercent / 100 <= fabs(close[i] - open[i]);
      bool up = DC && close[i] > open[i];
      bool dn = DC && close[i] < open[i];
      if(up)
        {
         buff0[i] = open[i];
         buff1[i] = high[i];
         buff2[i] = low[i];
         buff3[i] = close[i];
        }
      if(dn)
        {
         buff4[i] = open[i];
         buff5[i] = high[i];
         buff6[i] = low[i];
         buff7[i] = close[i];
        }
     }
//--- return value of prev_calculated for next call
   return(rates_total);
  }
//+------------------------------------------------------------------+