//+------------------------------------------------------------------+
//|                                         CPro Tool EA_E_mail MT4                          |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern int       TimeInterval=30;    // xx minutes to send the e-mail
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
   while(TimeInterval>0)
   {
       SendMail("Forex Account : " +AccountName()+ " Details",
      "Date and Time : "+TimeToStr(TimeCurrent(),TIME_DATE|TIME_SECONDS)+" \n"+
      "Balance       : "+DoubleToStr(AccountBalance(),2)+" \n"+
      "Used Margin   : "+DoubleToStr(AccountMargin(),2)+" \n"+
      "Free Margin   : "+DoubleToStr(AccountFreeMargin(),2)+" \n"+
      "Equity        : "+DoubleToStr(AccountEquity(),2)+" \n"+
      "Open Orders   : "+DoubleToStr(OrdersTotal(),0)+" \n\n"+
      "Broker  : "+AccountCompany()+" \n"+
      "Leverage: "+AccountLeverage()+"" );
       Sleep( TimeInterval*60*1000);    //sleep in miliseconds, so use 60*1000 to change to minute
   }
//----
   return(0);
  }
//+------------------------------------------------------------------+