//+------------------------------------------------------------------+
//|                                         CPro Indicator SupportResistance MT5             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//---- version
//---- indicator in the chart window
//---- 2 indicator buffers are used
//---- 2 graphic plots are used
//+----------------------------------------------+
//|  Bearish indicator options                   |
//+----------------------------------------------+
//---- drawing type as arrow
//---- Magenta color
//---- Line width
//---- Support label
//+----------------------------------------------+
//|  Bullish indicator options                   |
//+----------------------------------------------+
//---- drawing type as arrow
//---- Lime color
//---- Line width
//---- Resistance label
//+----------------------------------------------+
//| Indicator input parameters                   |
//+----------------------------------------------+
//input int iPeriod=70; // ATR period
//+----------------------------------------------+
//---- declaration of dynamic arrays, used as indicator buffers
double SellBuffer[];
double BuyBuffer[];
//---
int StartBars;
int FRA_Handle;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
void OnInit()
  {
//---- initialization of global variables
   CPro_Init();  // CPro营销模块初始化
   StartBars=6;
//---- get handle of the iFractals indicator
   FRA_Handle=iFractals(NULL,0);
   if(FRA_Handle==INVALID_HANDLE)Print(" INVALID_HANDLE FRA");
//---- set SellBuffer as indicator buffer
   SetIndexBuffer(0,SellBuffer,INDICATOR_DATA);
//---- set indxex of starting bar to plot
   PlotIndexSetInteger(0,PLOT_DRAW_BEGIN,StartBars);
//---- set label for support
   PlotIndexSetString(0,PLOT_LABEL,"Support");
//---- set arrow char code
   PlotIndexSetInteger(0,PLOT_ARROW,158);
//---- set indexing as timeseries
   ArraySetAsSeries(SellBuffer,true);
//---- set BuyBuffer as an indicator buffer
   SetIndexBuffer(1,BuyBuffer,INDICATOR_DATA);
//---- set index of starting bar to plot
   PlotIndexSetInteger(1,PLOT_DRAW_BEGIN,StartBars);
//---  set label for resistance
   PlotIndexSetString(1,PLOT_LABEL,"Resistance");
//---- set arrow char code
   PlotIndexSetInteger(1,PLOT_ARROW,158);
//---- set indexation as timeseries
   ArraySetAsSeries(BuyBuffer,true);
//---- set precision
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);
//---- indicator short name
   string short_name="Support & Resistance";
   IndicatorSetString(INDICATOR_SHORTNAME,short_name);
//----   
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]
                )
  {
//---- checking of bars
   if(BarsCalculated(FRA_Handle)<rates_total
      || rates_total<StartBars)
      return(0);
//---- declaration of local variables
   int to_copy,limit,bar;
   double FRAUp[],FRALo[];
//---- calculation of bars to copy
//---- and starting index (limit) for bars recalculation loop
   if(prev_calculated>rates_total || prev_calculated<=0)// checking the first call
     {
      to_copy=rates_total;           // bars to copy
      limit=rates_total-StartBars-1; // starting index
     }
   else
     {
      to_copy=rates_total-prev_calculated+3; // bars to copy
      limit=rates_total-prev_calculated+2;   // starting index
     }
//---- set indexing as timeseries
   ArraySetAsSeries(FRAUp,true);
   ArraySetAsSeries(FRALo,true);
   ArraySetAsSeries(high,true);
   ArraySetAsSeries(low,true);
//---- copy indicator data to arrays
   if(CopyBuffer(FRA_Handle,0,0,to_copy,FRAUp)<=0) return(0);
   if(CopyBuffer(FRA_Handle,1,0,to_copy,FRALo)<=0) return(0);
//---- main loop
   for(bar=limit; bar>=0; bar--)
     {
       BuyBuffer[bar] = 0.0;
       SellBuffer[bar] = 0.0;
       if(FRAUp[bar] != DBL_MAX) BuyBuffer[bar] = high[bar]; else BuyBuffer[bar] = BuyBuffer[bar+1];
       if(FRALo[bar] != DBL_MAX) SellBuffer[bar] = low[bar]; else SellBuffer[bar] = SellBuffer[bar+1];
     }
//----     
   return(rates_total);
  }
//+------------------------------------------------------------------+