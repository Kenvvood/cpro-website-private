//+------------------------------------------------------------------+
//|                                         CPro Tool RTReqBroker MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include <Zmq/Zmq.mqh>

//+------------------------------------------------------------------+
//| This example comes from the "Load Balancing Pattern"             |
//| The original example creates threads for workers and spawn them  |
//| in the broker main thread. MetaTrader Terminal does not support  |
//| thread creation. So we split the broker and worker code to two   |
//| scripts. Since we splitted the code, we need to wait all workers |
//| connect.                                                         |
//| This is the broker part.                                         |
//+------------------------------------------------------------------+
input int InpNumberWorkers=5;
//+------------------------------------------------------------------+
//| Custom routing Router to Mama (ROUTER to REQ) (adapted from C++) |
//| Olivier Chamoux <olivier.chamoux@fr.thalesgroup.com>             |
//+------------------------------------------------------------------+
void OnStart()
  {
   Context context("rtreq");
   Socket broker(context,ZMQ_ROUTER);
   broker.bind("inproc://rtreq");
   string identities[];
   ArrayResize(identities,InpNumberWorkers);
// Wait until InpNumberWorkers workers connected
   for(int i=0; i<InpNumberWorkers; i++)
     {
      ZmqMsg msg;
      broker.recv(msg);
      string identity=msg.getData();
      broker.recv(msg);     //  Envelope delimiter
      broker.recv(msg);     //  Response from worker
      identities[i]=identity;
      Print("Broker: Worker ",identity," connected.");
     }
   Print("Broker: All workers connected!");
// Notify all workers that it is ready to dispatch work
   for(int i2=0; i2<InpNumberWorkers; i2++)
     {
      broker.sendMore(identities[i2]);
      broker.sendMore();
      broker.send("Go!");
     }
//  Run for five seconds and then tell workers to end
   long endTime=TimeLocal()+5;
   int workersFired=0;
   while(!IsStopped())
     {
      ZmqMsg msg;
      //  Next message gives us least recently used worker
      broker.recv(msg);
      string identity2=msg.getData();
      Print("Broker: Get available worker [",identity2,"]");
      broker.recv(msg);     //  Envelope delimiter
      broker.recv(msg);     //  Response from worker
      Print("Broker: And he says ",msg.getData());
      if(!broker.sendMore(identity2)) {Print("Error sending identity2.");}
      if(!broker.sendMore("")) {Print("Error sending delimeter.");}
      //  Encourage workers until it's time to fire them
      if(TimeLocal()<endTime)
        {
         Print("Send work!");
         if(!broker.send("Work harder")) {Print("Error sending work.");}
        }
      else
        {
         Print("Send fire!");
         if(!broker.send("Fired!")) {Print("Error sending fired.");}
         if(++workersFired==InpNumberWorkers)
            break;
        }
     }
  }
//+------------------------------------------------------------------+