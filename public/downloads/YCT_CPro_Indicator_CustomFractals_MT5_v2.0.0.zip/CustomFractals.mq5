//+------------------------------------------------------------------+
//|                                         CPro Indicator CustomFractals MT5                |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


//--- indicator settings
//--- indicator buffers
double ExtUpperBuffer[];
double ExtLowerBuffer[];
//--- 10 pixels upper from high price
int    ExtArrowShift = -10;
//---
int ExtWingding01 = 217;
int ExtWingding02 = 218;
//--- input
input int how_many = 2;//K线数 left and right
input int how_far_away = -10;
input int sign_size = 3;
input int wingding_num1 = 217;
input int wingding_num2 = 218;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
void OnInit() {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0, ExtUpperBuffer, INDICATOR_DATA);
   SetIndexBuffer(1, ExtLowerBuffer, INDICATOR_DATA);
   IndicatorSetInteger(INDICATOR_DIGITS, _Digits);
//---check if the characters are within wingdings characters
   if(wingding_num1 < 0 || wingding_num1 > 255) {
      ExtWingding01 = 217;
      Print("unicode character must be within 255+0");
   } else ExtWingding01 = wingding_num1;
   if(wingding_num2 < 0 || wingding_num2 > 255) {
      ExtWingding02 = 218;
      Print("unicode character must be within 255+0");
   } else ExtWingding02 = wingding_num2;
//--- sets arrow form from microsoft wingdings that will be drawn
   PlotIndexSetInteger(0, PLOT_ARROW, wingding_num1);
   PlotIndexSetInteger(1, PLOT_ARROW, wingding_num2);
//--- arrow shifts when drawing
   ExtArrowShift = how_far_away;
   PlotIndexSetInteger(0, PLOT_ARROW_SHIFT, ExtArrowShift);
   PlotIndexSetInteger(1, PLOT_ARROW_SHIFT, -ExtArrowShift);
//--- sets drawing line empty value--
   PlotIndexSetDouble(0, PLOT_EMPTY_VALUE, EMPTY_VALUE);
   PlotIndexSetDouble(1, PLOT_EMPTY_VALUE, EMPTY_VALUE);
//--- sets sign size
   PlotIndexSetInteger(0, PLOT_LINE_WIDTH, sign_size);
   PlotIndexSetInteger(1, PLOT_LINE_WIDTH, sign_size);
}
//+------------------------------------------------------------------+
//|  OnCalculate function                                            |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
//if there are not enough bars
   if(rates_total < ((how_many * 2) + 1))
      return(0);
//--- preliminary settings
   int start;
   if(prev_calculated < ((how_many * 2) + 3)) {
      start = how_many;
   } else
      start = rates_total - ((how_many * 2) + 1);
//--- clean up arrays
   ArrayInitialize(ExtUpperBuffer, EMPTY_VALUE);
   ArrayInitialize(ExtLowerBuffer, EMPTY_VALUE);
//--- main cycle of calculations
//--- Upper Fractal
   for(int i = start; i < rates_total - (how_many + 1) && !IsStopped(); i++) {
      bool IsFractalUp = true;
      for(int j = 1; j <= how_many && IsFractalUp == true; j++) {
         IsFractalUp &= (high[i] > high[i + j]);
         IsFractalUp &= (high[i] > high[i - j]);
      }
      if(IsFractalUp) ExtUpperBuffer[i] = high[i];
      else
         ExtUpperBuffer[i] = EMPTY_VALUE;
   }
//--- Lower Fractal
   for(int i = start; i < rates_total - (how_many + 1) && !IsStopped(); i++) {
      bool IsFractalDn = true;
      for(int j = 1; j <= how_many && IsFractalDn == true; j++) {
         IsFractalDn &= (low[i] < low[i + j]);
         IsFractalDn &= (low[i] < low[i - j]);
      }
      if(IsFractalDn) ExtLowerBuffer[i] = low[i];
      else
         ExtLowerBuffer[i] = EMPTY_VALUE;
   }
//--- OnCalculate done. Return new prev_calculated.
   return(rates_total);
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+