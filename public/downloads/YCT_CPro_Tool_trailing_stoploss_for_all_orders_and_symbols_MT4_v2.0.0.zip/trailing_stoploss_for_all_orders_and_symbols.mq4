//+------------------------------------------------------------------+
//|                                         CPro Tool trailing_stoploss_for_all_orders_and_symbols MT4 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

// Input parameters
extern int TrailStart = 20;            // Trailing start level in pips
extern int TrailStop = 10;             // Trailing stop level in pips
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
void OnInit()
  {
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
    TrailingStop();
  }
//+------------------------------------------------------------------+
//| Trailing stop function                                          |
//+------------------------------------------------------------------+
void TrailingStop()
  {
    for(int i = OrdersTotal() - 1; i >= 0; i--)
      {
        if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
          {
            if(OrderType() <= OP_SELL)
              {
                double currentProfit = OrderProfit();
                double currentStopLoss = OrderStopLoss();
                double currentPrice = OrderOpenPrice();
                if(currentProfit > 0) // Only trailing if the trade is in profit
                  {
                    double trailPrice = 0;
                    // Calculate the trailing stop price
                    if(OrderType() == OP_BUY)
                      {
                        trailPrice = currentPrice + TrailStart * Point;
                        trailPrice = MathMax(trailPrice, currentStopLoss + TrailStop * Point);
                      }
                    else if(OrderType() == OP_SELL)
                      {
                        trailPrice = currentPrice - TrailStart * Point;
                        trailPrice = MathMin(trailPrice, currentStopLoss - TrailStop * Point);
                      }
                    // Update stop loss if the new price is better
                    if(trailPrice != currentStopLoss)
                      {
                        bool res = OrderModify(OrderTicket(), OrderOpenPrice(), trailPrice, OrderTakeProfit(), 0, clrNONE);
                        if(res)
                          {
                            Print("Trailing stop for order ", OrderTicket(), " updated successfully.");
                          }
                        else
                          {
                            Print("Failed to update trailing stop for order ", OrderTicket());
                          }
                      }
                  }
              }
          }
      }
  }