//+------------------------------------------------------------------+
//|  CPro MT4 Stub - Empty implementations for MT4 compatibility    |
//+------------------------------------------------------------------+
// This stub provides empty implementations of CPro marketing module
// for MQ4 files. CPro trading features require MQL5.

#ifndef __CPRO_MT4_STUB_MQH__
#define __CPRO_MT4_STUB_MQH__

//+------------------------------------------------------------------+
//| CPro MT4 Stub Classes                                            |
//+------------------------------------------------------------------+
class CProDialog {
public:
   CProDialog() {}
   ~CProDialog() {}
   void Init() {}
   void Deinit() {}
   void Show() {}
   void Hide() {}
};

class CProPanel {
public:
   CProPanel() {}
   ~CProPanel() {}
   void Init() {}
   void Deinit() {}
   void Show() {}
   void Hide() {}
};

class CProWatermark {
public:
   CProWatermark() {}
   ~CProWatermark() {}
   void Init() {}
   void Deinit() {}
   void Show() {}
   void Hide() {}
};

//+------------------------------------------------------------------+
//| CPro MT4 Stub Functions                                          |
//+------------------------------------------------------------------+
void CPro_Init() {}
void CPro_DeInit() {}  // MQL4 is case-insensitive
void CPro_Deinit() {}  // alias for compilers that are strict

#endif
