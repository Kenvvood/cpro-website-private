//+------------------------------------------------------------------+
//|                                         CPro Tool dual_stoploss MT4                      |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern double WhenToClose			= 10;			// Points to Close Order Just Before StopLoss Hit
double STOPLEVEL	= (int)MarketInfo(Symbol(), MODE_STOPLEVEL);
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
//---
//---
return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
//---
}
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
//---
	CloseBeforeStopLoss();
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| CLOSE ORDER BEFORE STOPLOSS						 		 											 |
//+------------------------------------------------------------------+
void CloseBeforeStopLoss()
{
	for (int i= OrdersTotal()-1 ; i>= 0 ; i--)
		{		
			if (OrderSelect(i, SELECT_BY_POS, MODE_TRADES))	//-------------> Expert searches all open orders in the pool
				{
					if (OrderMagicNumber()!= -1) //----------------------------> If you would like this EA acts on special orders, replace this section with >> if (OrderMagicNumber()== "Your desired Number")
						{
							if (OrderStopLoss()!= 0)	//---------------------------> Orders WITHOUT Stop-loss will be ignored.
								{
									if (OrderType()== OP_BUY) //-----------------------> BUY Orders will be processed
										{						
											if (MarketInfo(OrderSymbol(), MODE_BID)- OrderStopLoss() <= getPoint(WhenToClose + STOPLEVEL))
												{
													//---
													bool BUYCLOSE = OrderClose(OrderTicket(), OrderLots(), MarketInfo(OrderSymbol(),MODE_BID),	0, clrOrange);
													if(!BUYCLOSE)
														{
															Print("Error in CloseBeforeStopLoss. Error code=", GetLastError());
															return;
														}
													if(BUYCLOSE)break;
												}
										}
									if (OrderType()	== OP_SELL) //---------------------> SELL Orders will be processed
										{						
											if (OrderStopLoss() - MarketInfo(OrderSymbol(),MODE_ASK)	<= getPoint(WhenToClose + STOPLEVEL))
												{
													//---
													bool SELLCLOSE = OrderClose(OrderTicket(), OrderLots(), MarketInfo(OrderSymbol(), MODE_ASK), 0, clrOrange);
													if(!SELLCLOSE)
														{
															Print("Error in CloseBeforeStopLoss. Error code=", GetLastError());
															return;
														}
													if(SELLCLOSE)break;
												}
										}
								}
						}
				}
		}
}
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Point Value Converter Function 			                 						 |
//+------------------------------------------------------------------+
double	getPoint(double value)
{
	return (NormalizeDouble (value * Point , Digits));
}
//+------------------------------------------------------------------+