//+------------------------------------------------------------------+
//|                                         CPro Indicator Bollinger_Bands_with_pre_Band_Smoothing MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


// Plot properties for the Bollinger Bands
// Input parameters
input int BB_Period = 20;//bb 周期
input double BB_Deviation = 2.0;//standard 偏移量 乘数
input ENUM_MA_METHOD ma_method = MODE_SMA;//均线 类型
input bool additive_smoothing = true; // Additive outer band smoothing
input int MA_Period_1 = 14;//upper band 均线 smoothing 周期
input int MA_Period_2 = 14;//lower band 均线 smoothing 周期
// Indicator buffers
double BBUpperBuffer[];
double BBLowerBuffer[];
double BBMainBuffer[];
double BBCalcBuffer[];
double ma_buf_a[];
double ma_buf_b[];
// Moving Average handles
int handle;
int handle_2;
int upper;
int lower;
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int OnInit()
{
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0, BBUpperBuffer, INDICATOR_DATA);
   SetIndexBuffer(1, BBLowerBuffer, INDICATOR_DATA);
   SetIndexBuffer(2, BBMainBuffer, INDICATOR_DATA);
   SetIndexBuffer(3, BBCalcBuffer, INDICATOR_CALCULATIONS);
   SetIndexBuffer(4, ma_buf_a, INDICATOR_CALCULATIONS);
   SetIndexBuffer(5, ma_buf_b, INDICATOR_CALCULATIONS);
   handle = iMA(NULL, 0, BB_Period, 0, ma_method, PRICE_CLOSE);
   handle_2 = iMA(NULL, 0, BB_Period, 0, ma_method, PRICE_CLOSE);
   upper = iMA(NULL, 0, additive_smoothing ? BB_Period + MA_Period_1 : MA_Period_1, 0, ma_method, PRICE_CLOSE);
   lower = iMA(NULL, 0, additive_smoothing ? BB_Period + MA_Period_2 : MA_Period_2, 0, ma_method, PRICE_CLOSE);
   IndicatorSetString(INDICATOR_SHORTNAME, "Bollinger Bands with outer band smoothing");
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| Custom indicator deinitialization function                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   IndicatorRelease(handle);
   IndicatorRelease(handle_2);
   IndicatorRelease(upper);
   IndicatorRelease(lower);
   CPro_Deinit();  // CPro营销模块清理
}
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if(rates_total < BB_Period)
      return 0;
   int calculated = BarsCalculated(handle);
   if(calculated < rates_total)
   {
      Print("Not all data of handle is calculated (", calculated, " bars). Error ", GetLastError());
      return prev_calculated;
   }
   calculated = BarsCalculated(handle_2);
   if(calculated < rates_total)
   {
      Print("Not all data of handle_2 is calculated (", calculated, " bars). Error ", GetLastError());
      return prev_calculated;
   }
   calculated = BarsCalculated(upper);
   if(calculated < rates_total)
   {
      Print("Not all data of upper is calculated (", calculated, " bars). Error ", GetLastError());
      return prev_calculated;
   }
   calculated = BarsCalculated(lower);
   if(calculated < rates_total)
   {
      Print("Not all data of lower is calculated (", calculated, " bars). Error ", GetLastError());
      return prev_calculated;
   }
   int to_copy = (prev_calculated > rates_total || prev_calculated < 0) ? rates_total : rates_total - prev_calculated;
   if(prev_calculated > 0)
      to_copy++;
   if(IsStopped()) return 0;
   if(CopyBuffer(handle, 0, 0, to_copy, BBMainBuffer) <= 0)
   {
      Print("Getting main MA failed! Error ", GetLastError());
      return 0;
   }
   if(IsStopped()) return 0;
   if(CopyBuffer(handle_2, 0, 0, to_copy, BBCalcBuffer) <= 0)
   {
      Print("Getting calculation MA failed! Error ", GetLastError());
      return prev_calculated;
   }
   if(IsStopped()) return 0;
   if(CopyBuffer(upper, 0, 0, to_copy, ma_buf_a) <= 0)
   {
      Print("Getting upper smoothing MA failed! Error ", GetLastError());
      return prev_calculated;
   }
   if(IsStopped()) return 0;
   if(CopyBuffer(lower, 0, 0, to_copy, ma_buf_b) <= 0)
   {
      Print("Getting lower smoothing MA failed! Error ", GetLastError());
      return prev_calculated;
   }
   int limit = (prev_calculated == 0) ? 0 : prev_calculated - 1;
   for(int i = limit; i < rates_total && !IsStopped(); i++)
   {
      double stdDev = iDeviation(close, BBCalcBuffer, BB_Period, i);
      BBUpperBuffer[i] = ma_buf_a[i] + BB_Deviation * stdDev;
      BBLowerBuffer[i] = ma_buf_b[i] - BB_Deviation * stdDev;
   }
   return rates_total;
}
//+------------------------------------------------------------------+
//| Function to calculate standard deviation                         |
//+------------------------------------------------------------------+
double iDeviation(const double &price[], const double &ma_price[], int period, int pos)
{
   double dSum = 0;
   for(int i = 0; i < period && pos >= 0; i++)
   {
      int index = pos - i;
      if(index >= 0 && index < ArraySize(price) && index < ArraySize(ma_price))
         dSum += MathPow(price[index] - ma_price[pos], 2);
   }
   return MathSqrt(dSum / period);
}