//+------------------------------------------------------------------+
//|                                         CPro Indicator A_BETTER_RSI MT5                  |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <MovingAverages.mqh>

//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
input int Signal_period = 22;//信号 周期
input int ROC_period = 10;//比率 of change 周期
//--- indicator buffer
double Deriv[];
double RMS[];
double Clip[];
double Z3[];
double Signal[];
double ROC[];
double Z3MA[];
double SignalMA[];
int OnInit()
  {
//--- indicator buffers mapping
   CPro_Init();  // CPro营销模块初始化
   SetIndexBuffer(0,ROC,INDICATOR_DATA);
   SetIndexBuffer(1,RMS,INDICATOR_CALCULATIONS);
   SetIndexBuffer(2,Clip,INDICATOR_CALCULATIONS);
   SetIndexBuffer(3,Z3,INDICATOR_CALCULATIONS);
   SetIndexBuffer(4,Signal,INDICATOR_CALCULATIONS);
   SetIndexBuffer(5,Deriv,INDICATOR_CALCULATIONS);
   SetIndexBuffer(6,Z3MA,INDICATOR_CALCULATIONS);
   SetIndexBuffer(7,SignalMA,INDICATOR_CALCULATIONS);
   ArraySetAsSeries(Z3MA,true);
   ArraySetAsSeries(SignalMA,true);
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const int begin,
                const double &price[])
  {
//---
   for(int i = 3; i < rates_total; i++){
      Deriv[i] = 0.0;
      RMS[i] = 0.0;
      Clip[i] = 0.0;
      Z3[i] = 0.0;
      Signal[i] = 0.0;
      ROC[i] = 0.0;   
      // Derivative of the price wave
      Deriv[i] = price[i] - price[i-2];
      // Normalize Degap to half RMS and hard limit at +/- 1
     // for(int count = 0; count < rates_total; count ++){
         RMS[i] = RMS[i] + Deriv[i] * Deriv[i];
      //}
      if(RMS[i] != 0){
          Clip[i] = 2 * Deriv[i] / MathSqrt(RMS[i] / 50);
          }
      if(Clip[i] > 1){
          Clip[i] = 1;
          }
      if(Clip[i] < -1){
          Clip[i] = -1;
          }
      // Zeros at Nyquist and 2*Nyquist, i.e. Z3 = (1 + Z^-1)*(1 + Z^-2) to integrate derivative
      Z3[i] = Clip[i] + Clip[i-1] + Clip[i-2] + Clip[i-3];
      //--- Z3 MA calculation   
      Z3MA[i] = SimpleMA(i,ROC_period,Z3);
      // Smooth Z3 for trading signal
      Signal[i] = Z3MA[i];
      //--- Signal MA calculation
      SignalMA[i] = SimpleMA(i,Signal_period,Signal);
      // Use Rate of Change to identify entry point
     ROC[i] = Signal[i] - SignalMA[i];
   }
//--- return value of prev_calculated for next call
   return(rates_total);
  }