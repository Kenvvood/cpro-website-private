//+------------------------------------------------------------------+
//|                                         CPro Tool VLT_TRADER MT4                         |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int profit = 10;
extern int stop = 10;
double BUYLIMIT,SELLLIMIT,bar,sup,sup1;
int okbuy,oksell,onepossell,oneposbuy,i;
double value=100;
int start()
  {
  double VLT,VSE,ULTRA;
  VLT=MathAbs(iHigh(NULL,0,1)-iLow(NULL,0,1));
  for(int i=2;i<10;i++)
  {
  if (MathAbs(iHigh(NULL,0,i)-iLow(NULL,0,i))<value && MathAbs(iHigh(NULL,0,i)-iLow(NULL,0,i))>0){value=MathAbs(iHigh(NULL,0,i)-iLow(NULL,0,i));}
  }  
  okbuy=0;oksell=0;
  for(int cnt=0;cnt<OrdersTotal();cnt++)
     {
      OrderSelect(cnt, SELECT_BY_POS, MODE_TRADES);
         if(OrderType()==OP_BUY || OrderType()==OP_BUYSTOP)
         {
         okbuy=1;
         }
         if(OrderType()==OP_SELL || OrderType()==OP_SELLSTOP)
         {
         oksell=1;
         }
      }
  if(VLT<value && okbuy==0)
  {
  double OpenPrice=High[1]+10*Point;
  double Profit=OpenPrice+profit*Point;
  double Stop=OpenPrice-stop*Point;
  OrderSend(Symbol(),OP_BUYSTOP,0.1,OpenPrice,3,Stop,Profit,"My order #",16384,0,Green);
  okbuy=1;
  }
      if(VLT<value && oksell==0)
  {
   OpenPrice=Low[1]-10*Point;
   Profit=OpenPrice-profit*Point;
   Stop=OpenPrice+stop*Point;
  OrderSend(Symbol(),OP_SELLSTOP,0.1,OpenPrice,3,Stop,Profit,"My order #",16384,0,Green);
  oksell=1;
  }
value=100;
   return(0);
  }