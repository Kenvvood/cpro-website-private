//+------------------------------------------------------------------+
//|                                         CPro Tool trailingstop_ea MT4                    |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int ticket_of_open_pos=1;    // the ticket number of the open pos that you want the EA to manage it
extern int trailing_points=200;     // trailing stop in points
int k;
int i;
int tic;
double StopLoss;
bool otic;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
//---
//---
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
//---
  }
//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
  {
//---
   if(OrdersTotal()>0)
   {
      k=0;
      for(i=0;i<OrdersTotal();i++)
      {
         tic=OrderSelect(k,SELECT_BY_POS,MODE_TRADES);
         if(trailing_points<MarketInfo(OrderSymbol(),MODE_STOPLEVEL) && trailing_points>0)
         {
            trailing_points=MarketInfo(OrderSymbol(),MODE_STOPLEVEL);  
            Alert(OrderSymbol()+": You entered a lower trailing stop level than allowed. It will be changed to the minimum allowed level");
         }
         if (OrderTicket()==ticket_of_open_pos)
         {
            if(OrderType()==OP_BUY)
            {
               if(MarketInfo(OrderSymbol(),MODE_BID)-OrderOpenPrice()>=trailing_points*Point)
               {
                  TrailStop(OrderTicket());   
               }
            }
            if(OrderType()==OP_SELL)
            {
               if(OrderOpenPrice()-MarketInfo(OrderSymbol(),MODE_ASK)>=trailing_points*Point)
               {
                  TrailStop(OrderTicket());   
               }
            } 
         }
         k++;
      }
   }
  }
//+------------------------------------------------------------------+
void TrailStop(int orderticket)
{
   tic=OrderSelect(orderticket, SELECT_BY_TICKET);
   if(OrderType()==OP_BUY) 
   {
      StopLoss = MarketInfo(OrderSymbol(),MODE_BID)-(trailing_points*Point);
      if(StopLoss>OrderStopLoss()) 
      {
         otic=OrderModify(OrderTicket(),OrderOpenPrice(),StopLoss,OrderTakeProfit(),0,CLR_NONE);
      }
   }
   if(OrderType()==OP_SELL) 
   {
      StopLoss = MarketInfo(OrderSymbol(),MODE_ASK)+(trailing_points*Point);
      if(StopLoss<OrderStopLoss()) 
      {
         otic=OrderModify(OrderTicket(),OrderOpenPrice(),StopLoss,OrderTakeProfit(),0,CLR_NONE);
      }
   }
return;
}