//+------------------------------------------------------------------+
//|                                         CPro Tool nevalyashka MT4                        |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------
extern int  stoploss       = 50,
            takeprofit     = 50;
double      Lot=1;
int tip;
//--------------------------------------------------------------------
int init()
{
   OrderSend(Symbol(),OP_SELL,Lot,Bid,3,NormalizeDouble(Ask + stoploss*Point,Digits),
                                    NormalizeDouble(Bid - takeprofit*Point,Digits)," ",777,Blue);
}
//--------------------------------------------------------------------
int start()
{
   for (int i=0; i<OrdersTotal(); i++){   
      if (OrderSelect(i,SELECT_BY_POS,MODE_TRADES)==true){
         if (OrderSymbol()==Symbol()){
            tip = OrderType();
            Lot = OrderLots();return;}}}
   if (Lot==0) return;
   if (tip==0) OrderSend(Symbol(),OP_SELL,Lot,Bid,3,NormalizeDouble(Ask + stoploss*Point,Digits),
                                    NormalizeDouble(Bid - takeprofit*Point,Digits)," ",777,Blue);
   if (tip==1) OrderSend(Symbol(),OP_BUY ,Lot,Ask,3,NormalizeDouble(Bid - stoploss*Point,Digits),
                                    NormalizeDouble(Ask + takeprofit*Point,Digits)," ",777,Blue);
   return(0);
}
//-----------------------------------------------------------------