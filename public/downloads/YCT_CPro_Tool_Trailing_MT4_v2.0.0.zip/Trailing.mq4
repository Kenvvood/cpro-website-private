//+------------------------------------------------------------------+
//|                                         CPro Tool trailing MT4                           |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern int    TakeProfit       = 100;        
extern int    StopLoss         = 20;
extern int    Trailing     = 3;           
int init()
  {
//----
//----
   return(0);
  }
int deinit()
  {
//----
//----
   return(0);
  }
int start()
  {
 Comment("     " ,AccountName(), "              ACCOUNT  ",AccountNumber(),"            PROFIT  ",AccountProfit(),  "           FREE MARGIN  ",AccountFreeMargin(),  "             TOTAL  ",OrdersTotal(), "          EQUITY  ",AccountEquity(), "            BALANCE  ",AccountBalance());
int Magic=0;
for(int cnt=0;cnt<OrdersTotal();cnt++)
     {
      OrderSelect(cnt, SELECT_BY_POS, MODE_TRADES);
      if( OrderSymbol()==Symbol() && OrderMagicNumber()==Magic)
        {
         if(OrderType()==OP_BUY)
           {
            if(Bid-OrderOpenPrice()>=TakeProfit*Point|| OrderOpenPrice()-Ask>StopLoss*Point)
              {
               OrderClose(OrderTicket(),OrderLots(),Bid,0,Violet); return(0);
              }
            if(Trailing>0)
              {
               if(Bid-OrderOpenPrice()>Point*Trailing)
                 {
                  if(OrderStopLoss()<Bid-Point*Trailing)
                    {
                     OrderModify(OrderTicket(),OrderOpenPrice(),Bid-Point*Trailing,OrderTakeProfit(),0,Green); return(0);
                    }
                 }
              }
           }
         if(OrderType()==OP_SELL)
           {
            if(OrderOpenPrice()-Ask>=TakeProfit*Point|| Bid-OrderOpenPrice()>StopLoss*Point)
              {
               OrderClose(OrderTicket(),OrderLots(),Ask,0,Violet); return(0);
              }
            if(Trailing>0)
              {
               if((OrderOpenPrice()-Ask)>(Point*Trailing))
                 {
                  if((OrderStopLoss()>(Ask+Point*Trailing)) || (OrderStopLoss()==0))
                    {
                     OrderModify(OrderTicket(),OrderOpenPrice(),Ask+Point*Trailing,OrderTakeProfit(),0,Red); return(0);
                    }
                 }
              }
           }
         }
       }
  return(0);
}