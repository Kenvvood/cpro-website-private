//+------------------------------------------------------------------+
//|                                         CPro Tool TrendlineBreaker_V1 MT5                |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


int HandleValZigZag;
int HandleRSI;
int MaximalZigZagBufferRange = 200;
input int MinimumHigLowCandleIndex = 3;
int OnInit(){
   CPro_Init();  // CPro营销模块初始化
   string NameValZigZag = "Market\\Valable ZigZag MT5.ex5";
   HandleValZigZag = iCustom(_Symbol,PERIOD_CURRENT,NameValZigZag,1,1,false);
   HandleRSI = iRSI(_Symbol,PERIOD_CURRENT,14,PRICE_CLOSE);
   return(INIT_SUCCEEDED);
  }
void OnDeinit(const int reason){
   CPro_Deinit();  // CPro营销模块清理
  }
void OnTick(){
   double ZigZagValueComp[4][2];
   double RSIValue[];
   CopyBuffer(HandleRSI,0,0,1,RSIValue);
   int CountFoundHighLow = 0;
   double ZigZagValue[];
   CopyBuffer(HandleValZigZag,1,MaximalZigZagBufferRange,1,ZigZagValue);
   //ArraySetAsSeries(ZigZagValue,true);
   for(int i = MinimumHigLowCandleIndex; i < MaximalZigZagBufferRange -1; i++){
      if(ZigZagValue[i] > 0 && CountFoundHighLow < 4){
         ZigZagValueComp[CountFoundHighLow][0] = ZigZagValue[0];
         ZigZagValueComp[CountFoundHighLow][1] = i;
         CountFoundHighLow ++;
      }
      if(CountFoundHighLow == 4){break;}
   }
   int CurrDirectUp1Down2No0 = 0;
   if(ZigZagValueComp[0][0] < ZigZagValueComp[1][0]){CurrDirectUp1Down2No0 = 1;}
   else if(ZigZagValueComp[0][0] > ZigZagValueComp[1][0]){CurrDirectUp1Down2No0 = 2;}
   Comment("\nZigZagValueComp[0][0]: ",ZigZagValueComp[0][0],"   Index: ",ZigZagValueComp[0][1],
           "\nZigZagValueComp[1][0]: ",ZigZagValueComp[1][0],"   Index: ",ZigZagValueComp[1][1],
           "\nZigZagValueComp[2][0]: ",ZigZagValueComp[2][0],"   Index: ",ZigZagValueComp[2][1],
           "\nZigZagValueComp[3][0]: ",ZigZagValueComp[3][0],"   Index: ",ZigZagValueComp[3][1],
           "\nCurrDirectUp1Down2No0: ",CurrDirectUp1Down2No0);
  }