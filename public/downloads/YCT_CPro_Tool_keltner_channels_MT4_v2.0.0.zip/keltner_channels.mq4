//+------------------------------------------------------------------+
//|                                         CPro Tool keltner_channels MT4                   |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern int period = 10;
//----
double upper[], middle[], lower[];
//+------------------------------------------------------------------+
//| Custom indicator initialization function                         |
//+------------------------------------------------------------------+
int init()
  {
   SetIndexBuffer(0, upper);
   SetIndexStyle(0, DRAW_LINE);
   SetIndexShift(0, 0);
   SetIndexDrawBegin(0, 0);
//----
   SetIndexBuffer(1, middle);
   SetIndexStyle(1, DRAW_LINE, STYLE_DASHDOT);
   SetIndexShift(1, 0);
   SetIndexDrawBegin(1, 0);
//----
   SetIndexBuffer(2, lower);
   SetIndexStyle(2, DRAW_LINE);
   SetIndexShift(2, 0);
   SetIndexDrawBegin(2, 0);
//---- name for DataWindow label
   SetIndexLabel(0, "KChanUp(" + period + ")");    
   SetIndexLabel(1, "KChanMid(" + period + ")"); 
   SetIndexLabel(2, "KChanLow(" + period + ")"); 
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| Custor indicator deinitialization function                       |
//+------------------------------------------------------------------+
int deinit()
  {
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| Custom indicator iteration function                              |
//+------------------------------------------------------------------+
int start() 
  {
   int limit;
   double avg;   
   int counted_bars = IndicatorCounted();
   if(counted_bars < 0) return(-1);
   if(counted_bars > 0) counted_bars--;
   limit = Bars - counted_bars;
   if(counted_bars==0) limit-=1+period;
//----
   for(int x = 0; x < limit; x++) 
     {
      middle[x] = iMA(NULL, 0, period, 0, MODE_SMA, PRICE_TYPICAL, x);
      avg = findAvg(period, x);
      upper[x] = middle[x] + avg;
      lower[x] = middle[x] - avg;
     }
   return(0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+  
double findAvg(int period, int shift) 
  {
   double sum = 0;
   for(int x = shift; x < (shift + period); x++) 
     {     
       sum += High[x] - Low[x];
     }
   sum = sum / period;
   return(sum);
  }  
//+------------------------------------------------------------------+