//+------------------------------------------------------------------+
//|                                         CPro Tool hpcs_first_mt4_v01_we MT4              |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
  {
      Print("Account Balance: ",AccountBalance());
      Print("Account Equity: ", AccountEquity());
      Print("Account Credit: ", AccountCredit());
      Print("Account Currency: ", AccountCurrency());
      Print("Account Company: ", AccountCompany());
      Print("Account Name: ", AccountName());
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   //Print("Inside Deinit");
   // string ls_indicatorShortName = IndicatorShortName(); 
   //ChartIndicatorDelete(NULL,0,ChartIndicatorName(NULL,0,0));
  }
//+------------------------------------------------------------------+
void OnTick()
  {
   //Print("OnTick Function");
  }