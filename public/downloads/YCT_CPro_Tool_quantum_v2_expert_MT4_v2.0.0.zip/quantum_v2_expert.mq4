//+------------------------------------------------------------------+
//|                                         CPro Tool quantum_v2_expert MT4                  |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

#include <Quantum\Quantum_CalculateTradeType_v2.mqh>

//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
enum ENUM_YESNO
  {
   NO,                                                                                             // 
   YES                                                                                             // 
  };
input string               i_string1               = "Orders / ";                            // =================================================
input double               i_staticLots            = 0.1;//static 交易量 /
input double               i_dynamicLots           = 10.0;//dynamic 交易量, % /  , %
input uint                 i_tpSize                = 0;//尺寸 of 止盈, pts /  止盈, .
input uint                 i_slShift               = 40;//偏移 from ext., pts. /   , .
input string               i_string2               = " Stochastic  Quantum";             // ======================
input uint                 i_periodK               = 100;//%k 周期 /  %k
input uint                 i_periodD               = 100;//%d 周期 /  %d
input uint                 i_slowing               = 3;//止损owing /
input double               i_highLevel             = 80.0;                                         // Bottom of overbought zone /   
input double               i_lowLevel              = 20.0;//top of over卖出ing zone /
input double               i_highCloseLevel        = 90.0;//级别 for 买入 平仓 /    买入
input double               i_lowCloseLevel         = 10.0;//级别 for 卖出 平仓 /    卖出
input uint                 i_extremumRank          = 300;                                          // Rank of extremum /  
input string               i_string3               = " ";                           // ======================
input ENUM_YESNO           i_is5Digits           = YES;//使用 5-小数位 /  5-
input ENUM_YESNO           i_isECN               = NO;//使用 ecn /  ecn
input int                  i_slippage            = 3;//止损ippage /
input string               i_openOrderSound      = "ok.wav";//sound for 开仓 订单 /
input int                  i_magicNumber         = 2353;//id of expert 订单s / id
TradeParam           g_tradeParam;                                                                 //      
GetSymbolInfo       *g_symbolInfo;                                                                 //     
CTrade              *g_trade;                                                                      //    
CalculateTradeType  *g_calcTradeType;                                                              //     
//+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
//|                                                                                                                                                              |
//+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
int OnInit()
  {
//    
   CPro_Init();  // CPro营销模块初始化
   if(!IsTunningParametersCorrect())
      return INIT_FAILED;
   if(!InitializeClasses()) //   GetSymbolInfo, Trade  CalculateTradeType
      return INIT_SUCCEEDED;
   return INIT_SUCCEEDED;
  }
//+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
//|                                                                                                                                                  |
//+---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
bool IsTunningParametersCorrect()
  {
   string name=WindowExpertName();
   bool isRussianLang=(TerminalInfoString(TERMINAL_LANGUAGE)=="Russian");
   if(i_dynamicLots<0.01 || i_dynamicLots>99.99)
     {
      Alert(name,(isRussianLang)? ":      .    0.01  99.99.  ." :
            ": value of dynamic volume must be greater than 0.00 and less than 100.00. Expert is turned off.");
      return false;
     }
   if(i_periodK<1)
     {
      Alert(name,(isRussianLang)? ":  %     0.  ." :
            ": %K period of stochastic must be greater than zero. Expert is turned off.");
      return false;
     }
   if(i_periodD<1)
     {
      Alert(name,(isRussianLang)? ":  %D     0.  ." :
            ": %D period of stochastic must be greater than zero. Expert is turned off.");
      return false;
     }
   if(i_slowing<1)
     {
      Alert(name,(isRussianLang)? ":      0.  ." :
            ": slowing of stochastic must be greater than zero. Expert is turned off.");
      return false;
     }
   if(i_extremumRank<1)
     {
      Alert(name,(isRussianLang)? ":      0.  ." :
            ": rank of extremum must be greater than zero. Expert is turned off.");
      return false;
     }
   return true;
  }
//+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
//|                                                                                                                                                            |
//+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   if(g_symbolInfo)
     {
      delete g_symbolInfo;
      g_symbolInfo="";
   CPro_Deinit();  // CPro营销模块清理
     }
   if(g_trade)
     {
      delete g_trade;
      g_trade="";
     }
   if(g_calcTradeType)
     {
      delete g_calcTradeType;
      g_calcTradeType="";
     }
  }
//+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
//|                                                                                                                                                       |
//+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
bool InitializeClasses()
  {
   uint pointMul=1;
   if(i_is5Digits==YES)
      pointMul=10;
   string name=WindowExpertName();
   bool isRussianLang=(TerminalInfoString(TERMINAL_LANGUAGE)=="Russian");
   g_symbolInfo=new GetSymbolInfo(Symbol(),i_slippage*pointMul,i_isECN==YES);
   if(g_symbolInfo=="")
     {
      Alert(name,isRussianLang? ":    GetSymbolInfo.  !" :
            ": could not to initialize the class GetSymbolInfo. Expert is turned off!");
      return false;
     }
   if(g_symbolInfo.GetPoint()==0)
     {
      Alert(name,isRussianLang? ":   -    .  !" :
            ": fatal error - the size of one point is equal to zero. Expert is turned off!");
      return false;
     }
   if(g_symbolInfo.GetTickValue()==0)
     {
      Alert(name,isRussianLang? ":   -    .  !" :
            ": fatal error - the cost of one tick is equal to zero. Expert is turned off!");
      return false;
     }
   g_trade=new CTrade(i_openOrderSound);
   if(g_trade=="")
     {
      Alert(name,isRussianLang? ":    CTrade.  !" :
            ": could not to initialize the class CTrade. Expert is turned off!");
      return false;
     }
   g_calcTradeType=new CalculateTradeType(i_staticLots,i_dynamicLots,i_tpSize*pointMul,i_slShift*pointMul,i_periodK,i_periodD,i_slowing,i_highLevel,i_lowLevel,
                                          i_highCloseLevel,i_lowCloseLevel,i_extremumRank,i_magicNumber);
   if(g_calcTradeType=="")
     {
      Alert(name,isRussianLang? ":    CalculateTradeType.  !" :
            ": could not to initialize the class CalculateTradeType. Expert is turned off!");
      return false;
     }
   return true;
  }
//+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
//|  start                                                                                                                                                                    |
//+------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
void OnTick()
  {
   if(Bars<int(i_extremumRank))
      return;
//   
   while(!IsStopped())
     {
      //     
      g_symbolInfo.RefreshInfo();
      if(g_symbolInfo.GetTickValue()==0 || g_symbolInfo.GetPoint()==0 || g_symbolInfo.GetTickSize()==0)
        {
         bool isRussianLang=(TerminalInfoString(TERMINAL_LANGUAGE)=="Russian");
         Alert(WindowExpertName(),isRussianLang? ":    -      .  ." :
               ": fatal error - the size of one point or of one tick is equal to zero. Expert is turned off!");
         ExpertRemove();
         return;
        }
      ENUM_TRADE_TYPE tradeType=g_calcTradeType.GetTradeType(g_tradeParam,g_symbolInfo.GetAllSymbolInfo(),g_trade.GetTradeErrorState());
      bool isContinue=true;
      switch(tradeType)
        {
         case TRADE_OPEN:     isContinue=g_trade.OpenOrder(g_symbolInfo,g_tradeParam);
         break;
         case TRADE_MODIFY:   isContinue=g_trade.ModifyOrder(g_symbolInfo,g_tradeParam);
         break;
         case TRADE_DESTROY:  isContinue=g_trade.DestroyOrder(g_symbolInfo,g_tradeParam);
         break;
         case TRADE_CLOSEBY:  isContinue=g_trade.CloseCounter(g_tradeParam);
         break;
         case TRADE_FATAL_ERROR:
            ExpertRemove();
            return;
        }
      if(tradeType==TRADE_NONE || !isContinue)
         break;
     }
  }
//+------------------------------------------------------------------+
