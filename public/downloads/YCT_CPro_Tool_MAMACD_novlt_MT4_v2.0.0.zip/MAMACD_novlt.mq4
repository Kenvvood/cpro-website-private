//+------------------------------------------------------------------+
//|                                         CPro Tool MAMACD_novlt MT4                       |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

//---- input parameters
extern int       MA1=85;
extern int       MA2=75;
extern int       MA3=5;
extern int fastema=15;
extern int lowema=26;
extern int sl=15;
extern int tp=15;
/*
extern int vltbars=10;//    
extern double deliter=1.5; //  
extern double stoppercent=0.50; //  1  99
extern bool timecontrol=false;
extern string starttime = "07:00:00";
extern string stoptime = "17:00:00";
*/
extern double Lots=0.1;
int startb,starts;
double stoplevel;
int init()
{
 stoplevel=MarketInfo(Symbol(),MODE_SPREAD)+MarketInfo(Symbol(),MODE_STOPLEVEL);
}
int start()
  {int buy,sell;
    buy=0;sell=0;
     for(int  i=0;i<OrdersTotal();i++)
         {
           OrderSelect(i, SELECT_BY_POS, MODE_TRADES);
           if(OrderType()==OP_BUY){buy=1;}
           if(OrderType()==OP_SELL){sell=1;}
         }  
double wma1 =iMA(NULL,0,MA1,0,MODE_LWMA,PRICE_LOW,1);
double wma2 =iMA(NULL,0,MA2,0,MODE_LWMA,PRICE_LOW,1);
double ema1 =iMA(NULL,0,MA3,0,MODE_EMA,PRICE_CLOSE,1);
   double macdcurr =iMACD(NULL,0,lowema,lowema,1,PRICE_CLOSE,MODE_MAIN,1);
   double macdlast =iMACD(NULL,0,lowema,fastema,1,PRICE_CLOSE,MODE_MAIN,2);
 if(ema1<wma1 && ema1<wma2)startb=1;
 if(ema1>wma1 && ema1>wma2)starts=1;
 if(ema1>wma1 && ema1>wma2 && startb==1 && (macdcurr>0 || macdcurr>macdlast) && buy==0)
 {
 Print("BUY Bid: "+Bid+" sl: "+sl+" TakeProfit: "+tp);
 OrderSend(Symbol(),OP_BUY,0.1,Ask,3,Ask-sl*Point,Ask+tp*Point,"FORTRADER.RU",0,0,Red);
 startb=0;
 }
  if(ema1<wma1 && ema1<wma2 && starts==1 && (macdcurr<0 || macdcurr<macdlast)&& sell==0)
 {
  Print("SELL Bid: "+Bid+" sl: "+sl+" TakeProfit: "+tp);
 OrderSend(Symbol(),OP_SELL,0.1,Bid,3,Bid+sl*Point,Bid-tp*Point,"FORTRADER.RU",0,0,Red);
 starts=0;
 }
   return(0);
  }