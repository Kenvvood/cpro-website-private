//+------------------------------------------------------------------+
//|                                         CPro Tool 21hour MT4                             |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_watermark.Deinit();
}

extern double Lots = 0.1;
extern int ChasStart = 10;
extern int ChasStop  = 22;
extern int Step      = 15;
extern int TP        = 200;
int prevtime;
//+------------------------------------------------------------------+
//| expert initialization function                                   |
//+------------------------------------------------------------------+
int init()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert deinitialization function                                 |
//+------------------------------------------------------------------+
int deinit()
  {
//----
//----
   return(0);
  }
//+------------------------------------------------------------------+
//| expert start function                                            |
//+------------------------------------------------------------------+
int start()
  {
//----
   int OrderCountOtl=0;
      int i=0; 
   int total = OrdersTotal();   
   for(i = 0; i <= total; i++) 
     {
       OrderSelect(i, SELECT_BY_POS, MODE_TRADES);
       if(OrderMagicNumber() == 12321) 
         {
         if (OrderType()>1) OrderCountOtl++;
         }
      }
          if (OrderCountOtl==1) 
     {
   for(i = 0; i <= total; i++) 
     {
       OrderSelect(i, SELECT_BY_POS, MODE_TRADES);
       if(OrderMagicNumber() == 12321) 
         {
         if (OrderType()>1) OrderDelete(OrderTicket());
         }
      }
     } 
   if(Time[0] == prevtime) 
       return(0);
   prevtime = Time[0];
   if(!IsTradeAllowed()) 
     {
       prevtime = Time[1];
       return(0);
     }
if (TimeHour(TimeCurrent())==ChasStart && TimeMinute(TimeCurrent())==0)
  {
  OrderSend(Symbol(),OP_BUYSTOP,Lots,Ask+Step*Point,3,0,Ask+(Step+TP)*Point,"",12321,0,Green);
  OrderSend(Symbol(),OP_SELLSTOP,Lots,Bid-Step*Point,3,0,Bid-(Step+TP)*Point,"",12321,0,Red);
  }
if (TimeHour(TimeCurrent())==ChasStop && TimeMinute(TimeCurrent())==0)
  {
   i=0;  
  total = OrdersTotal();   
   for(i = 0; i <= total; i++) 
     {
       OrderSelect(i, SELECT_BY_POS, MODE_TRADES);
       if(OrderMagicNumber() == 12321) 
         {
          if (OrderType()==OP_BUY)OrderClose(OrderTicket(),OrderLots(),Bid,3,Green);
          if (OrderType()==OP_SELL)OrderClose(OrderTicket(),OrderLots(),Ask,3,Green);
          if (OrderType()>1)OrderDelete(OrderTicket());
         }
      }  
  }
//----
   return(0);
  }
//+------------------------------------------------------------------+