//+------------------------------------------------------------------+
//|                                         CPro Indicator 9nix6_Indicators_MedianRenko_WeisWaves MT5 |
//|                         城诺科技 · CPro Trading           |
//|                         技术支持微信: Lookee333                       |
//+------------------------------------------------------------------+

#property copyright   "城诺科技"
#property link      "https://www.cprotrading.com"
#property version   "1.00"

//+------------------------------------------------------------------+
//|                         CPro Trading 营销模块                       |
//+------------------------------------------------------------------+
#include <CPro\CPro.mqh>

// 全局营销组件实例
CProDialog      m_cpro_dialog;
CProPanel       m_cpro_panel;
CProWatermark   m_cpro_watermark;

//+------------------------------------------------------------------+
//| CPro营销模块初始化                                                 |
//+------------------------------------------------------------------+
void CPro_Init() {
    // 启动弹窗（一次性确认）
    m_cpro_dialog.Init();
    m_cpro_dialog.ShowStartupDialog();

    // 初始化统计面板
    m_cpro_panel.Init();

    // 初始化水印
    m_cpro_watermark.Init();
    m_cpro_watermark.DrawWatermark();

    Print("[CPro] 营销模块初始化完成");
}

//+------------------------------------------------------------------+
//| CPro营销模块清理                                                  |
//+------------------------------------------------------------------+
void CPro_Deinit() {
    m_cpro_dialog.Deinit();
    m_cpro_panel.Deinit();
    m_cpro_watermark.Deinit();
}


#include <AZ-INVEST/CustomBarConfig.mqh>

//--- input parameters
input int      ExtDeviation=5;
//--- indicator buffers
double         deviation;           // deviation in points
//+------------------------------------------------------------------+
//| Indicator Settings                                               |
//+------------------------------------------------------------------+
//+------------------------------------------------------------------+
//| Inputs from User Interface                                       |
//+------------------------------------------------------------------+
input ENUM_APPLIED_VOLUME inpVolumeType = VOLUME_TICK;//交易量 类型 to 使用 on waves
//
//
//+------------------------------------------------------------------+
//| Global Variables                                                 |
//+------------------------------------------------------------------+
double bufferWW[];
double bufferColors[];
//--- custom chart indicator handle
int customChartIndicator;
//+------------------------------------------------------------------+
//| OnInit()                                                         |
//+------------------------------------------------------------------+
int OnInit() {
   CPro_Init();  // CPro营销模块初始化
    SetIndexBuffer( 0, bufferWW, INDICATOR_DATA );
    SetIndexBuffer( 1, bufferColors, INDICATOR_COLOR_INDEX );
    IndicatorSetString( INDICATOR_SHORTNAME, "WeisWaves" );
   return(INIT_SUCCEEDED);
}
//+------------------------------------------------------------------+
//| OnDeinit()                                                       |
//+------------------------------------------------------------------+
void OnDeinit(const int reason) {
   CPro_Deinit();  // CPro营销模块清理
}
//+------------------------------------------------------------------+
//| OnCalculate()                                                    |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[]) {
   return(rates_total);
}